BEGIN;
ALTER TABLE game_transactions DROP CONSTRAINT ck_game_transactions_event_type_valid;
ALTER TABLE game_transactions ADD CONSTRAINT ck_game_transactions_event_type_valid CHECK (event_type IN (
 'create_farm','buy_seed','plant','harvest','sell','upgrade','buy_item','use_item','water','clear','steal','stolen','bind_group',
 'steal_blocked','defended','defense_place','build','buy_animal','feed_animal','collect_animal','craft_start','craft_collect',
 'quest_reward','competition_reward','admin_adjust','ranking_reward','transfer_group','gamble','explore','build_machine','exchange','make_seed',
 'fishing_buy','fish_sell','release_animal','boss_donate','boss_reward','rename_farm','checkin_reward','achievement_reward',
 'ruins_donate','ruins_guardian','rumor_treasure','seed_lab','seed_share','aid_gift','aid_water',
 'reputation_donate','auction_bid','auction_refund','auction_win'));
ALTER TABLE farms ADD COLUMN badge VARCHAR(20), ADD COLUMN theme VARCHAR(20),
 ADD COLUMN material_bag_level INTEGER NOT NULL DEFAULT 0, ADD COLUMN reputation BIGINT NOT NULL DEFAULT 0;
ALTER TABLE farms ADD CONSTRAINT ck_farms_material_bag_level_range CHECK (material_bag_level BETWEEN 0 AND 10);
ALTER TABLE farms ADD CONSTRAINT ck_farms_reputation_non_negative CHECK (reputation >= 0);
CREATE TABLE farm_cosmetics (
 farm_id BIGINT NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
 kind VARCHAR(10) NOT NULL, code VARCHAR(30) NOT NULL, source VARCHAR(20) NOT NULL,
 obtained_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 CONSTRAINT pk_farm_cosmetics PRIMARY KEY (farm_id, kind, code),
 CONSTRAINT ck_farm_cosmetics_kind_valid CHECK (kind IN ('badge','theme','hat','color')));
ALTER TABLE farm_pets ADD COLUMN hat VARCHAR(30), ADD COLUMN color VARCHAR(30);
CREATE TABLE auctions (
 id BIGSERIAL PRIMARY KEY, week_start DATE NOT NULL, item_kind VARCHAR(10) NOT NULL, item_code VARCHAR(30) NOT NULL,
 start_price BIGINT NOT NULL, min_increment_pct INTEGER NOT NULL, starts_at TIMESTAMPTZ NOT NULL, ends_at TIMESTAMPTZ NOT NULL,
 status VARCHAR(10) NOT NULL DEFAULT 'open', top_bid BIGINT, top_farm_id BIGINT REFERENCES farms(id) ON DELETE SET NULL,
 settled_at TIMESTAMPTZ, created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 CONSTRAINT uq_auctions_week_start UNIQUE (week_start),
 CONSTRAINT ck_auctions_status_valid CHECK (status IN ('open','settled','unsold')),
 CONSTRAINT ck_auctions_item_kind_valid CHECK (item_kind IN ('decor','badge','title')),
 CONSTRAINT ck_auctions_start_price_positive CHECK (start_price > 0),
 CONSTRAINT ck_auctions_min_increment_range CHECK (min_increment_pct BETWEEN 1 AND 100),
 CONSTRAINT ck_auctions_ends_after_starts CHECK (ends_at > starts_at));
CREATE INDEX ix_auctions_status_ends_at ON auctions (status, ends_at);
CREATE TABLE auction_bids (
 id BIGSERIAL PRIMARY KEY, auction_id BIGINT NOT NULL REFERENCES auctions(id) ON DELETE CASCADE,
 farm_id BIGINT NOT NULL REFERENCES farms(id) ON DELETE CASCADE, amount BIGINT NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), refunded_at TIMESTAMPTZ,
 CONSTRAINT ck_auction_bids_amount_positive CHECK (amount > 0));
CREATE INDEX ix_auction_bids_auction_amount ON auction_bids (auction_id, amount);
UPDATE alembic_version SET version_num = '0046';
COMMIT;
