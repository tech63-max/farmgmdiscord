﻿# 移植腳本：把 files\ 底下的檔案複製到目標專案，覆蓋前先把原檔備份。
# 用法：powershell -ExecutionPolicy Bypass -File .\apply.ps1 -Target "D:\path\to\farmgo-main"
# 先預覽不寫入：加上 -DryRun
param(
    [Parameter(Mandatory = $true)][string]$Target,
    [switch]$DryRun
)
$ErrorActionPreference = 'Stop'
$pkg = Join-Path $PSScriptRoot 'files'
if (-not (Test-Path (Join-Path $Target 'go.mod'))) { throw "找不到 $Target\go.mod，請確認目標是專案根目錄。" }

$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$backup = Join-Path $Target "_移植備份_$stamp"
$new = 0; $over = 0
Get-ChildItem -Path $pkg -Recurse -File | ForEach-Object {
    $rel = $_.FullName.Substring($pkg.Length + 1)
    $dst = Join-Path $Target $rel
    if (Test-Path $dst) {
        $over++
        Write-Host "覆蓋  $rel"
        if (-not $DryRun) {
            $bk = Join-Path $backup $rel
            New-Item -ItemType Directory -Force (Split-Path $bk) | Out-Null
            Copy-Item $dst $bk
        }
    } else {
        $new++
        Write-Host "新增  $rel"
    }
    if (-not $DryRun) {
        New-Item -ItemType Directory -Force (Split-Path $dst) | Out-Null
        Copy-Item $_.FullName $dst -Force
    }
}
Write-Host ""
Write-Host "新增 $new 個、覆蓋 $over 個。"
if ($DryRun) { Write-Host "（預覽模式，沒有寫入）" }
elseif ($over -gt 0) { Write-Host "被覆蓋的原檔備份在：$backup" }
