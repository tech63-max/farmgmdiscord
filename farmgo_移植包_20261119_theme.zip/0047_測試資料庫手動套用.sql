-- 只能用在本機測試資料庫（名稱以 _test 結尾）；正式資料庫請用 Alembic 升級。
-- 內容與 migrations/versions/0047_player_language.py 相同。要先套用 0046。
BEGIN;
ALTER TABLE players ADD COLUMN language VARCHAR(10);
ALTER TABLE players ADD CONSTRAINT ck_players_language_valid CHECK (language IS NULL OR language IN ('zh-TW', 'en'));
UPDATE alembic_version SET version_num = '0047';
COMMIT;
