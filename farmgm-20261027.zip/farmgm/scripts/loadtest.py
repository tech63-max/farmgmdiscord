"""負載測試：在測試資料庫模擬 500 位玩家與大量歷史交易，量測常用操作、排行榜、監控快照與並行操作的延遲。

只能對 TEST_DATABASE_URL（資料庫名稱以 _test 結尾）執行，會清空其中的遊戲資料。
用法：.venv/Scripts/python.exe scripts/loadtest.py [歷史交易筆數，預設 1000000]
"""

import statistics
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from pydantic_settings import BaseSettings, SettingsConfigDict  # noqa: E402
from sqlalchemy import make_url, text  # noqa: E402

from app.db.session import make_engine, make_session_factory  # noqa: E402
from app.services.admin_service import AdminService  # noqa: E402
from app.services.monitor_service import MonitorService  # noqa: E402

TX_ROWS = int(sys.argv[1]) if len(sys.argv) > 1 else 1_000_000


class S(BaseSettings):
    model_config = SettingsConfigDict(env_file=ROOT / ".env", extra="ignore")
    test_database_url: str


url = S().test_database_url
assert make_url(url).database.endswith("_test"), "只能用在測試資料庫"
engine = make_engine(url)  # 與正式程式相同的預設連線池（5 + overflow 10）
factory = make_session_factory(engine)
svc = AdminService(factory)
mon = MonitorService(factory)


def timed(label, fn, n=5):
    xs = []
    for _ in range(n):
        t = time.perf_counter()
        fn()
        xs.append((time.perf_counter() - t) * 1000)
    print(f"{label:<36} 中位數 {statistics.median(xs):7.1f} ms   最大 {max(xs):7.1f} ms")


with engine.begin() as c:
    c.execute(text(
        "TRUNCATE ranking_awards, ranking_settlements, ranking_reward_rules, game_events, competition_awards, "
        "competition_results, competition_contributions, competitions, quest_claims, quest_contributions, quests, "
        "admin_actions, craft_orders, farm_animals, farm_buildings, farm_defenses, steal_records, group_members, "
        "groups, farm_effects, farm_tools, game_transactions, inventory_items, farm_plots, farms, players "
        "RESTART IDENTITY CASCADE"
    ))
    c.execute(text("UPDATE crop_types SET active = true, grow_seconds = 60"))

t0 = time.perf_counter()
groups = [svc.create_group(f"群組{i:02d}").id for i in range(20)]
pids = []
for i in range(500):
    pid = svc.create_player(f"玩家{i:03d}").id
    svc.create_farm(pid, home_group_id=groups[i % 20])
    pids.append(pid)
print(f"建立 500 位玩家與農場：{time.perf_counter() - t0:.1f} 秒")

# 大量歷史交易（約數個月的遊玩量），平均分布在過去 90 天；含販售與其他事件
t0 = time.perf_counter()
with engine.begin() as c:
    c.execute(text("UPDATE farms SET gold = 100000"))
    c.execute(text(f"""
        INSERT INTO game_transactions (farm_id, event_type, item_code, quantity, gold_delta, description, created_at)
        SELECT 1 + (g % 500),
               (ARRAY['sell','buy_seed','plant','water','harvest'])[1 + (g % 5)],
               (ARRAY['wheat','carrot','tomato','strawberry','egg'])[1 + (g % 7 % 5)],
               1 + (g % 5),
               CASE WHEN g % 5 = 0 THEN 30 WHEN g % 5 = 1 THEN -20 ELSE 0 END,
               '壓力測試資料',
               now() - (random() * interval '90 days')
        FROM generate_series(1, {TX_ROWS}) AS g
    """))
    c.execute(text("ANALYZE"))
print(f"寫入 {TX_ROWS:,} 筆歷史交易：{time.perf_counter() - t0:.1f} 秒")

print("\n--- 單一玩家操作（一筆指令） ---")
p = pids[0]
timed("購買種子 buy", lambda: svc.buy_seeds(p, "wheat", 1))
svc.buy_seeds(p, "wheat", 10)
plot_no = iter(range(1, 5))
timed("種植 plant（含活動、品質判定）", lambda: svc.plant_crop(p, next(plot_no), "wheat"), n=4)
plot_no = iter(range(1, 5))
timed("澆水 water", lambda: svc.water_crop(p, next(plot_no)), n=4)
timed("查看農場 farm status", lambda: svc.get_farm_status(p))
timed("查看背包 backpack", lambda: svc.get_backpack(p))

print("\n--- 排行榜（Discord 指令也會用到） ---")
timed("個人總排行 金幣（全部）", lambda: svc.leaderboard("money"))
timed("個人總排行 農產品販售（全部）", lambda: svc.leaderboard("sales"))
timed("個人總排行 商品總販售（全部）", lambda: svc.leaderboard("goods"))
timed("群組總排行 販售（全部）", lambda: svc.group_leaderboard("sales"))
timed("群組總排行 金幣（本週）", lambda: svc.group_leaderboard("money", "week"))

print("\n--- 監控網站 ---")
timed("WebSocket 快照（每 3 秒／每位開著網頁的人）", mon.snapshot)
timed("排行榜 API（群組總排行 本月）", lambda: mon.leaderboard("goods", None, 100, scope="groups", period="month"))

print("\n--- 並行：500 位玩家中 100 人同時下指令（每人 5 個指令） ---")


def player_session(pid):
    lat = []
    for action in range(5):
        t = time.perf_counter()
        if action == 0:
            svc.buy_seeds(pid, "carrot", 1)
        elif action == 1:
            svc.get_farm_status(pid)
        elif action == 2:
            svc.plant_crop(pid, 1, "carrot")
        elif action == 3:
            svc.water_crop(pid, 1)
        else:
            svc.get_backpack(pid)
        lat.append((time.perf_counter() - t) * 1000)
    return lat


for workers in (15, 50):
    t0 = time.perf_counter()
    with ThreadPoolExecutor(max_workers=workers) as ex:
        results = list(ex.map(player_session, pids[100:200] if workers == 15 else pids[200:300]))
    lat = sorted(x for r in results for x in r)
    elapsed = time.perf_counter() - t0
    print(f"執行緒 {workers:>2}：500 個指令共 {elapsed:.1f} 秒（{500 / elapsed:.0f} 指令/秒），"
          f"延遲中位數 {statistics.median(lat):.0f} ms、95% {lat[int(len(lat) * 0.95)]:.0f} ms、最大 {lat[-1]:.0f} ms")

with engine.begin() as c:
    size = c.execute(text("select pg_size_pretty(pg_total_relation_size('game_transactions'))")).scalar()
print(f"\ngame_transactions 大小：{size}")
engine.dispose()
