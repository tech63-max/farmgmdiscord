# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

農場經營遊戲：CMD 介面 + PostgreSQL（唯一資料來源）+ FastAPI 即時監控／管理網站。程式註解、訊息與文件皆為繁體中文，新程式碼請沿用。
`discordbot.txt` 是下一階段（改造成 Discord Bot）的需求文件，尚未實作。

## 常用指令（Windows，虛擬環境在 `.venv`）

```powershell
docker compose up -d                      # PostgreSQL 16，127.0.0.1:5434；建立 farmgm 與 farmgm_test
.\.venv\Scripts\python.exe -m alembic upgrade head
.\.venv\Scripts\python.exe -m app.cli     # CMD 遊戲
.\.venv\Scripts\python.exe -m app.main    # 監控網站 http://127.0.0.1:8000

.\.venv\Scripts\python.exe -m pytest                                   # 全部測試（pyproject 預設 -q，看不到總結時加 -o addopts=""）
.\.venv\Scripts\python.exe -m pytest tests/test_admin.py::test_set_gold_and_level
.\.venv\Scripts\python.exe -m ruff check app tests migrations          # line-length 120；不要對整個專案跑 ruff format
node --check app/web/app.js
node --test tests/web/connection.test.js                               # 指定檔案，不要傳目錄
.\.venv\Scripts\python.exe -m alembic check                            # 確認 Model 與 Migration 一致
.\.venv\Scripts\python.exe -m app.hash_password                        # 產生 ADMIN_PASSWORD_HASH
```

- 設定在 `.env`（gitignored）：`DATABASE_URL`、`TEST_DATABASE_URL`（資料庫名稱必須以 `_test` 結尾，測試會清空遊戲資料表）、`ALLOWED_HOSTS`、`ADMIN_USERNAME`、`ADMIN_PASSWORD_HASH`（scrypt 雜湊，不存明文）、`RANKING_SETTLE_INTERVAL_SECONDS`。環境變數優先於 `.env`。
- 程式啟動時只檢查 DB 連線與 Migration 是否最新，**不會**自動建表。改資料結構一律新增 Alembic Migration（`migrations/versions/000N_*.py`，Migration 內寫死常數，不引用會變動的 app 常數），並在測試資料庫做 upgrade → downgrade -1 → upgrade → `alembic check`。
- 修改開發資料庫前先 `pg_dump` 備份（容器 `farmgm-postgres-1`）；不要執行 `docker compose down -v`。

## 架構

分層：`game/`（純規則，無 DB）→ `repositories/`（SQLAlchemy 查詢）→ `services/`（交易邊界）→ `cli/`、`api/` + `web/`（介面）。

- **服務繼承鏈**：`GameService` → `RanchService` → `SocialService` → `CommunityService` → `RankingService` → `AdminService`。CLI 使用 `RankingService`；網站 `app.state.social_service` 是 `AdminService`；`MonitorService` 獨立且所有查詢在 `SET TRANSACTION READ ONLY` 中執行。服務方法只收基本型別，不依賴 CMD／FastAPI，未來 Discord Bot 直接呼叫（玩家以 `external_platform`/`external_user_id` 對應）。
- **交易與併發**：每個公開服務方法 = 一筆 DB 交易（`self._transaction()`）；改變資產前先以 `farms_repo.get_by_player(..., for_update=True)`（`_locked_farm`）鎖農場列。重複發獎／重複偷菜等由資料庫 UNIQUE／CHECK 約束做最後防線。遊戲規則錯誤皆為 `app.game.errors.GameError` 子類別（訊息可直接給玩家；API 轉成 400／404）。
- **交易紀錄不變式**：所有資產變動都經 `GameService._record()` 寫入 `game_transactions`（含建立農場的初始金幣），因此全部 `gold_delta` 加總 = 全服金幣；管理員調整用 `admin_adjust`、排名獎勵用 `ranking_reward`。新增事件類型需同時改 `models.EVENT_TYPES`、`rules.EventType`／`EVENT_TYPE_LABELS`、Migration 的 CHECK 約束與 `web/app.js` 的 `EVENT_LABELS`。
- **任務／競賽計分**：`_record()` 在同一交易中呼叫 `services/activity.on_event`；只有 `context_group_id`（操作所在群組，由 `in_group_context()` 設定）等於農場 `home_group_id`（建立後由 DB 觸發器鎖定）時才計分。
- **時間**：一律注入 `Clock`（測試用 `ManualClock`，起點 2026-01-01 00:00 UTC = 台灣週四 08:00）；DB 存 UTC `timestamptz`，顯示與期間計算用台灣時間（`clock.TAIPEI_TZ`）。土地狀態依時間即時計算（`rules.plot_state`），不靠排程。
- **資料目錄**：作物（含珍稀變種 `variant_code`）與動物／動物產品在 DB（`crop_types`、`animal_types`，有 `active` 停用旗標，代碼不可改、被使用過只能停用）；道具、防守設施、建築、加工配方、加工品在 `game/balance.py`。顯示名稱與合法物品代碼用 `repositories/catalog.py`，不要再寫死作物／動物清單。
- **品質／突變與限時活動**：公式只在 `game/genetics.py`（設定版本存在 `crop_genetics_settings`）與 `game/events.py`（`game_events`，加成在播種／澆水／販售當下決定並記在 `applied_events`）。
- **排名獎勵**：`game/ranking.py`（期間、驗證）+ `services/ranking_service.py`；網站背景任務（`main._auto_settle`，注入 `session_factory` 的測試中不啟動）與 CLI `leaderboard groups|rewards` 會結算到期期間，`(rule_id, period_start)` 唯一保證只發一次。
- **網站安全**：`/api/monitor/*` 唯讀；寫入只在 `/api/admin/*`，需管理員登入（HttpOnly cookie，`app/auth.py`，記憶體 session）、`X-Farmgm-Admin: 1` 標頭與同源 Origin；`TrustedHostMiddleware` 只接受本機 Host。前端 `app.js` 一律用 `el()`／`textContent` 建 DOM（不使用 innerHTML）。WebSocket 每數秒推快照；分頁資料只更新目前分頁，且使用者操作中暫停（`userBusy()`），避免表單被重建。

## 測試慣例

`tests/conftest.py` 每個測試前 TRUNCATE `GAME_TABLES`、刪除測試新增的作物／動物種類並重設初始值、把作物生長時間設為短時間（60/180/300/600 秒）、品質突變設為 100% 普通無突變。新增資料表時記得加入 `GAME_TABLES`。fixture：`service`（`RankingService`）、`clock`、`player_id`、`home_group`、`make_farmer()`、`grow()`；管理功能測試用 `AdminService(session_factory, clock)`。API 測試以 `create_app(session_factory, clock=..., allowed_hosts=["testserver"], admin_auth=AdminAuth(...))` 建立。
