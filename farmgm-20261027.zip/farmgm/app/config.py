"""集中讀取環境設定（.env 或系統環境變數）。"""

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    database_url: str = Field(..., description="SQLAlchemy URL，例如 postgresql+psycopg://...")
    app_host: str = "127.0.0.1"
    app_port: int = Field(8000, ge=1, le=65535)
    monitor_refresh_seconds: float = Field(3.0, ge=1.0, le=60.0)
    # 允許的 Host 標頭（逗號分隔），防止 DNS rebinding；僅本機使用時不需修改
    allowed_hosts: str = "127.0.0.1,localhost"
    # 網頁管理功能的管理員帳號；密碼只存雜湊（python -m app.hash_password 產生）。未設定時管理功能停用
    admin_username: str | None = None
    admin_password_hash: str | None = None
    admin_session_hours: float = Field(8.0, gt=0, le=72)
    # 網頁服務背景檢查並結算到期排名獎勵的間隔（秒）
    ranking_settle_interval_seconds: float = Field(60.0, ge=10, le=3600)

    @property
    def allowed_host_list(self) -> list[str]:
        return [h.strip() for h in self.allowed_hosts.split(",") if h.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
