from sqlalchemy import func, select, update
from sqlalchemy.dialects.postgresql import insert
from sqlalchemy.orm import Session

from app.db.models import InventoryItem


def list_items(session: Session, farm_id: int) -> list[InventoryItem]:
    stmt = (
        select(InventoryItem)
        .where(InventoryItem.farm_id == farm_id, InventoryItem.quantity > 0)
        .order_by(InventoryItem.item_code, InventoryItem.quality, InventoryItem.mutation)
    )
    return list(session.scalars(stmt))


def _stack(farm_id: int, item_code: str, quality: str, mutation: str):
    return (
        InventoryItem.farm_id == farm_id,
        InventoryItem.item_code == item_code,
        InventoryItem.quality == quality,
        InventoryItem.mutation == mutation,
    )


def get_quantity(
    session: Session, farm_id: int, item_code: str, quality: str = "normal", mutation: str = "none"
) -> int:
    """同一物品不同品質／突變是不同的庫存；未指定時為普通、無突變。"""
    stmt = select(InventoryItem.quantity).where(*_stack(farm_id, item_code, quality, mutation))
    return session.scalar(stmt) or 0


def total_quantity(session: Session, farm_id: int) -> int:
    stmt = select(func.coalesce(func.sum(InventoryItem.quantity), 0)).where(
        InventoryItem.farm_id == farm_id
    )
    return int(session.scalar(stmt) or 0)


def add(
    session: Session, farm_id: int, item_code: str, quantity: int, quality: str = "normal", mutation: str = "none"
) -> None:
    # 以唯一限制 (farm_id, item_code, quality, mutation) 做 upsert，避免重複建立庫存紀錄
    stmt = insert(InventoryItem).values(
        farm_id=farm_id, item_code=item_code, quality=quality, mutation=mutation, quantity=quantity
    )
    stmt = stmt.on_conflict_do_update(
        constraint="uq_inventory_items_farm_item",
        set_={"quantity": InventoryItem.quantity + quantity, "updated_at": func.now()},
    )
    session.execute(stmt)


def remove(
    session: Session, farm_id: int, item_code: str, quantity: int, quality: str = "normal", mutation: str = "none"
) -> bool:
    """扣除指定品質／突變的庫存；數量不足時不做任何修改並回傳 False。"""
    stmt = (
        update(InventoryItem)
        .where(*_stack(farm_id, item_code, quality, mutation), InventoryItem.quantity >= quantity)
        .values(quantity=InventoryItem.quantity - quantity, updated_at=func.now())
    )
    return session.execute(stmt).rowcount == 1
