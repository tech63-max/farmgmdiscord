// Magic Forest Terrarium 魔法森林生態瓶
// 板子：Waveshare ESP32-S3-LCD-1.54 (腳位見 PINOUT.md / src/Config.h)
// 編譯：arduino-cli compile --fqbn "esp32:esp32:esp32s3:CDCOnBoot=cdc,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB" .
#include <Arduino.h>
#include <Arduino_GFX_Library.h>
#include <Preferences.h>
#include <WiFi.h>
#include <esp_heap_caps.h>

#include "src/Config.h"
#include "src/CreatureManager.h"
#include "src/Ecosystem.h"
#include "src/EventManager.h"
#include "src/EventMemory.h"
#include "src/ForestRenderer.h"
#include "src/Gfx.h"
#include "src/Journal.h"
#include "src/Particles.h"
#include "src/PlantManager.h"
#include "src/PlayerInteraction.h"
#include "src/SaveManager.h"
#include "src/SdStorage.h"
#include "src/SeasonManager.h"
#include "src/StructureManager.h"
#include "src/Families.h"
#include "src/ForestHistory.h"
#include "src/Ruins.h"
#include "src/Underground.h"
#include "src/Village.h"
#include "src/Evolution.h"
#include <nvs.h>
#include "src/VisitorManager.h"
#include "src/TimeManager.h"
#include "src/Util.h"
#include "src/WeatherManager.h"
#include "src/net/WebPanel.h"
#include "src/net/WifiConfig.h"
#include "src/net/WifiManager.h"
#include "src/PosAudit.h"

util::Rng util::rng;

namespace {
Arduino_ESP32SPI bus(cfg::PIN_LCD_DC, cfg::PIN_LCD_CS, cfg::PIN_LCD_SCK, cfg::PIN_LCD_MOSI, GFX_NOT_DEFINED);
Arduino_ST7789 panel(&bus, cfg::PIN_LCD_RST, cfg::LCD_ROTATION, true /*IPS*/, cfg::W, cfg::H);

WifiManager wifi;
WebPanel web;
bool wifiSavePending = false;
char pendingSsid[33], pendingPass[65];

uint32_t lastFrame = 0, lastSec = 0, lastPop = 0, lastPlant = 0, lastSave = 0, lastStats = 0;
uint32_t lastEcoEpoch = 0, lastPlantEpoch = 0;
uint32_t frames = 0, frameMsSum = 0, frameMsMax = 0;
float blLevel = cfg::BL_DAY_PCT;
bool ntpAnnounced = false;
char serialLine[96];
uint8_t serialLen = 0;

void setBacklight(float pct) { ledcWrite(cfg::PIN_LCD_BL, (uint32_t)(1023 * pct / 100)); }

// 每次從 240x240 畫面複製 16 列 → 疊上文字 UI → 送到 LCD (文字不會留在畫面緩衝裡)
constexpr int STRIP_H = 16;
uint16_t strip[cfg::W * STRIP_H];

void pushFrame(uint32_t ms) {
  for (int y0 = 0; y0 < cfg::H; y0 += STRIP_H) {
    memcpy(strip, gfx::fb + y0 * gfx::FW, sizeof(strip));
    render::drawUiStrip(strip, y0, STRIP_H, ms);
    panel.draw16bitRGBBitmap(0, y0, strip, cfg::W, STRIP_H);  // 非 const 指標 (PINOUT 坑 #2)
  }
}

// 顯示/隱藏講解 (右上角時鐘、底部事件提示)，設定存進 NVS
void setUiHidden(bool hide, uint32_t ms) {
  render::setUiHidden(hide);
  render::closeOverlays();
  Preferences p;
  if (p.begin("forest", false)) { p.putBool("uihide", hide); p.end(); }
  render::notice(hide ? "講解已隱藏" : "講解已顯示", ms);
}

void powerOff() {
  save::write();
  render::notice("森林進入休眠…", millis());
  digitalWrite(cfg::PIN_POWER_LATCH, LOW);  // 電池供電時斷電
  delay(300);                               // 只在關機時使用
  // 還活著 = USB 供電
  render::notice("USB 供電中，無法關機", millis());
}

// 第二階段的長期模擬 (森林時間)：和植物一起更新，關機補算時也一起推進
void worldTick(float dtSec) {
  const float dtH = dtSec / 3600.0f;
  structure::tick(dtSec);
  eco::worldTick(dtH);
  under::tick(dtH);
  ruins::tick(dtH);
  history::tick(dtH);
  families::tick(dtH);
  village::tick(dtH);
  evo::tick(dtH);
}

void plantTick() {
  const uint32_t now = timem::now();
  if (now < lastPlantEpoch) { lastPlantEpoch = now; return; }
  uint32_t dt = now - lastPlantEpoch;
  lastPlantEpoch = now;
  if (dt > 1800) {
    // 關機期間或剛校時：分段補算植物生長 (上限 3 天)
    if (dt > cfg::CATCHUP_MAX_S) dt = cfg::CATCHUP_MAX_S;
    journal::add(journal::J_RESUME, 0xFF, true);
    Serial.printf("[Eco] catch-up %lu s\n", (unsigned long)dt);
    while (dt > 0) {
      uint32_t step = dt > 600 ? 600 : dt;
      plant::tick(step);
      worldTick(step);
      dt -= step;
    }
    return;
  }
  plant::tick(dt);
  worldTick(dt);
}

void statusText(char* buf, size_t cap) {
  const weather::Now& w = weather::current();
  char hm[24];
  timem::format(timem::now(), hm, sizeof(hm), true);
  snprintf(buf, cap,
           "時間 %s%s\n天氣 %s %.1f°C 濕度 %.0f%% (%s)\n季節 %s\n生物 %d 隻活動中、螢火蟲 %d\n盛開的花 %d、成熟蘑菇 %d\n鳥巢 %.0f%%",
           hm, timem::synced() ? "" : " (推估)", weather::skyName(w.sky), w.tempC, w.humidity, w.live ? "真實天氣" : "本地模擬",
           season::name(season::dominant()), creature::activeCount(), creature::count(creature::C_FIREFLY),
           plant::bloomingFlowers(), plant::matureMushrooms(), creature::nestProgress() * 100);
}

void updateNetStatus() {
  const char* s = "";
  switch (wifi.state()) {
    case WifiState::Connected: s = "Wi-Fi 已連線"; break;
    case WifiState::Connecting: s = "Wi-Fi 連線中"; break;
    case WifiState::Disconnected: s = "Wi-Fi 斷線"; break;
    case WifiState::NoCredentials: s = "未設定 Wi-Fi"; break;
  }
  render::setNetStatus(s);
}

void handleNet(uint32_t ms) {
  if (wifiSavePending) {
    wifiSavePending = false;
    wifi.setCredentials(pendingSsid, pendingPass, ms);
    memset(pendingPass, 0, sizeof(pendingPass));
  }
  wifi.update(ms);
  web.setCaptive(wifi.apActive());
  web.update();
  if (wifi.justConnected()) {
    Serial.printf("[WiFi] connected, ip %s\n", WiFi.localIP().toString().c_str());
    timem::onNetworkUp();
    weather::forceRefresh();
    render::notice("Wi-Fi 已連線", ms);
  }
  if (wifi.apJustStarted()) render::setWifiPanel(true, wifi.apSsid(), wifi.apPass());
  if (!wifi.apActive()) render::setWifiPanel(false, "", "");
  if (!ntpAnnounced && timem::synced()) {
    ntpAnnounced = true;
    journal::add(journal::J_SYNC, 0xFF, false);
  }
  updateNetStatus();
}

// ---- 序列埠測試指令 ----
void runCommand(char* line, uint32_t ms) {
  char* cmd = strtok(line, " ");
  char* arg = strtok(nullptr, " ");
  char* arg2 = strtok(nullptr, " ");
  if (!cmd) return;
  if (!strcmp(cmd, "help")) {
    Serial.println("status | ev <name|list> | weather <clear|cloud|over|fog|drizzle|rain|storm|snow|live> | speed <x> | skip <min>");
    Serial.println("bless | breeze | pulse | save | reset | wifi [ssid pass] | ap | journal | shot | info | log | prof | story <name> | build <type> [site] | decay <hours> | world | history | set <k> <v> | erode | nvs");
  } else if (!strcmp(cmd, "status")) {
    char buf[400];
    statusText(buf, sizeof(buf));
    Serial.println(buf);
    Serial.printf("heap int %u (min %u) psram %u, frame avg %lu ms max %lu ms, scale x%.0f\n",
                  (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL), (unsigned)heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL),
                  (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM), (unsigned long)(frames ? frameMsSum / frames : 0),
                  (unsigned long)frameMsMax, timem::timeScale());
    for (int i = 0; i < plant::SLOT_N; i++) {
      const plant::Plant& p = plant::get(i);
      if (p.species) Serial.printf("  slot %2d %-6s stage %u prog %u\n", i, plant::name((plant::Species)p.species), p.stage, p.prog);
    }
  } else if (!strcmp(cmd, "ev")) {
    if (!arg || !strcmp(arg, "list")) {
      for (int i = 0; i < eventm::EV_COUNT; i++) Serial.printf("%s(%u) ", eventm::name(i), evmem::timesSeen(i));
      Serial.println();
      return;
    }
    for (int i = 0; i < eventm::EV_COUNT; i++)
      if (!strcmp(arg, eventm::name(i))) { Serial.printf("trigger %s: %d\n", arg, eventm::trigger((eventm::EvId)i, ms, true)); return; }
    Serial.println("unknown event");
  } else if (!strcmp(cmd, "weather") && arg) {
    static const char* N[] = {"clear", "cloud", "over", "fog", "drizzle", "rain", "storm", "snow"};
    if (!strcmp(arg, "live")) { weather::forceRefresh(); return; }
    for (int i = 0; i < 8; i++) if (!strcmp(arg, N[i])) { weather::debugSet((SkyKind)i); Serial.printf("weather -> %s\n", N[i]); }
  } else if (!strcmp(cmd, "speed") && arg) {
    timem::setTimeScale(atof(arg));
    Serial.printf("time scale x%.0f\n", timem::timeScale());
  } else if (!strcmp(cmd, "skip") && arg) {
    timem::skip(atoi(arg) * 60);
  } else if (!strcmp(cmd, "bless")) input::apply(input::A_BLESS, ms);
  else if (!strcmp(cmd, "breeze")) input::apply(input::A_BREEZE, ms);
  else if (!strcmp(cmd, "pulse")) input::apply(input::A_PULSE, ms);
  else if (!strcmp(cmd, "save")) save::write();
  else if (!strcmp(cmd, "info")) render::showInfo(ms);
  else if (!strcmp(cmd, "prof")) render::printProfile();
  else if (!strcmp(cmd, "history")) history::print();
  else if (!strcmp(cmd, "evo")) evo::print();
  else if (!strcmp(cmd, "audit")) {  // 位置診斷：audit on|off|reset，不帶參數印出統計
    if (arg && !strcmp(arg, "on")) audit::enable(true);
    else if (arg && !strcmp(arg, "off")) audit::enable(false);
    else if (arg && !strcmp(arg, "reset")) audit::reset();
    audit::report();
  }
  else if (!strcmp(cmd, "erode")) Serial.printf("erode: %d\n", ruins::erode(ms));
  else if (!strcmp(cmd, "world")) {
    const eco::World& w = eco::world;
    Serial.printf("acorns %.1f cache %.1f pond %.2f drought %.2f frost %.2f puddle %.2f burn %.2f rubble %.2f meteor %.2f heavyRainH %.1f moon %u\n",
                  w.acornsGround, w.acornCache, w.pondLevel, w.drought, w.frost, w.puddle, w.burn, w.rubble, w.meteorGlow, w.heavyRainH, (unsigned)eco::moon());
    Serial.printf("under moist %.2f water %.2f mycel %.2f\n", under::moisture(), under::water(), under::mycelium());
    for (int i = 0; i < under::CAP; i++) { const auto& b = under::at(i); if (b.state) Serial.printf("  burrow %d %s x%d occ %u gen %u age %.1fh\n", i, under::stateName(b.state), b.x, b.occupant, b.generation, b.ageH); }
    for (int i = 0; i < ruins::CAP; i++) { const auto& r = ruins::at(i); if (r.type < ruins::R_COUNT) Serial.printf("  ruin %d %s reveal %.2f moss %.2f roots %.2f flags %x\n", i, ruins::name(r.type), r.reveal, r.moss, r.roots, r.flags); }
    const families::Blob& f = families::state();
    Serial.printf("nest %s eggs %u chicks %u gen %u t %.0fh | frog %u n %u | young %u\n", families::nestName(f.nest), f.eggs, f.chicks, f.generation, f.nestT, f.frog, f.frogN, f.young);
    Serial.printf("village %s\n", village::stageName(village::stage()));
  } else if (!strcmp(cmd, "set") && arg && arg2) {
    // 測試用：直接設定世界狀態 (例：set puddle 1、set drought 0.8)
    eco::World& w = eco::world;
    float val = atof(arg2);
    if (!strcmp(arg, "puddle")) w.puddle = val; else if (!strcmp(arg, "drought")) w.drought = val;
    else if (!strcmp(arg, "frost")) w.frost = val; else if (!strcmp(arg, "rain")) w.heavyRainH = val;
    else if (!strcmp(arg, "acorns")) w.acornsGround = val; else if (!strcmp(arg, "burn")) w.burn = val;
    else if (!strcmp(arg, "rubble")) w.rubble = val; else if (!strcmp(arg, "nest")) creature::setNestProgress(val);
    else if (!strcmp(arg, "neststage")) { families::state().nest = (uint8_t)val; families::state().eggs = families::state().chicks = 3; families::state().nestT = 0; }
    else if (!strcmp(arg, "frog")) { families::state().frog = (uint8_t)val; families::state().frogN = 8; }
    else if (!strcmp(arg, "village")) village::debugStage((uint8_t)val);
    Serial.printf("set %s = %.2f\n", arg, val);
  } else if (!strcmp(cmd, "nvs")) {
    nvs_stats_t st;
    if (nvs_get_stats(nullptr, &st) == ESP_OK)
      Serial.printf("nvs entries used %u free %u total %u\n", (unsigned)st.used_entries, (unsigned)st.free_entries, (unsigned)st.total_entries);
  }
  else if (!strcmp(cmd, "story") && arg) {
    for (int i = 0; i < visitor::S_COUNT; i++)
      if (!strcmp(arg, visitor::storyName(i))) { Serial.printf("story %s: %d\n", arg, visitor::force(i, ms)); return; }
    Serial.println("cabin camp lost glow chase study hunt merchant mystic");
  } else if (!strcmp(cmd, "build") && arg) {
    for (int t = 0; t < structure::T_COUNT; t++)
      if (!strcmp(arg, structure::name(t))) {
        int site = arg2 ? atoi(arg2) : structure::freeSite((structure::Type)t);
        Serial.printf("build %s at %d: %d\n", arg, site, structure::create((structure::Type)t, site, ms));
        return;
      }
  } else if (!strcmp(cmd, "decay") && arg) {
    // 讓建築經過 N 小時 (森林時間) 的腐朽
    for (int h = 0; h < atoi(arg); h++) structure::tick(3600);
    for (int i = 0; i < structure::CAP; i++) {
      const structure::Structure& s = structure::at(i);
      if (s.type < structure::T_COUNT)
        Serial.printf("  %-8s site %u stage %u decay %.2f wet %.2f moss %.2f mush %.2f vine %.2f flags %x\n", structure::name(s.type), s.site,
                      s.stage, s.decay, s.wet, s.moss, s.mush, s.vine, s.flags);
    }
  }
  else if (!strcmp(cmd, "log")) render::showJournal(ms);
  else if (!strcmp(cmd, "ui")) {  // ui on / ui off / ui (查詢)
    if (arg) setUiHidden(!strcmp(arg, "off"), ms);
    Serial.printf("ui %s\n", render::uiIsHidden() ? "hidden" : "shown");
  }
  else if (!strcmp(cmd, "reset")) { save::erase(); Serial.println("forest reset, rebooting"); delay(100); ESP.restart(); }
  else if (!strcmp(cmd, "journal")) {
    char buf[128];
    for (int i = journal::count() - 1; i >= 0; i--) { journal::format(journal::get(i), buf, sizeof(buf)); Serial.println(buf); }
  } else if (!strcmp(cmd, "shot")) {
    // 傳回目前畫面 (RGB565 原始資料) 給 tools/serial_mon.py 存成 PNG
    Serial.setTxTimeoutMs(2000);
    Serial.printf("SHOT_BEGIN %d %d\n", gfx::FW, gfx::FH);  // 原生解析度畫面 (不含文字 UI)
    const uint8_t* p = (const uint8_t*)gfx::fb;
    for (size_t i = 0; i < (size_t)gfx::FW * gfx::FH * 2; i += 480) Serial.write(p + i, 480);
    Serial.println("\nSHOT_END");
    Serial.flush();
    Serial.setTxTimeoutMs(0);
  } else if (!strcmp(cmd, "ap")) {
    if (wifi.apActive()) wifi.stopAp(); else wifi.startAp(ms);
  } else if (!strcmp(cmd, "wifi")) {
    if (arg) {
      const char* p = arg2 ? arg2 : "";
      if (WifiConfig::save(arg, p)) { wifi.setCredentials(arg, p, ms); Serial.println("wifi saved (password not echoed)"); }
      else Serial.println("invalid ssid/password");
    } else {
      Serial.printf("wifi state %u ip %s ap %s\n", (unsigned)wifi.state(), WiFi.localIP().toString().c_str(), wifi.apActive() ? wifi.apSsid() : "off");
    }
  } else Serial.println("unknown command (help)");
}

void pollSerial(uint32_t ms) {
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c == '\r') continue;
    if (c == '\n') { serialLine[serialLen] = 0; runCommand(serialLine, ms); serialLen = 0; continue; }
    if (serialLen < sizeof(serialLine) - 1) serialLine[serialLen++] = c;
  }
}
}  // namespace

void setup() {
  // 電源鎖定 + 關功放 (本專案不使用聲音)
  pinMode(cfg::PIN_POWER_LATCH, OUTPUT);
  digitalWrite(cfg::PIN_POWER_LATCH, HIGH);
  pinMode(cfg::PIN_AMP, OUTPUT);
  digitalWrite(cfg::PIN_AMP, LOW);

  Serial.begin(115200);
  Serial.setTxTimeoutMs(0);  // PINOUT 坑 #3
  util::rng.seed(esp_random());

  ledcAttach(cfg::PIN_LCD_BL, 5000, 10);
  setBacklight(0);
  panel.begin(cfg::LCD_SPI_HZ);
  panel.fillScreen(0);

  if (!gfx::begin()) {
    Serial.println("[Boot] framebuffer alloc failed");
    for (;;) delay(1000);
  }
  const uint32_t ms = millis();
  const bool sdOk = sdstore::begin();
  Serial.printf("[Boot] SD %s\n", sdOk ? "mounted" : "not present");

  // 讀存檔 → 初始化各模組 → 套用存檔
  save::load();
  timem::begin(save::savedEpoch(), save::savedUtcOffset());
  season::update(timem::local().yday);
  journal::begin(sdOk);
  evmem::begin(timem::now());
  plant::begin();
  creature::begin();
  eventm::begin(ms);
  render::begin();
  {
    Preferences p;
    if (p.begin("forest", true)) { render::setUiHidden(p.getBool("uihide", false)); p.end(); }
  }
  input::begin(ms);
  weather::begin();
  structure::begin();
  visitor::begin(ms);
  under::begin();
  ruins::begin();
  history::begin(timem::now());
  families::begin();
  village::begin();
  evo::begin();
  save::applyLoaded();
  save::applyHuman();
  if (save::migrated()) save::write();  // 舊版存檔轉換後立刻寫入新版 (避免下次開機重複轉換)
  if (!save::loaded()) journal::add(journal::J_BOOT, 0xFF, false);
  lastEcoEpoch = lastPlantEpoch = timem::now();
  if (save::loaded() && save::savedEpoch()) lastPlantEpoch = save::savedEpoch();

  // Wi-Fi：帳密存在 NVS；首次開機若 NVS 沒有，就用 Secrets.h 的預設值寫入一次
  char ssid[33], pass[65];
  WifiConfig::load(ssid, sizeof(ssid), pass, sizeof(pass));
  if (!ssid[0] && strlen(WIFI_SSID) > 0 && WifiConfig::save(WIFI_SSID, WIFI_PASS)) WifiConfig::load(ssid, sizeof(ssid), pass, sizeof(pass));
  wifi.begin(ssid, pass, ms);
  memset(pass, 0, sizeof(pass));
  web.begin(
      [](const char* s, const char* p) {
        if (!WifiConfig::save(s, p)) return;
        strncpy(pendingSsid, s, sizeof(pendingSsid) - 1);
        strncpy(pendingPass, p, sizeof(pendingPass) - 1);
        wifiSavePending = true;  // 在主迴圈套用，避免在 HTTP handler 裡切換 Wi-Fi
      },
      statusText);

  // 第一幀畫好才開背光，避免看到雜訊
  eco::update(ms, 0);
  render::frame(ms, 0.05f);
  pushFrame(ms);
  setBacklight(cfg::BL_DAY_PCT);
  lastFrame = lastSec = lastPop = lastPlant = lastSave = lastStats = ms;
  Serial.printf("[Boot] ready. heap int %u psram %u\n", (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL),
                (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM));
}

void loop() {
  const uint32_t ms = millis();

  // 按鍵 (每圈都檢查，反應快)
  input::Action a = input::poll(ms);
  switch (a) {
    case input::A_NONE: break;
    case input::A_INFO: render::showInfo(ms); break;
    case input::A_JOURNAL: render::showJournal(ms); break;
    case input::A_POWEROFF: powerOff(); break;
    case input::A_TOGGLE_UI: setUiHidden(!render::uiIsHidden(), ms); break;
    case input::A_WIFI_SETUP:
      if (wifi.apActive()) { wifi.stopAp(); render::notice("Wi-Fi 設定熱點已關閉", ms); }
      else wifi.startAp(ms);
      break;
    default: input::apply(a, ms); break;
  }
  pollSerial(ms);
  handleNet(ms);

  // 每秒：天氣、環境、事件排程
  if (ms - lastSec >= 1000) {
    lastSec = ms;
    weather::update(wifi.state() == WifiState::Connected);
    const uint32_t now = timem::now();
    float simDt = now >= lastEcoEpoch ? (float)(now - lastEcoEpoch) : 0;
    lastEcoEpoch = now;
    eco::update(ms, fminf(simDt, 600));
    season::update(timem::local().yday);
    eventm::tick(ms);
    audit::tick(ms);
  }
  if (ms - lastPop >= 5000) { lastPop = ms; creature::populationTick(ms); visitor::tick(ms); }
  if (ms - lastPlant >= 10000) { lastPlant = ms; plantTick(); }
  if (ms - lastSave >= cfg::SAVE_INTERVAL_S * 1000) { lastSave = ms; save::write(); }

  // 畫面
  if (ms - lastFrame >= cfg::FRAME_MS) {
    float dt = fminf((ms - lastFrame) / 1000.0f, 0.1f);
    timem::update(ms - lastFrame);
    lastFrame = ms;
    creature::update(dt, ms);
    visitor::update(dt, ms);
    structure::update(dt, ms);
    under::update(dt, ms);
    families::update(dt, ms);
    village::update(dt, ms);
    fx::update(dt, eco::env.wind);
    eventm::update(dt, ms);
    if (eco::env.rain > 0.2f && util::rng.chance(dt * eco::env.rain * 4))
      fx::ripple(util::rng.range(145, 220), util::rng.range(197, 214), (uint8_t)util::rng.irange(3, 6));
    render::frame(ms, dt);
    pushFrame(ms);
    uint32_t took = millis() - ms;
    frames++; frameMsSum += took; if (took > frameMsMax) frameMsMax = took;
    // 背光：夜晚自動調暗
    float target = cfg::BL_NIGHT_PCT + (cfg::BL_DAY_PCT - cfg::BL_NIGHT_PCT) * (1 - eco::env.night);
    blLevel = util::approach(blLevel, target, dt * 2);
    setBacklight(blLevel);
  }

  if (ms - lastStats >= 60000) {
    Serial.printf("[Stats] fps %.1f avg %lu ms max %lu ms, heap int %u (min %u) psram %u, creatures %d\n", frames / 60.0f,
                  (unsigned long)(frames ? frameMsSum / frames : 0), (unsigned long)frameMsMax,
                  (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL), (unsigned)heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL),
                  (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM), creature::activeCount());
    lastStats = ms;
    frames = frameMsSum = frameMsMax = 0;
  }
  vTaskDelay(1);  // 讓出 CPU 給同核心的其他工作 (不阻塞)
}
