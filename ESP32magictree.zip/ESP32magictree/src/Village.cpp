#include "Village.h"
#include <Arduino.h>
#include <math.h>
#include "CreatureManager.h"
#include "Ecosystem.h"
#include "EventManager.h"
#include "ForestHistory.h"
#include "Gfx.h"
#include "PlantManager.h"
#include "Ruins.h"
#include "SeasonManager.h"
#include "TimeManager.h"
#include "Util.h"
#include "Evolution.h"

namespace village {
namespace {
Blob v;
constexpr int VX = 36, VY = 206;  // 聚落位置 (古樹左下的樹蔭，世界座標)
const int HUT_DX[HUTS] = {0, -16, 14};
uint32_t nextVisitMs = 0;

void go(Stage s, eventm::EvId ev) {
  v.stage = s;
  v.stageT = 0;
  eventm::trigger(ev, millis(), true);
}
int hutCount() { int n = 0; for (auto& h : v.huts) if (h.on) n++; return n; }
void addHut() {
  for (auto& h : v.huts) if (!h.on) { h.on = 1; h.hp = 1; h.moss = 0; return; }
}
bool stable() {
  const eco::Env& e = eco::env;
  const uint32_t now = timem::now();
  bool calm = eco::world.lastDisaster == 0 || now - eco::world.lastDisaster > 3 * 86400UL;
  return calm && eco::world.drought < 0.4f && season::weight(WINTER) < 0.6f && e.storm < 0.3f;
}
}  // namespace

void begin() { v = {}; }
uint8_t stage() { return v.stage; }
void boost() {
  if (v.stage == VS_GATHER) go(VS_COLLECT, eventm::VL_COLLECT);
  else if (v.stage == VS_COLLECT) v.materials = (uint8_t)fminf(20, v.materials + 3);
}
void grow() {
  if (v.stage == VS_HUT && stable()) { addHut(); go(VS_SETTLE, eventm::VL_SETTLE); }
  else if (v.stage == VS_SETTLE && hutCount() < HUTS && stable()) { addHut(); go(VS_EXPAND, eventm::VL_EXPAND); }
}
void repair() {
  for (auto& h : v.huts) if (h.on) h.hp = 1;
  if (v.stage == VS_DAMAGED) { v.stage = VS_SETTLE; v.stageT = 0; }
}
void debugStage(uint8_t s) {
  if (s > VS_OVERGROWN) return;
  v.stage = s; v.stageT = 0;
  int want = s >= VS_EXPAND ? 3 : s >= VS_SETTLE ? 2 : s >= VS_HUT ? 1 : 0;
  for (int k = 0; k < HUTS; k++) { v.huts[k].on = k < want || (s >= VS_DAMAGED && k < 3); v.huts[k].hp = s == VS_DAMAGED ? 0.3f : 1; v.huts[k].moss = s >= VS_ABANDONED ? 0.6f : 0; }
  if (s == VS_COLLECT) v.materials = 4;
}

void tick(float dtH) {
  if (dtH <= 0) return;
  v.stageT += dtH;
  // 小精靈在附近活動的累積：有小精靈、附近有花或發光植物時增加
  float near = creature::count(creature::C_SPRITE) * 0.5f + plant::bloomingFlowers() * 0.1f + plant::countSpecies(plant::P_GLOW) * 0.15f;
  if (ruins::find(ruins::R_GATE) >= 0 || ruins::find(ruins::R_STELE) >= 0) near *= 1.3f;  // 古代遺跡吸引小精靈
  v.activity = util::clamp(v.activity + dtH * (near * 0.05f - 0.03f), 0.0f, 10.0f);
  const uint32_t now = timem::now();
  switch (v.stage) {
    case VS_NONE:
      if (v.activity > 4 && stable() && (v.lastEnd == 0 || now - v.lastEnd > 7 * 86400UL)) go(VS_GATHER, eventm::VL_GATHER);
      break;
    case VS_GATHER:
      if (v.stageT > 12) go(VS_COLLECT, eventm::VL_COLLECT);
      else if (v.activity < 1) v.stage = VS_NONE;  // 沒有持續聚集就散了
      break;
    case VS_COLLECT:
      if (stable()) v.materials = (uint8_t)fminf(20, v.materials + (util::rng.chance(fminf(1, dtH * 0.3f)) ? 1 : 0));
      if (v.materials >= 6) { v.materials -= 6; addHut(); go(VS_HUT, eventm::VL_HUT); history::note(history::H_VILLAGE, VX); }
      break;
    case VS_HUT:
      if (v.stageT > 48 && stable()) { addHut(); go(VS_SETTLE, eventm::VL_SETTLE); }
      break;
    case VS_SETTLE:
      if (v.stageT > 96 && stable() && v.activity > 3 && hutCount() < HUTS) { addHut(); go(VS_EXPAND, eventm::VL_EXPAND); }
      break;
    case VS_EXPAND: break;  // 最多 3 間，不再擴張
    case VS_DAMAGED:
      // 環境穩定就慢慢修好；太久或環境變差就遷離
      if (stable()) for (auto& h : v.huts) if (h.on) h.hp = fminf(1, h.hp + dtH * 0.01f);
      if (v.stageT > 72 || eco::world.drought > 0.6f || season::weight(WINTER) > 0.7f) go(VS_ABANDONED, eventm::VL_ABANDON);
      else if (stable() && v.stageT > 24) { bool ok = true; for (auto& h : v.huts) if (h.on && h.hp < 0.7f) ok = false; if (ok) v.stage = VS_SETTLE; }
      break;
    case VS_ABANDONED:
      for (auto& h : v.huts) if (h.on) { h.moss = fminf(1, h.moss + dtH * 0.006f); h.hp = fmaxf(0, h.hp - dtH * 0.003f); }
      if (v.stageT > 24 * 10) { go(VS_OVERGROWN, eventm::VL_OVERGROWN); history::note(history::H_VILLAGE, VX, 1); }
      break;
    case VS_OVERGROWN:
      if (v.stageT > 24 * 10) {
        for (auto& h : v.huts) h.on = 0;
        v.stage = VS_NONE; v.lastEnd = now; v.activity = 0;
        plant::sproutRandom(plant::P_GLOW);  // 舊址留下發光植物
      }
      break;
  }
  // 環境變差時也可能直接遷離
  if ((v.stage == VS_SETTLE || v.stage == VS_EXPAND || v.stage == VS_HUT) && (eco::world.drought > 0.8f || season::weight(WINTER) > 0.85f))
    go(VS_ABANDONED, eventm::VL_ABANDON);
}

void damage(float amount) {
  if (v.stage < VS_HUT || v.stage > VS_DAMAGED) return;
  bool hurt = false;
  for (auto& h : v.huts) if (h.on) { h.hp = fmaxf(0, h.hp - amount * util::rng.range(0.6f, 1.2f)); if (h.hp < 0.5f) hurt = true; }
  if (hurt && v.stage != VS_DAMAGED) go(VS_DAMAGED, eventm::VL_DAMAGE);
}

void update(float dt, uint32_t ms) {
  // 聚落有人時，小精靈會來來去去 (搬材料、回家)
  if (v.stage >= VS_GATHER && v.stage <= VS_EXPAND && util::reached(ms, nextVisitMs)) {
    nextVisitMs = ms + (uint32_t)util::rng.range(50, 120) * 1000;
    int i = creature::visitPoint(creature::C_SPRITE, VX + util::rng.range(-14, 14), VY - 14, ms, 40000);
    if (i >= 0 && v.stage == VS_COLLECT) creature::at(i).flags |= creature::F_TWIG;  // 搬著材料
  }
  (void)dt;
}

void draw(uint32_t ms) {
  if (v.stage == VS_NONE) return;
  const bool w = gfx::world;
  gfx::world = false;
  const int bx = VX >> 1, by = VY >> 1;
  const eco::Env& e = eco::env;
  // 材料堆 (小石頭與樹枝)
  int mat = v.stage == VS_COLLECT ? v.materials : (v.stage >= VS_HUT && v.stage <= VS_EXPAND ? 2 : 0);
  for (int k = 0; k < mat && k < 8; k++) gfx::pset(bx + 6 + (k % 4), by - (k / 4), gfx::lit(k & 1 ? 0x8C8C96 : 0x8C643C));
  for (int k = 0; k < HUTS; k++) {
    const Hut& h = v.huts[k];
    if (!h.on) continue;
    const int hx = bx + HUT_DX[k] / 2, hy = by;
    // 不同聚落有不同建築風格：紅白蘑菇、藍紫蘑菇、葉片屋頂
    static const uint32_t STYLE[3][2] = {{0xC8463C, 0x46AAAA}, {0x8C5AC8, 0x4678C8}, {0x5A9A46, 0x8C6A3C}};
    const uint8_t st = evo::villageStyle() % 3;
    const uint32_t cap = h.moss > 0.5f ? 0x6E8A4A : STYLE[st][k == 1 ? 1 : 0];
    const bool broken = h.hp < 0.5f;
    // 小屋：蘑菇傘屋頂 + 小門 (損壞時屋頂破洞)
    for (int yy = 0; yy < 3; yy++) for (int xx = -3; xx <= 3; xx++) {
      if (yy == 0 && (xx == -3 || xx == 3)) continue;
      if (broken && util::hashf(xx + k * 7, yy) < 0.35f) continue;
      gfx::pset(hx + xx, hy - 6 + yy, gfx::lit((xx + yy) % 3 ? cap : 0xF0E6D2));
    }
    for (int yy = 0; yy < 3; yy++) for (int xx = -2; xx <= 2; xx++) gfx::pset(hx + xx, hy - 3 + yy, gfx::lit(0xE6D2B4));
    bool lit = e.night > 0.4f && v.stage != VS_ABANDONED && v.stage != VS_OVERGROWN;
    gfx::pset(hx, hy - 1, lit ? gfx::rgb(0xFFDC78) : gfx::lit(0x3A2A20));
    gfx::pset(hx, hy - 2, lit ? gfx::rgb(0xFFDC78) : gfx::lit(0x3A2A20));
    if (lit) gfx::glow(hx, hy - 1, 3, 0xFFC864, 90);
    // 苔蘚覆蓋
    int nm = (int)(h.moss * 8);
    for (int m = 0; m < nm; m++) gfx::pset(hx - 3 + (int)(util::hashf(m, k) * 7), hy - 1 - (int)(util::hashf(k, m) * 6), gfx::lit(0x5E9A46));
  }
  (void)ms;
  gfx::world = w;
}

const char* stageName(uint8_t s) {
  static const char* N[] = {"none", "gather", "collect", "hut", "settle", "expand", "damaged", "abandoned", "overgrown"};
  return s <= VS_OVERGROWN ? N[s] : "?";
}
void exportBlob(Blob& b) { b = v; }
void importBlob(const Blob& b) { v = b; if (v.stage > VS_OVERGROWN) v.stage = VS_NONE; }

}  // namespace village
