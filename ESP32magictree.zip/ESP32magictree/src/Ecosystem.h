// 生態環境：把天氣、時間、季節、玩家魔法整合成植物與生物共同感受到的環境值
#pragma once
#include <stdint.h>
#include "World.h"

namespace eco {

struct Env {
  // 由天氣/時間推得
  SkyKind sky = SkyKind::PartCloud;
  float tempC = 22;
  float rain = 0;        // 0..1 降雨強度 (平滑)
  float snow = 0;
  float storm = 0;       // 0..1
  float wind = 0.1f;     // 0..1 (含玩家微風)
  float fog = 0;         // 0..1
  float cloud = 0.4f;
  float light = 1;       // 0..1 日照
  float night = 0;       // 0..1
  // 模擬量
  float airHum = 70;     // 0..100 模擬濕度
  float soil = 0.5f;     // 0..1 土壤水分
  float magic = 0;       // 0..1 玩家魔法殘留
  float insects = 0.3f;  // 0..1 昆蟲密度 (食物)
  float nectar = 0;      // 0..1 花蜜 (盛開花朵多寡)
  float pollen = 0;      // 0..1
  float hoursSinceRain = 24;
  bool hot = false, cold = false;
  // 玩家效果剩餘時間 (毫秒)
  uint32_t blessUntil = 0, breezeUntil = 0, pulseUntil = 0;
  float gust = 0;        // 陣風 (事件用)
};

extern Env env;

// 長期世界狀態 (會存檔)：食物、災害痕跡與恢復進度
struct World {
  float acornsGround;   // 地上的橡果 (0..10)
  float acornCache;     // 松鼠囤積的存糧 (0..12)
  float pondLevel;      // 池塘水位 (1 = 正常，乾旱時下降)
  float drought;        // 0..1 乾旱程度
  float frost;          // 0..1 地面霜層
  float puddle;         // 0..1 豪雨後的積水
  float burn;           // 0..1 古樹被雷擊的焦痕 (慢慢淡去)
  float rubble;         // 0..1 土石崩落的石堆 (慢慢被苔蘚覆蓋)
  float meteorGlow;     // 0..1 流星落下的發光石
  int16_t meteorX;
  float heavyRainH;     // 連續大雨時數
  uint32_t lastDisaster;
};
extern World world;
enum Moon : uint8_t { MOON_NEW, MOON_WAXING, MOON_FIRST_Q, MOON_FULL, MOON_LAST_Q, MOON_WANING };
Moon moon();
bool fullMoonNight();
void worldTick(float dtH);  // 每次植物更新時呼叫 (森林時間)

void update(uint32_t ms, float dtSimSec);  // 每秒呼叫
void bless(uint32_t ms);
void breeze(uint32_t ms);
void pulse(uint32_t ms);
bool blessing(uint32_t ms);
bool breezing(uint32_t ms);
bool pulsing(uint32_t ms);
// 對生物/植物的「天氣偏好」評分：pref -1 討厭雨 .. +1 喜歡雨
float wetness();  // 0..1 整體潮濕感

}  // namespace eco
