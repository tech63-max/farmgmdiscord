// 真實天氣 (Open-Meteo，免金鑰)。HTTP 在獨立的 FreeRTOS task 執行，不影響動畫。
// 斷線時沿用最後資料；超過 WEATHER_STALE_S 改用本地依季節的隨機天氣，網路恢復後自動重新同步。
#pragma once
#include <stdint.h>
#include "World.h"

namespace weather {

struct Now {
  SkyKind sky = SkyKind::PartCloud;
  float tempC = 22;
  float humidity = 70;      // %
  float windKmh = 8;
  float cloud = 0.4f;       // 0..1
  float precipProb = 0.2f;  // 0..1
  float precipMm = 0;
  bool live = false;        // true = 來自真實天氣 (且未過期)
  uint32_t fetchedAt = 0;   // epoch
};

void begin();
void update(bool wifiUp);  // 主迴圈呼叫 (只做排程與資料交換，不阻塞)
const Now& current();
const char* skyName(SkyKind s);
void forceRefresh();
// 存檔用
struct Snapshot { uint32_t fetchedAt; int16_t code; int16_t tempX10; uint8_t hum, cloud, pop, wind; float riseH, setH; int32_t utcOff; };
void getSnapshot(Snapshot& s);
void restoreSnapshot(const Snapshot& s);
void debugSet(SkyKind s);  // 序列埠測試用：強制天氣 (live 資料到達前有效)

}  // namespace weather
