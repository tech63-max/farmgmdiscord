#include "ForestRenderer.h"
#include <Arduino.h>
#include <math.h>
#include <string.h>
#include <esp_heap_caps.h>
#include "Config.h"
#include "CreatureManager.h"
#include "Ecosystem.h"
#include "EventManager.h"
#include "Gfx.h"
#include "Journal.h"
#include "Particles.h"
#include "PlantManager.h"
#include "PlayerInteraction.h"
#include "Scene.h"
#include "SeasonManager.h"
#include "StructureManager.h"
#include "Families.h"
#include "ForestHistory.h"
#include "Ruins.h"
#include "Underground.h"
#include "Village.h"
#include "Evolution.h"
#include "VisitorManager.h"
#include "TimeManager.h"
#include "Util.h"
#include "WeatherManager.h"

namespace render {
using namespace gfx;
namespace {

struct C3 { float r, g, b; };
inline C3 c3(uint32_t h) { return {(float)(h >> 16), (float)((h >> 8) & 0xFF), (float)(h & 0xFF)}; }
inline C3 mixc(C3 a, C3 b, float t) { return {a.r + (b.r - a.r) * t, a.g + (b.g - a.g) * t, a.b + (b.b - a.b) * t}; }
inline uint32_t hexOf(C3 c) {
  auto q = [](float v) { return (uint32_t)util::clamp(v, 0.0f, 255.0f); };
  return (q(c.r) << 16) | (q(c.g) << 8) | q(c.b);
}
inline uint16_t litC(C3 c) { return lit(hexOf(c)); }

const uint8_t BAYER[16] = {0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5};

// 天空/光照狀態 (每幀計算)
C3 skyTop, skyHor;
float t = 0;  // 動畫時間 (秒)
uint32_t lastBake = 0, lastRelight = 0;
uint32_t albedoSig = 0xFFFFFFFF, lightSig = 0xFFFFFFFF;
// 背景分兩層：材質 (很少重算) + 打光 (光線變化時快速套用)
uint16_t* albedo = nullptr;  // 未打光的顏色 (PSRAM)
uint8_t* tags = nullptr;     // 每個像素屬於哪一層
// T_NORMAL 之後的都是「一般材質」(打光方式相同)，分開標記是為了在不同物件的交界畫輪廓線
enum Tag : uint8_t { T_SKY, T_FAR_A, T_FAR_B, T_CONIFER, T_CONIFER_D, T_POND, T_NORMAL, T_MID, T_TRUNK, T_CANOPY, T_ROCK, T_LOG };
uint8_t curTag = T_NORMAL;  // bset() 目前寫入的物件種類
float snowCover = 0;
int moonPx = -1;  // 月亮目前的 x (給池塘倒影用)
bool moonGlowOn = false;

// 雲
struct Cloud { float x, y, s; };
Cloud clouds[7];

// 星星
struct Star { uint8_t x, y, b; };
Star stars[56];

// UI
uint32_t infoUntil = 0, journalUntil = 0;
bool uiHidden = false;  // 隱藏時鐘、事件提示 (主動按出的資訊卡/日誌/Wi-Fi 面板仍會顯示)
int journalPage = 0;
bool wifiOn = false;
char wifiSsid[24] = "", wifiPass[12] = "";
char netStatus[40] = "";
char noticeBuf[64] = "";
uint32_t noticeAt = 0;

// ---------- 色彩關鍵影格 ----------
struct SkyKey { float e; uint32_t top, hor, tint; };
const SkyKey KEYS[] = {
    {-1.0f, 0x080C22, 0x161E40, 0x5A64A6},
    {-0.35f, 0x0A0E26, 0x1C2446, 0x5C68A8},
    {-0.12f, 0x28306A, 0xB46E64, 0x9C86AE},
    {0.04f, 0x5A78B8, 0xFFAA6E, 0xFFBE9E},
    {0.25f, 0x5096E1, 0xAFD7F0, 0xFAFAF5},
    {1.0f, 0x468CE6, 0xA5D2F0, 0xFFFFFF},
};

void computeLighting(uint32_t ms) {
  const float e = timem::sunElev();
  int k = 0;
  while (k < 4 && e > KEYS[k + 1].e) k++;
  const SkyKey &a = KEYS[k], &b = KEYS[k + 1];
  float f = util::clamp01((e - a.e) / (b.e - a.e));
  skyTop = mixc(c3(a.top), c3(b.top), f);
  skyHor = mixc(c3(a.hor), c3(b.hor), f);
  C3 tn = mixc(c3(a.tint), c3(b.tint), f);

  const eco::Env& env = eco::env;
  // 陰天、雨天：天空變灰、光線變柔
  float bright = 0.25f + 0.75f * timem::dayFactor();
  C3 gray = {128 * bright, 136 * bright, 146 * bright};
  C3 grayH = {170 * bright, 174 * bright, 180 * bright};
  float oc = util::clamp01(env.cloud * 0.7f + env.rain * 0.3f + env.storm * 0.2f);
  skyTop = mixc(skyTop, gray, oc);
  skyHor = mixc(skyHor, grayH, oc * 0.85f);
  if (env.storm > 0) { skyTop = mixc(skyTop, {40, 44, 56}, env.storm * 0.5f); skyHor = mixc(skyHor, {70, 74, 86}, env.storm * 0.4f); }
  if (env.fog > 0) skyHor = mixc(skyHor, {200 * bright, 204 * bright, 208 * bright}, env.fog * 0.7f);

  float dim = 1.0f - 0.22f * env.cloud - 0.15f * env.rain - 0.12f * env.storm;
  tn = {tn.r * dim, tn.g * dim, tn.b * dim};
  // 晴天時光線較暖
  if (env.cloud < 0.3f && e > 0.1f) tn.b *= 0.96f;
  // 閃電
  float fl = eventm::lightning(ms);
  if (fl > 0) tn = mixc(tn, {330, 330, 360}, fl * 0.8f);
  // 魔法脈動：淡紫光
  if (eco::pulsing(ms)) {
    float p = sinf((ms % 6000) / 6000.0f * 3.1416f);
    tn.r += 30 * p; tn.b += 60 * p; tn.g += 10 * p;
  }
  // 月相：新月的夜晚比較暗，滿月比較亮 (仍保持可辨識)
  if (env.night > 0.3f) {
    const eco::Moon m = eco::moon();
    float k = m == eco::MOON_NEW ? 0.9f : m == eco::MOON_FULL ? 1.1f : 1.0f;
    k = 1.0f + (k - 1.0f) * env.night;
    tn = {tn.r * k, tn.g * k, tn.b * k};
  }
  tint.r = (uint16_t)util::clamp(tn.r, 40.0f, 360.0f);
  tint.g = (uint16_t)util::clamp(tn.g, 40.0f, 360.0f);
  tint.b = (uint16_t)util::clamp(tn.b, 40.0f, 360.0f);
}

C3 seasonMix(const uint32_t sp, const uint32_t su, const uint32_t au, const uint32_t wi) {
  C3 r = {0, 0, 0};
  const uint32_t v[4] = {sp, su, au, wi};
  for (int i = 0; i < 4; i++) {
    float w = season::weight((Season)i);
    C3 c = c3(v[i]);
    r.r += c.r * w; r.g += c.g * w; r.b += c.b * w;
  }
  return r;
}

// 提高飽和度 (以亮度為軸心拉開色彩)，bright 另外調整亮度
C3 vivid(C3 c, float s = cfg::BG_VIVID, float bright = 1.0f) {
  const float l = c.r * 0.299f + c.g * 0.587f + c.b * 0.114f;
  auto f = [&](float v) { return util::clamp((l + (v - l) * s) * bright, 0.f, 255.f); };
  return {f(c.r), f(c.g), f(c.b)};
}

// ---------- 烘焙背景 ----------
constexpr int WW = cfg::W, WH = cfg::H;  // 世界座標範圍 (240)
// 背景以 240x240 原生解析度烘焙 (世界座標 = 螢幕像素)
inline void tset(int x, int y, uint8_t tag, uint16_t v) {
  if ((unsigned)x >= (unsigned)FW || (unsigned)y >= (unsigned)FH) return;
  const int i = y * FW + x;
  albedo[i] = v;
  tags[i] = tag;
}
inline void bset(int x, int y, uint16_t c) { tset(x, y, curTag, c); }

void bakeSky() {
  memset(tags, T_SKY, (size_t)FW * FH);
  memset(albedo, 0, (size_t)FW * FH * 2);
}

// 烘焙完成後：在物件交界補上深色輪廓線 (像素畫的描邊)，並更新天空遮罩
void bakeFinish() {
  auto darken = [](uint16_t c, uint32_t k) {  // k: 0..256
    return (uint16_t)(((((c >> 11) * k) >> 8) << 11) | (((((c >> 5) & 63) * k) >> 8) << 5) | (((c & 31) * k) >> 8));
  };
  for (int y = 0; y < FH; y++) {
    for (int x = 0; x < FW; x++) {
      const int i = y * FW + x;
      const uint8_t tg = tags[i];
      if (tg < T_MID) continue;
      const bool e1 = (x > 0 && tags[i - 1] != tg) || (x < FW - 1 && tags[i + 1] != tg) || (y > 0 && tags[i - FW] != tg) || (y < FH - 1 && tags[i + FW] != tg);
      // 輪廓線 2 像素粗：最外圈最深、第二圈稍淡。中景樹只畫 1 圈且較淡 (空氣透視)
      if (e1) { albedo[i] = darken(albedo[i], tg == T_MID ? 150 : 80); continue; }
      if (tg == T_MID || tg == T_ROCK) continue;
      const bool e2 = (x > 1 && tags[i - 2] != tg) || (x < FW - 2 && tags[i + 2] != tg) || (y > 1 && tags[i - 2 * FW] != tg) || (y < FH - 2 && tags[i + 2 * FW] != tg);
      if (e2) albedo[i] = darken(albedo[i], 150);
    }
  }
  // 天空遮罩是 120 畫布解析度：整格 2x2 都是天空才算 (日月星雲以 2x2 繪製，不會蓋到樹緣)
  for (int y = 0; y < H; y++) for (int x = 0; x < W; x++) {
    const uint8_t* p = tags + (y * 2) * FW + x * 2;
    setSky(x, y, p[0] == T_SKY && p[1] == T_SKY && p[FW] == T_SKY && p[FW + 1] == T_SKY);
  }
}

// ====== 場景繪製：照 example.png 的畫法 ======
// 葉子、灌木、苔蘚都是「一團一團」畫上去的：每團左上有亮點、右下暗、外圍一圈深色邊，
// 由後往前疊，前面的亮頂蓋住後面的暗底，形成一層層的葉叢。

struct Pal { uint16_t c[5]; };  // 亮點、亮、中、暗、邊線
Pal makePal(C3 b, float k = 1.0f, bool soft = false) {
  const C3 hi = {b.r * 1.7f * k + 25, b.g * 1.25f * k + 15, b.b * 0.85f * k}, li = {b.r * 1.1f * k, b.g * 1.1f * k, b.b * 1.1f * k},
           mi = {b.r * 0.84f * k, b.g * 0.84f * k, b.b * 0.84f * k}, da = {b.r * 0.55f * k, b.g * 0.62f * k, b.b * 0.72f * k},
           ri = {b.r * 0.3f * k, b.g * 0.38f * k, b.b * 0.5f * k};
  Pal p;
  // soft：沒有亮點和深邊，給生物活動的草地用 (背景安靜一點，生物才清楚)
  p.c[0] = litC(soft ? li : hi); p.c[1] = litC(li); p.c[2] = litC(mi);
  p.c[3] = litC(soft ? mixc(mi, da, 0.5f) : da); p.c[4] = litC(soft ? da : ri);
  return p;
}

void clump(int cx, int cy, int rx, int ry, const Pal& p, uint32_t seed) {
  const float ph = (seed & 63) * 0.1f, rimW = 1.5f / (rx < ry ? rx : ry);
  for (int y = -ry - 2; y <= ry + 2; y++) {
    for (int x = -rx - 2; x <= rx + 2; x++) {
      const float u = (float)x / rx, v = (float)y / ry;
      const float d = sqrtf(u * u + v * v) / (1.0f + 0.15f * sinf(atan2f(v, u) * 5.0f + ph));  // 花瓣狀的起伏邊緣
      if (d > 1.0f) continue;
      const float t = -u * 0.55f - v * 0.85f;  // 光從左上來
      int idx = t > 0.5f ? 0 : t > 0.12f ? 1 : t > -0.38f ? 2 : 3;
      const uint32_t h = util::hash2((cx + x) >> 1, cy + y) & 7;  // 零星的葉片亮點/暗點
      if (idx == 1 && h == 0) idx = 0;
      else if (idx == 2 && h == 0) idx = 1;
      else if (idx == 2 && h == 1) idx = 3;
      else if (idx == 3 && h == 0) idx = 2;
      if (d > 1.0f - rimW) idx = v > -0.2f ? 4 : 3;
      bset(cx + x, cy + y, p.c[idx]);
    }
  }
}

// 一批葉團：依 y 排序後由上往下畫 (下面的在前面)
struct Cl { int16_t x, y; uint8_t r, pal; uint16_t seed; };
constexpr int CL_MAX = 220;
Cl cls[CL_MAX];
int clN = 0;
void clAdd(int x, int y, int r, int pal, uint32_t seed) { if (clN < CL_MAX) cls[clN++] = {(int16_t)x, (int16_t)y, (uint8_t)r, (uint8_t)pal, (uint16_t)seed}; }
void clFlush(const Pal* pals) {
  for (int i = 1; i < clN; i++) { Cl v = cls[i]; int j = i - 1; while (j >= 0 && cls[j].y > v.y) { cls[j + 1] = cls[j]; j--; } cls[j + 1] = v; }
  for (int i = 0; i < clN; i++) clump(cls[i].x, cls[i].y, cls[i].r, cls[i].r * 5 / 6, pals[cls[i].pal], cls[i].seed);
  clN = 0;
}

// 圓石：藍灰色，左上亮、底部暗
void rock(int cx, int cy, int rx, int ry) {
  const C3 rl = c3(0xB0AEBC), rm = c3(0x7C7D90), rd = c3(0x4C4E62);
  for (int y = -ry; y <= ry * 2 / 3; y++)
    for (int x = -rx; x <= rx; x++) {
      float d = (float)(x * x) / (rx * rx) + (float)(y * y) / (ry * ry);
      if (d > 1) continue;
      float sh = (-x * 0.5f / rx - (float)y / ry) + (util::vnoise((cx + x) * 0.3f, (cy + y) * 0.3f) - 0.5f) * 0.4f;
      bset(cx + x, cy + y, litC(sh > 0.45f ? rl : sh > -0.25f ? rm : rd));
    }
}

// 苔蘚/草地的底色 (含積雪)
C3 mossBase() {
  C3 b = seasonMix(0x7CC84A, 0x6ABA40, 0x9AB840, 0x8CA08A);
  if (snowCover > 0.05f) b = mixc(b, {225, 232, 240}, snowCover * 0.8f);
  return b;
}

// 瀑布的位置 (岩壁中央)
constexpr int FALL_X0 = 139, FALL_X1 = 147, FALL_Y0 = 127, FALL_Y1 = 165;

void bakeFar() {
  // 霧裡的兩排樹影 (圓樹冠)，顏色在打光時依天空決定。樹林很高，只在上方留一小片天空
  for (int layer = 0; layer < 2; layer++) {
    const int step = layer ? 17 : 24, baseY = layer ? 94 : 72;
    for (int x = 0; x < WW; x++) {
      int top = baseY + 16;
      bool lit = false;
      for (int k = x / step - 2; k <= x / step + 2; k++) {
        const uint32_t h = util::hash32((uint32_t)(k * 37 + layer * 911 + 5));
        const int xk = k * step + (int)(h % 9), r = (layer ? 11 : 15) + (int)((h >> 8) % 8), cyk = baseY + (int)((h >> 16) % 14);
        const int dx = x - xk;
        if (abs(dx) > r) continue;
        const int ty = cyk - (int)sqrtf((float)(r * r - dx * dx));
        if (ty < top) { top = ty; lit = dx < -r / 4; }
      }
      for (int y = top; y < 200; y++) tset(x, y, layer ? T_FAR_B : T_FAR_A, (y - top < 6 && lit) ? 1 : (layer == 0 && y - top > 10 ? 2 : 0));
    }
  }
  // 深色的高大針葉林：前景的襯底
  for (int x = 0; x < WW; x++) {
    int top = 999;
    bool rightSide = false;
    for (int k = x / 11 - 2; k <= x / 11 + 2; k++) {
      if (k < 0) continue;
      int xk = k * 11 + (int)(util::hash32(k * 31) % 7);
      int hk = 30 + (int)(util::hash32(k * 17 + 3) % 34);
      int yb = 140 + (int)(util::hash32(k * 7 + 1) % 6);
      int ty = yb - hk + (int)(abs(x - xk) / 0.3f);
      if (ty < yb && ty < top) { top = ty; rightSide = x > xk; }
    }
    for (int y = top; y < 200; y++) tset(x, y, (!rightSide && y - top < 12) ? T_CONIFER : T_CONIFER_D, 0);
  }
  // 兩側的大樹剪影：把畫面框起來，中間留下透光的缺口
  struct D { int x, y, r; } dk[] = {{228, 54, 30}, {194, 84, 19}, {248, 98, 24}, {-6, 98, 22}};
  for (auto& d : dk) {
    for (int y = d.y; y < 200; y++) for (int dx = -3; dx <= 3; dx++) tset(d.x + dx, y, T_CONIFER_D, 0);
    for (int y = -d.r - 3; y <= d.r + 3; y++) for (int x = -d.r - 3; x <= d.r + 3; x++) {
      const float dist = sqrtf((float)(x * x + y * y)) / (d.r * (1.0f + 0.1f * sinf(atan2f((float)y, (float)x) * 7.0f + d.x)));
      if (dist > 1.0f) continue;
      const bool lit = (-x * 0.6f - y * 0.8f) > d.r * 0.82f;
      tset(d.x + x, d.y + y, lit ? T_CONIFER : T_CONIFER_D, 0);
    }
  }
}

// 四季的葉色：整年都以綠色為主 (範例的色調)，秋天另外混入金黃色的葉團
C3 leafBase() { return seasonMix(0x62B848, 0x52A63C, 0x86AE3C, 0x6A8A6C); }

void bakeMidTrees() {
  // 中景的樹 (帶霧氣、比古樹暗)
  curTag = T_MID;
  {
    const C3 base = mixc(leafBase(), c3(0x4E8C84), 0.3f);
    const Pal pals[3] = {makePal(base, 0.95f), makePal(base, 0.78f), makePal(mixc(c3(0xD89A34), c3(0x4E8C84), 0.25f), 0.9f)};
    const float au = season::weight(AUTUMN);
    const uint16_t trunk = litC(c3(0x3E2E26));
    struct T { int x, y, r; } trees[] = {{236, 116, 18}, {180, 128, 12}};
    int ti = 0;
    for (auto& tr : trees) {
      for (int y = tr.y; y < scene::groundY(tr.x) + 2; y++) for (int dx = -1; dx <= 1; dx++) bset(tr.x + dx, y, trunk);
      for (int y = -tr.r + 3; y <= tr.r - 3; y++) for (int x = -tr.r + 2; x <= tr.r - 2; x++)
        if (x * x + y * y * 5 / 4 <= (tr.r - 2) * (tr.r - 2)) bset(tr.x + x, tr.y - tr.r / 3 + y, pals[1].c[3]);
      const int cnt = tr.r * tr.r / 7;
      for (int k = 0; k < cnt; k++) {
        const uint32_t h = util::hash32(ti * 977 + k * 131 + 9);
        const float a = (h & 0xFFFF) / 65535.0f * 6.283f, rr = sqrtf(((h >> 16) & 0xFF) / 255.0f) * tr.r;
        const int x = tr.x + (int)(cosf(a) * rr), y = tr.y - tr.r / 3 + (int)(sinf(a) * rr * 0.85f);
        const bool gold = au > 0.3f && ((h >> 5) & 7) < (uint32_t)(au * 3.5f);
        clAdd(x, y, 5 + (h >> 28) % 3, gold ? 2 : (y > tr.y ? 1 : 0), h);
      }
      ti++;
    }
    clFlush(pals);
    // 沿著地平線的一排灌木
    for (int x = 100; x < WW + 8; x += 10) {
      const uint32_t h = util::hash32(x * 3 + 41);
      clAdd(x + (int)(h % 5), scene::groundY(x) - 3 - (int)((h >> 4) % 4), 7 + (h >> 8) % 4, (h >> 12) & 1, h);
    }
    clFlush(pals);
  }

  const C3 gb = mossBase();
  const Pal gp[3] = {makePal(gb, 1.05f), makePal(gb, 0.86f), makePal(gb, 0.66f)};

  // 左邊隆起的苔蘚土丘 (古樹就長在上面)：頂部受光、往下漸暗
  curTag = T_NORMAL;
  auto moundTop = [](int x) { const float u = (x - 38) / 72.0f; return 149 + (int)(u * u * 19); };
  for (int x = 0; x < 114; x++) for (int y = moundTop(x); y <= scene::groundY(x) + 1; y++) bset(x, y, gp[2].c[3]);
  for (int y0 = 0; y0 < 26; y0 += 5) {
    for (int x = -4 + (y0 & 1) * 4; x < 116; x += 9) {
      const uint32_t h = util::hash2(x, y0 + 17);
      const int cx = x + (int)(h % 5), cy = moundTop(cx) + y0 + 1;
      if (cy > scene::groundY(cx) + 1) continue;
      clump(cx, cy, 7, 4, gp[y0 < 5 ? 0 : y0 < 14 ? 1 : 2], h);
    }
  }

  // 中間的岩壁與瀑布：由上往下疊石頭 (下面的在前面)
  curTag = T_ROCK;
  { const int xs[2] = {131, 155}; for (int x : xs) rock(x, 134, 10, 8); }
  { const int xs[3] = {124, 143, 162}; for (int x : xs) rock(x, 147, 11, 9); }
  { const int xs[4] = {118, 133, 153, 168}; for (int x : xs) rock(x, 161, 10, 9); }
  // 瀑布：藍白相間的水柱
  curTag = T_NORMAL;
  {
    const uint16_t w0 = litC(c3(0x8CC4EC)), w1 = litC(c3(0xE8F6FF)), w2 = litC(c3(0x5A9CD6));
    for (int y = FALL_Y0; y <= FALL_Y1; y++) for (int x = FALL_X0; x <= FALL_X1; x++) {
      const uint32_t h = util::hash2(x, y / 5) & 3;
      bset(x, y, (x == FALL_X0 || x == FALL_X1) ? w2 : h == 0 ? w1 : h == 1 ? w2 : w0);
    }
    // 岩壁頂上的苔蘚 (瀑布兩側)
    clump(128, 125, 10, 4, gp[0], 3); clump(158, 125, 10, 4, gp[0], 8);
    clump(118, 139, 6, 3, gp[1], 5); clump(168, 139, 6, 3, gp[1], 6);
  }

  // 右邊長滿苔蘚的空心樹拱
  curTag = T_LOG;
  {
    const C3 bark = c3(0x6B4528), barkL = c3(0x9A6A3A), barkD = c3(0x432A1C);
    const int ax = 208, ay = scene::groundY(208) + 3;
    for (int y = -38; y <= 0; y++) for (int x = -34; x <= 34; x++) {
      const float dO = (float)(x * x) / (34 * 34) + (float)(y * y) / (38 * 38), dI = (float)(x * x) / (22 * 22) + (float)(y * y) / (26 * 26);
      if (dO > 1) continue;
      if (dI < 1) { bset(ax + x, ay + y, litC(dI < 0.55f ? c3(0x14100E) : c3(0x241A14))); continue; }  // 拱裡面是暗的
      const float t = -x * 0.5f / 34 - (float)y / 38;
      C3 c = t > 0.8f ? barkL : t > 0.4f ? bark : barkD;
      if (((int)(sqrtf(dO) * 38)) % 4 == 0) c = barkD;  // 樹皮的弧形紋
      bset(ax + x, ay + y, litC(c));
    }
    curTag = T_NORMAL;
    for (int k = 0; k < 6; k++) {
      const float a = -2.75f + k * 0.47f;
      clump(ax + (int)(cosf(a) * 33), ay + (int)(sinf(a) * 37) - 2, 8, 4, gp[k < 3 ? 0 : 1], k * 7);
    }
  }
}

void bakeGround() {
  curTag = T_NORMAL;
  C3 base = seasonMix(0x7CC84A, 0x6ABA40, 0x9AB840, 0x8CA08A);
  if (snowCover > 0.05f) base = mixc(base, {225, 232, 240}, snowCover * 0.8f);
  // 0 亮、1 一般、2 暗 (有亮點和深邊)；3、4 是生物活動區用的柔和版本
  const Pal pals[5] = {makePal(base, 1.08f), makePal(base, 0.92f), makePal(base, 0.7f), makePal(base, 1.05f, true), makePal(base, 0.9f, true)};
  const uint16_t under = pals[2].c[3];
  for (int x = 0; x < WW; x++) for (int y = scene::groundY(x); y < WH; y++) bset(x, y, under);
  // 苔蘚/草叢：由後往前一排排疊上去，越近越大
  int row = 0;
  for (float y = 168; y < 248; row++) {
    const float depth = (y - 168) / 74.0f;
    const int rx = 6 + (int)(7 * depth), ry = 3 + (int)(3.5f * depth);
    for (float x = -rx + (row & 1) * rx * 0.6f; x < WW + rx; x += rx * 1.25f) {
      const uint32_t h = util::hash2((int)x, row * 71 + 3);
      const int cx = (int)x + (int)(h % 5) - 2, cy = scene::groundY(cx) + (int)(y - 168) + (int)((h >> 4) % 3) - 1;
      const float z = util::vnoise(cx * 0.03f, cy * 0.06f);
      int pi;
      if (cy > 176 && cy < 214) pi = z > 0.5f ? 3 : 4;        // 生物走動的草地：柔和
      else pi = cy > 226 ? 2 : z > 0.6f ? 0 : z < 0.35f ? 2 : 1;  // 最前緣壓暗
      clump(cx, cy, rx, ry, pals[pi], h);
    }
    y += ry * 1.15f;
  }
}

void bakePond() {
  curTag = T_NORMAL;
  const uint16_t shoreA = litC(c3(0x4A3B2C)), shoreB = litC(c3(0x32281F));
  // 河道：中央深、靠岸淺；岸邊是一圈深色的濕土
  for (int y = scene::RIVER_Y0; y <= scene::RIVER_Y1; y++) {
    for (int x = scene::RIVER_X0; x <= scene::RIVER_X1; x++) {
      float hw, u;
      const float d = scene::riverDist(x, y, &hw, &u);
      const float wob = (util::vnoise(x * 0.2f, y * 0.4f) - 0.5f) * 1.6f;
      if (d < hw + wob) {
        // 只記錄「倒映天空的比例」，顏色在打光時依當下天空計算
        const float k = d / hw;
        float m = util::clamp01(0.28f + k * 0.45f + (util::vnoise(u * 18.0f, k * 2.0f) - 0.5f) * 0.2f) * 0.8f;
        tset(x, y, T_POND, (uint16_t)(m * 255));
      } else if (d < hw + 3.0f + wob) {
        bset(x, y, d < hw + 1.5f + wob ? shoreB : shoreA);
      }
    }
  }
  // 瀑布下的小水潭
  const int px = (FALL_X0 + FALL_X1) / 2, py = FALL_Y1 + 3;
  for (int y = -5; y <= 5; y++) for (int x = -15; x <= 15; x++) {
    const float d = (float)(x * x) / (15 * 15) + (float)(y * y) / 25.0f;
    if (d > 1) continue;
    if (d > 0.72f) bset(px + x, py + y, shoreB); else tset(px + x, py + y, T_POND, 150);
  }
  // 從水潭流到河裡的小溪：彎彎曲曲，上游窄、下游寬，河口張開匯入大河
  {
    const float cp[][2] = {{144, 170}, {144, 171}, {155, 176}, {152, 186}, {164, 192}, {168, 200}, {184, 203}, {200, 206}, {214, 212}, {220, 214}};
    constexpr int SEG = sizeof(cp) / sizeof(cp[0]) - 3, PER = 14, NP = SEG * PER + 1;
    static float sx[NP], sy[NP], sr[NP];
    for (int i = 0; i < NP; i++) {  // Catmull-Rom 曲線
      const int sgi = i == NP - 1 ? SEG - 1 : i / PER;
      const float t1 = i == NP - 1 ? 1.0f : (i % PER) / (float)PER, t2 = t1 * t1, t3 = t2 * t1;
      const float* p0 = cp[sgi]; const float* p1 = cp[sgi + 1]; const float* p2 = cp[sgi + 2]; const float* p3 = cp[sgi + 3];
      for (int c = 0; c < 2; c++) {
        const float v = 0.5f * (2 * p1[c] + (-p0[c] + p2[c]) * t1 + (2 * p0[c] - 5 * p1[c] + 4 * p2[c] - p3[c]) * t2 + (-p0[c] + 3 * p1[c] - 3 * p2[c] + p3[c]) * t3);
        (c ? sy : sx)[i] = v;
      }
      const float u = i / (float)(NP - 1);
      sr[i] = 1.7f + u * 2.6f + (u > 0.8f ? (u - 0.8f) * 16.0f : 0) + sinf(u * 19.0f) * 0.5f;  // 寬度有點起伏，河口張開
    }
    for (int y = 164; y <= 220; y++) {
      for (int x = 136; x <= 226; x++) {
        if (tags[y * FW + x] == T_POND) continue;  // 水潭和大河已經畫好了
        float best = 99, br = 1;
        for (int i = 0; i < NP; i++) {
          const float dx = x - sx[i], dy = (y - sy[i]) * 1.5f;  // 俯視的水面：上下方向壓扁
          const float d = sqrtf(dx * dx + dy * dy) - sr[i];
          if (d < best) { best = d; br = sr[i]; }
        }
        if (best < 0) {
          const float k = 1.0f + best / br;  // 0 中央 .. 1 岸邊，和大河同一套深淺
          const float m = util::clamp01(0.28f + k * 0.45f + (util::vnoise(x * 0.3f, y * 0.5f) - 0.5f) * 0.2f) * 0.8f;
          tset(x, y, T_POND, (uint16_t)(m * 255));
        } else if (best < 1.8f) {
          bset(x, y, best < 0.9f ? shoreB : shoreA);
        }
      }
    }
    // 岸邊的小石頭
    curTag = T_ROCK;
    const int ri[5] = {10, 22, 36, 52, 68};
    for (int k = 0; k < 5; k++) {
      const int i = ri[k], side = (k & 1) ? 1 : -1;
      rock((int)(sx[i] + side * (sr[i] + 3)), (int)(sy[i] + (side > 0 ? -1 : 2)), 3, 2);
    }
    curTag = T_NORMAL;
  }
}

void bakeTree() {
  const C3 bark = c3(0x6B4528), barkL = c3(0x9A6A3A), barkD = c3(0x432A1C), groove = c3(0x2E1C14);
  curTag = T_TRUNK;
  // 樹根
  for (int k = 0; k < 5; k++) {
    float side = k < 2 ? -1 : k < 4 ? 1 : 0.2f;
    float sx = scene::TRUNK_X + side * (scene::TRUNK_HALF - 2), sy = 160;
    float ex = scene::TRUNK_X + side * (26 + k * 3), ey = 184 + (k & 1) * 4;
    for (int s = 0; s <= 40; s++) {
      float u = s / 40.0f;
      float x = sx + (ex - sx) * u, y = sy + (ey - sy) * (u * u * 0.6f + u * 0.4f);
      int wdt = (int)(6 * (1 - u)) + 1;
      for (int j = -wdt; j <= wdt; j++) bset((int)x + j / 2, (int)y + (j > 0 ? 0 : 1), litC(j < 0 ? barkL : j > wdt / 2 ? barkD : bark));
    }
  }
  // 樹幹：左側受光、右側背光，直向的樹皮紋
  for (int y = scene::TRUNK_TOP - 10; y < scene::TRUNK_BOTTOM; y++) {
    float hw = scene::TRUNK_HALF + (y > 150 ? (y - 150) * 0.45f : 0) + sinf(y * 0.08f) * 1.5f;
    float cx = scene::TRUNK_X + sinf(y * 0.04f) * 3;
    for (int x = (int)(cx - hw); x <= (int)(cx + hw); x++) {
      float u = (x - (cx - hw)) / (2 * hw);
      C3 c = u < 0.28f ? barkL : u > 0.68f ? barkD : bark;
      float g = util::vnoise(x * 0.55f + sinf(y * 0.05f) * 2, y * 0.06f);
      if (g > 0.66f) c = groove;
      else if (g < 0.22f && u < 0.6f) c = barkL;
      bset(x, y, litC(c));
    }
  }
  // 樹洞
  for (int y = -scene::HOLLOW_RY - 2; y <= scene::HOLLOW_RY + 2; y++)
    for (int x = -scene::HOLLOW_RX - 2; x <= scene::HOLLOW_RX + 2; x++) {
      float d = (float)(x * x) / (scene::HOLLOW_RX * scene::HOLLOW_RX) + (float)(y * y) / (scene::HOLLOW_RY * scene::HOLLOW_RY);
      if (d < 1.0f) bset(scene::HOLLOW_X + x, scene::HOLLOW_Y + y, litC(d < 0.6f ? c3(0x140E0C) : c3(0x22170F)));
      else if (d < 1.45f && y < 2) bset(scene::HOLLOW_X + x, scene::HOLLOW_Y + y, litC(barkL));
    }
  // 樹枝
  for (int k = 0; k < scene::PERCH_N; k++) {
    int px = scene::PERCH[k].x, py = scene::PERCH[k].y;
    int sx = scene::TRUNK_X + (px > scene::TRUNK_X ? 6 : -6), sy = py + 24;
    int steps = abs(px - sx) + abs(py - sy);
    for (int s = 0; s <= steps; s++) {
      float u = (float)s / steps;
      int x = sx + (int)((px - sx) * u), y = sy + (int)((py - sy) * u) - (int)(sinf(u * 3.14f) * 5);
      int wdt = 5 - (int)(u * 3.2f);  // 由粗到細
      for (int j = 0; j < wdt; j++) bset(x, y + j, litC(j == 0 ? barkL : j == wdt - 1 ? barkD : bark));
      if (s == steps * 2 / 3) for (int k = 1; k < 6; k++) bset(x + (px > sx ? k : -k) / 2, y - k, litC(bark));
    }
  }
  // 樹根上的苔蘚
  {
    curTag = T_NORMAL;
    const Pal moss = makePal(seasonMix(0x7CC84A, 0x6ABA40, 0x9AB840, 0x8CA08A), 0.95f);
    const int mx[4] = {-24, -10, 16, 30}, my[4] = {180, 174, 176, 183};
    for (int k = 0; k < 4; k++) clump(scene::TRUNK_X + mx[k], my[k], 7, 3, moss, k * 13);
  }
  // 樹冠：先鋪一層暗色的底 (葉團之間的縫隙)，再疊上葉團
  curTag = T_CANOPY;
  const C3 base = leafBase();
  // 0 受光、1 一般、2 背光 (樹冠下緣)、3 秋天的金黃
  const Pal pals[4] = {makePal(base, 1.1f), makePal(base, 0.92f), makePal(base, 0.68f), makePal(c3(0xE0A030), 1.0f)};
  const float au = season::weight(AUTUMN);
  struct B { int x, y, r; } blobs[] = {{52, 30, 30}, {20, 46, 22}, {86, 40, 24}, {40, 62, 18}, {70, 62, 16}, {102, 58, 13},
                                        {6, 64, 13}, {60, 6, 22}, {26, 14, 18}, {96, 18, 17}, {114, 40, 11}};
  for (auto& bb : blobs) {
    const int r = bb.r - 3;
    for (int y = -r; y <= r; y++) for (int x = -r; x <= r; x++)
      if (x * x + y * y <= r * r) bset(bb.x + x, bb.y + y, pals[2].c[(util::hash2(bb.x + x, bb.y + y) & 3) ? 3 : 4]);
  }
  int bi = 0;
  for (auto& bb : blobs) {
    const int cnt = bb.r * bb.r / 26;
    for (int k = 0; k < cnt; k++) {
      const uint32_t h = util::hash32(bi * 977 + k * 131 + 5);
      const float a = (h & 0xFFFF) / 65535.0f * 6.283f, rr = sqrtf(((h >> 16) & 0xFF) / 255.0f) * bb.r;
      const int x = bb.x + (int)(cosf(a) * rr), y = bb.y + (int)(sinf(a) * rr * 0.9f);
      // 左上受光、下緣背光
      const float sc = ((h >> 24) & 0xFF) / 255.0f * 0.45f + (1.0f - (y + 10) / 90.0f) * 0.6f + (60 - x) / 300.0f;
      int pi = sc > 0.72f ? 0 : sc < 0.4f ? 2 : 1;
      if (au > 0.3f && ((h >> 5) & 7) < (uint32_t)(au * 3.5f)) pi = 3;
      clAdd(x, y, 7 + (h >> 28) % 4, pi, h);
    }
    bi++;
  }
  clFlush(pals);
  // 春天的小花
  float spr = season::weight(SPRING);
  if (spr > 0.3f) {
    const uint16_t pink = litC(c3(0xFFC8DC)), white = litC(c3(0xFFF4F8));
    for (int k = 0; k < (int)(70 * spr); k++) {
      auto& bb = blobs[util::hash32(k * 7) % 11];
      float a = util::hashf(k, 3) * 6.28f, r = util::hashf(k, 5) * bb.r * 0.9f;
      const int x = bb.x + (int)(cosf(a) * r), y = bb.y + (int)(sinf(a) * r);
      bset(x, y, (k & 1) ? pink : white); bset(x + 1, y, (k & 1) ? pink : white);
    }
  }
}

void bakeRocksLog() {
  curTag = T_ROCK;
  // 河岸的圓石
  for (int k = 0; k < 14; k++) {
    float x, y, hw, dx, dy;
    scene::riverAt(0.03f + k * 0.07f, x, y, &hw, &dx, &dy);
    for (int side = -1; side <= 1; side += 2) {
      const uint32_t h = util::hash32(k * 2 + side + 77);
      if ((h & 3) == 0) continue;  // 留一些缺口
      const float off = hw + 3 + (h >> 4) % 3;
      rock((int)(x - dy * side * off), (int)(y + dx * side * off), 4 + (h >> 8) % 3, 3 + (h >> 12) % 2);
    }
  }
  rock(scene::ROCK1_X, scene::ROCK1_Y, 15, 10);
  rock(scene::ROCK1_X + 13, scene::ROCK1_Y + 4, 7, 5);
  rock(scene::ROCK2_X, scene::ROCK2_Y, 11, 7);
  // 石頭頂上的苔蘚
  {
    curTag = T_NORMAL;
    const Pal moss = makePal(seasonMix(0x7CC84A, 0x6ABA40, 0x9AB840, 0x8CA08A), 1.0f);
    clump(scene::ROCK1_X - 3, scene::ROCK1_Y - 9, 9, 3, moss, 5);
    clump(scene::ROCK2_X - 1, scene::ROCK2_Y - 6, 7, 3, moss, 9);
  }

  const plant::Deadwood& lg = plant::log();
  if (!lg.state) return;
  curTag = T_LOG;
  const C3 b1 = c3(0x7A5230), b2 = c3(0x4E3422), ring = c3(0xD2AA72), ringD = c3(0x8C6A44), moss = c3(0x78B446);
  for (int x = scene::LOG_X0; x <= scene::LOG_X1; x++) {
    for (int y = -5; y <= 4; y++) {
      C3 c = y < -2 ? b1 : y > 2 ? b2 : (util::vnoise(x * 0.5f, y * 0.6f) > 0.6f ? b2 : b1);
      if (lg.state >= 2 && y < -2 && util::vnoise(x * 0.3f, 7) > 0.45f) c = moss;
      bset(x, scene::LOG_Y + y, litC(c));
    }
  }
  for (int y = -5; y <= 4; y++) for (int x = -3; x <= 3; x++) {
    float d = (x * x) / 9.0f + (y * y) / 25.0f;
    if (d <= 1) bset(scene::LOG_X1 + x, scene::LOG_Y + y, litC(d < 0.25f ? ringD : ring));
  }
}

uint32_t albedoSignature() {
  uint32_t s = 0;
  for (int i = 0; i < 4; i++) s = s * 31 + (uint32_t)(season::weight((Season)i) * 10);
  s = s * 31 + plant::log().state;
  s = s * 31 + (uint32_t)(snowCover * 6);
  return s;
}
uint32_t lightSignature() {
  uint32_t s = (tint.r >> 3) | ((tint.g >> 3) << 6) | ((tint.b >> 3) << 12);
  s ^= ((uint32_t)(skyHor.r / 6)) << 18 ^ ((uint32_t)(skyTop.b / 6)) << 23;
  s ^= ((uint32_t)(skyHor.g / 6)) * 0x9E3779B1u ^ ((uint32_t)(skyTop.r / 6)) * 0x85EBCA6Bu;
  return s;
}

// 重算材質層 (慢：雜訊紋理)：只在季節/枯木/積雪改變時
void bakeAlbedo(uint32_t ms) {
  const Tint saved = tint;
  tint = Tint{};  // 中性光
  bakeSky();
  bakeFar();
  bakeMidTrees();
  bakeGround();
  bakePond();
  bakeRocksLog();
  bakeTree();
  bakeFinish();
  tint = saved;
  lastBake = ms;
  Serial.printf("[Render] albedo bake %lu ms\n", (unsigned long)(millis() - ms));
}

// 套用目前光照與天空顏色到背景 (快)
void relight(uint32_t ms) {
  const uint16_t farA = litC(mixc(skyHor, c3(0x7FAAA0), 0.5f)), farB = litC(mixc(skyHor, c3(0x4E8878), 0.68f));  // 霧裡的樹影
  const C3 con = vivid(mixc(skyHor, c3(0x1C4640), 0.82f));  // 深色的樹林當背景，前面的東西才跳得出來
  const uint16_t conL = litC({con.r * 1.2f, con.g * 1.22f, con.b * 1.12f}), conD = litC({con.r * 0.74f, con.g * 0.76f, con.b * 0.82f});
  // 遠山的亮面/暗面/本色 (far[albedo])
  const C3 fa = mixc(skyHor, c3(0x7FAAA0), 0.5f), fb_ = mixc(skyHor, c3(0x4E8878), 0.68f);
  const uint16_t farAs[3] = {farA, litC(mixc(fa, skyHor, 0.35f)), litC({fa.r * 0.88f, fa.g * 0.88f, fa.b * 0.9f})};
  const uint16_t farBs[2] = {farB, litC(mixc(fb_, skyHor, 0.3f))};
  const C3 deep = vivid({24, 82, 128}), refl = vivid(mixc(skyTop, skyHor, 0.6f), 1.0f + (cfg::BG_VIVID - 1.0f) * 0.7f);
  const uint32_t tr = tint.r, tg = tint.g, tb = tint.b;
  // 光束強度 (0..10/32)：只有晴朗的白天才有
  const float rayA = util::clamp01(timem::dayFactor() * 1.3f - 0.3f) * util::clamp01(1.0f - eco::env.cloud * 1.6f) * (1.0f - eco::env.fog) * 13.0f;
  const uint32_t rayX = expand565(rgb(0xFFF4C0));
  for (int y = 0; y < FH; y++) {
    float f = util::clamp01(y / 150.0f);
    f = f * f * 0.6f + f * 0.4f;
    const C3 sc = mixc(skyTop, skyHor, f);
    // 天空的抖色只和 (x & 3) 有關，每列先算好 4 個顏色
    uint16_t skyRow[4];
    for (int k = 0; k < 4; k++) {
      const float d = (BAYER[(y & 3) * 4 + k] - 7.5f) * 0.9f;
      skyRow[k] = rgb((uint8_t)util::clamp(sc.r + d, 0.f, 255.f), (uint8_t)util::clamp(sc.g + d, 0.f, 255.f), (uint8_t)util::clamp(sc.b + d, 0.f, 255.f));
    }
    uint16_t* out = bg + y * FW;
    const uint16_t* al = albedo + y * FW;
    const uint8_t* tg8 = tags + y * FW;
    for (int x = 0; x < FW; x++) {
      switch (tg8[x]) {
        case T_SKY: out[x] = skyRow[x & 3]; break;
        case T_FAR_A: out[x] = farAs[al[x] > 2 ? 0 : al[x]]; break;
        case T_FAR_B: out[x] = farBs[al[x] ? 1 : 0]; break;
        case T_CONIFER: out[x] = conL; break;
        case T_CONIFER_D: out[x] = conD; break;
        case T_POND: {
          C3 c = mixc(deep, refl, al[x] / 255.0f);
          float d = (BAYER[(y & 3) * 4 + (x & 3)] - 7.5f) * 0.8f;
          out[x] = litC({c.r + d, c.g + d, c.b + d});
          break;
        }
        default: {
          const uint16_t c = al[x];
          uint32_t r = ((c >> 11) * tr) >> 8, g = (((c >> 5) & 63) * tg) >> 8, b = ((c & 31) * tb) >> 8;
          out[x] = (uint16_t)(((r > 31 ? 31 : r) << 11) | ((g > 63 ? 63 : g) << 5) | (b > 31 ? 31 : b));
        }
      }
    }
    // 晴朗白天的光束：從右上斜照到左下，直接烘進背景 (不佔每幀時間)
    if (rayA > 0 && y < 222) {
      static const int RC[3] = {218, 252, 288}, RW[3] = {22, 12, 26};
      const float fade = y < 150 ? 1.0f : (222 - y) / 72.0f;
      for (int k = 0; k < 3; k++) {
        const int c0 = RC[k] - (int)(y * 0.55f);
        for (int x = c0 - RW[k] / 2; x <= c0 + RW[k] / 2; x++) {
          if ((unsigned)x >= (unsigned)FW || tg8[x] == T_SKY) continue;
          const int edge = abs(x - c0) > RW[k] / 2 - 3 ? 1 : 2;  // 邊緣淡一階
          out[x] = blendFast(out[x], rayX, (uint32_t)(rayA * fade * edge * 0.5f + 0.5f));
        }
      }
    }
  }
  lastRelight = ms;
}

// ---------- 天空物件 (只畫在天空像素) ----------
void skyPset(int x, int y, uint16_t c) { if (isSky(x, y)) pset(x, y, c); }
void skyAdd(int x, int y, int r, int g, int b) { if (isSky(x, y)) padd(x, y, r, g, b); }
void skyGlow(int cx, int cy, int r, uint32_t hex, uint8_t in) {
  // 在 120 畫布上逐像素計算 (避免世界座標重複疊加)
  const bool w = world;
  if (w) { cx >>= 1; cy >>= 1; r = r > 2 ? r >> 1 : 1; world = false; }
  const int R = hex >> 16, G = (hex >> 8) & 0xFF, B = hex & 0xFF, r2 = r * r;
  for (int y = -r; y <= r; y++) for (int x = -r; x <= r; x++) {
    int d2 = x * x + y * y;
    if (d2 > r2) continue;
    int f = (r2 - d2) * 256 / r2; f = f * f >> 8; f = f * in >> 8;
    if (f > 2) skyAdd(cx + x, cy + y, R * f >> 8, G * f >> 8, B * f >> 8);
  }
  world = w;
}

void drawStars(float night) {
  const eco::Env& e = eco::env;
  float vis = night * (1 - e.cloud * 0.85f) * (1 - e.fog);
  if (vis < 0.05f) return;
  world = false;  // 星星座標是 120 畫布座標
  for (int i = 0; i < 56; i++) {
    const Star& s = stars[i];
    float tw = 0.6f + 0.4f * sinf(t * (0.8f + (i % 5) * 0.3f) + i);
    int v = (int)(s.b * tw * vis);
    if (v < 8) continue;
    skyAdd(s.x, s.y, v, v, v * 9 / 8);
    if (s.b > 200 && v > 120) { skyAdd(s.x + 1, s.y, v / 3, v / 3, v / 3); skyAdd(s.x - 1, s.y, v / 3, v / 3, v / 3); skyAdd(s.x, s.y + 1, v / 3, v / 3, v / 3); skyAdd(s.x, s.y - 1, v / 3, v / 3, v / 3); }
  }
  world = true;
}

void drawSunMoon() {
  const float h = timem::local().hourF, rise = timem::sunriseH(), set = timem::sunsetH();
  const eco::Env& e = eco::env;
  float vis = 1 - e.cloud * 0.8f - e.fog * 0.5f;
  moonPx = -1;
  if (h > rise - 0.3f && h < set + 0.3f) {
    float u = (h - rise) / (set - rise);
    int x = 20 + (int)(200 * u), y = 128 - (int)(112 * sinf(util::clamp01(u) * 3.1416f));
    float low = util::clamp01(1 - fabsf(timem::sunElev()) * 3);
    uint32_t col = hexOf(mixc(c3(0xFFF5C8), c3(0xFF9A50), low));
    if (vis > 0.1f) skyGlow(x, y, 22, col, (uint8_t)(120 * vis));
    Fine fine;  // 原生像素的圓
    for (int yy = -10; yy <= 10; yy++) for (int xx = -10; xx <= 10; xx++)
      if (xx * xx + yy * yy <= 105 && isSky((x + xx) >> 1, (y + yy) >> 1)) {
        uint16_t c = rgb(col);
        if (vis < 0.4f) c = mix(pget(x + xx, y + yy), c, (uint8_t)(255 * (vis + 0.25f)));
        pset(x + xx, y + yy, c);
      }
  }
  // 月亮：夜間沿弧線移動
  float nh = h >= set ? h - set : h + 24 - set;
  float nlen = rise + 24 - set;
  if (h > set - 0.5f || h < rise + 0.5f) {
    float u = util::clamp01(nh / nlen);
    int x = 220 - (int)(200 * u), y = 120 - (int)(96 * sinf(u * 3.1416f));
    if (vis > 0.3f && e.night > 0.5f && eco::moon() != eco::MOON_NEW) moonPx = x;
    float ph = timem::moonPhase();
    float illum = 1 - fabsf(ph - 0.5f) * 2;  // 0 新月 .. 1 滿月
    if (vis > 0.1f) skyGlow(x, y, 16, 0xC8D2FF, (uint8_t)(70 * vis * (0.3f + illum)));
    // 用位移的暗圓做月相
    float off = (ph < 0.5f ? 1 : -1) * (1 - illum) * 18;
    Fine fine;  // 原生像素的圓
    for (int yy = -9; yy <= 9; yy++) for (int xx = -9; xx <= 9; xx++) {
      if (xx * xx + yy * yy > 74 || !isSky((x + xx) >> 1, (y + yy) >> 1)) continue;
      float sx = xx - off;
      bool shadow = (sx * sx + yy * yy) <= 74 && illum < 0.97f;
      if (ph > 0.03f && ph < 0.97f && !shadow) {
        uint16_t c = rgb(0xEEF0FF);
        const int dx1 = xx - 3, dy1 = yy + 2, dx2 = xx + 4, dy2 = yy - 3;
        if (dx1 * dx1 + dy1 * dy1 <= 3 || dx2 * dx2 + dy2 * dy2 <= 5) c = rgb(0xC8CCE0);  // 坑洞
        pset(x + xx, y + yy, vis < 0.4f ? mix(pget(x + xx, y + yy), c, (uint8_t)(255 * (vis + 0.25f))) : c);
      }
    }
  }
}

void drawClouds(float dt) {
  const eco::Env& e = eco::env;
  int n = 1 + (int)(e.cloud * 6.5f);
  float speed = 2 + e.wind * 14;
  C3 lightC = mixc(skyHor, {250, 250, 252}, 0.7f * timem::dayFactor() + 0.1f);
  C3 darkC = mixc(skyTop, {90, 95, 105}, 0.5f);
  if (e.storm > 0.2f || e.rain > 0.4f) lightC = mixc(lightC, {110, 115, 125}, 0.6f);
  // 夕陽時雲染成橘紅
  float low = util::clamp01(1 - fabsf(timem::sunElev()) * 3.5f) * timem::dayFactor();
  lightC = mixc(lightC, c3(0xFFA078), low * 0.6f);
  const uint16_t cl = rgb(hexOf(lightC)), cd = rgb(hexOf(mixc(lightC, darkC, 0.45f)));
  for (int i = 0; i < 7; i++) {
    Cloud& c = clouds[i];
    c.x += speed * dt * (0.6f + i * 0.08f);
    if (c.x > cfg::W + 40) { c.x = -40; c.y = 8 + util::rng.range(0, 60); c.s = util::rng.range(0.7f, 1.4f); }
    if (i >= n) continue;
    uint8_t a = (uint8_t)(150 + e.cloud * 100);
    int r = (int)(4 * c.s) + 1;
    const int ox[5] = {0, 5, -5, 2, -2}, oy[5] = {0, 1, 1, -2, -2};
    Fine fine;  // 雲以原生像素畫，邊緣才圓滑
    for (int k = 0; k < 5; k++) {
      const int rr = (k < 3 ? r : r - 1) * 2;
      const int cx = (int)c.x + (int)(ox[k] * c.s * 2), cy = (int)c.y + (int)(oy[k] * c.s * 2);
      const int ra2 = (rr + 2) * (rr + 2), rb2 = rr * rr;
      const uint32_t a32 = (a + 4) >> 3;
      for (int y = -rr; y <= rr / 2 + 2; y++) {
        const int py = cy + y;
        if ((unsigned)py >= (unsigned)FH) continue;
        // 這一列的半寬只算一次，再直接寫入畫面緩衝
        const int hw = (int)sqrtf((float)(ra2 * rb2 - y * y * ra2) / rb2);
        int xa = cx - hw, xb = cx + hw;
        if (xa < 0) xa = 0;
        if (xb > FW - 1) xb = FW - 1;
        const uint32_t fgx = expand565(y > rr / 3 ? cd : cl);
        uint16_t* row = fb + py * FW;
        for (int px = xa; px <= xb; px++) if (isSky(px >> 1, py >> 1)) row[px] = blendFast(row[px], fgx, a32);
      }
    }
  }
}

// ---------- 植物 ----------
const uint32_t FLOWER_COL[4][2] = {{0xFF8CB4, 0xFFD2E6}, {0xFFD24B, 0xFFF0A0}, {0x8C8CFF, 0xC8C8FF}, {0xF5F5F5, 0xFFFFFF}};

void drawFlower(int x, int y, const plant::Plant& p, float g, float sway) {
  const uint16_t stem = lit(p.stage == plant::S_WITHER || p.stage == plant::S_DORMANT ? 0x7D7350 : 0x4E9A3E);
  const uint16_t leaf = lit(p.stage == plant::S_WITHER ? 0x8C8250 : 0x64B44E);
  if (p.stage == plant::S_SEED) { pset(x, y - 1, lit(0x6E5A3C)); return; }
  int h = 2 + (int)(8 * g);
  int tx = x + (int)(sway * h * 0.3f);
  for (int i = 0; i < h; i++) pset(x + (int)(sway * i * 0.3f), y - i, stem);
  if (h > 4) { pset(x - 1, y - h / 3, leaf); pset(x - 2, y - h / 3 + 1, leaf); pset(x + 1, y - h / 2, leaf); pset(x + 2, y - h / 2 + 1, leaf); }
  int hy = y - h;
  const uint32_t* col = FLOWER_COL[p.variant & 3];
  static const uint32_t RARE_COL[2] = {0xFFD24B, 0xFFF5C8};
  const bool rare = p.variant & 0x10;  // 稀有/變異的花：金色並在夜裡發光
  if (rare) col = RARE_COL;
  if (rare && p.stage == plant::S_BLOOM) glow(x + (int)(sway * h * 0.3f), y - h, 5, 0xFFE68C, (uint8_t)(70 + 110 * eco::env.night));
  const eco::Env& e = eco::env;
  if (p.stage == plant::S_BLOOM) {
    // 夜晚/高溫時花朵閉合
    float open = (1 - e.night * 0.7f) * (e.hot ? 0.5f : 1.0f);
    if (open > 0.5f) {
      const int ox[5] = {-2, 2, 0, -1, 1}, oy[5] = {0, 0, -2, 2, 2};
      for (int k = 0; k < 5; k++) { pset(tx + ox[k], hy + oy[k], lit(col[0])); pset(tx + ox[k] / 2, hy + oy[k] / 2, lit(col[1])); }
      pset(tx, hy, lit(0xFFC83C));
    } else {
      pset(tx, hy, lit(col[0])); pset(tx, hy - 1, lit(col[0])); pset(tx - 1, hy, lit(col[1])); pset(tx + 1, hy, lit(col[1]));
    }
  } else if (p.stage == plant::S_MATURE) {
    pset(tx, hy, lit(0x5AA046)); pset(tx, hy - 1, lit(col[0]));
  } else if (p.stage == plant::S_WITHER) {
    pset(tx + 1, hy + 1, lit(0x8C643C)); pset(tx + 2, hy + 2, lit(0x6E4E32));
  }
}

void drawMushroom(int x, int y, const plant::Plant& p, float g) {
  if (p.stage == plant::S_SEED) return;
  const bool glowType = (p.variant & 3) >= 2 || (p.variant & 0x10);  // 變異的蘑菇也會發光
  static const uint32_t CAP[4] = {0xC8463C, 0x9A6440, 0x46B4B4, 0xA064DC};
  const eco::Env& e = eco::env;
  int sh = 1 + (int)(5 * g), rx = 1 + (int)(4 * g), ry = 1 + (int)(2 * g);
  uint32_t capc = CAP[p.variant & 3];
  if (p.stage == plant::S_WITHER) capc = 0x6E5A46;
  if (glowType && e.night > 0.3f && p.stage >= plant::S_GROW && p.stage != plant::S_WITHER) {
    float fl = eventm::lightning(millis());
    glow(x, y - sh - 1, 6 + rx, capc, (uint8_t)(e.night * 150 * (0.8f + 0.2f * sinf(t * 1.5f + x)) + fl * 100));
  }
  for (int i = 0; i < sh; i++) { pset(x, y - i, lit(0xF0E6D2)); if (g > 0.6f) pset(x + 1, y - i, lit(0xD2C8B4)); }
  bool unlit = glowType && e.night > 0.5f;
  uint16_t c = unlit ? rgb(capc) : lit(capc);
  // 菌傘：頂端亮、傘緣暗，有立體感
  const uint16_t cHi = mix(c, rgb(0xFFFFFF), 60), cLo = mix(c, rgb(0x000000), 80);
  for (int yy = -ry; yy <= 0; yy++) for (int xx = -rx; xx <= rx; xx++)
    if ((xx * xx) * ry * ry + (yy * yy) * rx * rx <= rx * rx * ry * ry)
      pset(x + xx, y - sh + yy, (ry >= 2 && yy == 0) ? cLo : (ry >= 2 && yy == -ry && xx <= 0) ? cHi : c);
  if (rx >= 3 && p.stage != plant::S_WITHER) { pset(x - 1, y - sh - 1, lit(0xFAF0DC)); pset(x + 2, y - sh, lit(0xFAF0DC)); }
}

void drawSapling(int x, int y, const plant::Plant& p, float g, float sway) {
  const uint16_t trunk = lit(0x6E4E36), trunkL = lit(0x8C6A4A);
  if (p.stage == plant::S_SEED) { pset(x, y - 1, lit(0x8C643C)); return; }
  int h = 3 + (int)(24 * g);
  int w = g > 0.6f ? 2 : 1;
  for (int i = 0; i < h; i++) for (int j = 0; j < w; j++) pset(x + j + (int)(sway * i * 0.08f), y - i, j ? trunk : trunkL);
  int cr = 2 + (int)(8 * g);
  int cx = x + (int)(sway * h * 0.08f), cy = y - h;
  C3 base = seasonMix(0x78BE5A, 0x5AA54B, 0xE69641, 0x8C826E);
  if (p.stage == plant::S_WITHER) base = c3(0x8C7850);
  bool bare = season::weight(WINTER) > 0.6f || p.stage == plant::S_DORMANT;
  for (int yy = -cr; yy <= cr; yy++) for (int xx = -cr; xx <= cr; xx++) {
    float d = sqrtf((float)(xx * xx + yy * yy));
    if (d > cr + (util::hashf(xx + x, yy) - 0.5f) * 2) continue;
    if (bare && util::hashf(xx * 3 + x, yy * 5) > 0.35f) continue;
    float sh = (-xx - yy) / (float)(cr * 2) + util::vnoise((xx + x) * 0.4f, (yy + cy) * 0.4f) * 0.5f;
    float k = sh > 0.5f ? 1.2f : sh > 0.15f ? 1.0f : 0.75f;
    pset(cx + xx, cy + yy, litC({base.r * k, base.g * k, base.b * k}));
  }
  if (p.stage >= plant::S_MATURE && season::weight(SPRING) > 0.4f && !bare)
    for (int k = 0; k < cr; k++) pset(cx + (int)((util::hashf(k, x) - 0.5f) * cr * 1.6f), cy + (int)((util::hashf(x, k) - 0.5f) * cr * 1.6f), lit(0xFFD2E6));
}

void drawVine(const plant::Plant& p, float g) {
  int len = 6 + (int)(80 * g);
  const uint16_t vine = lit(p.stage == plant::S_DORMANT ? 0x6E6446 : 0x4E8C3C), leafc = lit(p.stage == plant::S_DORMANT ? 0x8C7850 : 0x6EB450);
  for (int i = 0; i < len; i++) {
    int y = scene::TRUNK_TOP + i;
    int x = scene::TRUNK_X - 6 + (int)(sinf(i * 0.15f + t * 0.3f * eco::env.wind) * 4) + (int)(sinf(i * 0.05f) * 3);
    pset(x, y, vine);
    if (i % 6 == 0) { pset(x + 1, y, leafc); pset(x + 2, y - 1, leafc); }
    if (i % 6 == 3) { pset(x - 1, y, leafc); pset(x - 2, y - 1, leafc); }
    if (p.stage == plant::S_BLOOM && i % 11 == 5) { pset(x + 1, y + 1, lit(0xE6C8FF)); pset(x + 2, y + 1, lit(0xFFFFFF)); }
  }
}

void drawMoss(int i, const plant::Plant& p, float g) {
  const plant::Slot& s = plant::SLOTS[i];
  const uint16_t m1 = lit(p.stage == plant::S_DORMANT ? 0x7D8250 : 0x6EAA46), m2 = lit(0x4E8C3C), m3 = lit(0x96C85A);
  int n = (int)(g * 40);
  int rx = s.zone == plant::Z_ROCK ? 12 : s.zone == plant::Z_TRUNK ? 6 : 8;
  int baseY = s.zone == plant::Z_ROCK ? s.y : s.y;
  if (s.zone == plant::Z_LOG) rx = 10;
  for (int k = 0; k < n; k++) {
    float a = util::hashf(k, i * 7), r = util::hashf(i, k * 3);
    int x = s.x + (int)((a - 0.5f) * 2 * rx);
    int y = baseY + (int)((r - 0.5f) * (s.zone == plant::Z_TRUNK ? 20 : 4));
    if (s.zone == plant::Z_ROCK) y = scene::ROCK1_Y - 8 + (int)(fabsf(a - 0.5f) * 8) + (i == 16 ? scene::ROCK2_Y - scene::ROCK1_Y + 2 : 0);
    uint16_t c = k % 5 == 0 ? m3 : k % 3 == 0 ? m2 : m1;
    pset(x, y, c);
    if (k % 2 == 0) pset(x + 1, y, c);
  }
}

void drawGlowPlant(int x, int y, const plant::Plant& p, float g) {
  const eco::Env& e = eco::env;
  if (p.stage == plant::S_SEED) return;
  static const uint32_t GC[4] = {0x64E6FF, 0xB48CFF, 0x8CFFB4, 0xFFB4F0};
  uint32_t gc = GC[p.variant & 3];
  int h = 2 + (int)(7 * g);
  const uint16_t stem = lit(0x3C7864);
  for (int s = -1; s <= 1; s++) {
    int hh = h - abs(s) * 2;
    for (int i = 0; i < hh; i++) pset(x + s * (i / 3), y - i, stem);
    int bx = x + s * (hh / 3), by = y - hh;
    bool bright = p.stage == plant::S_BLOOM || (p.stage == plant::S_MATURE && e.night > 0.5f);
    if (p.stage >= plant::S_GROW && p.stage != plant::S_WITHER) {
      float pulse = 0.7f + 0.3f * sinf(t * 1.2f + x + s);
      if (bright) glow(bx, by, 5, gc, (uint8_t)((60 + e.night * 160 + e.magic * 80) * pulse));
      pset(bx, by, bright && e.night > 0.3f ? rgb(gc) : lit(gc));
    }
  }
}

void drawReed(int x, int y, const plant::Plant& p, float g, float sway) {
  bool dry = p.stage == plant::S_DORMANT || season::weight(WINTER) > 0.6f;
  const uint16_t c = lit(dry ? 0xA08C5A : 0x5A9A46), c2 = lit(dry ? 0x8C7846 : 0x46823C);
  int n = 2 + (int)(3 * g);
  for (int k = 0; k < n; k++) {
    int h = 4 + (int)(9 * g) - (k & 1) * 3;
    int ox = (k - n / 2) * 2;
    for (int i = 0; i < h; i++) pset(x + ox + (int)(sway * i * 0.25f * (1 + k * 0.2f)), y - i, (k & 1) ? c2 : c);
    if (p.stage >= plant::S_MATURE && k == 1) {
      int tx = x + ox + (int)(sway * h * 0.25f * 1.2f);
      for (int i = 0; i < 3; i++) { pset(tx, y - h - i, lit(0x6E4630)); pset(tx + 1, y - h - i, lit(0x5A3A28)); }
    }
  }
}

void drawLily(int x, int y, const plant::Plant& p, float g) {
  if (p.stage == plant::S_SEED || p.stage == plant::S_DORMANT) return;
  int rx = 2 + (int)(3 * g), ry = 1 + (int)(1 * g);
  float bob = sinf(t * 0.8f + x) * 0.6f;
  int yy = y + (int)bob;
  const uint16_t pad = lit(0x5AA046), padD = lit(0x3C7D37);
  for (int j = -ry; j <= ry; j++) for (int i = -rx; i <= rx; i++) {
    if (i * i * ry * ry + j * j * rx * rx > rx * rx * ry * ry) continue;
    if (i > 0 && j < 0 && i > -j * 2) continue;  // 缺口
    pset(x + i, yy + j, j > 0 ? padD : pad);
  }
  if (p.stage == plant::S_BLOOM) {
    pset(x - 1, yy - 2, lit(0xFFB4D2)); pset(x + 1, yy - 2, lit(0xFFB4D2)); pset(x, yy - 3, lit(0xFFE6F0)); pset(x, yy - 2, lit(0xFFE678));
  }
}

void drawPlant(int i) {
  const plant::Plant& p = plant::get(i);
  if (p.species == plant::P_NONE) return;
  const plant::Slot& s = plant::SLOTS[i];
  float g = plant::growthFrac(i);
  float sway = sinf(t * (1.2f + eco::env.wind * 2) + i * 1.7f) * (0.3f + eco::env.wind * 1.6f);
  // 藤蔓、苔蘚貼著場景物件，用世界座標；其他植物在 120 畫布上以 1:1 像素畫 (螢幕上 2 倍大)
  const int x = s.x >> 1, y = s.y >> 1;
  world = p.species == plant::P_VINE || p.species == plant::P_MOSS;
  switch (p.species) {
    case plant::P_FLOWER: drawFlower(x, y, p, g, sway); break;
    case plant::P_MUSHROOM: drawMushroom(x, y, p, g); break;
    case plant::P_SAPLING: drawSapling(x, y, p, g, sway * 0.5f); break;
    case plant::P_VINE: drawVine(p, g); break;
    case plant::P_MOSS: {  // 苔蘚是貼在表面的零碎小點，不描邊 (直接畫到畫面)
      const bool lo = layerOn;
      layerOn = false;
      drawMoss(i, p, g);
      layerOn = lo;
      break;
    }
    case plant::P_GLOW: drawGlowPlant(x, y, p, g); break;
    case plant::P_REED: drawReed(x, y, p, g, sway); break;
    case plant::P_LILY: drawLily(x, y, p, g); break;
    default: break;
  }
  // 月光照耀下植物發光 (事件)
  if (moonGlowOn && p.species != plant::P_VINE && p.species != plant::P_MOSS && p.stage >= plant::S_GROW)
    glow(world ? s.x : x, world ? s.y - 10 : y - 5, world ? 8 : 4, 0xC8E6FF, 70);
  world = true;
}

void drawNest() {
  float n = creature::nestProgress();
  if (n < 0.1f) return;
  int w = 2 + (int)(5 * n);
  const uint16_t c1 = lit(0x8C643C), c2 = lit(0x6E4A2E);
  for (int i = -w; i <= w; i++) {
    pset(scene::NEST.x + i, scene::NEST.y, (i & 1) ? c1 : c2);
    if (abs(i) < w - 1) pset(scene::NEST.x + i, scene::NEST.y + 1, c2);
    if (n > 0.6f && abs(i) == w) pset(scene::NEST.x + i, scene::NEST.y - 1, c1);
  }
}

// ---------- 水面、天氣 ----------
void drawWater() {
  const uint16_t hl = lit(hexOf(mixc(skyHor, {255, 255, 255}, 0.3f)));
  world = false;
  // 反光沿著河道往下游流動
  for (int k = 0; k < 10; k++) {
    float x, y, hw, dx, dy;
    scene::riverAt(fmodf(t * 0.03f + k * 0.1f, 1.0f), x, y, &hw, &dx, &dy);
    const float side = (float)((k * 7) % 5 - 2) * 0.3f * hw;  // 偏離中心線 (-0.6..0.6 半寬)
    x -= dy * side; y += dx * side;
    const int len = 2 + (k & 1);
    for (int i = 0; i < len; i++) {
      const float px = x + dx * i * 2, py = y + dy * i * 2;
      if (scene::inPond(px, py, 3)) pblend((int)px >> 1, (int)py >> 1, hl, 110);
    }
  }
  world = true;
  // 瀑布：往下流的白色水花與底部的水霧
  {
    Fine fine;
    const uint16_t wc = lit(0xF4FBFF);
    const int fh = FALL_Y1 - FALL_Y0;
    for (int k = 0; k < 12; k++) {
      const int x = FALL_X0 + 1 + (int)(util::hash32(k * 17 + 3) % (FALL_X1 - FALL_X0 - 1));
      const int y = FALL_Y0 + (int)fmodf(t * (38 + (k % 4) * 9) + k * 7.3f, (float)fh);
      for (int i = 0; i < 4; i++) pblend(x, y + i, wc, (uint8_t)(210 - i * 40));
    }
    for (int k = 0; k < 8; k++) {
      const uint32_t h = util::hash32(k * 31 + (uint32_t)(t * 9));
      pblend(FALL_X0 - 4 + (int)(h % 17), FALL_Y1 - 1 + (int)((h >> 8) % 5), wc, 170);
    }
  }
}

void drawRain(uint32_t ms) {
  const eco::Env& e = eco::env;
  const bool magic = eco::blessing(ms);
  float amount = fmaxf(e.rain, magic ? 0.35f : 0);
  if (amount < 0.02f && e.snow < 0.02f) return;
  const float slant = 0.15f + e.wind * 0.6f;
  world = false;  // 雨雪直接在 120 畫布上畫，一滴就是一顆像素
  if (amount >= 0.02f) {
    int n = (int)(amount * 90);
    // 雨滴不完全跟著變暗，夜裡仍看得見
    const uint16_t rc = mix(lit(magic && e.rain < 0.2f ? 0xC8E6FF : 0xAABED7), rgb(0x8CA0BE), (uint8_t)(eco::env.night * 140));
    for (int i = 0; i < n; i++) {
      uint32_t h = util::hash32(i * 7919 + 13);
      float spd = 85 + (h & 31);
      float y = fmodf((h >> 8) % 130 + t * spd, 130.0f) - 10;
      float x = fmodf((h >> 16) % 140 + y * slant + 150, 140.0f) - 10;
      int len = 2 + (int)(amount * 1.5f);
      for (int k = 0; k < len; k++) pblend((int)(x - k * slant), (int)y - k, rc, (uint8_t)(150 - k * 25));
      if (magic && (i % 9) == 0) padd((int)x, (int)y, 40, 50, 70);
    }
  }
  if (e.snow >= 0.02f) {
    int n = (int)(e.snow * 60);
    const uint16_t sc = lit(0xF5F8FF);
    for (int i = 0; i < n; i++) {
      uint32_t h = util::hash32(i * 104729 + 7);
      float y = fmodf((h >> 8) % 130 + t * (9 + (h & 7)), 130.0f) - 10;
      float x = fmodf((h >> 16) % 130 + sinf(t * 0.7f + i) * 3 + y * e.wind * 0.5f, 130.0f) - 5;
      pset((int)x, (int)y, sc);
    }
  }
  world = true;
}

void drawFog() {
  const eco::Env& e = eco::env;
  if (e.fog < 0.03f) return;
  float b = 0.3f + 0.7f * timem::dayFactor();
  uint16_t fc = rgb((uint8_t)(205 * b + 20), (uint8_t)(210 * b + 20), (uint8_t)(215 * b + 25));
  const uint32_t fcx = expand565(fc);
  // 霧的濃淡在 4x4 的粗網格上計算 (省 CPU)，再用 Bayer 抖色過渡，保持像素風
  constexpr int Y0 = 20, CW = W / 4 + 1, CH = (H - Y0) / 4 + 2;  // 120 畫布座標
  static uint8_t grid[CH][CW];
  for (int cy = 0; cy < CH; cy++) {
    const int y = (Y0 + cy * 4) * 2;  // 換算成世界座標判斷高度
    // 垂直漸層：上方淡入、遠景最濃、近景較淡 (避免出現水平分界線)
    float depth = y < 110 ? util::smooth((y - Y0 * 2) / 70.0f) : y < 165 ? 1.0f : 1.0f - (y - 165) / 120.0f;
    for (int cx = 0; cx < CW; cx++) {
      float n = util::vnoise(cx * 0.24f + t * 0.05f, cy * 0.48f);
      int a = (int)(e.fog * (0.45f + 0.4f * n) * depth * 230);
      grid[cy][cx] = (uint8_t)(a > 220 ? 220 : a < 0 ? 0 : a);
    }
  }
  for (int y = Y0; y < H; y++) {
    const int gy = (y - Y0) >> 2, fy = (y - Y0) & 3;
    for (int x = 0; x < W; x++) {
      const int gx = x >> 2, fx = x & 3;
      // 在相鄰兩格之間用 Bayer 門檻挑選，產生平滑的抖色漸層
      const uint8_t th = BAYER[fy * 4 + fx];
      const int a = grid[gy + (fy * 4 > (int)th ? 1 : 0)][gx + (fx * 4 > (int)th ? 1 : 0)];
      if (a > 8) blendCanvasPx(x, y, fcx, (uint32_t)a >> 3);
    }
  }
}

void drawLightning(uint32_t ms) {
  float f = eventm::lightning(ms);
  if (f <= 0) return;
  // 遠方閃電：天空中的折線
  if (f > 0.7f) {
    uint32_t seed = ms / 1000;
    int x = 60 + util::hash32(seed) % 150, y = 0;
    const uint16_t c = rgb(0xF0F0FF);
    while (y < 100) {
      int nx = x + (int)(util::hash32(seed + y) % 9) - 4, ny = y + 6 + util::hash32(seed * 3 + y) % 6;
      for (int s = 0; s <= 6; s++) { int px = x + (nx - x) * s / 6, py = y + (ny - y) * s / 6; skyPset(px, py, c); skyAdd(px + 1, py, 80, 80, 100); }
      x = nx; y = ny;
    }
  }
}

// ---------- 事件特效 ----------
void drawEvents(uint32_t ms, bool groundLayer) {
  for (int i = 0; i < eventm::ACTIVE_CAP; i++) {
    const eventm::Active& a = eventm::active(i);
    if (!a.on) continue;
    float p = eventm::progress(a, ms);
    float fade = util::clamp01(fminf(p * 6, (1 - p) * 4));
    switch (a.id) {
      case eventm::R_METEOR: {
        if (groundLayer || p > 0.5f) break;
        float u = p * 2;
        int hx = (int)(a.x - u * 90) >> 1, hy = (int)(a.y + u * 40) >> 1;
        world = false;
        for (int k = 0; k < 12; k++) { int v = 255 - k * 20; skyAdd(hx + k, hy - k / 2, v, v, v * 9 / 10); }
        skyGlow(hx, hy, 2, 0xFFFFE6, 200);
        world = true;
        break;
      }
      case eventm::M_STARSIGN: {
        if (groundLayer) break;
        int idx[6];
        for (int k = 0; k < 6; k++) idx[k] = (a.seed >> (k * 4)) % 56;
        const uint16_t lc = rgb(0x8CC8FF);
        world = false;  // 星星是 120 畫布座標
        for (int k = 0; k < 5; k++) {
          const Star &s0 = stars[idx[k]], &s1 = stars[idx[k + 1]];
          int steps = abs(s1.x - s0.x) > abs(s1.y - s0.y) ? abs(s1.x - s0.x) : abs(s1.y - s0.y);
          if (steps < 1) steps = 1;
          for (int s = 0; s <= steps; s++) {
            int x = s0.x + (s1.x - s0.x) * s / steps, y = s0.y + (s1.y - s0.y) * s / steps;
            if (isSky(x, y)) pblend(x, y, lc, (uint8_t)(110 * fade));
          }
        }
        for (int k = 0; k < 6; k++) skyGlow(stars[idx[k]].x, stars[idx[k]].y, 2, 0xB4DCFF, (uint8_t)(220 * fade));
        world = true;
        break;
      }
      case eventm::R_RAINBOW: {
        if (groundLayer) break;
        static const uint32_t RB[6] = {0xFF6464, 0xFFAA50, 0xFFF064, 0x78E678, 0x64AAFF, 0xA078FF};
        world = false;
        for (int band = 0; band < 6; band++) {
          int r = 59 - band;
          uint16_t c = rgb(RB[band]);
          int lastX = -999, lastY = -999;
          for (int k = 0; k < 240; k++) {
            float ang = 3.1416f + k * 3.1416f / 240;
            int x = 75 + (int)(cosf(ang) * r * 1.2f), y = 88 + (int)(sinf(ang) * r);
            if (x == lastX && y == lastY) continue;  // 同一顆像素只疊一次
            lastX = x; lastY = y;
            if (isSky(x, y)) pblend(x, y, c, (uint8_t)(80 * fade));
            if (!util::reached(ms, evo::doubleRainbowUntil())) {  // 雙彩虹：外側較淡、顏色順序相反
              int x2 = 75 + (int)(cosf(ang) * (r + 8) * 1.2f), y2 = 88 + (int)(sinf(ang) * (r + 8));
              if (isSky(x2, y2)) pblend(x2, y2, rgb(RB[5 - band]), (uint8_t)(45 * fade));
            }
          }
        }
        world = true;
        break;
      }
      case eventm::R_DEEP_LIGHTS: {
        if (groundLayer) break;
        for (int k = 0; k < 6; k++) {
          float ph = (a.seed % 100) + k * 1.3f;
          int x = 135 + (int)(k * 17 + sinf(t * 0.4f + ph) * 6), y = 124 + (int)(sinf(t * 0.6f + ph * 2) * 5) + (k & 1) * 6;
          static const uint32_t LC[3] = {0xFFE68C, 0x8CF0FF, 0xDCA0FF};
          uint8_t in = (uint8_t)(fade * (130 + 80 * sinf(t * 2 + k)));
          glow(x, y, 5, LC[k % 3], in);
        }
        break;
      }
      case eventm::R_ANCIENT: {
        if (groundLayer) break;
        // 古樹的臉：一對琥珀色的眼睛慢慢睜開
        float open = util::clamp01(fminf(p * 5, (1 - p) * 5));
        int eyeY = 104, lh = (int)(open * 2.5f);
        for (int s = -1; s <= 1; s += 2) {
          int ex = scene::TRUNK_X + s * 6;
          glow(ex, eyeY, 8, 0xFFC850, (uint8_t)(140 * open));
          for (int xx = -2; xx <= 2; xx++) for (int yy = -lh; yy <= lh; yy++) pset(ex + xx, eyeY + yy, rgb(0xFFDC78));
          if (lh > 0) pset(ex, eyeY, rgb(0x3C2814));
        }
        glow(scene::CANOPY_CX, scene::CANOPY_CY, 40, 0x78FFB4, (uint8_t)(50 * open));
        break;
      }
      case eventm::M_EYES: {
        if (groundLayer) break;
        // 樹洞裡眨眼的眼睛
        float bl = fmodf(t * 0.7f, 3.0f);
        if (bl > 0.15f) {
          for (int s = -1; s <= 1; s += 2) {
            int ex = scene::HOLLOW_X + s * 2, ey = scene::HOLLOW_Y - 1;
            glow(ex, ey, 3, 0xFFF064, (uint8_t)(200 * fade));
            pset(ex, ey, rgb(0xFFFFB4));
          }
        }
        break;
      }
      case eventm::M_RUNES: {
        if (!groundLayer) break;
        static const uint8_t GLYPH[6] = {0x5A, 0xA5, 0x7E, 0x99, 0x3C, 0xE7};
        const uint32_t rc = 0x8CB4FF;
        uint8_t in = (uint8_t)(fade * (160 + 60 * sinf(t * 2)));
        int cx = 59, cy = 111;  // 120 畫布座標
        world = false;
        for (int k = 0; k < 8; k++) {
          float ang = k * 0.785f + t * 0.05f;
          int gx = cx + (int)(cosf(ang) * 17), gy = cy + (int)(sinf(ang) * 4);
          uint8_t gm = GLYPH[(k + a.seed) % 6];
          for (int b = 0; b < 8; b++) if (gm & (1 << b)) { int px = gx + (b % 3) - 1, py = gy + (b / 3) - 1; padd(px, py, in / 2, in * 3 / 4, in); }
          glow(gx, gy, 3, rc, in / 3);
        }
        for (int k = 0; k < 28; k++) { float ang = k * 0.2244f; padd(cx + (int)(cosf(ang) * 13), cy + (int)(sinf(ang) * 3), in / 3, in / 2, in * 3 / 4); }
        world = true;
        break;
      }
      case eventm::N_MOONFLOWER: {  // 月光花：白色發光花朵
        if (!groundLayer || a.x < 0) break;
        const plant::Slot& sl = plant::SLOTS[(int)a.x];
        int fx_ = sl.x >> 1, fy_ = (sl.y >> 1) - 10;
        world = false;
        glow(fx_, fy_, 6, 0xC8DCFF, (uint8_t)(170 * fade));
        const int ox[5] = {-2, 2, 0, -1, 1}, oy[5] = {0, 0, -2, 2, 2};
        for (int k = 0; k < 5; k++) pblend(fx_ + ox[k], fy_ + oy[k], rgb(0xF5F8FF), (uint8_t)(255 * fade));
        pblend(fx_, fy_, rgb(0xFFF0B4), (uint8_t)(255 * fade));
        world = true;
        break;
      }
      case eventm::N_TREE_GLOW:
        if (groundLayer) break;
        glow(scene::CANOPY_CX, scene::CANOPY_CY + 10, 46, 0x8CFFC8, (uint8_t)(40 * fade));
        glow(scene::TRUNK_X, 120, 16, 0xB4FFDC, (uint8_t)(50 * fade));
        break;
      case eventm::N_FALLEN_STAR: case eventm::X_METEOR_CRASH: {  // 流星落向森林遠處 / 墜落在近處
        if (groundLayer) break;
        float u = util::clamp01(p * 1.4f);
        int x0 = 230, y0 = 6, x1 = eco::world.meteorX, y1 = a.id == eventm::X_METEOR_CRASH ? 206 : 168;
        if (a.id == eventm::X_METEOR_CRASH && u >= 1.0f && p < 0.9f) glow(x1, y1, 14, 0xFFC878, (uint8_t)(200 * (1 - p)));  // 撞擊的閃光
        int hx = (int)(x0 + (x1 - x0) * u), hy = (int)(y0 + (y1 - y0) * u);
        for (int k = 0; k < 10; k++) glow(hx + k * 3, hy - k * 4, 1, 0xFFF0C8, (uint8_t)(220 - k * 20));
        glow(hx, hy, 4, 0xFFFFE6, 220);
        break;
      }
      case eventm::M_PORTAL: {
        if (!groundLayer) break;
        int px = (int)a.x, py = (int)a.y;
        float o = util::clamp01(fminf(p * 4, (1 - p) * 4));
        int rx = (int)(7 * o), ry = (int)(15 * o);
        if (rx < 1) break;
        blendEllipse(px, py, rx, ry, rgb(0x281446), 200);
        for (int k = 0; k < 28; k++) {
          float ang = k * 0.2244f + t * 2.0f;
          glow(px + (int)(cosf(ang) * rx), py + (int)(sinf(ang) * ry), 2, k & 1 ? 0xC8A0FF : 0x78C8FF, (uint8_t)(180 * o));
        }
        glow(px, py, ry + 4, 0x9678FF, (uint8_t)(60 * o));
        break;
      }
      default: break;
    }
  }
  // 魔法脈動：擴散的光環
  if (!groundLayer && eco::pulsing(ms)) {
    float u = 1.0f - (eco::env.pulseUntil - ms) / 6000.0f;
    if (u < 0.45f) {
      float r = u / 0.45f * 190;
      uint8_t in = (uint8_t)(160 * (1 - u / 0.45f));
      for (int k = 0; k < 90; k++) {
        float ang = k * 0.0698f;
        int x = 120 + (int)(cosf(ang) * r), y = 160 + (int)(sinf(ang) * r * 0.55f);
        glow(x, y, 3, 0xC8B4FF, in);
      }
    }
  }
}

// ---------- 第二階段：災害痕跡與夜間景象 (120 畫布) ----------
void drawWorldGround(uint32_t ms) {
  const eco::World& w = eco::world;
  const eco::Env& e = eco::env;
  world = false;
  // 豪雨後的積水：倒映天空
  if (w.puddle > 0.05f) {
    const uint16_t pc = lit(hexOf(mixc(skyHor, {60, 90, 120}, 0.4f)));
    const int PX[3] = {24, 62, 108}, PY[3] = {108, 116, 112};
    for (int k = 0; k < 3; k++) {
      int rx = 2 + (int)(w.puddle * (3 + k)), ry = 1;
      for (int dx = -rx; dx <= rx; dx++) { pblend(PX[k] + dx, PY[k], pc, (uint8_t)(160 * w.puddle)); if (abs(dx) < rx - 1) pblend(PX[k] + dx, PY[k] - ry, pc, (uint8_t)(110 * w.puddle)); }
    }
  }
  // 土石崩落的石堆 (慢慢長滿苔蘚)
  if (w.rubble > 0.05f) {
    for (int k = 0; k < 7; k++) {
      int x = 46 + (int)(util::hashf(k, 5) * 10), y = 117 - (k % 3);
      uint32_t c = w.rubble < 0.5f && (k & 1) ? 0x6E9A4A : (k % 3 ? 0x8A8A90 : 0x6A6A70);
      uint8_t a = (uint8_t)(255 * util::clamp01(w.rubble * 3));
      pblend(x, y, lit(c), a); pblend(x + 1, y, lit(c), a);
    }
  }
  // 古樹的雷擊焦痕；曾被雷擊的樹在夜裡長出發光菌類 (歷史影響)
  if (w.burn > 0.05f) for (int y = 44; y < 66; y++) pblend(scene::TRUNK_X / 2 + 3 + ((y / 3) & 1), y, rgb(0x141010), (uint8_t)(200 * w.burn));
  if (history::zoneHas(scene::TRUNK_X, history::H_LIGHTNING) && e.night > 0.4f)
    for (int k = 0; k < 4; k++) glow(scene::TRUNK_X / 2 + 4, 50 + k * 4, 2, 0x64E6C8, (uint8_t)(e.night * 120 * (0.7f + 0.3f * sinf(ms * 0.002f + k))));
  // 流星留下的發光石 (森林遠處)
  if (w.meteorGlow > 0.02f) {
    int mx = w.meteorX >> 1, my = evo::meteorNear() ? 103 : 84;  // 近處墜落的隕石坑 / 遠處的發光石
    pset(mx, my, lit(0x5A5A6E)); pset(mx + 1, my, lit(0x6E6E82));
    if (e.night > 0.3f) glow(mx, my, 4, 0x9CDCFF, (uint8_t)(w.meteorGlow * 160 * e.night));
  }
  // 霜層
  if (w.frost > 0.05f) {
    const uint16_t fc = lit(0xE6F0FF);
    int n = (int)(w.frost * 160);
    for (int k = 0; k < n; k++) {
      int x = (int)(util::hashf(k, 17) * W), y = 85 + (int)(util::hashf(19, k) * 35);
      if (y * 2 < scene::groundY(x * 2)) continue;
      pblend(x, y, fc, (uint8_t)(120 + 100 * w.frost));
    }
  }
  world = true;
}

void drawPondExtras(uint32_t ms) {
  const eco::World& w = eco::world;
  world = false;
  // 乾旱時水位下降，露出泥岸
  if (w.pondLevel < 0.97f) {
    const uint16_t mud = lit(0x6E5A41), mudD = lit(0x5A4A36);
    const float lvl = util::clamp(w.pondLevel, 0.4f, 1.0f);
    for (int y = scene::RIVER_Y0 / 2; y <= scene::RIVER_Y1 / 2; y++)
      for (int x = scene::RIVER_X0 / 2; x <= scene::RIVER_X1 / 2; x++) {
        float hw;
        const float d = scene::riverDist(x * 2.0f, y * 2.0f, &hw);
        if (d < hw && d > hw * lvl) pset(x, y, ((x + y) & 1) ? mud : mudD);
      }
  }
  // 河面倒映月亮 (只在河道的橫向段)
  if (moonPx >= 0) {
    float rx, ry;
    const float u = 0.1f + (1.0f - (util::clamp(moonPx, 186, 236) - 186) / 50.0f) * 0.35f;  // 月亮在右 → 上游
    scene::riverAt(u, rx, ry);
    int x = (int)rx >> 1, y = ((int)ry - 2) >> 1;
    int shim = (int)(sinf(ms * 0.003f) * 1.5f);
    for (int dx = -2; dx <= 2; dx++) pblend(x + dx + (dx & 1 ? shim : 0), y, rgb(0xE6EBFF), dx == 0 ? 200 : 120);
    pblend(x, y - 1, rgb(0xE6EBFF), 150); pblend(x + shim, y + 1, rgb(0xE6EBFF), 90);
  }
  world = true;
}

void drawGrassFront() {
  // 前景草叢 (隨風擺動)
  const uint16_t g1 = lit(hexOf(seasonMix(0x5A9A46, 0x3C8237, 0x6E9A3C, 0x8C9682))), g2 = lit(hexOf(seasonMix(0x8CC850, 0x6EB446, 0xA0BE4A, 0xAAB4A0)));
  const uint16_t gd = mix(g1, rgb(0x140E12), 120);
  Fine fine;  // 原生像素：草葉底部 2 像素寬、尖端 1 像素，左側有暗邊
  for (int x = 0; x < FW; x += 3) {
    if (util::hashf(x, 41) < 0.45f) continue;
    const int h = 5 + (int)(util::hashf(x, 43) * 9);
    const float sw = sinf(t * (1.5f + eco::env.wind * 2) + x * 0.15f) * (0.3f + eco::env.wind * 1.5f);
    for (int i = 0; i < h; i++) {
      const int px = x + (int)(sw * i * 0.35f), py = FH - 1 - i;
      pset(px - 1, py, gd);
      pset(px, py, (i > h / 2) ? g2 : g1);
      if (i < h * 2 / 3) pset(px + 1, py, g1);
    }
  }
}

// ---------- UI (低調) ----------
void panel(int x, int y, int w, int h, uint8_t a) {
  blendRect(x, y, w, h, rgb(0x0E1424), a);
  const uint16_t edge = rgb(0x3C4A6E);
  for (int i = x + 2; i < x + w - 2; i++) { pblend(i, y, edge, a); pblend(i, y + h - 1, edge, a); }
}

void drawUi(uint32_t ms) {
  const timem::Local& l = timem::local();
  char buf[96];
  bool overlay = wifiOn || (infoUntil && !util::reached(ms, infoUntil)) || (journalUntil && !util::reached(ms, journalUntil));
  if (cfg::SHOW_CORNER_CLOCK && !overlay && !uiHidden) {
    snprintf(buf, sizeof(buf), "%02d:%02d", l.hour, l.min);
    int w = textWidth(buf);
    textAlpha(cfg::W - w - 4, 3, buf, rgb(0xF0F0F0), (uint8_t)(70 + eco::env.night * 20));
  }
  // 冷卻中提示：角落一顆微弱的光點
  if (!uiHidden && !util::reached(ms, input::restingUntil())) glow(cfg::W - 6, cfg::H - 6, 3, 0x8C8CB4, 120);

  if (wifiOn) {
    panel(10, 70, 220, 86, 215);
    textShadow(20, 78, "Wi-Fi 設定熱點", rgb(0xFFD678), 0);
    snprintf(buf, sizeof(buf), "名稱  %s", wifiSsid);  text(20, 98, buf, rgb(0xF7F1E3));
    snprintf(buf, sizeof(buf), "密碼  %s", wifiPass);  text(20, 114, buf, rgb(0xF7F1E3));
    text(20, 134, "手機連上後開 192.168.4.1", rgb(0x8C98BA));
    return;
  }
  if (infoUntil && !util::reached(ms, infoUntil)) {
    uint32_t left = infoUntil - ms;
    uint8_t a = left < 500 ? left * 200 / 500 : 200;
    panel(6, 6, 176, 72, a);
    static const char* WD[7] = {"日", "一", "二", "三", "四", "五", "六"};
    time_t tt = (time_t)timem::now();
    struct tm tm;
    localtime_r(&tt, &tm);
    snprintf(buf, sizeof(buf), "%d月%d日 週%s %02d:%02d", l.mon, l.mday, WD[tm.tm_wday], l.hour, l.min);
    textAlpha(14, 11, buf, rgb(0xF7F1E3), a);
    const weather::Now& w = weather::current();
    snprintf(buf, sizeof(buf), "%s %.0f°C 濕度%.0f%% 風%.0f", weather::skyName(w.sky), w.tempC, w.humidity, w.windKmh);
    textAlpha(14, 27, buf, rgb(0xF7F1E3), a);
    int rh = (int)timem::sunriseH(), rm = (int)((timem::sunriseH() - rh) * 60), sh = (int)timem::sunsetH(), sm = (int)((timem::sunsetH() - sh) * 60);
    snprintf(buf, sizeof(buf), "%s季 日出%02d:%02d 日落%02d:%02d", season::name(season::dominant()), rh, rm, sh, sm);
    textAlpha(14, 43, buf, rgb(0xC8D2E6), a);
    snprintf(buf, sizeof(buf), "%s %s", w.live ? "真實天氣" : "本地模擬", netStatus);
    textAlpha(14, 59, buf, rgb(0x8C98BA), a);
    return;
  }
  if (journalUntil && !util::reached(ms, journalUntil)) {
    uint32_t left = journalUntil - ms;
    uint8_t a = left < 500 ? left * 210 / 500 : 210;
    panel(4, 4, 232, 128, a);
    textAlpha(12, 8, "觀察日誌", rgb(0xFFD678), a);
    int n = journal::count();
    int start = journalPage * 7;
    if (n == 0) textAlpha(12, 28, "還沒有紀錄", rgb(0x8C98BA), a);
    for (int k = 0; k < 7 && start + k < n; k++) {
      journal::format(journal::get(start + k), buf, sizeof(buf));
      textAlpha(12, 25 + k * 15, buf, rgb(0xF7F1E3), a);
    }
    if (n > 7) {
      snprintf(buf, sizeof(buf), "%d/%d", journalPage + 1, (n + 6) / 7);
      textAlpha(cfg::W - 12 - textWidth(buf), 8, buf, rgb(0x8C98BA), a);
    }
    return;
  }
  // 系統訊息優先，其次事件提示
  uint8_t a = 0;
  bool have = false;
  if (noticeAt && ms - noticeAt < 4000) {
    strncpy(buf, noticeBuf, sizeof(buf)); buf[sizeof(buf) - 1] = 0;
    uint32_t age = ms - noticeAt;
    a = age > 3400 ? (4000 - age) * 255 / 600 : 255;
    have = true;
  } else {
    have = !uiHidden && journal::toast(buf, sizeof(buf), ms, a);
    // 講解常駐：沒有新提示時，淡淡地留著最新一則日誌
    if (!have && !uiHidden && journal::count() > 0) {
      journal::format(journal::get(0), buf, sizeof(buf));
      a = 150;
      have = true;
    } else if (have && a < 150) a = 150;  // 新提示淡出時接到常駐的亮度，不會閃一下
  }
  if (have) {
    int w = textWidth(buf);
    if (w > cfg::W - 12) w = cfg::W - 12;
    int x = (cfg::W - w) / 2;
    blendRect(x - 5, cfg::H - 21, w + 10, 17, rgb(0x0E1424), (uint8_t)(a * 120 / 255));
    textAlpha(x, cfg::H - 19, buf, rgb(0xF7F1E3), a);
  }
}
}  // namespace

void begin() {
  albedo = (uint16_t*)heap_caps_malloc((size_t)FW * FH * 2, MALLOC_CAP_SPIRAM);
  tags = (uint8_t*)heap_caps_malloc((size_t)FW * FH, MALLOC_CAP_SPIRAM);
  for (int i = 0; i < 56; i++) {
    uint32_t h = util::hash32(i * 2654435761u + 17);
    stars[i] = {(uint8_t)(h % W), (uint8_t)((h >> 8) % 55), (uint8_t)(90 + (h >> 16) % 166)};
  }
  for (int i = 0; i < 7; i++) clouds[i] = {util::rng.range(-40, 260), util::rng.range(8, 70), util::rng.range(0.7f, 1.4f)};
}

// 效能剖析 (序列埠 prof 指令)
uint32_t profUs[8], profN = 0;
#define PROF(i) do { uint32_t _n = micros(); profUs[i] += _n - _pt; _pt = _n; } while (0)

void printProfile() {
  static const char* N[8] = {"light/bake", "memcpy", "sky", "mid", "front", "weather", "ui", "-"};
  for (int i = 0; i < 7; i++) Serial.printf("  %-10s %5lu us\n", N[i], (unsigned long)(profN ? profUs[i] / profN : 0));
  memset(profUs, 0, sizeof(profUs));
  profN = 0;
}

void frame(uint32_t ms, float dt) {
  uint32_t _pt = micros();
  profN++;
  targetScene(true);
  t += dt;
  computeLighting(ms);
  snowCover = util::approach(snowCover, fmaxf(eco::env.snow > 0.2f ? 1.0f : 0.0f, evo::snow()), dt * 0.004f);  // 冬季積雪會留在地上
  moonGlowOn = eventm::isActive(eventm::X_MOON_GLOW);

  // 光照/季節變化時重新烘焙背景 (最多每 3 秒一次；閃電期間不重烘)
  const uint32_t aSig = albedoSignature(), lSig = lightSignature();
  if (aSig != albedoSig && (lastBake == 0 || ms - lastBake > 3000)) {
    albedoSig = aSig;
    bakeAlbedo(ms);
    lightSig = ~lSig;  // 強制重新打光
  }
  if (lSig != lightSig && (ms - lastRelight > 700 || eventm::lightning(ms) > 0)) {
    lightSig = lSig;
    relight(ms);
  }
  PROF(0);
  blitBg();
  PROF(1);

  // 天空
  const float night = eco::env.night;
  drawStars(night);
  drawSunMoon();
  evo::drawSky(ms);  // 持續數天的魔法極光
  drawClouds(dt);
  drawEvents(ms, false);  // 天空類特效 (流星、星象、彩虹、深林光點、古樹)
  drawLightning(ms);
  PROF(2);

  // 中景：植物 (後排) → 地面生物 → 水面 → 植物 (前排) → 前排生物
  // 植物、建築等物件先畫進物件圖層，結束時一起做邊緣平滑與描邊 (要在生物之前合成，才不會蓋住生物)
  {
    Layer layer;
    drawNest();
    for (int i = 0; i < plant::SLOT_N; i++) if (plant::SLOTS[i].y < 185 || plant::SLOTS[i].zone == plant::Z_TRUNK) drawPlant(i);
    drawEvents(ms, true);  // 地面特效 (符文、傳送門、月光花)
    drawWorldGround(ms);   // 積水、落石、焦痕、霜
    evo::drawGround(ms);   // 地形演化、聚落擴充、稀有生物的巢
    ruins::draw(ms);
    under::draw(ms);
    village::draw(ms);
    visitor::drawTracks();
    structure::draw(0, 196, ms);
  }
  creature::drawGround(0, 196);
  visitor::draw(0, 196);
  drawWater();
  drawPondExtras(ms);
  fx::drawBack();
  {
    Layer layer;
    for (int i = 0; i < plant::SLOT_N; i++) if (plant::SLOTS[i].y >= 185 && plant::SLOTS[i].zone != plant::Z_TRUNK) drawPlant(i);
    structure::draw(196, 400, ms);
  }
  creature::drawGround(196, 400);
  visitor::draw(196, 400);
  families::draw(ms);
  PROF(3);
  drawGrassFront();
  creature::drawFliers();
  fx::drawFront();
  PROF(4);

  // 天氣
  drawRain(ms);
  drawFog();
  float fl = eventm::lightning(ms);
  if (fl > 0.3f) blendRect(0, 0, cfg::W, cfg::H, rgb(0xE6E6FF), (uint8_t)(fl * 90));
  PROF(5);
}

void drawUiStrip(uint16_t* buf, int y0, int h, uint32_t ms) {
  targetStrip(buf, y0, h);
  drawUi(ms);
  targetScene(true);
}

void showInfo(uint32_t ms) { infoUntil = ms + 6000; journalUntil = 0; }
void showJournal(uint32_t ms) {
  int pages = (journal::count() + 6) / 7;
  if (journalUntil && !util::reached(ms, journalUntil)) journalPage = pages ? (journalPage + 1) % pages : 0;
  else journalPage = 0;
  journalUntil = ms + 10000;
  infoUntil = 0;
}
void setWifiPanel(bool on, const char* ssid, const char* pass) {
  wifiOn = on;
  strncpy(wifiSsid, ssid ? ssid : "", sizeof(wifiSsid) - 1);
  strncpy(wifiPass, pass ? pass : "", sizeof(wifiPass) - 1);
}
void setUiHidden(bool h) { uiHidden = h; }
bool uiIsHidden() { return uiHidden; }
void closeOverlays() { infoUntil = 0; journalUntil = 0; }
void setNetStatus(const char* s) { strncpy(netStatus, s, sizeof(netStatus) - 1); netStatus[sizeof(netStatus) - 1] = 0; }
void notice(const char* s, uint32_t ms) { strncpy(noticeBuf, s, sizeof(noticeBuf) - 1); noticeBuf[sizeof(noticeBuf) - 1] = 0; noticeAt = ms; }

}  // namespace render
