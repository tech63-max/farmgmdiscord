#include "ForestRenderer.h"
#include <Arduino.h>
#include <math.h>
#include <string.h>
#include <esp_heap_caps.h>
#include "Config.h"
#include "CreatureManager.h"
#include "Ecosystem.h"
#include "EventManager.h"
#include "Gfx.h"
#include "Journal.h"
#include "Particles.h"
#include "PlantManager.h"
#include "PlayerInteraction.h"
#include "Scene.h"
#include "SeasonManager.h"
#include "StructureManager.h"
#include "Families.h"
#include "ForestHistory.h"
#include "Ruins.h"
#include "Underground.h"
#include "Village.h"
#include "Evolution.h"
#include "VisitorManager.h"
#include "TimeManager.h"
#include "Util.h"
#include "WeatherManager.h"

namespace render {
using namespace gfx;
namespace {

struct C3 { float r, g, b; };
inline C3 c3(uint32_t h) { return {(float)(h >> 16), (float)((h >> 8) & 0xFF), (float)(h & 0xFF)}; }
inline C3 mixc(C3 a, C3 b, float t) { return {a.r + (b.r - a.r) * t, a.g + (b.g - a.g) * t, a.b + (b.b - a.b) * t}; }
inline uint32_t hexOf(C3 c) {
  auto q = [](float v) { return (uint32_t)util::clamp(v, 0.0f, 255.0f); };
  return (q(c.r) << 16) | (q(c.g) << 8) | q(c.b);
}
inline uint16_t litC(C3 c) { return lit(hexOf(c)); }

const uint8_t BAYER[16] = {0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5};

// 天空/光照狀態 (每幀計算)
C3 skyTop, skyHor;
float t = 0;  // 動畫時間 (秒)
uint32_t lastBake = 0, lastRelight = 0;
uint32_t albedoSig = 0xFFFFFFFF, lightSig = 0xFFFFFFFF;
// 背景分兩層：材質 (很少重算) + 打光 (光線變化時快速套用)
uint16_t* albedo = nullptr;  // 未打光的顏色 (PSRAM)
uint8_t* tags = nullptr;     // 每個像素屬於哪一層
enum Tag : uint8_t { T_SKY, T_FAR_A, T_FAR_B, T_CONIFER, T_CONIFER_D, T_NORMAL, T_POND };
float snowCover = 0;
int moonPx = -1;  // 月亮目前的 x (給池塘倒影用)
bool moonGlowOn = false;

// 雲
struct Cloud { float x, y, s; };
Cloud clouds[7];

// 星星
struct Star { uint8_t x, y, b; };
Star stars[56];

// UI
uint32_t infoUntil = 0, journalUntil = 0;
bool uiHidden = false;  // 隱藏時鐘、事件提示 (主動按出的資訊卡/日誌/Wi-Fi 面板仍會顯示)
int journalPage = 0;
bool wifiOn = false;
char wifiSsid[24] = "", wifiPass[12] = "";
char netStatus[40] = "";
char noticeBuf[64] = "";
uint32_t noticeAt = 0;

// ---------- 色彩關鍵影格 ----------
struct SkyKey { float e; uint32_t top, hor, tint; };
const SkyKey KEYS[] = {
    {-1.0f, 0x080C22, 0x161E40, 0x5A64A6},
    {-0.35f, 0x0A0E26, 0x1C2446, 0x5C68A8},
    {-0.12f, 0x28306A, 0xB46E64, 0x9C86AE},
    {0.04f, 0x5A78B8, 0xFFAA6E, 0xFFBE9E},
    {0.25f, 0x5096E1, 0xAFD7F0, 0xFAFAF5},
    {1.0f, 0x468CE6, 0xA5D2F0, 0xFFFFFF},
};

void computeLighting(uint32_t ms) {
  const float e = timem::sunElev();
  int k = 0;
  while (k < 4 && e > KEYS[k + 1].e) k++;
  const SkyKey &a = KEYS[k], &b = KEYS[k + 1];
  float f = util::clamp01((e - a.e) / (b.e - a.e));
  skyTop = mixc(c3(a.top), c3(b.top), f);
  skyHor = mixc(c3(a.hor), c3(b.hor), f);
  C3 tn = mixc(c3(a.tint), c3(b.tint), f);

  const eco::Env& env = eco::env;
  // 陰天、雨天：天空變灰、光線變柔
  float bright = 0.25f + 0.75f * timem::dayFactor();
  C3 gray = {128 * bright, 136 * bright, 146 * bright};
  C3 grayH = {170 * bright, 174 * bright, 180 * bright};
  float oc = util::clamp01(env.cloud * 0.7f + env.rain * 0.3f + env.storm * 0.2f);
  skyTop = mixc(skyTop, gray, oc);
  skyHor = mixc(skyHor, grayH, oc * 0.85f);
  if (env.storm > 0) { skyTop = mixc(skyTop, {40, 44, 56}, env.storm * 0.5f); skyHor = mixc(skyHor, {70, 74, 86}, env.storm * 0.4f); }
  if (env.fog > 0) skyHor = mixc(skyHor, {200 * bright, 204 * bright, 208 * bright}, env.fog * 0.7f);

  float dim = 1.0f - 0.22f * env.cloud - 0.15f * env.rain - 0.12f * env.storm;
  tn = {tn.r * dim, tn.g * dim, tn.b * dim};
  // 晴天時光線較暖
  if (env.cloud < 0.3f && e > 0.1f) tn.b *= 0.96f;
  // 閃電
  float fl = eventm::lightning(ms);
  if (fl > 0) tn = mixc(tn, {330, 330, 360}, fl * 0.8f);
  // 魔法脈動：淡紫光
  if (eco::pulsing(ms)) {
    float p = sinf((ms % 6000) / 6000.0f * 3.1416f);
    tn.r += 30 * p; tn.b += 60 * p; tn.g += 10 * p;
  }
  // 月相：新月的夜晚比較暗，滿月比較亮 (仍保持可辨識)
  if (env.night > 0.3f) {
    const eco::Moon m = eco::moon();
    float k = m == eco::MOON_NEW ? 0.9f : m == eco::MOON_FULL ? 1.1f : 1.0f;
    k = 1.0f + (k - 1.0f) * env.night;
    tn = {tn.r * k, tn.g * k, tn.b * k};
  }
  tint.r = (uint16_t)util::clamp(tn.r, 40.0f, 360.0f);
  tint.g = (uint16_t)util::clamp(tn.g, 40.0f, 360.0f);
  tint.b = (uint16_t)util::clamp(tn.b, 40.0f, 360.0f);
}

C3 seasonMix(const uint32_t sp, const uint32_t su, const uint32_t au, const uint32_t wi) {
  C3 r = {0, 0, 0};
  const uint32_t v[4] = {sp, su, au, wi};
  for (int i = 0; i < 4; i++) {
    float w = season::weight((Season)i);
    C3 c = c3(v[i]);
    r.r += c.r * w; r.g += c.g * w; r.b += c.b * w;
  }
  return r;
}

// 提高飽和度 (以亮度為軸心拉開色彩)，bright 另外調整亮度
C3 vivid(C3 c, float s = cfg::BG_VIVID, float bright = 1.0f) {
  const float l = c.r * 0.299f + c.g * 0.587f + c.b * 0.114f;
  auto f = [&](float v) { return util::clamp((l + (v - l) * s) * bright, 0.f, 255.f); };
  return {f(c.r), f(c.g), f(c.b)};
}

// ---------- 烘焙背景 ----------
constexpr int WW = cfg::W, WH = cfg::H;  // 世界座標範圍 (240)
inline void tset(int x, int y, uint8_t tag, uint16_t v) {
  x >>= 1; y >>= 1;  // 世界座標 → 120 畫布
  if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H) return;
  const int i = y * W + x;
  albedo[i] = v;
  tags[i] = tag;
  setSky(x, y, tag == T_SKY);
}
inline void bset(int x, int y, uint16_t c) { tset(x, y, T_NORMAL, c); }

void bakeSky() {
  for (int y = 0; y < WH; y += 2) for (int x = 0; x < WW; x += 2) tset(x, y, T_SKY, 0);
}

void bakeFar() {
  for (int x = 0; x < WW; x++) {
    int r1 = 92 + (int)(14 * util::vnoise(x * 0.015f, 1.3f) + 8 * util::vnoise(x * 0.05f, 2.7f));
    int r2 = 110 + (int)(9 * util::vnoise(x * 0.03f, 5.1f) + 4 * sinf(x * 0.09f));
    for (int y = r1; y < 200; y++) tset(x, y, (y < r2) ? T_FAR_A : T_FAR_B, 0);
  }
  // 遠方針葉林
  for (int x = 0; x < WW; x++) {
    int top = 999;
    for (int k = x / 7 - 2; k <= x / 7 + 2; k++) {
      if (k < 0) continue;
      int xk = k * 7 + (int)(util::hash32(k * 31) % 5);
      int hk = 10 + (int)(util::hash32(k * 17 + 3) % 16);
      int yb = 134 + (int)(util::hash32(k * 7 + 1) % 6);
      int dx = abs(x - xk);
      int ty = yb - hk + (int)(dx / 0.36f);
      if (ty < yb && ty < top) top = ty;
    }
    for (int y = top; y < 200; y++) {
      tset(x, y, (y & 3) == 0 && ((x + y) & 1) ? T_CONIFER_D : T_CONIFER, 0);
    }
  }
}

void blob(int cx, int cy, int r, const C3* pal, int seed) {
  // 有葉子紋理的樹冠團塊：左上亮、右下暗
  const int R = r + 4;
  for (int y = -R; y <= R; y++) {
    for (int x = -R; x <= R; x++) {
      const int gx = cx + x, gy = cy + y;
      float d = sqrtf((float)(x * x + y * y));
      // 低頻雜訊讓輪廓呈現一簇簇葉團，而不是正圓
      float edge = r * (0.78f + 0.42f * util::vnoise(gx * 0.16f + seed, gy * 0.16f)) + (util::hashf(gx + seed, gy) - 0.5f) * 1.5f;
      if (d > edge) continue;
      float shade = (-(float)x * 0.8f - (float)y) / (r * 1.6f) * 0.6f + 0.5f;
      // 小葉團：每簇左上亮、右下暗
      float clump = util::vnoise(gx * 0.32f, gy * 0.32f);
      float cl2 = util::vnoise(gx * 0.32f + 0.35f, gy * 0.32f + 0.35f);
      float n = clump * 0.45f + (clump - cl2) * 0.9f + shade * 0.65f - (d / r) * 0.22f;
      n += (BAYER[(gy & 3) * 4 + (gx & 3)] - 7.5f) * 0.014f;
      int idx = n > 0.74f ? 0 : n > 0.5f ? 1 : n > 0.26f ? 2 : 3;
      bset(gx, gy, litC(pal[idx]));
    }
  }
}

void bakeMidTrees() {
  C3 pal[4];
  C3 base = vivid(seasonMix(0x5AA050, 0x46914B, 0xB4783C, 0x6E7364));
  for (int i = 0; i < 4; i++) { float k = 1.15f - i * 0.22f; pal[i] = mixc({base.r * k, base.g * k, base.b * k}, skyHor, 0.12f); }
  const uint16_t trunk = litC(mixc(c3(0x4A3A30), skyHor, 0.2f));
  struct T { int x, y, r; } trees[] = {{150, 128, 16}, {196, 118, 22}, {232, 130, 17}, {172, 140, 12}};
  for (auto& tr : trees) {
    for (int y = tr.y; y < scene::groundY(tr.x) + 2; y++) for (int dx = -1; dx <= 1; dx++) bset(tr.x + dx, y, trunk);
    blob(tr.x, tr.y - tr.r / 3, tr.r, pal, tr.x);
    blob(tr.x - tr.r / 2, tr.y + 2, tr.r * 2 / 3, pal, tr.x + 7);
  }
  // 灌木
  for (int x = 120; x < WW; x += 9) blob(x, scene::groundY(x) - 2, 6 + (int)(util::hash32(x) % 4), pal, x * 3);
}

void bakeGround() {
  C3 top = vivid(seasonMix(0x82BE5A, 0x64AA46, 0xAFA550, 0x96A08C), cfg::BG_VIVID, 1.06f);
  C3 mid = vivid(seasonMix(0x5FA04B, 0x468C3C, 0x8C823C, 0x73826E), cfg::BG_VIVID, 1.04f);
  C3 dark = vivid(seasonMix(0x3C7841, 0x2D6937, 0x645F32, 0x556455));
  if (snowCover > 0.05f) {
    C3 sn = {235, 240, 248};
    top = mixc(top, sn, snowCover); mid = mixc(mid, sn, snowCover * 0.8f); dark = mixc(dark, sn, snowCover * 0.5f);
  }
  const uint16_t cT = litC(top), cM = litC(mid), cD = litC(dark);
  const uint16_t dirt = litC(mixc(c3(0x6E5A41), dark, 0.3f));
  for (int x = 0; x < WW; x++) {
    int gy = scene::groundY(x);
    for (int y = gy; y < WH; y++) {
      float depth = (float)(y - gy) / (WH - gy);
      float n = util::vnoise(x * 0.18f, y * 0.3f) * 0.6f + util::hashf(x, y) * 0.25f + (1 - depth) * 0.35f;
      n += (BAYER[(y & 3) * 4 + (x & 3)] - 7.5f) * 0.02f;
      uint16_t c = n > 0.72f ? cT : n > 0.42f ? cM : cD;
      if (y == gy || (y == gy + 1 && (x & 1))) c = cT;  // 草地上緣亮邊
      // 樹根附近的泥土
      float rx = (x - scene::TRUNK_X) / 34.0f, ry = (y - 186) / 8.0f;
      if (rx * rx + ry * ry < 1 && util::hashf(x, y) > 0.3f) c = dirt;
      bset(x, y, c);
    }
    // 草葉
    if (util::hashf(x, 99) > 0.55f) for (int k = 1; k <= 1 + (int)(util::hashf(x, 7) * 3); k++) bset(x, gy - k, cM);
  }
  // 小石子
  const uint16_t peb = litC(c3(0x9A968C)), pebD = litC(c3(0x6E6A64));
  for (int k = 0; k < 18; k++) {
    int x = util::hash32(k * 13 + 5) % WW, y = 190 + util::hash32(k * 29) % 48;
    if (scene::inPond(x, y, -4)) continue;
    bset(x, y, peb); bset(x + 1, y, peb); bset(x, y + 1, pebD); bset(x + 1, y + 1, pebD);
  }
}

void bakePond() {
  const uint16_t shoreA = litC(c3(0x8C7A5A)), shoreB = litC(c3(0x6E5F46)), stone = litC(c3(0x8E8E8A));
  // 河道：中央深、靠岸淺；加一點沿著水流方向拉長的紋理
  for (int y = scene::RIVER_Y0; y <= scene::RIVER_Y1; y++) {
    for (int x = scene::RIVER_X0; x <= scene::RIVER_X1; x++) {
      float hw, u;
      const float d = scene::riverDist(x, y, &hw, &u);
      const float wob = (util::vnoise(x * 0.2f, y * 0.4f) - 0.5f) * 1.6f;
      if (d < hw + wob) {
        // 只記錄「倒映天空的比例」，顏色在打光時依當下天空計算
        const float k = d / hw;
        float m = util::clamp01(0.28f + k * 0.45f + (util::vnoise(u * 18.0f, k * 2.0f) - 0.5f) * 0.2f) * 0.8f;
        tset(x, y, T_POND, (uint16_t)(m * 255));
      } else if (d < hw + 3.5f + wob) {
        bset(x, y, util::hashf(x, y) > 0.7f ? stone : (d < hw + 1.8f + wob ? shoreB : shoreA));
      }
    }
  }
}

void bakeTree() {
  const C3 bark = c3(0x5A4130), barkL = c3(0x7D5A3C), barkD = c3(0x3C2A20), groove = c3(0x2E2018);
  // 樹根
  for (int k = 0; k < 5; k++) {
    float side = k < 2 ? -1 : k < 4 ? 1 : 0.2f;
    float sx = scene::TRUNK_X + side * (scene::TRUNK_HALF - 2), sy = 160;
    float ex = scene::TRUNK_X + side * (26 + k * 3), ey = 184 + (k & 1) * 4;
    for (int s = 0; s <= 20; s++) {
      float u = s / 20.0f;
      float x = sx + (ex - sx) * u, y = sy + (ey - sy) * (u * u * 0.6f + u * 0.4f);
      int wdt = (int)(6 * (1 - u)) + 1;
      for (int j = -wdt; j <= wdt; j++) bset((int)x + j / 2, (int)y + (j > 0 ? 0 : 1), litC(j < 0 ? barkL : j > wdt / 2 ? barkD : bark));
    }
  }
  // 樹幹
  for (int y = scene::TRUNK_TOP - 10; y < scene::TRUNK_BOTTOM; y++) {
    float hw = scene::TRUNK_HALF + (y > 150 ? (y - 150) * 0.45f : 0) + sinf(y * 0.08f) * 1.5f;
    float cx = scene::TRUNK_X + sinf(y * 0.04f) * 3;
    for (int x = (int)(cx - hw); x <= (int)(cx + hw); x++) {
      float u = (x - (cx - hw)) / (2 * hw);
      C3 c = u < 0.22f ? barkL : u > 0.75f ? barkD : bark;
      float g = util::vnoise(x * 0.7f, y * 0.07f);
      if (g > 0.64f) c = groove;
      else if (g < 0.2f && u < 0.6f) c = barkL;
      bset(x, y, litC(c));
    }
  }
  // 樹洞
  for (int y = -scene::HOLLOW_RY - 2; y <= scene::HOLLOW_RY + 2; y++)
    for (int x = -scene::HOLLOW_RX - 2; x <= scene::HOLLOW_RX + 2; x++) {
      float d = (float)(x * x) / (scene::HOLLOW_RX * scene::HOLLOW_RX) + (float)(y * y) / (scene::HOLLOW_RY * scene::HOLLOW_RY);
      if (d < 1.0f) bset(scene::HOLLOW_X + x, scene::HOLLOW_Y + y, litC(d < 0.6f ? c3(0x140E0C) : c3(0x22170F)));
      else if (d < 1.45f && y < 2) bset(scene::HOLLOW_X + x, scene::HOLLOW_Y + y, litC(barkL));
    }
  // 樹枝
  for (int k = 0; k < scene::PERCH_N; k++) {
    int px = scene::PERCH[k].x, py = scene::PERCH[k].y;
    int sx = scene::TRUNK_X + (px > scene::TRUNK_X ? 6 : -6), sy = py + 24;
    int steps = abs(px - sx) + abs(py - sy);
    for (int s = 0; s <= steps; s++) {
      float u = (float)s / steps;
      int x = sx + (int)((px - sx) * u), y = sy + (int)((py - sy) * u) - (int)(sinf(u * 3.14f) * 5);
      int wdt = 4 - (int)(u * 3.2f);  // 由粗到細
      for (int j = 0; j < wdt; j++) bset(x, y + j, litC(j == 0 ? barkL : j == wdt - 1 ? barkD : bark));
      // 小分枝
      if (s == steps * 2 / 3) for (int k = 1; k < 6; k++) bset(x + (px > sx ? k : -k) / 2, y - k, litC(bark));
    }
  }
  // 樹冠
  C3 base = vivid(seasonMix(0x6EB45A, 0x52A04B, 0xE6A046, 0x7D7D64), 1.0f + (cfg::BG_VIVID - 1.0f) * 0.6f);
  C3 pal[4];
  for (int i = 0; i < 4; i++) { float k = 1.2f - i * 0.25f; pal[i] = {base.r * k, base.g * k, base.b * k}; }
  if (season::weight(AUTUMN) > 0.3f) pal[1] = mixc(pal[1], c3(0xC8643C), season::weight(AUTUMN) * 0.5f);
  struct B { int x, y, r; } blobs[] = {{52, 30, 30}, {20, 46, 22}, {86, 40, 24}, {40, 62, 18}, {70, 62, 16}, {102, 58, 13},
                                        {6, 64, 13}, {60, 6, 22}, {26, 14, 18}, {96, 18, 17}, {114, 40, 11}};
  for (auto& bb : blobs) blob(bb.x, bb.y, bb.r, pal, 11);
  // 邊緣的小葉團，打破圓形輪廓
  for (int k = 0; k < 18; k++) {
    auto& bb = blobs[util::hash32(k * 13 + 1) % 11];
    float a = util::hashf(k, 21) * 6.28f;
    blob(bb.x + (int)(cosf(a) * bb.r * 0.9f), bb.y + (int)(sinf(a) * bb.r * 0.9f), 5 + (int)(util::hashf(k, 23) * 5), pal, 29 + k);
  }
  // 春天的小花
  float spr = season::weight(SPRING);
  if (spr > 0.3f) {
    const uint16_t pink = litC(c3(0xFFC8DC)), white = litC(c3(0xFFF4F8));
    for (int k = 0; k < (int)(70 * spr); k++) {
      auto& bb = blobs[util::hash32(k * 7) % 11];
      float a = util::hashf(k, 3) * 6.28f, r = util::hashf(k, 5) * bb.r * 0.9f;
      bset(bb.x + (int)(cosf(a) * r), bb.y + (int)(sinf(a) * r), (k & 1) ? pink : white);
    }
  }
}

void bakeRocksLog() {
  auto rock = [](int cx, int cy, int rx, int ry) {
    const C3 rl = c3(0xA0A0A5), rm = c3(0x7D7D84), rd = c3(0x55555C);
    for (int y = -ry; y <= ry / 2; y++)
      for (int x = -rx; x <= rx; x++) {
        float d = (float)(x * x) / (rx * rx) + (float)(y * y) / (ry * ry);
        if (d > 1) continue;
        float sh = (-x * 0.6f - y) / (float)ry + util::vnoise((cx + x) * 0.4f, (cy + y) * 0.4f) * 0.6f;
        bset(cx + x, cy + y, litC(sh > 0.7f ? rl : sh > 0.0f ? rm : rd));
      }
  };
  rock(scene::ROCK1_X, scene::ROCK1_Y, 15, 10);
  rock(scene::ROCK1_X + 13, scene::ROCK1_Y + 4, 7, 5);
  rock(scene::ROCK2_X, scene::ROCK2_Y, 11, 7);

  const plant::Deadwood& lg = plant::log();
  if (!lg.state) return;
  const C3 b1 = c3(0x6E5038), b2 = c3(0x4E382A), ring = c3(0xC8A578), ringD = c3(0x8C6E4B), moss = c3(0x6EA04B);
  for (int x = scene::LOG_X0; x <= scene::LOG_X1; x++) {
    for (int y = -5; y <= 4; y++) {
      C3 c = y < -2 ? b1 : y > 2 ? b2 : (util::vnoise(x * 0.5f, y * 0.6f) > 0.6f ? b2 : b1);
      if (lg.state >= 2 && y < -2 && util::vnoise(x * 0.3f, 7) > 0.45f) c = moss;
      bset(x, scene::LOG_Y + y, litC(c));
    }
  }
  for (int y = -5; y <= 4; y++) for (int x = -3; x <= 3; x++) {
    float d = (x * x) / 9.0f + (y * y) / 25.0f;
    if (d <= 1) bset(scene::LOG_X1 + x, scene::LOG_Y + y, litC(d < 0.25f ? ringD : ring));
  }
}

uint32_t albedoSignature() {
  uint32_t s = 0;
  for (int i = 0; i < 4; i++) s = s * 31 + (uint32_t)(season::weight((Season)i) * 10);
  s = s * 31 + plant::log().state;
  s = s * 31 + (uint32_t)(snowCover * 6);
  return s;
}
uint32_t lightSignature() {
  uint32_t s = (tint.r >> 3) | ((tint.g >> 3) << 6) | ((tint.b >> 3) << 12);
  s ^= ((uint32_t)(skyHor.r / 6)) << 18 ^ ((uint32_t)(skyTop.b / 6)) << 23;
  s ^= ((uint32_t)(skyHor.g / 6)) * 0x9E3779B1u ^ ((uint32_t)(skyTop.r / 6)) * 0x85EBCA6Bu;
  return s;
}

// 重算材質層 (慢：雜訊紋理)：只在季節/枯木/積雪改變時
void bakeAlbedo(uint32_t ms) {
  const Tint saved = tint;
  tint = Tint{};  // 中性光
  bakeSky();
  bakeFar();
  bakeMidTrees();
  bakeGround();
  bakePond();
  bakeRocksLog();
  bakeTree();
  tint = saved;
  lastBake = ms;
  Serial.printf("[Render] albedo bake %lu ms\n", (unsigned long)(millis() - ms));
}

// 套用目前光照與天空顏色到背景 (快)
void relight(uint32_t ms) {
  const uint16_t farA = litC(vivid(mixc(skyHor, c3(0x5F6E96), 0.45f))), farB = litC(vivid(mixc(skyHor, c3(0x465F6E), 0.6f)));
  const C3 con = vivid(mixc(skyHor, c3(0x2D5A46), 0.72f));
  const uint16_t conL = litC(con), conD = litC({con.r * 0.88f, con.g * 0.88f, con.b * 0.88f});
  const C3 deep = vivid({24, 82, 128}), refl = vivid(mixc(skyTop, skyHor, 0.6f), 1.0f + (cfg::BG_VIVID - 1.0f) * 0.7f);
  const uint32_t tr = tint.r, tg = tint.g, tb = tint.b;
  for (int y = 0; y < H; y++) {
    float f = util::clamp01(y * 2 / 150.0f);
    f = f * f * 0.6f + f * 0.4f;
    const C3 sc = mixc(skyTop, skyHor, f);
    uint16_t* out = bg + y * W;
    const uint16_t* al = albedo + y * W;
    const uint8_t* tg8 = tags + y * W;
    for (int x = 0; x < W; x++) {
      switch (tg8[x]) {
        case T_SKY: {
          float d = (BAYER[(y & 3) * 4 + (x & 3)] - 7.5f) * 0.9f;
          out[x] = rgb((uint8_t)util::clamp(sc.r + d, 0.f, 255.f), (uint8_t)util::clamp(sc.g + d, 0.f, 255.f), (uint8_t)util::clamp(sc.b + d, 0.f, 255.f));
          break;
        }
        case T_FAR_A: out[x] = farA; break;
        case T_FAR_B: out[x] = farB; break;
        case T_CONIFER: out[x] = conL; break;
        case T_CONIFER_D: out[x] = conD; break;
        case T_POND: {
          C3 c = mixc(deep, refl, al[x] / 255.0f);
          float d = (BAYER[(y & 3) * 4 + (x & 3)] - 7.5f) * 0.8f;
          out[x] = litC({c.r + d, c.g + d, c.b + d});
          break;
        }
        default: {
          const uint16_t c = al[x];
          uint32_t r = ((c >> 11) * tr) >> 8, g = (((c >> 5) & 63) * tg) >> 8, b = ((c & 31) * tb) >> 8;
          out[x] = (uint16_t)(((r > 31 ? 31 : r) << 11) | ((g > 63 ? 63 : g) << 5) | (b > 31 ? 31 : b));
        }
      }
    }
  }
  lastRelight = ms;
}

// ---------- 天空物件 (只畫在天空像素) ----------
void skyPset(int x, int y, uint16_t c) { if (isSky(x, y)) pset(x, y, c); }
void skyAdd(int x, int y, int r, int g, int b) { if (isSky(x, y)) padd(x, y, r, g, b); }
void skyGlow(int cx, int cy, int r, uint32_t hex, uint8_t in) {
  // 在 120 畫布上逐像素計算 (避免世界座標重複疊加)
  const bool w = world;
  if (w) { cx >>= 1; cy >>= 1; r = r > 2 ? r >> 1 : 1; world = false; }
  const int R = hex >> 16, G = (hex >> 8) & 0xFF, B = hex & 0xFF, r2 = r * r;
  for (int y = -r; y <= r; y++) for (int x = -r; x <= r; x++) {
    int d2 = x * x + y * y;
    if (d2 > r2) continue;
    int f = (r2 - d2) * 256 / r2; f = f * f >> 8; f = f * in >> 8;
    if (f > 2) skyAdd(cx + x, cy + y, R * f >> 8, G * f >> 8, B * f >> 8);
  }
  world = w;
}

void drawStars(float night) {
  const eco::Env& e = eco::env;
  float vis = night * (1 - e.cloud * 0.85f) * (1 - e.fog);
  if (vis < 0.05f) return;
  world = false;  // 星星座標是 120 畫布座標
  for (int i = 0; i < 56; i++) {
    const Star& s = stars[i];
    float tw = 0.6f + 0.4f * sinf(t * (0.8f + (i % 5) * 0.3f) + i);
    int v = (int)(s.b * tw * vis);
    if (v < 8) continue;
    skyAdd(s.x, s.y, v, v, v * 9 / 8);
    if (s.b > 200 && v > 120) { skyAdd(s.x + 1, s.y, v / 3, v / 3, v / 3); skyAdd(s.x - 1, s.y, v / 3, v / 3, v / 3); skyAdd(s.x, s.y + 1, v / 3, v / 3, v / 3); skyAdd(s.x, s.y - 1, v / 3, v / 3, v / 3); }
  }
  world = true;
}

void drawSunMoon() {
  const float h = timem::local().hourF, rise = timem::sunriseH(), set = timem::sunsetH();
  const eco::Env& e = eco::env;
  float vis = 1 - e.cloud * 0.8f - e.fog * 0.5f;
  moonPx = -1;
  if (h > rise - 0.3f && h < set + 0.3f) {
    float u = (h - rise) / (set - rise);
    int x = 20 + (int)(200 * u), y = 128 - (int)(112 * sinf(util::clamp01(u) * 3.1416f));
    float low = util::clamp01(1 - fabsf(timem::sunElev()) * 3);
    uint32_t col = hexOf(mixc(c3(0xFFF5C8), c3(0xFF9A50), low));
    if (vis > 0.1f) skyGlow(x, y, 22, col, (uint8_t)(120 * vis));
    for (int yy = -5; yy <= 5; yy++) for (int xx = -5; xx <= 5; xx++)
      if (xx * xx + yy * yy <= 26) { uint16_t c = rgb(col); if (vis < 0.4f) c = mix(pget(x + xx, y + yy), c, (uint8_t)(255 * (vis + 0.25f))); skyPset(x + xx, y + yy, c); }
  }
  // 月亮：夜間沿弧線移動
  float nh = h >= set ? h - set : h + 24 - set;
  float nlen = rise + 24 - set;
  if (h > set - 0.5f || h < rise + 0.5f) {
    float u = util::clamp01(nh / nlen);
    int x = 220 - (int)(200 * u), y = 120 - (int)(96 * sinf(u * 3.1416f));
    if (vis > 0.3f && e.night > 0.5f && eco::moon() != eco::MOON_NEW) moonPx = x;
    float ph = timem::moonPhase();
    float illum = 1 - fabsf(ph - 0.5f) * 2;  // 0 新月 .. 1 滿月
    if (vis > 0.1f) skyGlow(x, y, 16, 0xC8D2FF, (uint8_t)(70 * vis * (0.3f + illum)));
    // 用位移的暗圓做月相
    float off = (ph < 0.5f ? 1 : -1) * (1 - illum) * 9;
    for (int yy = -4; yy <= 4; yy++) for (int xx = -4; xx <= 4; xx++) {
      if (xx * xx + yy * yy > 18) continue;
      float sx = xx - off;
      bool shadow = (sx * sx + yy * yy) <= 18 && illum < 0.97f;
      if (ph > 0.03f && ph < 0.97f && !shadow) {
        uint16_t c = rgb(0xEEF0FF);
        if ((xx == 1 && yy == -1) || (xx == -2 && yy == 1)) c = rgb(0xC8CCE0);  // 坑洞
        skyPset(x + xx, y + yy, vis < 0.4f ? mix(pget(x + xx, y + yy), c, (uint8_t)(255 * (vis + 0.25f))) : c);
      }
    }
  }
}

void drawClouds(float dt) {
  const eco::Env& e = eco::env;
  int n = 1 + (int)(e.cloud * 6.5f);
  float speed = 2 + e.wind * 14;
  C3 lightC = mixc(skyHor, {250, 250, 252}, 0.7f * timem::dayFactor() + 0.1f);
  C3 darkC = mixc(skyTop, {90, 95, 105}, 0.5f);
  if (e.storm > 0.2f || e.rain > 0.4f) lightC = mixc(lightC, {110, 115, 125}, 0.6f);
  // 夕陽時雲染成橘紅
  float low = util::clamp01(1 - fabsf(timem::sunElev()) * 3.5f) * timem::dayFactor();
  lightC = mixc(lightC, c3(0xFFA078), low * 0.6f);
  const uint16_t cl = rgb(hexOf(lightC)), cd = rgb(hexOf(mixc(lightC, darkC, 0.45f)));
  for (int i = 0; i < 7; i++) {
    Cloud& c = clouds[i];
    c.x += speed * dt * (0.6f + i * 0.08f);
    if (c.x > cfg::W + 40) { c.x = -40; c.y = 8 + util::rng.range(0, 60); c.s = util::rng.range(0.7f, 1.4f); }
    if (i >= n) continue;
    uint8_t a = (uint8_t)(150 + e.cloud * 100);
    int r = (int)(4 * c.s) + 1;
    const int ox[5] = {0, 5, -5, 2, -2}, oy[5] = {0, 1, 1, -2, -2};
    world = false;  // 雲在 120 畫布上計算
    for (int k = 0; k < 5; k++) {
      int rr = k < 3 ? r : r - 1;
      int cx = ((int)c.x >> 1) + (int)(ox[k] * c.s), cy = ((int)c.y >> 1) + (int)(oy[k] * c.s);
      for (int y = -rr; y <= rr / 2 + 1; y++) for (int x = -rr - 1; x <= rr + 1; x++) {
        float d = (x * x) / (float)((rr + 1) * (rr + 1)) + (y * y) / (float)(rr * rr);
        if (d > 1 || !isSky(cx + x, cy + y)) continue;
        pblend(cx + x, cy + y, y > rr / 3 ? cd : cl, a);
      }
    }
    world = true;
  }
}

// ---------- 植物 ----------
const uint32_t FLOWER_COL[4][2] = {{0xFF8CB4, 0xFFD2E6}, {0xFFD24B, 0xFFF0A0}, {0x8C8CFF, 0xC8C8FF}, {0xF5F5F5, 0xFFFFFF}};

void drawFlower(int x, int y, const plant::Plant& p, float g, float sway) {
  const uint16_t stem = lit(p.stage == plant::S_WITHER || p.stage == plant::S_DORMANT ? 0x7D7350 : 0x4E9A3E);
  const uint16_t leaf = lit(p.stage == plant::S_WITHER ? 0x8C8250 : 0x64B44E);
  if (p.stage == plant::S_SEED) { pset(x, y - 1, lit(0x6E5A3C)); return; }
  int h = 2 + (int)(8 * g);
  int tx = x + (int)(sway * h * 0.3f);
  for (int i = 0; i < h; i++) pset(x + (int)(sway * i * 0.3f), y - i, stem);
  if (h > 4) { pset(x - 1, y - h / 3, leaf); pset(x - 2, y - h / 3 + 1, leaf); pset(x + 1, y - h / 2, leaf); pset(x + 2, y - h / 2 + 1, leaf); }
  int hy = y - h;
  const uint32_t* col = FLOWER_COL[p.variant & 3];
  static const uint32_t RARE_COL[2] = {0xFFD24B, 0xFFF5C8};
  const bool rare = p.variant & 0x10;  // 稀有/變異的花：金色並在夜裡發光
  if (rare) col = RARE_COL;
  if (rare && p.stage == plant::S_BLOOM) glow(x + (int)(sway * h * 0.3f), y - h, 5, 0xFFE68C, (uint8_t)(70 + 110 * eco::env.night));
  const eco::Env& e = eco::env;
  if (p.stage == plant::S_BLOOM) {
    // 夜晚/高溫時花朵閉合
    float open = (1 - e.night * 0.7f) * (e.hot ? 0.5f : 1.0f);
    if (open > 0.5f) {
      const int ox[5] = {-2, 2, 0, -1, 1}, oy[5] = {0, 0, -2, 2, 2};
      for (int k = 0; k < 5; k++) { pset(tx + ox[k], hy + oy[k], lit(col[0])); pset(tx + ox[k] / 2, hy + oy[k] / 2, lit(col[1])); }
      pset(tx, hy, lit(0xFFC83C));
    } else {
      pset(tx, hy, lit(col[0])); pset(tx, hy - 1, lit(col[0])); pset(tx - 1, hy, lit(col[1])); pset(tx + 1, hy, lit(col[1]));
    }
  } else if (p.stage == plant::S_MATURE) {
    pset(tx, hy, lit(0x5AA046)); pset(tx, hy - 1, lit(col[0]));
  } else if (p.stage == plant::S_WITHER) {
    pset(tx + 1, hy + 1, lit(0x8C643C)); pset(tx + 2, hy + 2, lit(0x6E4E32));
  }
}

void drawMushroom(int x, int y, const plant::Plant& p, float g) {
  if (p.stage == plant::S_SEED) return;
  const bool glowType = (p.variant & 3) >= 2 || (p.variant & 0x10);  // 變異的蘑菇也會發光
  static const uint32_t CAP[4] = {0xC8463C, 0x9A6440, 0x46B4B4, 0xA064DC};
  const eco::Env& e = eco::env;
  int sh = 1 + (int)(5 * g), rx = 1 + (int)(4 * g), ry = 1 + (int)(2 * g);
  uint32_t capc = CAP[p.variant & 3];
  if (p.stage == plant::S_WITHER) capc = 0x6E5A46;
  if (glowType && e.night > 0.3f && p.stage >= plant::S_GROW && p.stage != plant::S_WITHER) {
    float fl = eventm::lightning(millis());
    glow(x, y - sh - 1, 6 + rx, capc, (uint8_t)(e.night * 150 * (0.8f + 0.2f * sinf(t * 1.5f + x)) + fl * 100));
  }
  for (int i = 0; i < sh; i++) { pset(x, y - i, lit(0xF0E6D2)); if (g > 0.6f) pset(x + 1, y - i, lit(0xD2C8B4)); }
  bool unlit = glowType && e.night > 0.5f;
  uint16_t c = unlit ? rgb(capc) : lit(capc);
  for (int yy = -ry; yy <= 0; yy++) for (int xx = -rx; xx <= rx; xx++)
    if ((xx * xx) * ry * ry + (yy * yy) * rx * rx <= rx * rx * ry * ry) pset(x + xx, y - sh + yy, c);
  if (rx >= 3 && p.stage != plant::S_WITHER) { pset(x - 1, y - sh - 1, lit(0xFAF0DC)); pset(x + 2, y - sh, lit(0xFAF0DC)); }
}

void drawSapling(int x, int y, const plant::Plant& p, float g, float sway) {
  const uint16_t trunk = lit(0x6E4E36), trunkL = lit(0x8C6A4A);
  if (p.stage == plant::S_SEED) { pset(x, y - 1, lit(0x8C643C)); return; }
  int h = 3 + (int)(24 * g);
  int w = g > 0.6f ? 2 : 1;
  for (int i = 0; i < h; i++) for (int j = 0; j < w; j++) pset(x + j + (int)(sway * i * 0.08f), y - i, j ? trunk : trunkL);
  int cr = 2 + (int)(8 * g);
  int cx = x + (int)(sway * h * 0.08f), cy = y - h;
  C3 base = seasonMix(0x78BE5A, 0x5AA54B, 0xE69641, 0x8C826E);
  if (p.stage == plant::S_WITHER) base = c3(0x8C7850);
  bool bare = season::weight(WINTER) > 0.6f || p.stage == plant::S_DORMANT;
  for (int yy = -cr; yy <= cr; yy++) for (int xx = -cr; xx <= cr; xx++) {
    float d = sqrtf((float)(xx * xx + yy * yy));
    if (d > cr + (util::hashf(xx + x, yy) - 0.5f) * 2) continue;
    if (bare && util::hashf(xx * 3 + x, yy * 5) > 0.35f) continue;
    float sh = (-xx - yy) / (float)(cr * 2) + util::vnoise((xx + x) * 0.4f, (yy + cy) * 0.4f) * 0.5f;
    float k = sh > 0.5f ? 1.2f : sh > 0.15f ? 1.0f : 0.75f;
    pset(cx + xx, cy + yy, litC({base.r * k, base.g * k, base.b * k}));
  }
  if (p.stage >= plant::S_MATURE && season::weight(SPRING) > 0.4f && !bare)
    for (int k = 0; k < cr; k++) pset(cx + (int)((util::hashf(k, x) - 0.5f) * cr * 1.6f), cy + (int)((util::hashf(x, k) - 0.5f) * cr * 1.6f), lit(0xFFD2E6));
}

void drawVine(const plant::Plant& p, float g) {
  int len = 6 + (int)(80 * g);
  const uint16_t vine = lit(p.stage == plant::S_DORMANT ? 0x6E6446 : 0x4E8C3C), leafc = lit(p.stage == plant::S_DORMANT ? 0x8C7850 : 0x6EB450);
  for (int i = 0; i < len; i++) {
    int y = scene::TRUNK_TOP + i;
    int x = scene::TRUNK_X - 6 + (int)(sinf(i * 0.15f + t * 0.3f * eco::env.wind) * 4) + (int)(sinf(i * 0.05f) * 3);
    pset(x, y, vine);
    if (i % 6 == 0) { pset(x + 1, y, leafc); pset(x + 2, y - 1, leafc); }
    if (i % 6 == 3) { pset(x - 1, y, leafc); pset(x - 2, y - 1, leafc); }
    if (p.stage == plant::S_BLOOM && i % 11 == 5) { pset(x + 1, y + 1, lit(0xE6C8FF)); pset(x + 2, y + 1, lit(0xFFFFFF)); }
  }
}

void drawMoss(int i, const plant::Plant& p, float g) {
  const plant::Slot& s = plant::SLOTS[i];
  const uint16_t m1 = lit(p.stage == plant::S_DORMANT ? 0x7D8250 : 0x6EAA46), m2 = lit(0x4E8C3C), m3 = lit(0x96C85A);
  int n = (int)(g * 40);
  int rx = s.zone == plant::Z_ROCK ? 12 : s.zone == plant::Z_TRUNK ? 6 : 8;
  int baseY = s.zone == plant::Z_ROCK ? s.y : s.y;
  if (s.zone == plant::Z_LOG) rx = 10;
  for (int k = 0; k < n; k++) {
    float a = util::hashf(k, i * 7), r = util::hashf(i, k * 3);
    int x = s.x + (int)((a - 0.5f) * 2 * rx);
    int y = baseY + (int)((r - 0.5f) * (s.zone == plant::Z_TRUNK ? 20 : 4));
    if (s.zone == plant::Z_ROCK) y = scene::ROCK1_Y - 8 + (int)(fabsf(a - 0.5f) * 8) + (i == 16 ? scene::ROCK2_Y - scene::ROCK1_Y + 2 : 0);
    uint16_t c = k % 5 == 0 ? m3 : k % 3 == 0 ? m2 : m1;
    pset(x, y, c);
    if (k % 2 == 0) pset(x + 1, y, c);
  }
}

void drawGlowPlant(int x, int y, const plant::Plant& p, float g) {
  const eco::Env& e = eco::env;
  if (p.stage == plant::S_SEED) return;
  static const uint32_t GC[4] = {0x64E6FF, 0xB48CFF, 0x8CFFB4, 0xFFB4F0};
  uint32_t gc = GC[p.variant & 3];
  int h = 2 + (int)(7 * g);
  const uint16_t stem = lit(0x3C7864);
  for (int s = -1; s <= 1; s++) {
    int hh = h - abs(s) * 2;
    for (int i = 0; i < hh; i++) pset(x + s * (i / 3), y - i, stem);
    int bx = x + s * (hh / 3), by = y - hh;
    bool bright = p.stage == plant::S_BLOOM || (p.stage == plant::S_MATURE && e.night > 0.5f);
    if (p.stage >= plant::S_GROW && p.stage != plant::S_WITHER) {
      float pulse = 0.7f + 0.3f * sinf(t * 1.2f + x + s);
      if (bright) glow(bx, by, 5, gc, (uint8_t)((60 + e.night * 160 + e.magic * 80) * pulse));
      pset(bx, by, bright && e.night > 0.3f ? rgb(gc) : lit(gc));
    }
  }
}

void drawReed(int x, int y, const plant::Plant& p, float g, float sway) {
  bool dry = p.stage == plant::S_DORMANT || season::weight(WINTER) > 0.6f;
  const uint16_t c = lit(dry ? 0xA08C5A : 0x5A9A46), c2 = lit(dry ? 0x8C7846 : 0x46823C);
  int n = 2 + (int)(3 * g);
  for (int k = 0; k < n; k++) {
    int h = 4 + (int)(9 * g) - (k & 1) * 3;
    int ox = (k - n / 2) * 2;
    for (int i = 0; i < h; i++) pset(x + ox + (int)(sway * i * 0.25f * (1 + k * 0.2f)), y - i, (k & 1) ? c2 : c);
    if (p.stage >= plant::S_MATURE && k == 1) {
      int tx = x + ox + (int)(sway * h * 0.25f * 1.2f);
      for (int i = 0; i < 3; i++) { pset(tx, y - h - i, lit(0x6E4630)); pset(tx + 1, y - h - i, lit(0x5A3A28)); }
    }
  }
}

void drawLily(int x, int y, const plant::Plant& p, float g) {
  if (p.stage == plant::S_SEED || p.stage == plant::S_DORMANT) return;
  int rx = 2 + (int)(3 * g), ry = 1 + (int)(1 * g);
  float bob = sinf(t * 0.8f + x) * 0.6f;
  int yy = y + (int)bob;
  const uint16_t pad = lit(0x5AA046), padD = lit(0x3C7D37);
  for (int j = -ry; j <= ry; j++) for (int i = -rx; i <= rx; i++) {
    if (i * i * ry * ry + j * j * rx * rx > rx * rx * ry * ry) continue;
    if (i > 0 && j < 0 && i > -j * 2) continue;  // 缺口
    pset(x + i, yy + j, j > 0 ? padD : pad);
  }
  if (p.stage == plant::S_BLOOM) {
    pset(x - 1, yy - 2, lit(0xFFB4D2)); pset(x + 1, yy - 2, lit(0xFFB4D2)); pset(x, yy - 3, lit(0xFFE6F0)); pset(x, yy - 2, lit(0xFFE678));
  }
}

void drawPlant(int i) {
  const plant::Plant& p = plant::get(i);
  if (p.species == plant::P_NONE) return;
  const plant::Slot& s = plant::SLOTS[i];
  float g = plant::growthFrac(i);
  float sway = sinf(t * (1.2f + eco::env.wind * 2) + i * 1.7f) * (0.3f + eco::env.wind * 1.6f);
  // 藤蔓、苔蘚貼著場景物件，用世界座標；其他植物在 120 畫布上以 1:1 像素畫 (螢幕上 2 倍大)
  const int x = s.x >> 1, y = s.y >> 1;
  world = p.species == plant::P_VINE || p.species == plant::P_MOSS;
  switch (p.species) {
    case plant::P_FLOWER: drawFlower(x, y, p, g, sway); break;
    case plant::P_MUSHROOM: drawMushroom(x, y, p, g); break;
    case plant::P_SAPLING: drawSapling(x, y, p, g, sway * 0.5f); break;
    case plant::P_VINE: drawVine(p, g); break;
    case plant::P_MOSS: drawMoss(i, p, g); break;
    case plant::P_GLOW: drawGlowPlant(x, y, p, g); break;
    case plant::P_REED: drawReed(x, y, p, g, sway); break;
    case plant::P_LILY: drawLily(x, y, p, g); break;
    default: break;
  }
  // 月光照耀下植物發光 (事件)
  if (moonGlowOn && p.species != plant::P_VINE && p.species != plant::P_MOSS && p.stage >= plant::S_GROW)
    glow(world ? s.x : x, world ? s.y - 10 : y - 5, world ? 8 : 4, 0xC8E6FF, 70);
  world = true;
}

void drawNest() {
  float n = creature::nestProgress();
  if (n < 0.1f) return;
  int w = 2 + (int)(5 * n);
  const uint16_t c1 = lit(0x8C643C), c2 = lit(0x6E4A2E);
  for (int i = -w; i <= w; i++) {
    pset(scene::NEST.x + i, scene::NEST.y, (i & 1) ? c1 : c2);
    if (abs(i) < w - 1) pset(scene::NEST.x + i, scene::NEST.y + 1, c2);
    if (n > 0.6f && abs(i) == w) pset(scene::NEST.x + i, scene::NEST.y - 1, c1);
  }
}

// ---------- 水面、天氣 ----------
void drawWater() {
  const uint16_t hl = lit(hexOf(mixc(skyHor, {255, 255, 255}, 0.3f)));
  world = false;
  // 反光沿著河道往下游流動
  for (int k = 0; k < 10; k++) {
    float x, y, hw, dx, dy;
    scene::riverAt(fmodf(t * 0.03f + k * 0.1f, 1.0f), x, y, &hw, &dx, &dy);
    const float side = (float)((k * 7) % 5 - 2) * 0.3f * hw;  // 偏離中心線 (-0.6..0.6 半寬)
    x -= dy * side; y += dx * side;
    const int len = 2 + (k & 1);
    for (int i = 0; i < len; i++) {
      const float px = x + dx * i * 2, py = y + dy * i * 2;
      if (scene::inPond(px, py, 3)) pblend((int)px >> 1, (int)py >> 1, hl, 110);
    }
  }
  world = true;
}

void drawRain(uint32_t ms) {
  const eco::Env& e = eco::env;
  const bool magic = eco::blessing(ms);
  float amount = fmaxf(e.rain, magic ? 0.35f : 0);
  if (amount < 0.02f && e.snow < 0.02f) return;
  const float slant = 0.15f + e.wind * 0.6f;
  world = false;  // 雨雪直接在 120 畫布上畫，一滴就是一顆像素
  if (amount >= 0.02f) {
    int n = (int)(amount * 90);
    // 雨滴不完全跟著變暗，夜裡仍看得見
    const uint16_t rc = mix(lit(magic && e.rain < 0.2f ? 0xC8E6FF : 0xAABED7), rgb(0x8CA0BE), (uint8_t)(eco::env.night * 140));
    for (int i = 0; i < n; i++) {
      uint32_t h = util::hash32(i * 7919 + 13);
      float spd = 85 + (h & 31);
      float y = fmodf((h >> 8) % 130 + t * spd, 130.0f) - 10;
      float x = fmodf((h >> 16) % 140 + y * slant + 150, 140.0f) - 10;
      int len = 2 + (int)(amount * 1.5f);
      for (int k = 0; k < len; k++) pblend((int)(x - k * slant), (int)y - k, rc, (uint8_t)(150 - k * 25));
      if (magic && (i % 9) == 0) padd((int)x, (int)y, 40, 50, 70);
    }
  }
  if (e.snow >= 0.02f) {
    int n = (int)(e.snow * 60);
    const uint16_t sc = lit(0xF5F8FF);
    for (int i = 0; i < n; i++) {
      uint32_t h = util::hash32(i * 104729 + 7);
      float y = fmodf((h >> 8) % 130 + t * (9 + (h & 7)), 130.0f) - 10;
      float x = fmodf((h >> 16) % 130 + sinf(t * 0.7f + i) * 3 + y * e.wind * 0.5f, 130.0f) - 5;
      pset((int)x, (int)y, sc);
    }
  }
  world = true;
}

void drawFog() {
  const eco::Env& e = eco::env;
  if (e.fog < 0.03f) return;
  float b = 0.3f + 0.7f * timem::dayFactor();
  uint16_t fc = rgb((uint8_t)(205 * b + 20), (uint8_t)(210 * b + 20), (uint8_t)(215 * b + 25));
  const uint32_t fcx = expand565(fc);
  // 霧的濃淡在 4x4 的粗網格上計算 (省 CPU)，再用 Bayer 抖色過渡，保持像素風
  constexpr int Y0 = 20, CW = W / 4 + 1, CH = (H - Y0) / 4 + 2;  // 120 畫布座標
  static uint8_t grid[CH][CW];
  for (int cy = 0; cy < CH; cy++) {
    const int y = (Y0 + cy * 4) * 2;  // 換算成世界座標判斷高度
    // 垂直漸層：上方淡入、遠景最濃、近景較淡 (避免出現水平分界線)
    float depth = y < 110 ? util::smooth((y - Y0 * 2) / 70.0f) : y < 165 ? 1.0f : 1.0f - (y - 165) / 120.0f;
    for (int cx = 0; cx < CW; cx++) {
      float n = util::vnoise(cx * 0.24f + t * 0.05f, cy * 0.48f);
      int a = (int)(e.fog * (0.45f + 0.4f * n) * depth * 230);
      grid[cy][cx] = (uint8_t)(a > 220 ? 220 : a < 0 ? 0 : a);
    }
  }
  for (int y = Y0; y < H; y++) {
    const int gy = (y - Y0) >> 2, fy = (y - Y0) & 3;
    uint16_t* row = fb + y * W;
    for (int x = 0; x < W; x++) {
      const int gx = x >> 2, fx = x & 3;
      // 在相鄰兩格之間用 Bayer 門檻挑選，產生平滑的抖色漸層
      const uint8_t th = BAYER[fy * 4 + fx];
      const int a = grid[gy + (fy * 4 > (int)th ? 1 : 0)][gx + (fx * 4 > (int)th ? 1 : 0)];
      if (a > 8) row[x] = blendFast(row[x], fcx, (uint32_t)a >> 3);
    }
  }
}

void drawLightning(uint32_t ms) {
  float f = eventm::lightning(ms);
  if (f <= 0) return;
  // 遠方閃電：天空中的折線
  if (f > 0.7f) {
    uint32_t seed = ms / 1000;
    int x = 60 + util::hash32(seed) % 150, y = 0;
    const uint16_t c = rgb(0xF0F0FF);
    while (y < 100) {
      int nx = x + (int)(util::hash32(seed + y) % 9) - 4, ny = y + 6 + util::hash32(seed * 3 + y) % 6;
      for (int s = 0; s <= 6; s++) { int px = x + (nx - x) * s / 6, py = y + (ny - y) * s / 6; skyPset(px, py, c); skyAdd(px + 1, py, 80, 80, 100); }
      x = nx; y = ny;
    }
  }
}

// ---------- 事件特效 ----------
void drawEvents(uint32_t ms, bool groundLayer) {
  for (int i = 0; i < eventm::ACTIVE_CAP; i++) {
    const eventm::Active& a = eventm::active(i);
    if (!a.on) continue;
    float p = eventm::progress(a, ms);
    float fade = util::clamp01(fminf(p * 6, (1 - p) * 4));
    switch (a.id) {
      case eventm::R_METEOR: {
        if (groundLayer || p > 0.5f) break;
        float u = p * 2;
        int hx = (int)(a.x - u * 90) >> 1, hy = (int)(a.y + u * 40) >> 1;
        world = false;
        for (int k = 0; k < 12; k++) { int v = 255 - k * 20; skyAdd(hx + k, hy - k / 2, v, v, v * 9 / 10); }
        skyGlow(hx, hy, 2, 0xFFFFE6, 200);
        world = true;
        break;
      }
      case eventm::M_STARSIGN: {
        if (groundLayer) break;
        int idx[6];
        for (int k = 0; k < 6; k++) idx[k] = (a.seed >> (k * 4)) % 56;
        const uint16_t lc = rgb(0x8CC8FF);
        world = false;  // 星星是 120 畫布座標
        for (int k = 0; k < 5; k++) {
          const Star &s0 = stars[idx[k]], &s1 = stars[idx[k + 1]];
          int steps = abs(s1.x - s0.x) > abs(s1.y - s0.y) ? abs(s1.x - s0.x) : abs(s1.y - s0.y);
          if (steps < 1) steps = 1;
          for (int s = 0; s <= steps; s++) {
            int x = s0.x + (s1.x - s0.x) * s / steps, y = s0.y + (s1.y - s0.y) * s / steps;
            if (isSky(x, y)) pblend(x, y, lc, (uint8_t)(110 * fade));
          }
        }
        for (int k = 0; k < 6; k++) skyGlow(stars[idx[k]].x, stars[idx[k]].y, 2, 0xB4DCFF, (uint8_t)(220 * fade));
        world = true;
        break;
      }
      case eventm::R_RAINBOW: {
        if (groundLayer) break;
        static const uint32_t RB[6] = {0xFF6464, 0xFFAA50, 0xFFF064, 0x78E678, 0x64AAFF, 0xA078FF};
        world = false;
        for (int band = 0; band < 6; band++) {
          int r = 59 - band;
          uint16_t c = rgb(RB[band]);
          int lastX = -999, lastY = -999;
          for (int k = 0; k < 240; k++) {
            float ang = 3.1416f + k * 3.1416f / 240;
            int x = 75 + (int)(cosf(ang) * r * 1.2f), y = 88 + (int)(sinf(ang) * r);
            if (x == lastX && y == lastY) continue;  // 同一顆像素只疊一次
            lastX = x; lastY = y;
            if (isSky(x, y)) pblend(x, y, c, (uint8_t)(80 * fade));
            if (!util::reached(ms, evo::doubleRainbowUntil())) {  // 雙彩虹：外側較淡、顏色順序相反
              int x2 = 75 + (int)(cosf(ang) * (r + 8) * 1.2f), y2 = 88 + (int)(sinf(ang) * (r + 8));
              if (isSky(x2, y2)) pblend(x2, y2, rgb(RB[5 - band]), (uint8_t)(45 * fade));
            }
          }
        }
        world = true;
        break;
      }
      case eventm::R_DEEP_LIGHTS: {
        if (groundLayer) break;
        for (int k = 0; k < 6; k++) {
          float ph = (a.seed % 100) + k * 1.3f;
          int x = 135 + (int)(k * 17 + sinf(t * 0.4f + ph) * 6), y = 124 + (int)(sinf(t * 0.6f + ph * 2) * 5) + (k & 1) * 6;
          static const uint32_t LC[3] = {0xFFE68C, 0x8CF0FF, 0xDCA0FF};
          uint8_t in = (uint8_t)(fade * (130 + 80 * sinf(t * 2 + k)));
          glow(x, y, 5, LC[k % 3], in);
        }
        break;
      }
      case eventm::R_ANCIENT: {
        if (groundLayer) break;
        // 古樹的臉：一對琥珀色的眼睛慢慢睜開
        float open = util::clamp01(fminf(p * 5, (1 - p) * 5));
        int eyeY = 104, lh = (int)(open * 2.5f);
        for (int s = -1; s <= 1; s += 2) {
          int ex = scene::TRUNK_X + s * 6;
          glow(ex, eyeY, 8, 0xFFC850, (uint8_t)(140 * open));
          for (int xx = -2; xx <= 2; xx++) for (int yy = -lh; yy <= lh; yy++) pset(ex + xx, eyeY + yy, rgb(0xFFDC78));
          if (lh > 0) pset(ex, eyeY, rgb(0x3C2814));
        }
        glow(scene::CANOPY_CX, scene::CANOPY_CY, 40, 0x78FFB4, (uint8_t)(50 * open));
        break;
      }
      case eventm::M_EYES: {
        if (groundLayer) break;
        // 樹洞裡眨眼的眼睛
        float bl = fmodf(t * 0.7f, 3.0f);
        if (bl > 0.15f) {
          for (int s = -1; s <= 1; s += 2) {
            int ex = scene::HOLLOW_X + s * 2, ey = scene::HOLLOW_Y - 1;
            glow(ex, ey, 3, 0xFFF064, (uint8_t)(200 * fade));
            pset(ex, ey, rgb(0xFFFFB4));
          }
        }
        break;
      }
      case eventm::M_RUNES: {
        if (!groundLayer) break;
        static const uint8_t GLYPH[6] = {0x5A, 0xA5, 0x7E, 0x99, 0x3C, 0xE7};
        const uint32_t rc = 0x8CB4FF;
        uint8_t in = (uint8_t)(fade * (160 + 60 * sinf(t * 2)));
        int cx = 59, cy = 111;  // 120 畫布座標
        world = false;
        for (int k = 0; k < 8; k++) {
          float ang = k * 0.785f + t * 0.05f;
          int gx = cx + (int)(cosf(ang) * 17), gy = cy + (int)(sinf(ang) * 4);
          uint8_t gm = GLYPH[(k + a.seed) % 6];
          for (int b = 0; b < 8; b++) if (gm & (1 << b)) { int px = gx + (b % 3) - 1, py = gy + (b / 3) - 1; padd(px, py, in / 2, in * 3 / 4, in); }
          glow(gx, gy, 3, rc, in / 3);
        }
        for (int k = 0; k < 28; k++) { float ang = k * 0.2244f; padd(cx + (int)(cosf(ang) * 13), cy + (int)(sinf(ang) * 3), in / 3, in / 2, in * 3 / 4); }
        world = true;
        break;
      }
      case eventm::N_MOONFLOWER: {  // 月光花：白色發光花朵
        if (!groundLayer || a.x < 0) break;
        const plant::Slot& sl = plant::SLOTS[(int)a.x];
        int fx_ = sl.x >> 1, fy_ = (sl.y >> 1) - 10;
        world = false;
        glow(fx_, fy_, 6, 0xC8DCFF, (uint8_t)(170 * fade));
        const int ox[5] = {-2, 2, 0, -1, 1}, oy[5] = {0, 0, -2, 2, 2};
        for (int k = 0; k < 5; k++) pblend(fx_ + ox[k], fy_ + oy[k], rgb(0xF5F8FF), (uint8_t)(255 * fade));
        pblend(fx_, fy_, rgb(0xFFF0B4), (uint8_t)(255 * fade));
        world = true;
        break;
      }
      case eventm::N_TREE_GLOW:
        if (groundLayer) break;
        glow(scene::CANOPY_CX, scene::CANOPY_CY + 10, 46, 0x8CFFC8, (uint8_t)(40 * fade));
        glow(scene::TRUNK_X, 120, 16, 0xB4FFDC, (uint8_t)(50 * fade));
        break;
      case eventm::N_FALLEN_STAR: case eventm::X_METEOR_CRASH: {  // 流星落向森林遠處 / 墜落在近處
        if (groundLayer) break;
        float u = util::clamp01(p * 1.4f);
        int x0 = 230, y0 = 6, x1 = eco::world.meteorX, y1 = a.id == eventm::X_METEOR_CRASH ? 206 : 168;
        if (a.id == eventm::X_METEOR_CRASH && u >= 1.0f && p < 0.9f) glow(x1, y1, 14, 0xFFC878, (uint8_t)(200 * (1 - p)));  // 撞擊的閃光
        int hx = (int)(x0 + (x1 - x0) * u), hy = (int)(y0 + (y1 - y0) * u);
        for (int k = 0; k < 10; k++) glow(hx + k * 3, hy - k * 4, 1, 0xFFF0C8, (uint8_t)(220 - k * 20));
        glow(hx, hy, 4, 0xFFFFE6, 220);
        break;
      }
      case eventm::M_PORTAL: {
        if (!groundLayer) break;
        int px = (int)a.x, py = (int)a.y;
        float o = util::clamp01(fminf(p * 4, (1 - p) * 4));
        int rx = (int)(7 * o), ry = (int)(15 * o);
        if (rx < 1) break;
        blendEllipse(px, py, rx, ry, rgb(0x281446), 200);
        for (int k = 0; k < 28; k++) {
          float ang = k * 0.2244f + t * 2.0f;
          glow(px + (int)(cosf(ang) * rx), py + (int)(sinf(ang) * ry), 2, k & 1 ? 0xC8A0FF : 0x78C8FF, (uint8_t)(180 * o));
        }
        glow(px, py, ry + 4, 0x9678FF, (uint8_t)(60 * o));
        break;
      }
      default: break;
    }
  }
  // 魔法脈動：擴散的光環
  if (!groundLayer && eco::pulsing(ms)) {
    float u = 1.0f - (eco::env.pulseUntil - ms) / 6000.0f;
    if (u < 0.45f) {
      float r = u / 0.45f * 190;
      uint8_t in = (uint8_t)(160 * (1 - u / 0.45f));
      for (int k = 0; k < 90; k++) {
        float ang = k * 0.0698f;
        int x = 120 + (int)(cosf(ang) * r), y = 160 + (int)(sinf(ang) * r * 0.55f);
        glow(x, y, 3, 0xC8B4FF, in);
      }
    }
  }
}

// ---------- 第二階段：災害痕跡與夜間景象 (120 畫布) ----------
void drawWorldGround(uint32_t ms) {
  const eco::World& w = eco::world;
  const eco::Env& e = eco::env;
  world = false;
  // 豪雨後的積水：倒映天空
  if (w.puddle > 0.05f) {
    const uint16_t pc = lit(hexOf(mixc(skyHor, {60, 90, 120}, 0.4f)));
    const int PX[3] = {24, 62, 108}, PY[3] = {108, 116, 112};
    for (int k = 0; k < 3; k++) {
      int rx = 2 + (int)(w.puddle * (3 + k)), ry = 1;
      for (int dx = -rx; dx <= rx; dx++) { pblend(PX[k] + dx, PY[k], pc, (uint8_t)(160 * w.puddle)); if (abs(dx) < rx - 1) pblend(PX[k] + dx, PY[k] - ry, pc, (uint8_t)(110 * w.puddle)); }
    }
  }
  // 土石崩落的石堆 (慢慢長滿苔蘚)
  if (w.rubble > 0.05f) {
    for (int k = 0; k < 7; k++) {
      int x = 46 + (int)(util::hashf(k, 5) * 10), y = 117 - (k % 3);
      uint32_t c = w.rubble < 0.5f && (k & 1) ? 0x6E9A4A : (k % 3 ? 0x8A8A90 : 0x6A6A70);
      uint8_t a = (uint8_t)(255 * util::clamp01(w.rubble * 3));
      pblend(x, y, lit(c), a); pblend(x + 1, y, lit(c), a);
    }
  }
  // 古樹的雷擊焦痕；曾被雷擊的樹在夜裡長出發光菌類 (歷史影響)
  if (w.burn > 0.05f) for (int y = 44; y < 66; y++) pblend(scene::TRUNK_X / 2 + 3 + ((y / 3) & 1), y, rgb(0x141010), (uint8_t)(200 * w.burn));
  if (history::zoneHas(scene::TRUNK_X, history::H_LIGHTNING) && e.night > 0.4f)
    for (int k = 0; k < 4; k++) glow(scene::TRUNK_X / 2 + 4, 50 + k * 4, 2, 0x64E6C8, (uint8_t)(e.night * 120 * (0.7f + 0.3f * sinf(ms * 0.002f + k))));
  // 流星留下的發光石 (森林遠處)
  if (w.meteorGlow > 0.02f) {
    int mx = w.meteorX >> 1, my = evo::meteorNear() ? 103 : 84;  // 近處墜落的隕石坑 / 遠處的發光石
    pset(mx, my, lit(0x5A5A6E)); pset(mx + 1, my, lit(0x6E6E82));
    if (e.night > 0.3f) glow(mx, my, 4, 0x9CDCFF, (uint8_t)(w.meteorGlow * 160 * e.night));
  }
  // 霜層
  if (w.frost > 0.05f) {
    const uint16_t fc = lit(0xE6F0FF);
    int n = (int)(w.frost * 160);
    for (int k = 0; k < n; k++) {
      int x = (int)(util::hashf(k, 17) * W), y = 85 + (int)(util::hashf(19, k) * 35);
      if (y * 2 < scene::groundY(x * 2)) continue;
      pblend(x, y, fc, (uint8_t)(120 + 100 * w.frost));
    }
  }
  world = true;
}

void drawPondExtras(uint32_t ms) {
  const eco::World& w = eco::world;
  world = false;
  // 乾旱時水位下降，露出泥岸
  if (w.pondLevel < 0.97f) {
    const uint16_t mud = lit(0x6E5A41), mudD = lit(0x5A4A36);
    const float lvl = util::clamp(w.pondLevel, 0.4f, 1.0f);
    for (int y = scene::RIVER_Y0 / 2; y <= scene::RIVER_Y1 / 2; y++)
      for (int x = scene::RIVER_X0 / 2; x <= scene::RIVER_X1 / 2; x++) {
        float hw;
        const float d = scene::riverDist(x * 2.0f, y * 2.0f, &hw);
        if (d < hw && d > hw * lvl) pset(x, y, ((x + y) & 1) ? mud : mudD);
      }
  }
  // 河面倒映月亮 (只在河道的橫向段)
  if (moonPx >= 0) {
    float rx, ry;
    const float u = 0.1f + (1.0f - (util::clamp(moonPx, 186, 236) - 186) / 50.0f) * 0.35f;  // 月亮在右 → 上游
    scene::riverAt(u, rx, ry);
    int x = (int)rx >> 1, y = ((int)ry - 2) >> 1;
    int shim = (int)(sinf(ms * 0.003f) * 1.5f);
    for (int dx = -2; dx <= 2; dx++) pblend(x + dx + (dx & 1 ? shim : 0), y, rgb(0xE6EBFF), dx == 0 ? 200 : 120);
    pblend(x, y - 1, rgb(0xE6EBFF), 150); pblend(x + shim, y + 1, rgb(0xE6EBFF), 90);
  }
  world = true;
}

void drawGrassFront() {
  // 前景草叢 (隨風擺動)
  const uint16_t g1 = lit(hexOf(seasonMix(0x5A9A46, 0x3C8237, 0x96823C, 0x8C9682))), g2 = lit(hexOf(seasonMix(0x78B455, 0x5A9A46, 0xB4A050, 0xAAB4A0)));
  world = false;  // 直接在 120 畫布上畫，一株草就是幾顆大像素
  for (int x = 0; x < W; x += 2) {
    if (util::hashf(x, 41) < 0.45f) continue;
    int h = 2 + (int)(util::hashf(x, 43) * 4);
    float sw = sinf(t * (1.5f + eco::env.wind * 2) + x * 0.3f) * (0.3f + eco::env.wind * 1.5f);
    for (int i = 0; i < h; i++) pset(x + (int)(sw * i * 0.35f), H - 1 - i, (i > h / 2) ? g2 : g1);
  }
  world = true;
}

// ---------- UI (低調) ----------
void panel(int x, int y, int w, int h, uint8_t a) {
  blendRect(x, y, w, h, rgb(0x0E1424), a);
  const uint16_t edge = rgb(0x3C4A6E);
  for (int i = x + 2; i < x + w - 2; i++) { pblend(i, y, edge, a); pblend(i, y + h - 1, edge, a); }
}

void drawUi(uint32_t ms) {
  const timem::Local& l = timem::local();
  char buf[96];
  bool overlay = wifiOn || (infoUntil && !util::reached(ms, infoUntil)) || (journalUntil && !util::reached(ms, journalUntil));
  if (cfg::SHOW_CORNER_CLOCK && !overlay && !uiHidden) {
    snprintf(buf, sizeof(buf), "%02d:%02d", l.hour, l.min);
    int w = textWidth(buf);
    textAlpha(cfg::W - w - 4, 3, buf, rgb(0xF0F0F0), (uint8_t)(70 + eco::env.night * 20));
  }
  // 冷卻中提示：角落一顆微弱的光點
  if (!uiHidden && !util::reached(ms, input::restingUntil())) glow(cfg::W - 6, cfg::H - 6, 3, 0x8C8CB4, 120);

  if (wifiOn) {
    panel(10, 70, 220, 86, 215);
    textShadow(20, 78, "Wi-Fi 設定熱點", rgb(0xFFD678), 0);
    snprintf(buf, sizeof(buf), "名稱  %s", wifiSsid);  text(20, 98, buf, rgb(0xF7F1E3));
    snprintf(buf, sizeof(buf), "密碼  %s", wifiPass);  text(20, 114, buf, rgb(0xF7F1E3));
    text(20, 134, "手機連上後開 192.168.4.1", rgb(0x8C98BA));
    return;
  }
  if (infoUntil && !util::reached(ms, infoUntil)) {
    uint32_t left = infoUntil - ms;
    uint8_t a = left < 500 ? left * 200 / 500 : 200;
    panel(6, 6, 176, 72, a);
    static const char* WD[7] = {"日", "一", "二", "三", "四", "五", "六"};
    time_t tt = (time_t)timem::now();
    struct tm tm;
    localtime_r(&tt, &tm);
    snprintf(buf, sizeof(buf), "%d月%d日 週%s %02d:%02d", l.mon, l.mday, WD[tm.tm_wday], l.hour, l.min);
    textAlpha(14, 11, buf, rgb(0xF7F1E3), a);
    const weather::Now& w = weather::current();
    snprintf(buf, sizeof(buf), "%s %.0f°C 濕度%.0f%% 風%.0f", weather::skyName(w.sky), w.tempC, w.humidity, w.windKmh);
    textAlpha(14, 27, buf, rgb(0xF7F1E3), a);
    int rh = (int)timem::sunriseH(), rm = (int)((timem::sunriseH() - rh) * 60), sh = (int)timem::sunsetH(), sm = (int)((timem::sunsetH() - sh) * 60);
    snprintf(buf, sizeof(buf), "%s季 日出%02d:%02d 日落%02d:%02d", season::name(season::dominant()), rh, rm, sh, sm);
    textAlpha(14, 43, buf, rgb(0xC8D2E6), a);
    snprintf(buf, sizeof(buf), "%s %s", w.live ? "真實天氣" : "本地模擬", netStatus);
    textAlpha(14, 59, buf, rgb(0x8C98BA), a);
    return;
  }
  if (journalUntil && !util::reached(ms, journalUntil)) {
    uint32_t left = journalUntil - ms;
    uint8_t a = left < 500 ? left * 210 / 500 : 210;
    panel(4, 4, 232, 128, a);
    textAlpha(12, 8, "觀察日誌", rgb(0xFFD678), a);
    int n = journal::count();
    int start = journalPage * 7;
    if (n == 0) textAlpha(12, 28, "還沒有紀錄", rgb(0x8C98BA), a);
    for (int k = 0; k < 7 && start + k < n; k++) {
      journal::format(journal::get(start + k), buf, sizeof(buf));
      textAlpha(12, 25 + k * 15, buf, rgb(0xF7F1E3), a);
    }
    if (n > 7) {
      snprintf(buf, sizeof(buf), "%d/%d", journalPage + 1, (n + 6) / 7);
      textAlpha(cfg::W - 12 - textWidth(buf), 8, buf, rgb(0x8C98BA), a);
    }
    return;
  }
  // 系統訊息優先，其次事件提示
  uint8_t a = 0;
  bool have = false;
  if (noticeAt && ms - noticeAt < 4000) {
    strncpy(buf, noticeBuf, sizeof(buf)); buf[sizeof(buf) - 1] = 0;
    uint32_t age = ms - noticeAt;
    a = age > 3400 ? (4000 - age) * 255 / 600 : 255;
    have = true;
  } else {
    have = !uiHidden && journal::toast(buf, sizeof(buf), ms, a);
  }
  if (have) {
    int w = textWidth(buf);
    if (w > cfg::W - 12) w = cfg::W - 12;
    int x = (cfg::W - w) / 2;
    blendRect(x - 5, cfg::H - 21, w + 10, 17, rgb(0x0E1424), (uint8_t)(a * 120 / 255));
    textAlpha(x, cfg::H - 19, buf, rgb(0xF7F1E3), a);
  }
}
}  // namespace

void begin() {
  albedo = (uint16_t*)heap_caps_malloc((size_t)W * H * 2, MALLOC_CAP_SPIRAM);
  tags = (uint8_t*)heap_caps_malloc((size_t)W * H, MALLOC_CAP_SPIRAM);
  for (int i = 0; i < 56; i++) {
    uint32_t h = util::hash32(i * 2654435761u + 17);
    stars[i] = {(uint8_t)(h % W), (uint8_t)((h >> 8) % 55), (uint8_t)(90 + (h >> 16) % 166)};
  }
  for (int i = 0; i < 7; i++) clouds[i] = {util::rng.range(-40, 260), util::rng.range(8, 70), util::rng.range(0.7f, 1.4f)};
}

// 效能剖析 (序列埠 prof 指令)
uint32_t profUs[8], profN = 0;
#define PROF(i) do { uint32_t _n = micros(); profUs[i] += _n - _pt; _pt = _n; } while (0)

void printProfile() {
  static const char* N[8] = {"light/bake", "memcpy", "sky", "mid", "front", "weather", "ui", "-"};
  for (int i = 0; i < 7; i++) Serial.printf("  %-10s %5lu us\n", N[i], (unsigned long)(profN ? profUs[i] / profN : 0));
  memset(profUs, 0, sizeof(profUs));
  profN = 0;
}

void frame(uint32_t ms, float dt) {
  uint32_t _pt = micros();
  profN++;
  targetScene(true);
  t += dt;
  computeLighting(ms);
  snowCover = util::approach(snowCover, fmaxf(eco::env.snow > 0.2f ? 1.0f : 0.0f, evo::snow()), dt * 0.004f);  // 冬季積雪會留在地上
  moonGlowOn = eventm::isActive(eventm::X_MOON_GLOW);

  // 光照/季節變化時重新烘焙背景 (最多每 3 秒一次；閃電期間不重烘)
  const uint32_t aSig = albedoSignature(), lSig = lightSignature();
  if (aSig != albedoSig && (lastBake == 0 || ms - lastBake > 3000)) {
    albedoSig = aSig;
    bakeAlbedo(ms);
    lightSig = ~lSig;  // 強制重新打光
  }
  if (lSig != lightSig && (ms - lastRelight > 700 || eventm::lightning(ms) > 0)) {
    lightSig = lSig;
    relight(ms);
  }
  PROF(0);
  memcpy(fb, bg, (size_t)W * H * 2);
  PROF(1);

  // 天空
  const float night = eco::env.night;
  drawStars(night);
  drawSunMoon();
  evo::drawSky(ms);  // 持續數天的魔法極光
  drawClouds(dt);
  drawEvents(ms, false);  // 天空類特效 (流星、星象、彩虹、深林光點、古樹)
  drawLightning(ms);
  PROF(2);

  // 中景：植物 (後排) → 地面生物 → 水面 → 植物 (前排) → 前排生物
  drawNest();
  for (int i = 0; i < plant::SLOT_N; i++) if (plant::SLOTS[i].y < 185 || plant::SLOTS[i].zone == plant::Z_TRUNK) drawPlant(i);
  drawEvents(ms, true);  // 地面特效 (符文、傳送門、月光花)
  drawWorldGround(ms);   // 積水、落石、焦痕、霜
  evo::drawGround(ms);   // 地形演化、聚落擴充、稀有生物的巢
  ruins::draw(ms);
  under::draw(ms);
  village::draw(ms);
  visitor::drawTracks();
  structure::draw(0, 196, ms);
  creature::drawGround(0, 196);
  visitor::draw(0, 196);
  drawWater();
  drawPondExtras(ms);
  fx::drawBack();
  for (int i = 0; i < plant::SLOT_N; i++) if (plant::SLOTS[i].y >= 185 && plant::SLOTS[i].zone != plant::Z_TRUNK) drawPlant(i);
  structure::draw(196, 400, ms);
  creature::drawGround(196, 400);
  visitor::draw(196, 400);
  families::draw(ms);
  PROF(3);
  drawGrassFront();
  creature::drawFliers();
  fx::drawFront();
  PROF(4);

  // 天氣
  drawRain(ms);
  drawFog();
  float fl = eventm::lightning(ms);
  if (fl > 0.3f) blendRect(0, 0, cfg::W, cfg::H, rgb(0xE6E6FF), (uint8_t)(fl * 90));
  PROF(5);
}

void drawUiStrip(uint16_t* buf, int y0, int h, uint32_t ms) {
  targetStrip(buf, y0, h);
  drawUi(ms);
  targetScene(true);
}

void showInfo(uint32_t ms) { infoUntil = ms + 6000; journalUntil = 0; }
void showJournal(uint32_t ms) {
  int pages = (journal::count() + 6) / 7;
  if (journalUntil && !util::reached(ms, journalUntil)) journalPage = pages ? (journalPage + 1) % pages : 0;
  else journalPage = 0;
  journalUntil = ms + 10000;
  infoUntil = 0;
}
void setWifiPanel(bool on, const char* ssid, const char* pass) {
  wifiOn = on;
  strncpy(wifiSsid, ssid ? ssid : "", sizeof(wifiSsid) - 1);
  strncpy(wifiPass, pass ? pass : "", sizeof(wifiPass) - 1);
}
void setUiHidden(bool h) { uiHidden = h; }
bool uiIsHidden() { return uiHidden; }
void closeOverlays() { infoUntil = 0; journalUntil = 0; }
void setNetStatus(const char* s) { strncpy(netStatus, s, sizeof(netStatus) - 1); netStatus[sizeof(netStatus) - 1] = 0; }
void notice(const char* s, uint32_t ms) { strncpy(noticeBuf, s, sizeof(noticeBuf) - 1); noticeBuf[sizeof(noticeBuf) - 1] = 0; noticeAt = ms; }

}  // namespace render
