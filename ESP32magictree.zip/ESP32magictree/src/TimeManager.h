// 時間與日夜。板子沒有 RTC：連網後用 NTP；沒網路時用存檔時間/編譯時間推估，模擬不會停。
#pragma once
#include <stdint.h>
#include "World.h"

namespace timem {

struct Local {
  int year, mon, mday, hour, min, sec, yday;  // mon 1..12, yday 0..365
  float hourF;                                // 0..24
};

void begin(uint32_t savedEpoch, int32_t savedUtcOffset);
void onNetworkUp();                  // 啟動 SNTP (非阻塞)
void update(uint32_t dtMs);          // 每幀呼叫：處理縮時
uint32_t now();                      // 森林時間 (epoch 秒)
bool synced();                       // NTP 已同步
void setUtcOffset(int32_t sec);      // 由 Open-Meteo 回傳的時區校正
int32_t utcOffset();
const Local& local();                // 每次 update 後更新
void setSunTimes(float riseH, float setH);  // 當地小時 (例 5.9, 17.4)；<0 = 用季節估算
float sunriseH();
float sunsetH();
float sunElev();      // -1..1 (地平線 = 0)
float dayFactor();    // 0 夜 .. 1 白天 (平滑)
DayPhase phase();
uint8_t phaseMask();
float moonPhase();    // 0 新月 .. 0.5 滿月 .. 1
void setTimeScale(float s);
float timeScale();
void skip(int32_t sec);  // 除錯：時間快轉
void format(uint32_t epoch, char* buf, int cap, bool withDate);

}  // namespace timem
