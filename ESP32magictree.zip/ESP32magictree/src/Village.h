// 森林文明 (實驗性)：小精靈在環境穩定時慢慢形成小聚落，最後遷離、被森林接管
// 只用少量角色與最多 3 間小屋呈現，不模擬人口
#pragma once
#include <stdint.h>

namespace village {

enum Stage : uint8_t { VS_NONE, VS_GATHER, VS_COLLECT, VS_HUT, VS_SETTLE, VS_EXPAND, VS_DAMAGED, VS_ABANDONED, VS_OVERGROWN };
constexpr int HUTS = 3;
struct Hut { uint8_t on, pad[3]; float hp, moss; };
struct Blob {
  uint8_t stage, materials, pad[2];
  float activity;   // 小精靈在附近活動的累積 (形成聚落的條件)
  float stageT;     // 目前階段時數
  Hut huts[HUTS];
  uint32_t lastEnd;
};

void begin();
void tick(float dtH);
void update(float dt, uint32_t ms);
void draw(uint32_t ms);
void damage(float amount);     // 豪雨/暴風造成損壞
void debugStage(uint8_t s);    // 測試用：直接設定聚落階段
void boost();                  // 事件：加快聚集/收集材料
void grow();                   // 事件：擴張 (受小屋上限限制)
void repair();                 // 事件：修好受損的小屋
uint8_t stage();
const char* stageName(uint8_t s);
void exportBlob(Blob& b);
void importBlob(const Blob& b);

}  // namespace village
