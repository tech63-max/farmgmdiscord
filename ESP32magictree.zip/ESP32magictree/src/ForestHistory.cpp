#include "ForestHistory.h"
#include <Arduino.h>
#include <math.h>
#include <string.h>
#include "Ecosystem.h"
#include "PlantManager.h"
#include "TimeManager.h"
#include "Util.h"

namespace history {
namespace {
Blob h;
const char* const KIND_NAMES[H_COUNT] = {"visitor", "cabin", "trap", "decay", "reclaimed", "ruin", "lightning", "nest", "migrate",
                                         "disaster", "mystic", "flood", "camp", "burrow", "village", "hatch"};
}  // namespace

void begin(uint32_t now) {
  memset(&h, 0, sizeof(h));
  h.firstEpoch = now;
  for (auto& z : h.zones) { z.lush = 0.3f; z.damp = 0.3f; }
}

int zoneOf(int x) { return util::clamp(x / 40, 0, ZONES - 1); }

void note(Kind k, int x, uint8_t arg) {
  if (k >= H_COUNT) return;
  const int z = zoneOf(x);
  h.ring[h.head] = {timem::now(), (uint8_t)k, (uint8_t)z, arg, 0};
  h.head = (h.head + 1) % RING;
  if (h.n < RING) h.n++;
  if (h.counts[k] < 65535) h.counts[k]++;
  h.zones[z].marks |= (uint16_t)(1u << k);
  // 部分事件直接改變區域地貌
  if (k == H_FLOOD) h.zones[z].damp = fminf(1, h.zones[z].damp + 0.2f);
  if (k == H_STRUCT_GONE || k == H_VILLAGE) h.zones[z].lush = fminf(1, h.zones[z].lush + 0.1f);
}

void tick(float dtH) {
  if (dtH <= 0) return;
  // 長期地貌：各區的花/菇/降雨慢慢改變茂盛度與潮濕度 (時間尺度：數週)
  float zoneBloom[ZONES] = {0}, zoneMush[ZONES] = {0};
  for (int i = 0; i < plant::SLOT_N; i++) {
    const plant::Plant& p = plant::get(i);
    const int z = zoneOf(plant::SLOTS[i].x);
    if (p.stage == plant::S_BLOOM) zoneBloom[z] += 1;
    if (p.species == plant::P_MUSHROOM && p.stage >= plant::S_MATURE) zoneMush[z] += 1;
  }
  const eco::Env& e = eco::env;
  for (int z = 0; z < ZONES; z++) {
    Zone& zn = h.zones[z];
    zn.lush = util::clamp01(zn.lush + dtH * (zoneBloom[z] * 0.0015f - 0.0004f));
    zn.damp = util::clamp01(zn.damp + dtH * (zoneMush[z] * 0.001f + e.rain * 0.0015f + eco::world.puddle * 0.002f - 0.0005f - eco::world.drought * 0.002f));
  }
}

bool zoneHas(int x, Kind k) { return h.zones[zoneOf(x)].marks & (1u << k); }
float lush(int x) { return h.zones[zoneOf(x)].lush; }
float damp(int x) { return h.zones[zoneOf(x)].damp; }
uint16_t count(Kind k) { return k < H_COUNT ? h.counts[k] : 0; }

float plantBias(int slot, uint8_t sp) {
  const int x = plant::SLOTS[slot].x;
  const Zone& z = h.zones[zoneOf(x)];
  switch (sp) {
    case plant::P_MUSHROOM:
      return 1.0f + z.damp * 1.5f + ((z.marks & ((1u << H_CABIN) | (1u << H_CAMP) | (1u << H_STRUCT_GONE))) ? 0.8f : 0) +
             ((z.marks & (1u << H_LIGHTNING)) ? 0.6f : 0);
    case plant::P_GLOW: return 1.0f + ((z.marks & (1u << H_LIGHTNING)) ? 1.5f : 0) + ((z.marks & (1u << H_RUIN)) ? 0.8f : 0);
    case plant::P_FLOWER: return 1.0f + z.lush;
    case plant::P_MOSS: return 1.0f + z.damp;
    case plant::P_SAPLING: return 1.0f + ((z.marks & (1u << H_STRUCT_GONE)) ? 0.6f : 0);
    default: return 1.0f;
  }
}

float plantRate(int slot, uint8_t sp) {
  const Zone& z = h.zones[zoneOf(plant::SLOTS[slot].x)];
  if (sp == plant::P_MUSHROOM || sp == plant::P_MOSS) return 0.8f + z.damp * 0.5f;
  if (sp == plant::P_FLOWER || sp == plant::P_VINE || sp == plant::P_SAPLING) return 0.85f + z.lush * 0.35f;
  return 1.0f;
}

bool specialVariant(int slot, uint8_t sp, uint8_t& variant) {
  if (sp != plant::P_MUSHROOM) return false;
  const Zone& z = h.zones[zoneOf(plant::SLOTS[slot].x)];
  // 曾蓋過木屋、被雷擊過的地方 → 發光菌類 (variant 2/3)
  if ((z.marks & ((1u << H_CABIN) | (1u << H_LIGHTNING) | (1u << H_CAMP))) && util::rng.chance(0.6f)) {
    variant = (uint8_t)util::rng.irange(2, 3);
    return true;
  }
  return false;
}

void print() {
  Serial.printf("history since %lu, %u records\n", (unsigned long)h.firstEpoch, h.n);
  for (int k = 0; k < H_COUNT; k++) if (h.counts[k]) Serial.printf("  %-10s x%u\n", KIND_NAMES[k], h.counts[k]);
  for (int z = 0; z < ZONES; z++) Serial.printf("  zone %d lush %.2f damp %.2f marks %04x\n", z, h.zones[z].lush, h.zones[z].damp, h.zones[z].marks);
  for (int i = 0; i < h.n; i++) {
    const Rec& r = h.ring[(h.head - 1 - i + RING * 2) % RING];
    char t[24];
    timem::format(r.epoch, t, sizeof(t), true);
    Serial.printf("  %s %-10s zone %u\n", t, r.kind < H_COUNT ? KIND_NAMES[r.kind] : "?", r.zone);
  }
}

void exportBlob(Blob& b) { b = h; }
void importBlob(const Blob& b) {
  h = b;
  h.head %= RING;
  if (h.n > RING) h.n = RING;
}

}  // namespace history
