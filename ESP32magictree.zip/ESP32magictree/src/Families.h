// 生物家庭與生命週期：鳥巢 (產卵 → 孵化 → 餵食 → 練飛 → 離巢，巢可被下一代沿用)、
// 青蛙 (卵 → 蝌蚪 → 小青蛙)、小獸帶著幼崽 (幼崽逐漸長大)
#pragma once
#include <stdint.h>

namespace families {

enum Nest : uint8_t { N_NONE, N_READY, N_EGGS, N_CHICKS, N_PRACTICE, N_EMPTY };
enum Frog : uint8_t { FR_NONE, FR_SPAWN, FR_TADPOLE };

struct Blob {
  uint8_t nest, eggs, chicks, generation;
  float nestT;        // 目前階段經過的時數
  uint8_t frog, frogN, young, pad;
  float frogT;
  float youngT;       // 幼崽長大的進度 (小時)
  uint32_t lastFrog;  // 上次產卵 (epoch)
};

void begin();
void tick(float dtH);
void update(float dt, uint32_t ms);
void draw(uint32_t ms);   // 巢裡的蛋/幼鳥、池塘的卵/蝌蚪、跟著親獸的幼崽
void startCritterFamily(uint32_t ms);
const char* nestName(uint8_t n);
void exportBlob(Blob& b);
void importBlob(const Blob& b);
Blob& state();

}  // namespace families
