#include "Families.h"
#include <Arduino.h>
#include <math.h>
#include "CreatureManager.h"
#include "Ecosystem.h"
#include "EventManager.h"
#include "EventMemory.h"
#include "ForestHistory.h"
#include "Gfx.h"
#include "Scene.h"
#include "SeasonManager.h"
#include "Sprites.h"
#include "TimeManager.h"
#include "Util.h"

namespace families {
namespace {
Blob f;
int8_t parentIdx = -1;      // 帶幼崽的親獸 (creature 索引，不存檔)
float trailX[24], trailY[24];
uint8_t trailHead = 0;
uint32_t nextFeedMs = 0, nextTrailMs = 0;

bool breeding() {
  const eco::Env& e = eco::env;
  return (season::weight(SPRING) + season::weight(SUMMER) * 0.7f) > 0.35f && e.tempC > 10 && !creature::awayUntil(creature::C_BIRD);
}
void milestone(eventm::EvId id) { eventm::trigger(id, millis(), true); }
}  // namespace

void begin() { f = {}; }
Blob& state() { return f; }

void tick(float dtH) {
  if (dtH <= 0) return;
  // ---- 鳥巢 ----
  if (f.nest == N_NONE && creature::nestProgress() >= 1.0f) { f.nest = N_READY; f.nestT = 0; }
  f.nestT += dtH;
  switch (f.nest) {
    case N_READY: {
      // 曾經有過鳥巢的大樹會吸引新一代更快來產卵
      // 各階段時間經 util::shortH 壓縮到 0.5~3 小時 (原設計：產卵 12/24h、孵化 72h、練飛 96h、離巢 36h)
      float need = util::shortH(history::count(history::H_NEST) > 0 ? 12 : 24);
      if (!breeding()) f.nestT = 0;
      else if (f.nestT > need) { f.nest = N_EGGS; f.eggs = (uint8_t)util::rng.irange(2, 3); f.nestT = 0; milestone(eventm::F_EGGS); }
      break;
    }
    case N_EGGS:
      if (f.nestT > util::shortH(72)) {
        f.nest = N_CHICKS; f.chicks = f.eggs; f.eggs = 0; f.nestT = 0;
        history::note(history::H_NEST, scene::NEST.x);
        history::note(history::H_HATCH, scene::NEST.x, f.chicks);
        milestone(eventm::F_HATCH);
      }
      break;
    case N_CHICKS:
      if (f.nestT > util::shortH(96)) { f.nest = N_PRACTICE; f.nestT = 0; milestone(eventm::F_PRACTICE); }
      break;
    case N_PRACTICE:
      if (f.nestT > util::shortH(36)) { f.nest = N_EMPTY; f.nestT = 0; f.generation++; milestone(eventm::F_FLEDGE); f.chicks = 0; }
      break;
    case N_EMPTY:
      // 空巢可以被下一代沿用
      if (f.nestT > util::shortH(24 * 7) && breeding()) { f.nest = N_READY; f.nestT = 0; }
      break;
    default: break;
  }
  // ---- 青蛙 ----
  f.frogT += dtH;
  const uint32_t now = timem::now();
  const float pond = eco::world.pondLevel;
  if (f.frog == FR_NONE && season::weight(SPRING) > 0.4f && pond > 0.7f && eco::env.tempC > 12 &&
      (f.lastFrog == 0 || now - f.lastFrog > util::shortS(20 * 86400.0f)) && util::rng.chance(fminf(1, dtH * 0.5f))) {
    f.frog = FR_SPAWN; f.frogN = 8; f.frogT = 0; f.lastFrog = now; milestone(eventm::F_FROGSPAWN);
  } else if (f.frog == FR_SPAWN && f.frogT > util::shortH(96)) {
    f.frog = FR_TADPOLE; f.frogT = 0; milestone(eventm::F_TADPOLE);
  } else if (f.frog == FR_TADPOLE) {
    if (pond < 0.6f && f.frogN > 1 && util::rng.chance(fminf(1, dtH * 1.0f))) f.frogN--;  // 乾旱讓蝌蚪減少
    if (f.frogT > util::shortH(120)) { f.frog = FR_NONE; milestone(eventm::F_FROGLET); }
  }
  // ---- 小獸幼崽 ----
  if (f.young == 0 && (season::weight(SPRING) + season::weight(SUMMER)) > 0.5f && creature::count(creature::C_CRITTER) > 0 &&
      now - evmem::lastTime(eventm::F_CRITTER_BABY) > util::shortS(15 * 86400.0f) && util::rng.chance(fminf(1, dtH * 0.5f)))
    milestone(eventm::F_CRITTER_BABY);
  if (f.young > 0) {
    f.youngT += dtH;
    if (f.youngT > util::shortH(240)) { f.young = 0; milestone(eventm::F_GROWN); }
  }
}

void startCritterFamily(uint32_t ms) {
  int i = -1;
  for (int k = 0; k < creature::CAP; k++) {
    creature::Creature& c = creature::at(k);
    if (c.active && c.sp == creature::C_CRITTER && c.state != creature::ST_LEAVE) { i = k; break; }
  }
  if (i < 0) i = creature::spawn(creature::C_CRITTER, ms, true);
  if (i < 0) return;
  creature::at(i).leaveAt = ms + 90000;
  parentIdx = (int8_t)i;
  if (f.young == 0) { f.young = 2; f.youngT = 0; }
  for (int k = 0; k < 24; k++) { trailX[k] = creature::at(i).x; trailY[k] = creature::at(i).y; }
}

void update(float dt, uint32_t ms) {
  // 親鳥定期飛回巢裡餵食
  if (f.nest == N_CHICKS && eco::env.night < 0.4f && util::reached(ms, nextFeedMs)) {
    nextFeedMs = ms + (uint32_t)util::rng.range(40, 90) * 1000;
    creature::visitPoint(creature::C_BIRD, scene::NEST.x + 4, scene::NEST.y - 2, ms, 15000);
    if (timem::now() - evmem::lastTime(eventm::F_FEED) > util::shortS(4 * 3600.0f)) milestone(eventm::F_FEED);
  }
  // 記錄親獸的足跡，幼崽沿著它走
  if (parentIdx >= 0) {
    creature::Creature& c = creature::at(parentIdx);
    if (!c.active || c.sp != creature::C_CRITTER || c.alpha == 0) parentIdx = -1;
    else if (util::reached(ms, nextTrailMs)) {
      nextTrailMs = ms + 120;
      trailHead = (trailHead + 1) % 24;
      trailX[trailHead] = c.x; trailY[trailHead] = c.y;
    }
  }
  (void)dt;
}

void draw(uint32_t ms) {
  const bool w = gfx::world;
  gfx::world = false;
  const int nx = scene::NEST.x >> 1, ny = scene::NEST.y >> 1;
  if (f.nest == N_EGGS) for (int k = 0; k < f.eggs; k++) gfx::pset(nx - 1 + k, ny - 1, gfx::lit(0xC8E6F0));
  if (f.nest == N_CHICKS || f.nest == N_PRACTICE) {
    for (int k = 0; k < f.chicks; k++) {
      int bob = ((ms / 300 + k) % 3 == 0) ? 1 : 0;  // 幼鳥探頭
      gfx::pset(nx - 1 + k * 2, ny - 1 - bob, gfx::lit(0x9A8C78));
      gfx::pset(nx - 1 + k * 2, ny - 2 - bob, gfx::lit(0xF0C850));
    }
  }
  if (f.nest == N_PRACTICE) {  // 練習飛行：在樹枝間短距離撲翅
    float a = ms * 0.002f;
    int px = nx + (int)(cosf(a) * 6), py = ny - 3 + (int)(sinf(a * 2) * 2);
    gfx::pset(px, py, gfx::lit(0x9A8C78)); gfx::pset(px + 1, py, gfx::lit(0xF0C850));
    gfx::pset(px - 1, py - ((ms / 120) & 1), gfx::lit(0x7A6E5A));
  }
  // 池塘的卵與蝌蚪
  if (f.frog == FR_SPAWN) for (int k = 0; k < f.frogN; k++) {
    int x = 82 + (k % 4), y = 100 + k / 4;
    gfx::pblend(x, y, gfx::lit(0xDCE6E6), 150); gfx::pset(x, y, gfx::lit(0x283228));
  }
  if (f.frog == FR_TADPOLE) for (int k = 0; k < f.frogN; k++) {
    float a = ms * 0.0006f + k * 0.8f;
    int x = 91 + (int)(cosf(a) * (8 + k)), y = 102 + (int)(sinf(a * 1.3f) * 2);
    gfx::pset(x, y, gfx::lit(0x283228)); gfx::pset(x + (cosf(a) > 0 ? -1 : 1), y, gfx::lit(0x3C463C));
  }
  // 跟著親獸的幼崽
  if (parentIdx >= 0 && f.young > 0) {
    const creature::Creature& c = creature::at(parentIdx);
    for (int k = 0; k < f.young; k++) {
      int t = (trailHead - 6 - k * 5 + 48) % 24;
      gfx::spritePx = cfg::CREATURE_PX;  // 和親獸一樣的比例
      gfx::sprite(spr::BABY, ((ms / 200) + k) & 1, ((int)trailX[t] >> 1) - 3, ((int)trailY[t] >> 1) - 5, c.flip, spr::CRITTER_PAL, true, c.alpha);
      gfx::spritePx = 0;
    }
  }
  gfx::world = w;
}

const char* nestName(uint8_t n) {
  static const char* N[] = {"none", "ready", "eggs", "chicks", "practice", "empty"};
  return n <= N_EMPTY ? N[n] : "?";
}
void exportBlob(Blob& b) { b = f; }
void importBlob(const Blob& b) { f = b; if (f.nest > N_EMPTY) f.nest = N_NONE; if (f.frog > FR_TADPOLE) f.frog = FR_NONE; }

}  // namespace families
