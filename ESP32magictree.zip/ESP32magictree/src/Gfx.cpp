#include "Gfx.h"
#include <Arduino.h>
#include <esp_heap_caps.h>
#include <string.h>
#include "assets/Font12.h"

namespace gfx {

uint16_t* fb = nullptr;
uint16_t* bg = nullptr;
uint8_t* skyMask = nullptr;
Tint tint;
uint16_t* tbuf = nullptr;
int tw = FW, th = FH, ty0 = 0;
bool world = true;
uint8_t blk = 2;
bool layerOn = false;

namespace {
// 物件圖層的狀態
constexpr uint16_t LKEY = 0xF81E;  // 圖層的「透明」；真的畫到這個顏色時改成相鄰的 0xF81F
uint16_t* lay = nullptr;           // (W + 4) x (H + 4)：四周留兩圈透明格 (取鄰居時不用檢查邊界)
constexpr int LS = W + 4, LROWS = H + 4;
constexpr int LT = W / 8;           // 圖層分成 8x8 畫布像素的區塊，合成時只處理有內容的區塊
uint8_t tileDirty[LT * LT];
bool layAny = false;
}  // namespace

namespace {
// 世界座標的形狀先換算成畫布座標，再以畫布座標繪製
struct Native {
  bool saved;
  Native() : saved(world) { world = false; }
  ~Native() { world = saved; }
};
}  // namespace

void targetScene(bool worldCoords) { tbuf = fb; tw = FW; th = FH; ty0 = 0; world = worldCoords; blk = 2; }
void targetStrip(uint16_t* buf, int y0, int h) { tbuf = buf; tw = cfg::W; th = h; ty0 = y0; world = false; blk = 1; }

bool begin() {
  // 240x240 畫面 (115 KB) 放 PSRAM：內部 RAM 要留給 Wi-Fi/TLS
  fb = (uint16_t*)heap_caps_malloc((size_t)FW * FH * 2, MALLOC_CAP_SPIRAM);
  if (!fb) fb = (uint16_t*)heap_caps_malloc((size_t)FW * FH * 2, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  bg = (uint16_t*)heap_caps_malloc((size_t)FW * FH * 2, MALLOC_CAP_SPIRAM);
  skyMask = (uint8_t*)heap_caps_calloc(1, W * H / 8, MALLOC_CAP_SPIRAM);
  // 物件圖層 (29 KB) 每幀密集讀寫，放內部 RAM 比 PSRAM 快很多
  lay = (uint16_t*)heap_caps_malloc((size_t)LS * LROWS * 2, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  if (!lay) lay = (uint16_t*)heap_caps_malloc((size_t)LS * LROWS * 2, MALLOC_CAP_SPIRAM);
  if (lay) for (int i = 0; i < LS * LROWS; i++) lay[i] = LKEY;
  targetScene(true);
  return fb && bg && skyMask && lay;
}

void setSky(int x, int y, bool v) {
  if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H) return;
  int i = y * W + x;
  if (v) skyMask[i >> 3] |= (1 << (i & 7));
  else skyMask[i >> 3] &= ~(1 << (i & 7));
}

uint16_t mix(uint16_t a, uint16_t b, uint8_t t) {
  int ar, ag, ab, br, bg_, bb;
  unpack(a, ar, ag, ab);
  unpack(b, br, bg_, bb);
  return rgb(ar + ((br - ar) * t >> 8), ag + ((bg_ - ag) * t >> 8), ab + ((bb - ab) * t >> 8));
}

uint16_t litc(uint8_t r, uint8_t g, uint8_t b) {
  int R = r * tint.r >> 8, G = g * tint.g >> 8, B = b * tint.b >> 8;
  return rgb(R > 255 ? 255 : R, G > 255 ? 255 : G, B > 255 ? 255 : B);
}
uint16_t lit(uint32_t hex) { return litc(hex >> 16, (hex >> 8) & 0xFF, hex & 0xFF); }

void blitBg() {
  memcpy(fb, bg, (size_t)FW * FH * 2);
}

// 2x2 像素塊：四顆同色 (絕大多數情況) 只算一次；被細緻模式的角色蓋過的地方才逐顆算
static inline bool blockUniform(const uint16_t* p, int stride) {
  return p[0] == p[1] && p[0] == p[stride] && p[0] == p[stride + 1];
}

void blendCanvasPx(int x, int y, uint32_t fgx, uint32_t a32) {
  uint16_t* p = fb + (y * 2) * FW + x * 2;
  if (blockUniform(p, FW)) { p[0] = p[1] = p[FW] = p[FW + 1] = blendFast(p[0], fgx, a32); return; }
  p[0] = blendFast(p[0], fgx, a32); p[1] = blendFast(p[1], fgx, a32);
  p[FW] = blendFast(p[FW], fgx, a32); p[FW + 1] = blendFast(p[FW + 1], fgx, a32);
}

// ---- 物件圖層 ----
static inline uint16_t& layAt(int x, int y) { return lay[(y + 2) * LS + x + 2]; }

void layerSet(int x, int y, uint16_t c) {
  if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H) return;
  layAt(x, y) = c == LKEY ? (uint16_t)0xF81F : c;
  // 標記這一格和四個斜角所在的區塊 (平滑與描邊會影響到相鄰一格)
  const int xa = (x > 0 ? x - 1 : 0) >> 3, xb = (x < W - 1 ? x + 1 : x) >> 3;
  const int ya = ((y > 0 ? y - 1 : 0) >> 3) * LT, yb = ((y < H - 1 ? y + 1 : y) >> 3) * LT;
  tileDirty[ya + xa] = tileDirty[ya + xb] = tileDirty[yb + xa] = tileDirty[yb + xb] = 1;
  layAny = true;
}
bool layerBlend(int x, int y, uint32_t fgx, uint32_t a32) {
  if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H) return false;
  uint16_t& p = layAt(x, y);
  if (p == LKEY) return false;
  const uint16_t c = blendFast(p, fgx, a32);
  p = c == LKEY ? (uint16_t)0xF81F : c;
  return true;
}
void layerBegin() { layerOn = true; }

void layerEnd() {
  layerOn = false;
  if (!layAny) return;
  layAny = false;
  const uint32_t ox = expand565(rgb(0x140E12));
  // 一次處理一個 8x8 區塊：先在本地暫存算出放大後的結果 (含外圍一格，描邊要看鄰居)，再寫到畫面
  constexpr int NB = 20;  // (8 + 2) 格 x 2
  static uint16_t nb[NB * NB];
  for (int t = 0; t < LT * LT; t++) {
    if (!tileDirty[t]) continue;
    const int x0 = (t % LT) * 8, y0 = (t / LT) * 8;
    // 1) 放大 2 倍 + Scale2x：斜邊與轉角補上過渡像素 (透明也當成一種顏色，外形一起變圓滑)
    uint32_t rowHas = 0;  // 暫存的哪幾列 (原生) 有不透明像素
    for (int cy = -1; cy <= 8; cy++) {
      const uint16_t* l = &layAt(x0 - 1, y0 + cy);  // 從 cx = -1 開始 (畫布外的格子落在留白圈內)
      uint16_t* o = nb + (cy + 1) * 2 * NB;
      for (int cx = -1; cx <= 8; cx++, l++, o += 2) {
        const uint16_t E = l[0], D = l[-1], F = l[1];
        if (E == LKEY && D == LKEY && F == LKEY) { o[0] = o[1] = o[NB] = o[NB + 1] = LKEY; continue; }  // 空白格：左右都空就不可能被補上
        const uint16_t B = l[-LS], Hh = l[LS];
        uint16_t e0 = E, e1 = E, e2 = E, e3 = E;
        if (B != Hh && D != F) {
          if (D == B) e0 = D;
          if (B == F) e1 = F;
          if (D == Hh) e2 = D;
          if (Hh == F) e3 = F;
        }
        o[0] = e0; o[1] = e1; o[NB] = e2; o[NB + 1] = e3;
        if (e0 != LKEY || e1 != LKEY) rowHas |= 1u << ((cy + 1) * 2);
        if (e2 != LKEY || e3 != LKEY) rowHas |= 1u << ((cy + 1) * 2 + 1);
      }
    }
    if (!rowHas) continue;
    // 2) 寫到畫面；緊貼物件的透明像素疊上深色 (描邊)。上下三列都沒內容的列直接跳過
    for (int ny = 0; ny < 16; ny++) {
      if (!(rowHas & (7u << (ny + 1)))) continue;
      const uint16_t* q = nb + (ny + 2) * NB + 2;
      uint16_t* row = fb + (y0 * 2 + ny) * FW + x0 * 2;
      for (int nx = 0; nx < 16; nx++) {
        const uint16_t v = q[nx];
        if (v != LKEY) row[nx] = v;
        else if (q[nx - 1] != LKEY || q[nx + 1] != LKEY || q[nx - NB] != LKEY || q[nx + NB] != LKEY) row[nx] = blendFast(row[nx], ox, 19);
      }
    }
  }
  // 3) 清空，下次再用
  for (int t = 0; t < LT * LT; t++) {
    if (!tileDirty[t]) continue;
    tileDirty[t] = 0;
    const int x0 = (t % LT) * 8, y0 = (t / LT) * 8;
    for (int y = y0; y < y0 + 8; y++) {
      uint16_t* l = &layAt(x0, y);
      for (int i = 0; i < 8; i++) l[i] = LKEY;
    }
  }
}

void pblend(int x, int y, uint16_t c, uint8_t a) {
  const uint32_t fgx = expand565(c), a32 = (a + 4) >> 3;
  if (layerOn && blk == 2 && layerBlend(world ? x >> 1 : x, world ? y >> 1 : y, fgx, a32)) return;
  uint16_t* p = at(x, y);
  if (!p) return;
  if (blk != 2) { *p = blendFast(*p, fgx, a32); return; }
  if (blockUniform(p, tw)) { p[0] = p[1] = p[tw] = p[tw + 1] = blendFast(p[0], fgx, a32); return; }
  p[0] = blendFast(p[0], fgx, a32); p[1] = blendFast(p[1], fgx, a32);
  p[tw] = blendFast(p[tw], fgx, a32); p[tw + 1] = blendFast(p[tw + 1], fgx, a32);
}

static inline uint16_t addc(uint16_t c, int r, int g, int b) {
  int pr, pg, pb;
  unpack(c, pr, pg, pb);
  pr += r; pg += g; pb += b;
  return rgb(pr > 255 ? 255 : pr, pg > 255 ? 255 : pg, pb > 255 ? 255 : pb);
}

bool layerAdd(int x, int y, int r, int g, int b) {
  if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H) return false;
  uint16_t& p = layAt(x, y);
  if (p == LKEY) return false;
  const uint16_t c = addc(p, r, g, b);
  p = c == LKEY ? (uint16_t)0xF81F : c;
  return true;
}

void padd(int x, int y, int r, int g, int b) {
  if (layerOn && blk == 2 && layerAdd(world ? x >> 1 : x, world ? y >> 1 : y, r, g, b)) return;
  uint16_t* p = at(x, y);
  if (!p) return;
  if (blk != 2) { *p = addc(*p, r, g, b); return; }
  if (blockUniform(p, tw)) { p[0] = p[1] = p[tw] = p[tw + 1] = addc(p[0], r, g, b); return; }
  p[0] = addc(p[0], r, g, b); p[1] = addc(p[1], r, g, b);
  p[tw] = addc(p[tw], r, g, b); p[tw + 1] = addc(p[tw + 1], r, g, b);
}

void fillRect(int x, int y, int w, int h, uint16_t c) {
  if (world) { Native n; fillRect(x >> 1, y >> 1, (w + 1) >> 1, (h + 1) >> 1, c); return; }
  if (blk == 2 && layerOn) {
    if (x < 0) { w += x; x = 0; }
    if (y < 0) { h += y; y = 0; }
    if (x + w > W) w = W - x;
    if (y + h > H) h = H - y;
    for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) layerSet(x + i, y + j, c);
    return;
  }
  if (blk == 2) { x <<= 1; y <<= 1; w <<= 1; h <<= 1; }
  y -= ty0;
  if (x < 0) { w += x; x = 0; }
  if (y < 0) { h += y; y = 0; }
  if (x + w > tw) w = tw - x;
  if (y + h > th) h = th - y;
  if (w <= 0 || h <= 0) return;
  for (int j = 0; j < h; j++) {
    uint16_t* p = tbuf + (y + j) * tw + x;
    for (int i = 0; i < w; i++) p[i] = c;
  }
}

void blendRect(int x, int y, int w, int h, uint16_t c, uint8_t a) {
  if (world) { Native n; blendRect(x >> 1, y >> 1, (w + 1) >> 1, (h + 1) >> 1, c, a); return; }
  if (blk == 2) { x <<= 1; y <<= 1; w <<= 1; h <<= 1; }
  // 先裁切到目前目標 (分條繪製時很重要)
  int y1 = y + h, x1 = x + w;
  if (y < ty0) y = ty0;
  if (y1 > ty0 + th) y1 = ty0 + th;
  if (x < 0) x = 0;
  if (x1 > tw) x1 = tw;
  const uint32_t cx = expand565(c), a32 = (a + 4) >> 3;
  for (int j = y; j < y1; j++) {
    uint16_t* row = tbuf + (j - ty0) * tw;
    for (int i = x; i < x1; i++) row[i] = blendFast(row[i], cx, a32);
  }
}

void hline(int x, int y, int w, uint16_t c) { fillRect(x, y, w, 1, c); }
void vline(int x, int y, int h, uint16_t c) { fillRect(x, y, 1, h, c); }

void line(int x0, int y0, int x1, int y1, uint16_t c) {
  if (world) { Native n; line(x0 >> 1, y0 >> 1, x1 >> 1, y1 >> 1, c); return; }
  int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1, err = dx + dy;
  for (;;) {
    pset(x0, y0, c);
    if (x0 == x1 && y0 == y1) break;
    int e2 = 2 * err;
    if (e2 >= dy) { err += dy; x0 += sx; }
    if (e2 <= dx) { err += dx; y0 += sy; }
  }
}

void fillEllipse(int cx, int cy, int rx, int ry, uint16_t c) {
  if (world) { Native n; fillEllipse(cx >> 1, cy >> 1, rx >> 1, ry >> 1, c); return; }
  if (rx <= 0 || ry <= 0) { pset(cx, cy, c); return; }
  for (int y = -ry; y <= ry; y++) {
    float t = 1.0f - (float)(y * y) / (float)(ry * ry);
    int hw = (int)(rx * sqrtf(t > 0 ? t : 0) + 0.5f);
    hline(cx - hw, cy + y, hw * 2 + 1, c);
  }
}
void fillCircle(int cx, int cy, int r, uint16_t c) { fillEllipse(cx, cy, r, r, c); }

void blendEllipse(int cx, int cy, int rx, int ry, uint16_t c, uint8_t a) {
  if (world) { Native n; blendEllipse(cx >> 1, cy >> 1, (rx + 1) >> 1, (ry + 1) >> 1, c, a); return; }
  if (rx <= 0 || ry <= 0) return;
  for (int y = -ry; y <= ry; y++) {
    float t = 1.0f - (float)(y * y) / (float)(ry * ry);
    int hw = (int)(rx * sqrtf(t > 0 ? t : 0) + 0.5f);
    for (int x = -hw; x <= hw; x++) pblend(cx + x, cy + y, c, a);
  }
}

void glow(int cx, int cy, int r, uint32_t hex, uint8_t intensity) {
  if (world) { Native n; glow(cx >> 1, cy >> 1, r >> 1, hex, intensity); return; }
  if (r < 1) r = 1;
  const int R = hex >> 16, G = (hex >> 8) & 0xFF, B = hex & 0xFF;
  const int r2 = r * r;
  for (int y = -r; y <= r; y++) {
    for (int x = -r; x <= r; x++) {
      int d2 = x * x + y * y;
      if (d2 > r2) continue;
      // 平方衰減，邊緣柔和
      int f = (r2 - d2) * 256 / r2;
      f = f * f >> 8;
      f = f * intensity >> 8;
      if (f <= 2) continue;
      padd(cx + x, cy + y, R * f >> 8, G * f >> 8, B * f >> 8);
    }
  }
}

static inline int palIndex(char ch) {
  if (ch >= '1' && ch <= '9') return ch - '0';
  if (ch >= 'a' && ch <= 'f') return ch - 'a' + 10;
  return 0;
}

// 角色用的光照：把夜晚/陰天的暗色往原色拉回一些，角色才不會沉進背景裡
static uint16_t litLifted(uint32_t hex) {
  const int k = (int)(cfg::CREATURE_LIFT * 256);
  auto up = [k](int t) { return t < 256 ? t + ((256 - t) * k >> 8) : t; };
  int R = (int)(hex >> 16) * up(tint.r) >> 8, G = (int)((hex >> 8) & 0xFF) * up(tint.g) >> 8, B = (int)(hex & 0xFF) * up(tint.b) >> 8;
  return rgb(R > 255 ? 255 : R, G > 255 ? 255 : G, B > 255 ? 255 : B);
}

// 細緻模式的精靈圖：一格 = px 顆原生像素。(cx, by) = 圖的底部中心 (原生座標，by 是腳底下一列)
namespace {
constexpr int FINE_MW = 64, FINE_MH = 58;
constexpr uint8_t OUTLINE = 0xFF;
uint8_t fineGrid[FINE_MW * FINE_MH];
}
static void spriteFine(const Sprite& s, const char* d, int cx, int by, bool flip, const uint16_t* cols, bool litOn, uint8_t alpha, int px) {
  const int gw = s.w * px + 2, gh = s.h * px + 2;  // 四周各留 1 像素給描邊
  uint8_t* g = fineGrid;
  memset(g, 0, (size_t)gw * gh);
  auto src = [&](int i, int j) -> uint8_t {
    if ((unsigned)i >= s.w || (unsigned)j >= s.h) return 0;
    return (uint8_t)palIndex(d[j * s.w + (flip ? s.w - 1 - i : i)]);
  };
  for (int j = 0; j < s.h; j++) {
    for (int i = 0; i < s.w; i++) {
      const uint8_t E = src(i, j);
      uint8_t* o = g + (j * px + 1) * gw + i * px + 1;
      if (px == 3 && cfg::CREATURE_SMOOTH) {
        // Scale3x：斜邊與轉角補上過渡像素，輪廓變圓滑 (透明也當成一種顏色，所以外形一起平滑)
        const uint8_t A = src(i - 1, j - 1), B = src(i, j - 1), C = src(i + 1, j - 1), D = src(i - 1, j), F = src(i + 1, j),
                      G = src(i - 1, j + 1), Hh = src(i, j + 1), I = src(i + 1, j + 1);
        uint8_t e[9] = {E, E, E, E, E, E, E, E, E};
        if (B != Hh && D != F) {
          if (D == B) e[0] = D;
          if ((D == B && E != C) || (B == F && E != A)) e[1] = B;
          if (B == F) e[2] = F;
          if ((D == B && E != G) || (D == Hh && E != A)) e[3] = D;
          if ((B == F && E != I) || (Hh == F && E != C)) e[5] = F;
          if (D == Hh) e[6] = D;
          if ((D == Hh && E != I) || (Hh == F && E != G)) e[7] = Hh;
          if (Hh == F) e[8] = F;
        }
        for (int k = 0; k < 9; k++) o[(k / 3) * gw + (k % 3)] = e[k];
      } else if (px == 2 && cfg::CREATURE_SMOOTH) {
        // Scale2x：同樣的邊緣平滑，2 倍版
        const uint8_t B = src(i, j - 1), D = src(i - 1, j), F = src(i + 1, j), Hh = src(i, j + 1);
        uint8_t e0 = E, e1 = E, e2 = E, e3 = E;
        if (B != Hh && D != F) {
          if (D == B) e0 = D;
          if (B == F) e1 = F;
          if (D == Hh) e2 = D;
          if (Hh == F) e3 = F;
        }
        o[0] = e0; o[1] = e1; o[gw] = e2; o[gw + 1] = e3;
      } else if (E) {
        for (int v = 0; v < px; v++) for (int u = 0; u < px; u++) o[v * gw + u] = E;
      }
    }
  }
  if (cfg::CREATURE_OUTLINE) {
    for (int y = 0; y < gh; y++) {
      for (int x = 0; x < gw; x++) {
        uint8_t* q = g + y * gw + x;
        if (*q) continue;
        auto solid = [](uint8_t v) { return v && v != OUTLINE; };
        if ((x > 0 && solid(q[-1])) || (x < gw - 1 && solid(q[1])) || (y > 0 && solid(q[-gw])) || (y < gh - 1 && solid(q[gw]))) *q = OUTLINE;
      }
    }
  }
  // 描邊：深色半透明 (發光體淡一點)，跟著角色的透明度淡入淡出
  const uint32_t ox = expand565(rgb(0x140E12));
  const uint32_t oa = ((litOn ? 215 : 120) * alpha / 255 + 4) >> 3;
  const uint32_t a32 = (alpha + 4) >> 3;
  const int x0 = cx - gw / 2, y0 = by - gh + 1;
  for (int y = 0; y < gh; y++) {
    const int ty = y0 + y - ty0;
    if ((unsigned)ty >= (unsigned)th) continue;
    uint16_t* row = tbuf + ty * tw;
    const uint8_t* q = g + y * gw;
    for (int x = 0; x < gw; x++) {
      const uint8_t k = q[x];
      const int tx = x0 + x;
      if (!k || (unsigned)tx >= (unsigned)tw) continue;
      if (k == OUTLINE) row[tx] = blendFast(row[tx], ox, oa);
      else if (alpha == 255) row[tx] = cols[k];
      else row[tx] = blendFast(row[tx], expand565(cols[k]), a32);
    }
  }
}

void sprite(const Sprite& s, int frame, int x, int y, bool flip, const uint32_t* pal, bool litOn, uint8_t alpha) {
  // 位置可用世界座標，換算成畫布座標 (圖的左上角)
  if (world) { x >>= 1; y >>= 1; }
  Native native;
  const int px = spritePx;
  const bool fine = px >= 1 && blk == 2 && s.w * px + 2 <= FINE_MW && s.h * px + 2 <= FINE_MH;
  uint16_t cols[16];
  for (int i = 1; i < 16; i++) cols[i] = 0;
  // 先找出用到的最大索引，避免讀到調色盤外面
  const char* d = s.data + (size_t)(frame % s.frames) * s.w * s.h;
  int maxIdx = 0;
  for (int i = 0; i < s.w * s.h; i++) { int k = palIndex(d[i]); if (k > maxIdx) maxIdx = k; }
  for (int i = 1; i <= maxIdx; i++) cols[i] = !litOn ? rgb(pal[i]) : fine ? litLifted(pal[i]) : lit(pal[i]);
  if (fine) {
    // 以原尺寸圖的底部中心為錨點：腳底位置和畫布版一致
    spriteFine(s, d, x * 2 + s.w, (y + s.h) * 2, flip, cols, litOn, alpha, px);
    return;
  }
  for (int j = 0; j < s.h; j++) {
    for (int i = 0; i < s.w; i++) {
      int k = palIndex(d[j * s.w + i]);
      if (!k) continue;
      const int qx = (flip ? s.w - 1 - i : i) + x, qy = j + y;
      if (alpha == 255) pset(qx, qy, cols[k]);
      else pblend(qx, qy, cols[k], alpha);
    }
  }
}
int spritePx = 0;

// ---- 文字 ----
static uint32_t nextCp(const char*& s) {
  uint8_t c = (uint8_t)*s++;
  if (c < 0x80) return c;
  int n = (c >= 0xF0) ? 3 : (c >= 0xE0) ? 2 : (c >= 0xC0) ? 1 : 0;
  uint32_t cp = c & (0x3F >> n);
  while (n-- > 0 && (*s & 0xC0) == 0x80) cp = (cp << 6) | (*s++ & 0x3F);
  return cp;
}

static int glyphIndex(uint32_t cp) {
  if (cp > 0xFFFF) return -1;
  int lo = 0, hi = FONT12_COUNT - 1;
  while (lo <= hi) {
    int mid = (lo + hi) >> 1;
    if (FONT12_CODES[mid] == cp) return mid;
    if (FONT12_CODES[mid] < cp) lo = mid + 1; else hi = mid - 1;
  }
  return -1;
}

int textWidth(const char* s) {
  int w = 0;
  while (*s) { int g = glyphIndex(nextCp(s)); w += g >= 0 ? FONT12_WIDTHS[g] : 6; }
  return w;
}

static int drawText(int x, int y, const char* s, uint16_t color, uint8_t alpha) {
  if (y + FONT12_HEIGHT <= ty0 || y >= ty0 + th) return 0;  // 不在目前分條內
  int x0 = x;
  while (*s) {
    int g = glyphIndex(nextCp(s));
    if (g < 0) { x += 6; continue; }
    const uint16_t* rows = &FONT12_ROWS[(uint32_t)g * FONT12_HEIGHT];
    int gw = FONT12_WIDTHS[g];
    for (int j = 0; j < FONT12_HEIGHT; j++) {
      uint16_t bits = rows[j];
      for (int i = 0; i < gw && bits; i++, bits <<= 1)
        if (bits & 0x8000) { if (alpha == 255) pset(x + i, y + j, color); else pblend(x + i, y + j, color, alpha); }
    }
    x += gw;
  }
  return x - x0;
}

int text(int x, int y, const char* s, uint16_t color) { return drawText(x, y, s, color, 255); }
void textAlpha(int x, int y, const char* s, uint16_t color, uint8_t alpha) { if (alpha) drawText(x, y, s, color, alpha); }

void textShadow(int x, int y, const char* s, uint16_t color, uint16_t shadow) {
  text(x + 1, y + 1, s, shadow);
  text(x, y, s, color);
}

}  // namespace gfx
