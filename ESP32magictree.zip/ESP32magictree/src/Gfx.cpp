#include "Gfx.h"
#include <Arduino.h>
#include <esp_heap_caps.h>
#include <string.h>
#include "assets/Font12.h"

namespace gfx {

uint16_t* fb = nullptr;
uint16_t* bg = nullptr;
uint8_t* skyMask = nullptr;
Tint tint;
uint16_t* tbuf = nullptr;
int tw = W, th = H, ty0 = 0;
bool world = true;

namespace {
// 世界座標的形狀先換算成畫布座標，再以畫布座標繪製
struct Native {
  bool saved;
  Native() : saved(world) { world = false; }
  ~Native() { world = saved; }
};
}  // namespace

void targetScene(bool worldCoords) { tbuf = fb; tw = W; th = H; ty0 = 0; world = worldCoords; }
void targetStrip(uint16_t* buf, int y0, int h) { tbuf = buf; tw = cfg::W; th = h; ty0 = y0; world = false; }

bool begin() {
  const size_t px = (size_t)W * H * 2;
  // 低解析度畫面放內部 RAM (逐像素繪圖較快)
  fb = (uint16_t*)heap_caps_malloc(px, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  if (!fb) fb = (uint16_t*)heap_caps_malloc(px, MALLOC_CAP_SPIRAM);
  bg = (uint16_t*)heap_caps_malloc(px, MALLOC_CAP_SPIRAM);
  skyMask = (uint8_t*)heap_caps_calloc(1, W * H / 8, MALLOC_CAP_SPIRAM);
  targetScene(true);
  return fb && bg && skyMask;
}

void setSky(int x, int y, bool v) {
  if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H) return;
  int i = y * W + x;
  if (v) skyMask[i >> 3] |= (1 << (i & 7));
  else skyMask[i >> 3] &= ~(1 << (i & 7));
}

uint16_t mix(uint16_t a, uint16_t b, uint8_t t) {
  int ar, ag, ab, br, bg_, bb;
  unpack(a, ar, ag, ab);
  unpack(b, br, bg_, bb);
  return rgb(ar + ((br - ar) * t >> 8), ag + ((bg_ - ag) * t >> 8), ab + ((bb - ab) * t >> 8));
}

uint16_t litc(uint8_t r, uint8_t g, uint8_t b) {
  int R = r * tint.r >> 8, G = g * tint.g >> 8, B = b * tint.b >> 8;
  return rgb(R > 255 ? 255 : R, G > 255 ? 255 : G, B > 255 ? 255 : B);
}
uint16_t lit(uint32_t hex) { return litc(hex >> 16, (hex >> 8) & 0xFF, hex & 0xFF); }

void pblend(int x, int y, uint16_t c, uint8_t a) {
  if (uint16_t* p = at(x, y)) *p = blendFast(*p, expand565(c), (a + 4) >> 3);
}

void padd(int x, int y, int r, int g, int b) {
  uint16_t* p = at(x, y);
  if (!p) return;
  int pr, pg, pb;
  unpack(*p, pr, pg, pb);
  pr += r; pg += g; pb += b;
  *p = rgb(pr > 255 ? 255 : pr, pg > 255 ? 255 : pg, pb > 255 ? 255 : pb);
}

void fillRect(int x, int y, int w, int h, uint16_t c) {
  if (world) { Native n; fillRect(x >> 1, y >> 1, (w + 1) >> 1, (h + 1) >> 1, c); return; }
  y -= ty0;
  if (x < 0) { w += x; x = 0; }
  if (y < 0) { h += y; y = 0; }
  if (x + w > tw) w = tw - x;
  if (y + h > th) h = th - y;
  if (w <= 0 || h <= 0) return;
  for (int j = 0; j < h; j++) {
    uint16_t* p = tbuf + (y + j) * tw + x;
    for (int i = 0; i < w; i++) p[i] = c;
  }
}

void blendRect(int x, int y, int w, int h, uint16_t c, uint8_t a) {
  if (world) { Native n; blendRect(x >> 1, y >> 1, (w + 1) >> 1, (h + 1) >> 1, c, a); return; }
  // 先裁切到目前目標 (分條繪製時很重要)
  int y1 = y + h, x1 = x + w;
  if (y < ty0) y = ty0;
  if (y1 > ty0 + th) y1 = ty0 + th;
  if (x < 0) x = 0;
  if (x1 > tw) x1 = tw;
  const uint32_t cx = expand565(c), a32 = (a + 4) >> 3;
  for (int j = y; j < y1; j++) {
    uint16_t* row = tbuf + (j - ty0) * tw;
    for (int i = x; i < x1; i++) row[i] = blendFast(row[i], cx, a32);
  }
}

void hline(int x, int y, int w, uint16_t c) { fillRect(x, y, w, 1, c); }
void vline(int x, int y, int h, uint16_t c) { fillRect(x, y, 1, h, c); }

void line(int x0, int y0, int x1, int y1, uint16_t c) {
  if (world) { Native n; line(x0 >> 1, y0 >> 1, x1 >> 1, y1 >> 1, c); return; }
  int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1, err = dx + dy;
  for (;;) {
    pset(x0, y0, c);
    if (x0 == x1 && y0 == y1) break;
    int e2 = 2 * err;
    if (e2 >= dy) { err += dy; x0 += sx; }
    if (e2 <= dx) { err += dx; y0 += sy; }
  }
}

void fillEllipse(int cx, int cy, int rx, int ry, uint16_t c) {
  if (world) { Native n; fillEllipse(cx >> 1, cy >> 1, rx >> 1, ry >> 1, c); return; }
  if (rx <= 0 || ry <= 0) { pset(cx, cy, c); return; }
  for (int y = -ry; y <= ry; y++) {
    float t = 1.0f - (float)(y * y) / (float)(ry * ry);
    int hw = (int)(rx * sqrtf(t > 0 ? t : 0) + 0.5f);
    hline(cx - hw, cy + y, hw * 2 + 1, c);
  }
}
void fillCircle(int cx, int cy, int r, uint16_t c) { fillEllipse(cx, cy, r, r, c); }

void blendEllipse(int cx, int cy, int rx, int ry, uint16_t c, uint8_t a) {
  if (world) { Native n; blendEllipse(cx >> 1, cy >> 1, (rx + 1) >> 1, (ry + 1) >> 1, c, a); return; }
  if (rx <= 0 || ry <= 0) return;
  for (int y = -ry; y <= ry; y++) {
    float t = 1.0f - (float)(y * y) / (float)(ry * ry);
    int hw = (int)(rx * sqrtf(t > 0 ? t : 0) + 0.5f);
    for (int x = -hw; x <= hw; x++) pblend(cx + x, cy + y, c, a);
  }
}

void glow(int cx, int cy, int r, uint32_t hex, uint8_t intensity) {
  if (world) { Native n; glow(cx >> 1, cy >> 1, r >> 1, hex, intensity); return; }
  if (r < 1) r = 1;
  const int R = hex >> 16, G = (hex >> 8) & 0xFF, B = hex & 0xFF;
  const int r2 = r * r;
  for (int y = -r; y <= r; y++) {
    for (int x = -r; x <= r; x++) {
      int d2 = x * x + y * y;
      if (d2 > r2) continue;
      // 平方衰減，邊緣柔和
      int f = (r2 - d2) * 256 / r2;
      f = f * f >> 8;
      f = f * intensity >> 8;
      if (f <= 2) continue;
      padd(cx + x, cy + y, R * f >> 8, G * f >> 8, B * f >> 8);
    }
  }
}

static inline int palIndex(char ch) {
  if (ch >= '1' && ch <= '9') return ch - '0';
  if (ch >= 'a' && ch <= 'f') return ch - 'a' + 10;
  return 0;
}

void sprite(const Sprite& s, int frame, int x, int y, bool flip, const uint32_t* pal, bool litOn, uint8_t alpha) {
  // 位置可用世界座標，像素一律 1:1 畫在畫布上 (角色在螢幕上是 2 倍大)
  if (world) { x >>= 1; y >>= 1; }
  Native native;
  uint16_t cols[16];
  for (int i = 1; i < 16; i++) cols[i] = 0;
  // 先找出用到的最大索引，避免讀到調色盤外面
  const char* d = s.data + (size_t)(frame % s.frames) * s.w * s.h;
  int maxIdx = 0;
  for (int i = 0; i < s.w * s.h; i++) { int k = palIndex(d[i]); if (k > maxIdx) maxIdx = k; }
  for (int i = 1; i <= maxIdx; i++) cols[i] = litOn ? lit(pal[i]) : rgb(pal[i]);
  const int sc = spriteScale < 1 ? 1 : spriteScale;
  if (sc > 1) { x += s.w / 2 - s.w * sc / 2; y += s.h - s.h * sc; }  // 底部中心不動
  for (int j = 0; j < s.h; j++) {
    for (int i = 0; i < s.w; i++) {
      int k = palIndex(d[j * s.w + i]);
      if (!k) continue;
      const int px = (flip ? s.w - 1 - i : i) * sc + x, py = j * sc + y;
      for (int dy = 0; dy < sc; dy++)
        for (int dx = 0; dx < sc; dx++) {
          if (alpha == 255) pset(px + dx, py + dy, cols[k]);
          else pblend(px + dx, py + dy, cols[k], alpha);
        }
    }
  }
}
int spriteScale = 1;

// ---- 文字 ----
static uint32_t nextCp(const char*& s) {
  uint8_t c = (uint8_t)*s++;
  if (c < 0x80) return c;
  int n = (c >= 0xF0) ? 3 : (c >= 0xE0) ? 2 : (c >= 0xC0) ? 1 : 0;
  uint32_t cp = c & (0x3F >> n);
  while (n-- > 0 && (*s & 0xC0) == 0x80) cp = (cp << 6) | (*s++ & 0x3F);
  return cp;
}

static int glyphIndex(uint32_t cp) {
  if (cp > 0xFFFF) return -1;
  int lo = 0, hi = FONT12_COUNT - 1;
  while (lo <= hi) {
    int mid = (lo + hi) >> 1;
    if (FONT12_CODES[mid] == cp) return mid;
    if (FONT12_CODES[mid] < cp) lo = mid + 1; else hi = mid - 1;
  }
  return -1;
}

int textWidth(const char* s) {
  int w = 0;
  while (*s) { int g = glyphIndex(nextCp(s)); w += g >= 0 ? FONT12_WIDTHS[g] : 6; }
  return w;
}

static int drawText(int x, int y, const char* s, uint16_t color, uint8_t alpha) {
  if (y + FONT12_HEIGHT <= ty0 || y >= ty0 + th) return 0;  // 不在目前分條內
  int x0 = x;
  while (*s) {
    int g = glyphIndex(nextCp(s));
    if (g < 0) { x += 6; continue; }
    const uint16_t* rows = &FONT12_ROWS[(uint32_t)g * FONT12_HEIGHT];
    int gw = FONT12_WIDTHS[g];
    for (int j = 0; j < FONT12_HEIGHT; j++) {
      uint16_t bits = rows[j];
      for (int i = 0; i < gw && bits; i++, bits <<= 1)
        if (bits & 0x8000) { if (alpha == 255) pset(x + i, y + j, color); else pblend(x + i, y + j, color, alpha); }
    }
    x += gw;
  }
  return x - x0;
}

int text(int x, int y, const char* s, uint16_t color) { return drawText(x, y, s, color, 255); }
void textAlpha(int x, int y, const char* s, uint16_t color, uint8_t alpha) { if (alpha) drawText(x, y, s, color, alpha); }

void textShadow(int x, int y, const char* s, uint16_t color, uint16_t shadow) {
  text(x + 1, y + 1, s, shadow);
  text(x, y, s, color);
}

}  // namespace gfx
