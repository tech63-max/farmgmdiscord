#include "SeasonManager.h"
#include "Config.h"
#include "Util.h"

namespace season {
namespace {
float w[4] = {1, 0, 0, 0};
int lastDay = -1;
// 季節開始日 (北半球 day-of-year)：春分、夏至、秋分、冬至
const int START[4] = {79, 172, 265, 355};
constexpr int BLEND = 15;
}  // namespace

void update(int yday) {
  if (yday == lastDay) return;
  lastDay = yday;
  int d = yday;
  if (FOREST_LAT < 0) d = (d + 182) % 365;  // 南半球季節相反
  for (int i = 0; i < 4; i++) w[i] = 0;
  // 找出目前季節，再看離邊界多近
  int cur = 3;
  for (int i = 3; i >= 0; i--) if (d >= START[i]) { cur = i; break; }
  int start = START[cur], next = cur == 3 ? START[0] + 365 : START[cur + 1];
  int dd = d < start ? d + 365 : d;  // 冬季跨年
  if (cur == 3 && d < START[0]) dd = d + 365;
  float sinceStart = dd - start, toNext = next - dd;
  w[cur] = 1;
  if (sinceStart < BLEND) {
    float t = 0.5f + 0.5f * sinceStart / BLEND;
    int prev = (cur + 3) % 4;
    w[cur] = t; w[prev] = 1 - t;
  } else if (toNext < BLEND) {
    float t = 0.5f + 0.5f * toNext / BLEND;
    int nx = (cur + 1) % 4;
    w[cur] = t; w[nx] = 1 - t;
  }
}

float weight(Season s) { return w[s]; }
Season dominant() {
  int best = 0;
  for (int i = 1; i < 4; i++) if (w[i] > w[best]) best = i;
  return (Season)best;
}
const char* name(Season s) {
  static const char* N[4] = {"春", "夏", "秋", "冬"};
  return N[s];
}
}  // namespace season
