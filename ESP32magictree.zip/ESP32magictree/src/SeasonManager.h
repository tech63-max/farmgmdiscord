// 季節：依當地日期 (與南北半球) 計算，季節交界前後 15 天平滑過渡
#pragma once
#include "World.h"

namespace season {
void update(int yday);
float weight(Season s);  // 0..1，四季總和 = 1
Season dominant();
const char* name(Season s);
}  // namespace season
