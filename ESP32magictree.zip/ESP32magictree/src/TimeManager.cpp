#include "TimeManager.h"
#include <Arduino.h>
#include <time.h>
#include <math.h>
#include "Config.h"
#include "Util.h"

namespace timem {
namespace {
uint32_t baseEpoch = 0;       // 未同步時的基準
uint32_t baseMillis = 0;
double offsetSec = 0;         // 縮時/快轉累積
float scale = 1.0f;
int32_t utcOff = 8 * 3600;
bool ntpStarted = false;
Local loc{};
float riseH = -1, setH = -1;  // 天氣資料提供的日出日落
float elev = 0, dayF = 1;
DayPhase ph = PH_MORNING;

void applyTz() {
  // POSIX TZ 的正負號跟 UTC offset 相反
  char tz[24];
  int32_t o = -utcOff;
  snprintf(tz, sizeof(tz), "UTC%c%ld:%02ld", o < 0 ? '-' : '+', (long)(labs(o) / 3600), (long)((labs(o) % 3600) / 60));
  setenv("TZ", tz, 1);
  tzset();
}

uint32_t compileEpoch() {
  // __DATE__ = "Nov 10 2026"；沒有存檔也沒網路時，從編譯日的早上 8 點開始
  static const char* mons = "JanFebMarAprMayJunJulAugSepOctNovDec";
  char m[4] = {__DATE__[0], __DATE__[1], __DATE__[2], 0};
  struct tm t{};
  t.tm_mon = (strstr(mons, m) - mons) / 3;
  t.tm_mday = atoi(__DATE__ + 4);
  t.tm_year = atoi(__DATE__ + 7) - 1900;
  t.tm_hour = 8;
  return (uint32_t)mktime(&t);
}

void computeSun() {
  float rise = riseH, set = setH;
  if (rise < 0 || set < 0) {
    // 依季節估算日照長度 (北半球，緯度越高差越多)
    float amp = 1.0f + fabsf(FOREST_LAT) / 30.0f;
    float d = cosf(2 * PI * (loc.yday - 172) / 365.0f) * (FOREST_LAT >= 0 ? 1 : -1);
    float len = 12.0f + amp * d;
    rise = 12.2f - len / 2;
    set = 12.2f + len / 2;
  }
  const float h = loc.hourF;
  if (h >= rise && h <= set) {
    elev = sinf(PI * (h - rise) / (set - rise));
  } else {
    float dist = h < rise ? rise - h : h - set;
    if (h < rise && h + 24 - set < dist) dist = h + 24 - set;
    elev = -util::clamp01(dist / 2.0f);
  }
  dayF = util::smooth((elev + 0.18f) / 0.36f);
  if (h < rise - 0.6f || h > set + 0.7f) ph = PH_NIGHT;
  else if (h < rise + 1.0f) ph = PH_DAWN;
  else if (h < 11.0f) ph = PH_MORNING;
  else if (h < 14.0f) ph = PH_NOON;
  else if (h < set - 1.2f) ph = PH_AFTERNOON;
  else ph = PH_DUSK;
}

void refreshLocal() {
  time_t t = (time_t)now();
  struct tm tm;
  localtime_r(&t, &tm);
  loc.year = tm.tm_year + 1900; loc.mon = tm.tm_mon + 1; loc.mday = tm.tm_mday;
  loc.hour = tm.tm_hour; loc.min = tm.tm_min; loc.sec = tm.tm_sec; loc.yday = tm.tm_yday;
  loc.hourF = tm.tm_hour + tm.tm_min / 60.0f + tm.tm_sec / 3600.0f;
  computeSun();
}
}  // namespace

void begin(uint32_t savedEpoch, int32_t savedUtcOffset) {
  if (savedUtcOffset >= -14 * 3600 && savedUtcOffset <= 14 * 3600 && savedUtcOffset != 0) utcOff = savedUtcOffset;
  applyTz();
  const uint32_t ce = compileEpoch();
  baseEpoch = savedEpoch > ce ? savedEpoch : ce;
  baseMillis = millis();
  refreshLocal();
}

void onNetworkUp() {
  if (ntpStarted) return;
  ntpStarted = true;
  configTime(0, 0, cfg::NTP1, cfg::NTP2);  // 非阻塞，背景同步
  applyTz();                               // configTime 會覆寫 TZ
}

bool synced() { return time(nullptr) > 1700000000; }

uint32_t now() {
  uint32_t base = synced() ? (uint32_t)time(nullptr) : baseEpoch + (millis() - baseMillis) / 1000;
  return base + (uint32_t)(int64_t)offsetSec;
}

void update(uint32_t dtMs) {
  if (scale != 1.0f) offsetSec += dtMs * 0.001 * (scale - 1.0f);
  refreshLocal();
}

void setUtcOffset(int32_t sec) {
  if (sec == utcOff || sec < -14 * 3600 || sec > 14 * 3600) return;
  utcOff = sec;
  applyTz();
}
int32_t utcOffset() { return utcOff; }
const Local& local() { return loc; }
void setSunTimes(float r, float s) { riseH = r; setH = s; }
float sunriseH() { return riseH >= 0 ? riseH : 6.0f; }
float sunsetH() { return setH >= 0 ? setH : 18.0f; }
float sunElev() { return elev; }
float dayFactor() { return dayF; }
DayPhase phase() { return ph; }
uint8_t phaseMask() { return 1 << ph; }

float moonPhase() {
  // 參考新月 2000-01-06 18:14 UTC，朔望月 29.53059 天
  double days = ((double)now() - 947182440.0) / 86400.0;
  double p = fmod(days / 29.53059, 1.0);
  return (float)(p < 0 ? p + 1 : p);
}

void setTimeScale(float s) { scale = util::clamp(s, 1.0f, 3600.0f); }
float timeScale() { return scale; }
void skip(int32_t sec) { offsetSec += sec; refreshLocal(); }

void format(uint32_t epoch, char* buf, int cap, bool withDate) {
  time_t t = (time_t)epoch;
  struct tm tm;
  localtime_r(&t, &tm);
  if (withDate) snprintf(buf, cap, "%04d-%02d-%02d %02d:%02d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min);
  else snprintf(buf, cap, "%02d:%02d", tm.tm_hour, tm.tm_min);
}

}  // namespace timem
