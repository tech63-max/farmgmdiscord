// 地下生態：不另開畫面，透過洞口、泥土、積水、菌絲與生物行為讓人「發現」地下世界
#pragma once
#include <stdint.h>

namespace under {

// 洞穴狀態：新挖 → 有住戶 → (豪雨) 淹水 → 廢棄 → 被蘑菇佔據 → 被植物遮住 → 消失
enum BState : uint8_t { B_NONE, B_FRESH, B_OCCUPIED, B_FLOODED, B_ABANDONED, B_MUSHROOM, B_HIDDEN };

struct Burrow {
  uint8_t state;
  uint8_t occupant;   // 物種編號 (creature::Species)
  int16_t x, y;       // 世界座標
  float ageH;         // 目前狀態經過的時數 (float：每次只增加很少)
  uint8_t generation; // 住過幾代 (棲息地延續)
  uint8_t pad;
  float dirt;         // 洞口新鮮泥土 (0..1，慢慢消失)
};
constexpr int CAP = 3;

struct Blob {
  float moist, water, temp, mycel, roots;
  Burrow b[CAP];
  uint32_t lastDig;
};

void begin();
void tick(float dtH);                    // 森林時間 (小時)
void update(float dt, uint32_t ms);      // 動畫 (泥土飛濺)
void draw(uint32_t ms);                  // 在 120 畫布上畫洞口、菌絲
int dig(float x, float y, uint8_t occupant, uint32_t ms);  // 挖新洞 (回傳索引，-1 = 已滿)
int digNear(uint8_t occupant, uint32_t ms);                 // 在適合的地點挖洞
int nearest(float x, float& bx, float& by);                // 最近的可躲藏洞穴
int findState(uint8_t state);
int count();
Burrow& at(int i);
void setState(int i, uint8_t st);
void eyes(int i, uint32_t ms);           // 洞口出現發光的眼睛
void glowMycelium(uint32_t ms);          // 菌絲網絡短暫發光
float water();
float mycelium();
float moisture();
float growthBonus(uint8_t plantSpecies); // 地下水/菌絲對地表植物的加成 (乘數)
void addMycelium(float v);
void addWater(float v);
const char* stateName(uint8_t s);
void exportBlob(Blob& b);
void importBlob(const Blob& b);

}  // namespace under
