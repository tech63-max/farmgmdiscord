// 考古與失落文明：遺跡有固定位置與歷史狀態，透過「大雨沖刷 → 露出石板 → 冒險家挖掘 → 研究」被發現
// 遺跡永久存在，會被苔蘚與樹根逐漸包圍，但保留輪廓
#pragma once
#include <stdint.h>

namespace ruins {

enum Type : uint8_t { R_STELE, R_GATE, R_CHEST, R_PILLAR, R_STATUE, R_ENTRANCE, R_STONEBRIDGE, R_COUNT };
constexpr uint8_t F_STUDIED = 1, F_MARKED = 2, F_RUNES = 4, F_OPENED = 8;
constexpr int CAP = 4;

struct Ruin {
  uint8_t type;   // R_COUNT = 尚未發現
  uint8_t flags;
  uint16_t pad;
  float reveal;   // 0 埋著 .. 0.2 露出一角 .. 1 完全出土
  float moss, roots;
  uint32_t found;
};
struct Blob {
  Ruin r[CAP];
  uint8_t nextType;
  uint8_t pad[3];
  uint32_t lastFind;
};

void begin();
void tick(float dtH);
void draw(uint32_t ms);
bool erode(uint32_t ms);          // 大雨沖刷：露出新的遺跡一角 (回傳是否成功)
int exposed();                    // 露出一角、等待挖掘的遺跡 (-1 = 無)
int excavated();                  // 已出土的遺跡 (隨機一個，-1 = 無)
void excavate(int i, uint32_t ms);
void study(int i);
void mark(int i);
void glow(int i, uint32_t ms);
int find(Type t);                 // 已出土的某種遺跡
bool gateHasRunes();
bool hasFreeSite();               // 還有尚未出現遺跡的位置
Ruin& at(int i);
void pos(int i, int& x, int& y);  // 世界座標
const char* name(uint8_t t);
void exportBlob(Blob& b);
void importBlob(const Blob& b);

}  // namespace ruins
