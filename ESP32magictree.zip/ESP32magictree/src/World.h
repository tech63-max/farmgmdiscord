// 各模組共用的列舉
#pragma once
#include <stdint.h>

enum DayPhase : uint8_t { PH_NIGHT, PH_DAWN, PH_MORNING, PH_NOON, PH_AFTERNOON, PH_DUSK, PH_COUNT };
constexpr uint8_t PM_NIGHT = 1 << PH_NIGHT, PM_DAWN = 1 << PH_DAWN, PM_MORNING = 1 << PH_MORNING,
                  PM_NOON = 1 << PH_NOON, PM_AFTERNOON = 1 << PH_AFTERNOON, PM_DUSK = 1 << PH_DUSK;
constexpr uint8_t PM_DAY = PM_MORNING | PM_NOON | PM_AFTERNOON;
constexpr uint8_t PM_ALL = 0x3F;

enum Season : uint8_t { SPRING, SUMMER, AUTUMN, WINTER };

enum class SkyKind : uint8_t { Clear, PartCloud, Overcast, Fog, Drizzle, Rain, Storm, Snow };
inline bool skyWet(SkyKind s) { return s == SkyKind::Drizzle || s == SkyKind::Rain || s == SkyKind::Storm; }
