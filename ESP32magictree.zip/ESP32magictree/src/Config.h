// 硬體腳位與全域參數 —— 腳位全部取自 PINOUT.md (Waveshare ESP32-S3-LCD-1.54，實機驗證)
#pragma once
#include <stdint.h>

#if __has_include("Secrets.h")
#include "Secrets.h"
#else
#include "Secrets.example.h"
#endif

namespace cfg {
// LCD ST7789 240x240 SPI
constexpr int PIN_LCD_SCK = 38, PIN_LCD_MOSI = 39, PIN_LCD_CS = 21, PIN_LCD_DC = 45, PIN_LCD_RST = 40, PIN_LCD_BL = 46;
// 按鍵 (按下 = LOW)
constexpr int PIN_BTN_BOOT = 0, PIN_BTN_PWR = 5, PIN_BTN_PLUS = 4;
// 電源
constexpr int PIN_POWER_LATCH = 2, PIN_AMP = 7;
// microSD SDMMC 4-bit
constexpr int SD_CLK = 16, SD_CMD = 15, SD_D0 = 17, SD_D1 = 18, SD_D2 = 13, SD_D3 = 14;

constexpr int W = 240, H = 240;
constexpr uint32_t LCD_SPI_HZ = 40000000;
// 畫面方向 (由 LCD 控制器旋轉，文字 UI 也一起轉)：0 = 原始，1 = 右轉 90°
// 註：這塊 240x240 面板的顯示記憶體是 240x320，旋轉 2/3 需要額外的 80 像素位移
constexpr uint8_t LCD_ROTATION = 1;
constexpr uint32_t FRAME_MS = 50;            // ~20 fps
constexpr uint8_t BL_DAY_PCT = 80, BL_NIGHT_PCT = 35;

// 天氣
constexpr uint32_t WEATHER_INTERVAL_S = 40 * 60;   // 成功後 40 分鐘更新一次
constexpr uint32_t WEATHER_RETRY_S = 5 * 60;       // 失敗後 5 分鐘重試
constexpr uint32_t WEATHER_STALE_S = 3 * 3600;     // 超過 3 小時視為過期 → 本地模擬天氣
constexpr const char* NTP1 = "pool.ntp.org";
constexpr const char* NTP2 = "time.google.com";
constexpr const char* DEFAULT_TZ = "CST-8";        // Open-Meteo 回傳 utc_offset 後會自動校正

constexpr uint32_t SAVE_INTERVAL_S = 15 * 60;      // NVS 寫入間隔 (考量 Flash 壽命)
constexpr uint32_t CATCHUP_MAX_S = 3 * 24 * 3600;  // 關機期間補算生長的上限

// 玩家互動冷卻 (秒)
constexpr uint32_t CD_BLESS = 90, CD_BREEZE = 60, CD_PULSE = 240, CD_GLOBAL = 15;

// 事件節奏：兩個事件之間的間隔 (真實秒數，連鎖事件也算在內)；超過 QUIET_MAX 仍抽不到時放寬冷卻挑日常事件
constexpr uint32_t QUIET_MIN = 60, QUIET_MAX = 180;

// 常駐生物上限 (自然出現的生物；事件帶來的生物不受限制)。螢火蟲另計
constexpr int AMBIENT_MAX = 2, AMBIENT_FIREFLY_MAX = 3;

// 生物/訪客在畫面上的放大倍率 (1 = 原本大小)。白鹿、巨龜本來就大，不放大
constexpr int CREATURE_SCALE = 2;
// 生物頭上的狀態小圖示 (睡覺 z、受驚/躲藏 !、被困住 紅色 !)
constexpr bool CREATURE_EMOTES = true;

// 背景鮮豔度 (飽和度倍率，1.0 = 原本的顏色)：草地、樹木、池塘、遠山
constexpr float BG_VIVID = 1.45f;

constexpr bool SHOW_CORNER_CLOCK = true;  // 右上角低調時鐘
}  // namespace cfg
