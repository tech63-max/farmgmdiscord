#include "SaveManager.h"
#include <Arduino.h>
#include <Preferences.h>
#include <esp_rom_crc.h>
#include <string.h>
#include "CreatureManager.h"
#include "Ecosystem.h"
#include "EventMemory.h"
#include "Journal.h"
#include "PlantManager.h"
#include "Families.h"
#include "ForestHistory.h"
#include "Ruins.h"
#include "Underground.h"
#include "Village.h"
#include "Evolution.h"
#include "StructureManager.h"
#include "VisitorManager.h"
#include "TimeManager.h"
#include "WeatherManager.h"

namespace save {
namespace {
constexpr uint32_t MAGIC = 0x46524F53;  // "FROS"
constexpr uint16_t VERSION = 1;

struct Blob {
  uint32_t magic;
  uint16_t version, size;
  uint32_t crc;
  // ---- 以下參與 CRC ----
  uint32_t epoch;
  int32_t utcOff;
  plant::Plant plants[plant::SLOT_N];
  plant::Deadwood log;
  float nest;
  uint32_t seen[creature::C_LEGACY];  // 第一版格式固定 11 種 (新物種存在 world 區)
  uint32_t away[creature::C_LEGACY];
  float airHum, soil, hoursSinceRain;
  weather::Snapshot ws;
  evmem::Blob em;
  journal::Entry jr[journal::CAP];
  uint8_t jrN;
};
Blob b;
bool ok = false;

// 訪客與建築 (擴充功能，獨立存放：舊存檔不受影響)
constexpr uint32_t HMAGIC = 0x48554D31;  // "HUM1"
struct HumanBlob {
  uint32_t magic;
  uint16_t size;
  uint32_t crc;
  structure::Blob st;
  visitor::Stats vs;
};
HumanBlob hb;
bool hok = false;
// ---- 世界存檔 第一版 (NVS key "world")：只用來讀取舊資料並轉換，大小全部寫死，格式不可再改 ----
constexpr uint32_t WMAGIC1 = 0x574F5231;  // "WOR1"
struct WorldBlobV1 {
  uint32_t magic;
  uint16_t size;
  uint32_t crc;
  struct { uint32_t last[56]; uint16_t times[56]; } emx;  // 第一版事件記憶擴充 (編號 40..95)
  uint32_t seenX[3], awayX[3];                             // 第一版的新物種：地鼠、蜜蜂、松鼠
  eco::World ew;
  under::Blob ub;
  ruins::Blob rb;
  history::Blob hb;
  families::Blob fb;
  village::Blob vb;
  uint32_t vx[2];                                          // 第一版的新故事：挖掘、重返
};
// ---- 世界存檔 第二版 (NVS key "world2")：事件容量 200、遠古巨龜、任務故事、世界演化 ----
constexpr uint32_t WMAGIC2 = 0x574F5232;  // "WOR2"
constexpr uint16_t WVERSION = 2;
constexpr int NEW_SPECIES = creature::C_COUNT - creature::C_LEGACY;
struct WorldBlob {
  uint32_t magic;
  uint16_t version, size;
  uint32_t crc;
  evmem::BlobExt emx;
  uint32_t seenX[NEW_SPECIES], awayX[NEW_SPECIES];
  eco::World ew;
  under::Blob ub;
  ruins::Blob rb;
  history::Blob hb;
  families::Blob fb;
  village::Blob vb;
  visitor::StatsExt vx;
  evo::Blob evb;
};
WorldBlob wb, wcheck;
WorldBlobV1 w1;
bool wok = false;
bool migratedV1 = false;  // 這次開機從第一版轉換來的 (寫入第二版成功後會刪除第一版)
uint32_t lastHumanCrc = 0, lastWorldCrc = 0;  // 沒有變化就不寫入 NVS
uint32_t wcrc(const WorldBlob& x) { return esp_rom_crc32_le(0, (const uint8_t*)&x.emx, sizeof(WorldBlob) - offsetof(WorldBlob, emx)); }
uint32_t w1crc(const WorldBlobV1& x) { return esp_rom_crc32_le(0, (const uint8_t*)&x.emx, sizeof(WorldBlobV1) - offsetof(WorldBlobV1, emx)); }

// 第一版 → 第二版 (只複製存在的欄位，新欄位用預設值)
void convertV1(const WorldBlobV1& o, WorldBlob& n) {
  memset(&n, 0, sizeof(n));
  for (int i = 0; i < 56; i++) { n.emx.last[i] = o.emx.last[i]; n.emx.times[i] = o.emx.times[i]; }
  for (int i = 0; i < 3 && i < NEW_SPECIES; i++) { n.seenX[i] = o.seenX[i]; n.awayX[i] = o.awayX[i]; }
  n.ew = o.ew; n.ub = o.ub; n.rb = o.rb; n.hb = o.hb; n.fb = o.fb; n.vb = o.vb;
  for (int i = 0; i < 2; i++) n.vx.lastStory[i] = o.vx[i];
  evo::Blob fresh;
  evo::exportBlob(fresh);  // 世界演化用全新狀態 (evo::begin 已初始化)
  n.evb = fresh;
}

uint32_t hcrc(const HumanBlob& x) { return esp_rom_crc32_le(0, (const uint8_t*)&x.st, sizeof(HumanBlob) - offsetof(HumanBlob, st)); }

uint32_t crcOf(const Blob& x) {
  const uint8_t* p = (const uint8_t*)&x.epoch;
  size_t len = sizeof(Blob) - offsetof(Blob, epoch);
  return esp_rom_crc32_le(0, p, len);
}
}  // namespace

bool load() {
  Preferences p;
  ok = false;
  if (!p.begin("forest", true)) return false;
  size_t n = p.getBytesLength("eco");
  if (n == sizeof(Blob)) {
    p.getBytes("eco", &b, sizeof(Blob));
    ok = b.magic == MAGIC && b.version == VERSION && b.size == sizeof(Blob) && b.crc == crcOf(b);
  }
  hok = false;
  if (p.getBytesLength("human") == sizeof(HumanBlob)) {
    p.getBytes("human", &hb, sizeof(HumanBlob));
    hok = hb.magic == HMAGIC && hb.size == sizeof(HumanBlob) && hb.crc == hcrc(hb);
    if (hok) lastHumanCrc = hb.crc;
  }
  wok = false;
  migratedV1 = false;
  if (p.getBytesLength("world2") == sizeof(WorldBlob)) {
    p.getBytes("world2", &wb, sizeof(WorldBlob));
    wok = wb.magic == WMAGIC2 && wb.version == WVERSION && wb.size == sizeof(WorldBlob) && wb.crc == wcrc(wb);
    if (wok) lastWorldCrc = wb.crc;
  }
  if (!wok && p.getBytesLength("world") == sizeof(WorldBlobV1)) {
    // 只讀第一版，先在記憶體中轉換；寫入第二版成功前不會動到原始資料
    p.getBytes("world", &w1, sizeof(WorldBlobV1));
    if (w1.magic == WMAGIC1 && w1.size == sizeof(WorldBlobV1) && w1.crc == w1crc(w1)) {
      wok = true;
      migratedV1 = true;
      Serial.println("[Save] world v1 found, will migrate to v2");
    }
  }
  Serial.printf("[Save] human %s, world %s (%u bytes)\n", hok ? "ok" : "none", wok ? "ok" : "none", (unsigned)sizeof(WorldBlob));
  p.end();
  Serial.printf("[Save] load %s (%u bytes)\n", ok ? "ok" : "none/invalid", (unsigned)n);
  return ok;
}

bool loaded() { return ok; }
uint32_t savedEpoch() { return ok ? b.epoch : 0; }
int32_t savedUtcOffset() { return ok ? b.utcOff : 0; }

void applyLoaded() {
  if (!ok) return;
  for (int i = 0; i < plant::SLOT_N; i++) {
    plant::Plant& d = plant::mut(i);
    d = b.plants[i];
    if (d.species >= plant::P_COUNT) d = {};
  }
  plant::setLog(b.log);
  creature::setNestProgress(b.nest);
  for (int i = 0; i < creature::C_LEGACY; i++) { creature::setLastSeen(i, b.seen[i]); creature::setAwayUntil(i, b.away[i]); }
  eco::env.airHum = b.airHum;
  eco::env.soil = b.soil;
  eco::env.hoursSinceRain = b.hoursSinceRain;
  weather::restoreSnapshot(b.ws);
  evmem::importBlob(b.em);
  journal::importRing(b.jr, b.jrN);
}

void applyHuman() {
  if (hok) {
    structure::importBlob(hb.st);
    visitor::importStats(hb.vs);
  }
  if (wok && migratedV1) convertV1(w1, wb);  // evo::begin 之後才轉換 (取得世界演化的初始值)
  if (wok) {
    evmem::importExt(wb.emx);
    for (int i = 0; i < NEW_SPECIES; i++) {
      creature::setLastSeen(creature::C_LEGACY + i, wb.seenX[i]);
      creature::setAwayUntil(creature::C_LEGACY + i, wb.awayX[i]);
    }
    eco::world = wb.ew;
    under::importBlob(wb.ub);
    ruins::importBlob(wb.rb);
    history::importBlob(wb.hb);
    families::importBlob(wb.fb);
    village::importBlob(wb.vb);
    visitor::importExt(wb.vx);
    evo::importBlob(wb.evb);
  }
}

bool migrated() { return migratedV1; }

bool write() {
  memset(&b, 0, sizeof(b));
  b.magic = MAGIC;
  b.version = VERSION;
  b.size = sizeof(Blob);
  b.epoch = timem::now();
  b.utcOff = timem::utcOffset();
  for (int i = 0; i < plant::SLOT_N; i++) b.plants[i] = plant::get(i);
  b.log = plant::log();
  b.nest = creature::nestProgress();
  for (int i = 0; i < creature::C_LEGACY; i++) { b.seen[i] = creature::lastSeen(i); b.away[i] = creature::awayUntil(i); }
  b.airHum = eco::env.airHum;
  b.soil = eco::env.soil;
  b.hoursSinceRain = eco::env.hoursSinceRain;
  weather::getSnapshot(b.ws);
  evmem::exportBlob(b.em);
  journal::exportRing(b.jr, b.jrN);
  b.crc = crcOf(b);
  Preferences p;
  if (!p.begin("forest", false)) return false;
  size_t w = p.putBytes("eco", &b, sizeof(b));
  memset(&hb, 0, sizeof(hb));
  hb.magic = HMAGIC;
  hb.size = sizeof(HumanBlob);
  structure::exportBlob(hb.st);
  visitor::exportStats(hb.vs);
  hb.crc = hcrc(hb);
  if (hb.crc != lastHumanCrc && p.putBytes("human", &hb, sizeof(hb)) == sizeof(hb)) lastHumanCrc = hb.crc;
  memset(&wb, 0, sizeof(wb));
  wb.magic = WMAGIC2;
  wb.version = WVERSION;
  wb.size = sizeof(WorldBlob);
  evmem::exportExt(wb.emx);
  for (int i = 0; i < NEW_SPECIES; i++) {
    wb.seenX[i] = creature::lastSeen(creature::C_LEGACY + i);
    wb.awayX[i] = creature::awayUntil(creature::C_LEGACY + i);
  }
  wb.ew = eco::world;
  under::exportBlob(wb.ub);
  ruins::exportBlob(wb.rb);
  history::exportBlob(wb.hb);
  families::exportBlob(wb.fb);
  village::exportBlob(wb.vb);
  visitor::exportExt(wb.vx);
  evo::exportBlob(wb.evb);
  wb.crc = wcrc(wb);
  if (wb.crc != lastWorldCrc && p.putBytes("world2", &wb, sizeof(wb)) == sizeof(wb)) {
    // 讀回驗證；確定第二版完整寫入後才刪除第一版
    bool good = p.getBytes("world2", &wcheck, sizeof(wcheck)) == sizeof(wcheck) && wcheck.crc == wb.crc && wcrc(wcheck) == wb.crc;
    if (good) {
      lastWorldCrc = wb.crc;
      if (migratedV1 || p.isKey("world")) { p.remove("world"); migratedV1 = false; Serial.println("[Save] world migrated to v2, v1 removed"); }
    }
  }
  p.end();
  ok = w == sizeof(b);
  Serial.printf("[Save] write %s (%u bytes)\n", ok ? "ok" : "FAILED", (unsigned)sizeof(b));
  return ok;
}

void erase() {
  Preferences p;
  if (!p.begin("forest", false)) return;
  p.remove("eco");
  p.remove("human");
  p.remove("world");
  p.remove("world2");
  p.end();
  ok = false;
}

}  // namespace save
