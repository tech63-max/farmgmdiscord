// 生物自主生活：每種生物有自己的狀態機、活動時段、速度、天氣偏好、休息與出現條件
#pragma once
#include <stdint.h>

namespace creature {

enum Species : uint8_t {
  C_SPRITE, C_SHROOM, C_CRITTER, C_SNAIL, C_FROG, C_BIRD, C_BUTTERFLY, C_FIREFLY,
  C_DEER, C_VISITOR, C_GLOWMOTH,  // 只在事件中出現
  C_MOLE, C_BEE, C_SQUIRREL,      // 第二階段 (加在尾端，舊存檔的物種編號不變)
  C_TURTLE,                       // 第三階段：遠古巨龜 (只在事件中出現)
  C_COUNT
};
constexpr int C_LEGACY = 11;      // 第一版存檔記錄的物種數
bool ambient(uint8_t sp);         // 會自然出現的物種
enum State : uint8_t { ST_ENTER, ST_IDLE, ST_MOVE, ST_ACT, ST_SLEEP, ST_HIDE, ST_LEAVE, ST_HOP };

struct Creature {
  bool active;
  uint8_t sp, state, variant;
  bool flip, flying;
  float x, y, tx, ty, vx, vy;
  float phase;        // 動畫相位
  float hopT;         // 跳躍進度
  float sx, sy;       // 跳躍起點
  uint32_t until;     // 目前狀態結束時間 (millis)
  uint32_t leaveAt;   // 這次拜訪結束時間
  int8_t slot;        // 目標植物格 / 樹枝
  uint8_t flags;      // F_*
  uint8_t alpha;      // 淡入淡出
  uint8_t trait;      // 個性 (evo::Trait，出現時決定)
};
constexpr uint8_t F_EVENT = 1, F_TWIG = 2, F_CHASER = 4, F_LIT = 8, F_GRASS = 16, F_FADE = 32, F_MAGIC = 64, F_TRAPPED = 128;
constexpr int CAP = 24;
constexpr int MAX_ACTIVE = 8;  // 螢火蟲以外同時活動的上限

void begin();
void update(float dt, uint32_t ms);     // 每幀
void populationTick(uint32_t ms);       // 每幾秒：出現/離開/遷徙
int spawn(Species sp, uint32_t ms, bool fromEvent = false);  // 回傳索引或 -1
int count(Species sp);
int activeCount();
Creature& at(int i);
void wakeAll(uint32_t ms);              // 魔法脈動
void scare(uint32_t ms);                // 雷聲/強風：躲起來
void startChase(uint32_t ms);
// ---- 訪客互動用 ----
int hideFrom(float x, float radius, uint32_t ms);   // 附近的小動物逃進草叢躲起來，回傳數量
int visitPoint(Species sp, float x, float y, uint32_t ms, uint32_t stayMs);  // 生物前往某處停留 (小獸會睡覺)
bool find(Species sp, float& x, float& y);           // 找一隻正在活動的生物
bool captureOne(Species sp);                         // 被捕捉：淡出離開
bool hideInHollow(Species sp, uint32_t ms);          // 飛進樹洞後消失
int emergeAt(Species sp, float x, float y, uint32_t ms, uint32_t stayMs);  // 從洞口探出頭，之後回到洞裡
void foodFight(uint32_t ms);                         // 小獸和松鼠搶食物
float foodFor(uint8_t sp);                           // 0..1 這種生物目前的食物充足度
void gatherFireflies(float x, float y, uint32_t ms, int n);
const char* speciesName(uint8_t sp);
float nestProgress();
void setNestProgress(float v);
uint32_t lastSeen(uint8_t sp);          // epoch
void setLastSeen(uint8_t sp, uint32_t e);
uint32_t awayUntil(uint8_t sp);
void setAwayUntil(uint8_t sp, uint32_t e);
float hoursSinceSeen(uint8_t sp);

void drawGround(int yMin, int yMax);    // 地面生物 (依 y 排序後分段畫)
void drawFliers();                      // 飛行生物 + 發光

}  // namespace creature
