#include "Underground.h"
#include <Arduino.h>
#include <math.h>
#include "CreatureManager.h"
#include "Ecosystem.h"
#include "EventManager.h"
#include "Gfx.h"
#include "Particles.h"
#include "PlantManager.h"
#include "Scene.h"
#include "SeasonManager.h"
#include "Util.h"

namespace under {
namespace {
Blob s;
uint32_t eyesUntil = 0;
int8_t eyesIdx = -1;
uint32_t mycelGlowUntil = 0;
// 適合挖洞的地點 (避開池塘、石頭、建築位置)
// 已避開背景：原本 (108,222) 在大石上、(12,222) 在左邊石頭上、(182,232)/(226,222) 在河裡
const scene::Pt DIG_SPOTS[] = {{54, 212}, {84, 214}, {150, 206}};
constexpr int DIG_N = sizeof(DIG_SPOTS) / sizeof(DIG_SPOTS[0]);

bool spotUsed(int x, int y) {
  for (auto& b : s.b) if (b.state != B_NONE && abs(b.x - x) < 18 && abs(b.y - y) < 10) return true;
  return false;
}
}  // namespace

void begin() {
  s = {};
  s.moist = 0.5f; s.water = 0.3f; s.temp = 18; s.mycel = 0.15f; s.roots = 0.3f;
}

void tick(float dtH) {
  if (dtH <= 0) return;
  const eco::Env& e = eco::env;
  const eco::World& w = eco::world;
  // 地下環境：跟著土壤慢慢變化 (地下比地表穩定)
  s.moist = util::lerp(s.moist, util::clamp01(e.soil * 0.8f + e.rain * 0.3f), util::clamp01(dtH * 0.1f));
  s.temp = util::lerp(s.temp, e.tempC * 0.6f + 8, util::clamp01(dtH * 0.05f));
  s.water += dtH * (e.rain > 0.6f ? 0.12f * e.rain : -0.01f - w.drought * 0.03f);
  s.water = util::clamp01(s.water + w.puddle * dtH * 0.02f);  // 積水滲入地下
  float food = plant::matureMushrooms() * 0.15f + (plant::hasLog() ? 0.3f : 0);
  s.mycel = util::clamp01(s.mycel + dtH * (0.006f * (s.moist + food) - 0.004f * (1 - s.moist) - w.drought * 0.01f));
  s.roots = util::approach(s.roots, plant::treeMaturity(), dtH * 0.002f);

  for (int i = 0; i < CAP; i++) {
    Burrow& b = s.b[i];
    if (b.state == B_NONE) continue;
    // 舊存檔留在河裡或石頭上的洞穴 (舊的挖洞位置) 直接移除
    if (scene::inPond(b.x, b.y) || (b.x == 108 && b.y == 222) || (b.x == 12 && b.y == 222)) { b.state = B_NONE; continue; }
    b.ageH = fminf(b.ageH + dtH, 1e6f);
    b.dirt = fmaxf(0, b.dirt - dtH * 0.04f);
    switch (b.state) {
      case B_FRESH:
        if (b.ageH > 2) setState(i, B_OCCUPIED);
        break;
      case B_OCCUPIED:
        // 豪雨讓洞穴淹水 → 住戶搬家
        if (s.water > 0.8f && w.heavyRainH > 1.0f) {
          setState(i, B_FLOODED);
          eventm::trigger(eventm::U_FLOOD_RELOCATE, millis(), true);
        } else if (b.ageH > util::shortH(24 * 12) && util::rng.chance(fminf(1, dtH * 0.5f))) {  // 時間經 shortH 壓縮到 0.5~3 小時
          setState(i, B_ABANDONED);  // 住戶搬走了
        }
        break;
      case B_FLOODED:
        if (s.water < 0.5f) setState(i, B_ABANDONED);
        break;
      case B_ABANDONED:
        if (s.mycel > 0.35f && s.moist > 0.45f && b.ageH > util::shortH(12)) {
          setState(i, B_MUSHROOM);
          eventm::trigger(eventm::U_MUSH_HOLE, millis(), true);
        } else if (b.ageH > util::shortH(48) && util::rng.chance(fminf(1, dtH * 0.5f))) {
          // 廢棄巢穴被其他生物接手 (棲息地延續)
          b.occupant = util::rng.chance(0.5f) ? creature::C_CRITTER : creature::C_SQUIRREL;
          b.generation++;
          setState(i, B_OCCUPIED);
          eventm::trigger(eventm::I_SHARE_HOME, millis(), true);
        }
        break;
      case B_MUSHROOM:
        if (b.ageH > util::shortH(24 * 10)) { setState(i, B_HIDDEN); eventm::trigger(eventm::U_HIDDEN, millis(), true); }
        break;
      case B_HIDDEN:
        if (b.ageH > util::shortH(24 * 30)) b.state = B_NONE;  // 完全融入地表
        break;
    }
  }
}

void update(float dt, uint32_t ms) {
  for (auto& b : s.b)
    if (b.state == B_FRESH && b.dirt > 0.6f && util::rng.chance(dt * 2))
      fx::spawn(fx::PT_PETAL, b.x + util::rng.range(-3, 3), b.y - 2, util::rng.range(-12, 12), -12, 700, 0x7A5A3C);
  (void)ms;
}

int dig(float x, float y, uint8_t occupant, uint32_t ms) {
  for (int i = 0; i < CAP; i++) {
    Burrow& b = s.b[i];
    if (b.state != B_NONE) continue;
    b = {};
    b.state = B_FRESH;
    b.occupant = occupant;
    b.x = (int16_t)x; b.y = (int16_t)y;
    b.dirt = 1;
    b.generation = 1;
    (void)ms;
    return i;
  }
  return -1;
}

int digNear(uint8_t occupant, uint32_t ms) {
  int pick = -1, seen = 0;
  for (int k = 0; k < DIG_N; k++) {
    if (spotUsed(DIG_SPOTS[k].x, DIG_SPOTS[k].y)) continue;
    if (util::rng.irange(0, seen++) == 0) pick = k;
  }
  if (pick < 0) return -1;
  return dig(DIG_SPOTS[pick].x, DIG_SPOTS[pick].y, occupant, ms);
}

int nearest(float x, float& bx, float& by) {
  int best = -1;
  float bd = 1e9f;
  for (int i = 0; i < CAP; i++) {
    const Burrow& b = s.b[i];
    if (b.state != B_FRESH && b.state != B_OCCUPIED && b.state != B_ABANDONED) continue;
    float d = fabsf(b.x - x);
    if (d < bd) { bd = d; best = i; }
  }
  if (best >= 0) { bx = s.b[best].x; by = s.b[best].y; }
  return best;
}

int findState(uint8_t st) {
  for (int i = 0; i < CAP; i++) if (s.b[i].state == st) return i;
  return -1;
}
int count() { int n = 0; for (auto& b : s.b) if (b.state != B_NONE) n++; return n; }
Burrow& at(int i) { return s.b[i]; }
void setState(int i, uint8_t st) { if (i >= 0 && i < CAP) { s.b[i].state = st; s.b[i].ageH = 0; } }
void eyes(int i, uint32_t ms) { eyesIdx = (int8_t)i; eyesUntil = ms + 15000; }
void glowMycelium(uint32_t ms) { mycelGlowUntil = ms + 20000; }
float water() { return s.water; }
float mycelium() { return s.mycel; }
float moisture() { return s.moist; }
void addMycelium(float v) { s.mycel = util::clamp01(s.mycel + v); }
void addWater(float v) { s.water = util::clamp01(s.water + v); }

float growthBonus(uint8_t sp) {
  switch (sp) {
    case plant::P_MUSHROOM: return 1.0f + s.mycel * 0.8f + s.water * 0.2f;
    case plant::P_MOSS: case plant::P_REED: case plant::P_LILY: return 1.0f + s.water * 0.4f;
    case plant::P_FLOWER: case plant::P_SAPLING: case plant::P_VINE: return 1.0f + s.water * 0.2f + s.roots * 0.1f;
    default: return 1.0f;
  }
}

const char* stateName(uint8_t st) {
  static const char* N[] = {"none", "fresh", "occupied", "flooded", "abandoned", "mushroom", "hidden"};
  return st <= B_HIDDEN ? N[st] : "?";
}

void draw(uint32_t ms) {
  const eco::Env& e = eco::env;
  const bool w = gfx::world;
  gfx::world = false;
  // 菌絲網絡：夜晚在蘑菇與洞穴之間隱約發光
  float mg = s.mycel * e.night * (util::reached(ms, mycelGlowUntil) ? 0.5f : 1.0f);
  if (mg > 0.08f) {
    int n = (int)(s.mycel * 26);
    for (int k = 0; k < n; k++) {
      int x = (int)(util::hashf(k, 71) * 120), y = 96 + (int)(util::hashf(73, k) * 22);
      uint8_t a = (uint8_t)(mg * (90 + 60 * sinf(ms * 0.002f + k)));
      gfx::padd(x, y, a / 3, a / 3, a / 2);
      if (k & 1) gfx::padd(x + 1, y, a / 4, a / 4, a / 3);
    }
  }
  for (int i = 0; i < CAP; i++) {
    const Burrow& b = s.b[i];
    if (b.state == B_NONE) continue;
    const int x = b.x >> 1, y = b.y >> 1;
    const bool hidden = b.state == B_HIDDEN;
    // 新鮮泥土堆
    if (b.dirt > 0.05f) {
      uint16_t dc = gfx::lit(0x7A5A3C);
      uint8_t a = (uint8_t)(b.dirt * 230);
      gfx::pblend(x - 3, y, dc, a); gfx::pblend(x + 3, y, dc, a); gfx::pblend(x - 2, y - 1, dc, a); gfx::pblend(x + 2, y - 1, dc, a);
      gfx::pblend(x + 4, y + 1, dc, a); gfx::pblend(x - 4, y + 1, dc, a);
    }
    // 洞口
    uint16_t hole = gfx::lit(0x1E140E), rim = gfx::lit(0x4A3626);
    if (!hidden) {
      for (int dx = -2; dx <= 2; dx++) gfx::pset(x + dx, y, hole);
      for (int dx = -1; dx <= 1; dx++) gfx::pset(x + dx, y - 1, hole);
      gfx::pset(x - 2, y - 1, rim); gfx::pset(x + 2, y - 1, rim); gfx::pset(x - 3, y, rim); gfx::pset(x + 3, y, rim);
    } else {
      gfx::pset(x, y, hole); gfx::pset(x + 1, y, hole);  // 只露出一點縫
    }
    if (b.state == B_FLOODED) { gfx::pset(x - 1, y, gfx::lit(0x5A8CB4)); gfx::pset(x, y, gfx::lit(0x8CC8E6)); gfx::pset(x + 1, y, gfx::lit(0x5A8CB4)); }
    if (b.state == B_MUSHROOM || hidden) {
      gfx::pset(x - 3, y - 1, gfx::lit(0xF0E6D2)); gfx::pset(x - 3, y - 2, gfx::lit(0xC8643C)); gfx::pset(x - 4, y - 2, gfx::lit(0xC8643C));
      gfx::pset(x + 3, y - 1, gfx::lit(0xF0E6D2)); gfx::pset(x + 3, y - 2, gfx::lit(0xE6D2AA));
    }
    if (hidden || b.state == B_MUSHROOM) {  // 植物遮住洞口
      for (int k = 0; k < (hidden ? 9 : 4); k++) {
        int gx = x - 4 + (int)(util::hashf(k, i * 5) * 9);
        gfx::pset(gx, y - (k % 3), gfx::lit(k & 1 ? 0x5A9A46 : 0x7CB45A));
      }
    }
    // 發光的眼睛
    if (i == eyesIdx && !util::reached(ms, eyesUntil) && fmodf(ms * 0.0007f, 3.0f) > 0.2f) {
      gfx::glow(x - 1, y - 1, 2, 0xFFE664, 160); gfx::glow(x + 1, y - 1, 2, 0xFFE664, 160);
      gfx::pset(x - 1, y - 1, gfx::rgb(0xFFFFB4)); gfx::pset(x + 1, y - 1, gfx::rgb(0xFFFFB4));
    }
  }
  gfx::world = w;
}

void exportBlob(Blob& b) { b = s; }
void importBlob(const Blob& b) {
  s = b;
  for (auto& x : s.b) if (x.state > B_HIDDEN) x.state = B_NONE;
}

}  // namespace under
