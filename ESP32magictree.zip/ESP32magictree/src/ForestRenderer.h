// 森林畫面：分層繪製 (天空 → 遠景 → 中景 → 植物/生物 → 前景 → 天氣 → 事件特效 → 低調 UI)
#pragma once
#include <stdint.h>

namespace render {
void begin();
void frame(uint32_t ms, float dt);   // 畫一幀到 gfx::fb
void showInfo(uint32_t ms);
void showJournal(uint32_t ms);       // 再按一次翻頁
void setWifiPanel(bool on, const char* ssid, const char* pass);
void setNetStatus(const char* s);
void setUiHidden(bool hidden);       // 隱藏時鐘與事件提示
bool uiIsHidden();
void closeOverlays();                // 關掉資訊卡/日誌
void notice(const char* text, uint32_t ms);  // 系統訊息 (Wi-Fi 等)
void printProfile();
void drawUiStrip(uint16_t* buf, int y0, int h, uint32_t ms);  // 送畫面時把文字 UI 疊到 240 寬的分條上
}
