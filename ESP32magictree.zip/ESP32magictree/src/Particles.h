// 粒子 (固定大小池，不動態配置)。雨、雪由 ForestRenderer 以無狀態方式繪製，不佔粒子池。
#pragma once
#include <stdint.h>

namespace fx {

enum PType : uint8_t { PT_NONE, PT_LEAF, PT_POLLEN, PT_SPARKLE, PT_SEED, PT_DEW, PT_RIPPLE, PT_SPLASH, PT_INSECT, PT_MAGIC, PT_ACORN, PT_ZZZ, PT_PETAL, PT_GLOWDOT };

struct P {
  float x, y, vx, vy;
  uint16_t life, maxLife;  // 毫秒
  uint32_t color;
  uint8_t type, a;         // a: 種類相關參數
  float tx, ty;            // 種子目標
};
constexpr int CAP = 120;

void spawn(PType t, float x, float y, float vx, float vy, uint16_t lifeMs, uint32_t color, uint8_t a = 0);
void seedFlight(float x0, float y0, float x1, float y1);
void ripple(float x, float y, uint8_t size = 6);
void leaves(int n, bool autumn);
void update(float dtSec, float wind);
void drawBack();   // 畫在生物後面 (漣漪)
void drawFront();  // 畫在最前面
int count(PType t);
int nearest(PType t, float x, float y, float maxDist);  // 回傳索引或 -1
P& at(int i);
void kill(int i);

}  // namespace fx
