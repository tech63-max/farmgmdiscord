// 畫面緩衝與基本繪圖
// 畫面緩衝是 240x240 原生解析度。背景與場景物件仍以 120x120「畫布」的像素風繪製：
// 每個畫布像素在緩衝裡佔 2x2 (看起來和以前一樣)；生物/訪客則用細緻模式直接畫在原生像素上。
// 文字 UI 在送畫面時以 240 原生解析度疊在分條緩衝上 (中文字才清楚)。
#pragma once
#include <stdint.h>
#include "Config.h"

namespace gfx {

constexpr int SCALE = 2;
constexpr int W = cfg::W / SCALE, H = cfg::H / SCALE;  // 像素風畫布 120x120 (背景、天空遮罩用)
constexpr int FW = cfg::W, FH = cfg::H;                // 畫面緩衝 240x240
extern uint16_t* fb;      // 畫面 (FW x FH)
extern uint16_t* bg;      // 打光後的靜態背景 (FW x FH 原生解析度，PSRAM)
extern uint8_t* skyMask;  // 1 = 天空像素 (日月星雲只畫在天空)；120 畫布解析度，整格 2x2 都是天空才算

// 目前的繪製目標：預設 = fb；送畫面時切到 240 寬的分條緩衝畫文字
extern uint16_t* tbuf;
extern int tw, th, ty0;
// 世界座標模式：座標/半徑以 240 世界座標傳入，自動換算到 120 畫布
extern bool world;
// 一個邏輯像素在目標緩衝裡的邊長：場景 = 2 (畫布像素風)，細緻模式/分條 = 1 (原生像素)
extern uint8_t blk;
void targetScene(bool worldCoords);            // 畫森林
// 細緻模式：在這個物件的生命週期內，座標 = 240 原生像素 (等於世界座標)，一次畫一顆原生像素
struct Fine {
  bool w; uint8_t b;
  Fine() : w(world), b(blk) { world = false; blk = 1; }
  ~Fine() { world = w; blk = b; }
};
void blitBg();                                 // 把背景複製到畫面緩衝 (每幀開頭)

// ---- 物件圖層 ----
// 開啟期間，以畫布像素 (blk == 2) 畫的不透明像素先存進 120x120 的圖層；關閉時一次合成到畫面：
// 放大 2 倍時做邊緣平滑 (Scale2x)，外圍補一圈深色描邊。植物、建築等物件因此和背景、生物是同一種畫法。
// 半透明/加色 (pblend、padd、glow) 落在圖層已有的像素上就疊在圖層，否則直接疊到畫面。
extern bool layerOn;
void layerSet(int x, int y, uint16_t c);  // 120 畫布座標
bool layerBlend(int x, int y, uint32_t fgx, uint32_t a32);  // 該處有圖層像素才處理，回傳是否已處理
bool layerAdd(int x, int y, int r, int g, int b);
void layerBegin();
void layerEnd();
struct Layer {  // 可巢狀：只有最外層負責合成
  bool own;
  Layer() : own(!layerOn) { if (own) layerBegin(); }
  ~Layer() { if (own) layerEnd(); }
};
// 對一個畫布像素 (2x2 原生像素) 疊色；x,y 是 120 畫布座標，呼叫端保證在範圍內
void blendCanvasPx(int x, int y, uint32_t fgx, uint32_t a32);
void targetStrip(uint16_t* buf, int y0, int h);  // 畫 UI 到分條 (240 原生座標)

bool begin();  // 配置緩衝區 (只在開機時配置一次)

inline uint16_t rgb(uint8_t r, uint8_t g, uint8_t b) { return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3); }
inline uint16_t rgb(uint32_t hex) { return rgb(hex >> 16, (hex >> 8) & 0xFF, hex & 0xFF); }
inline void unpack(uint16_t c, int& r, int& g, int& b) {
  r = (c >> 8) & 0xF8; r |= r >> 5;
  g = (c >> 3) & 0xFC; g |= g >> 6;
  b = (c << 3) & 0xF8; b |= b >> 5;
}
uint16_t mix(uint16_t a, uint16_t b, uint8_t t);  // t=0 → a, 255 → b
// 快速混色：把 565 展開成 0x07E0F81F 格式，三個色版一次算完 (大面積疊色用)
inline uint32_t expand565(uint16_t c) { return (c | ((uint32_t)c << 16)) & 0x07E0F81Fu; }
inline uint16_t blendFast(uint16_t bgc, uint32_t fgx, uint32_t a32) {  // a32: 0..32
  uint32_t b = expand565(bgc);
  b = (b + (((fgx - b) * a32) >> 5)) & 0x07E0F81Fu;
  return (uint16_t)(b | (b >> 16));
}

// 全域光照：每幀依日夜/天氣算一次，畫物件時把調色盤乘上它
struct Tint { uint16_t r = 256, g = 256, b = 256; };
extern Tint tint;
uint16_t lit(uint32_t hex);          // 0xRRGGBB → 套用光照的 565
uint16_t litc(uint8_t r, uint8_t g, uint8_t b);

// 目標座標換算後回傳指標 (超出範圍回傳 nullptr)。blk == 2 時指向 2x2 像素塊的左上角
inline uint16_t* at(int x, int y) {
  if (blk == 2) {
    if (world) { x &= ~1; y &= ~1; }
    else { x <<= 1; y <<= 1; }
  }
  y -= ty0;
  if ((unsigned)x >= (unsigned)tw || (unsigned)y >= (unsigned)th) return nullptr;
  return tbuf + y * tw + x;
}
inline void pset(int x, int y, uint16_t c) {
  if (layerOn && blk == 2) { if (world) layerSet(x >> 1, y >> 1, c); else layerSet(x, y, c); return; }
  if (uint16_t* p = at(x, y)) {
    p[0] = c;
    if (blk == 2) { p[1] = c; p[tw] = c; p[tw + 1] = c; }
  }
}
inline uint16_t pget(int x, int y) { uint16_t* p = at(x, y); return p ? *p : 0; }
void pblend(int x, int y, uint16_t c, uint8_t a);
void padd(int x, int y, int r, int g, int b);  // 加色 (發光)

void fillRect(int x, int y, int w, int h, uint16_t c);
void blendRect(int x, int y, int w, int h, uint16_t c, uint8_t a);
void hline(int x, int y, int w, uint16_t c);
void vline(int x, int y, int h, uint16_t c);
void line(int x0, int y0, int x1, int y1, uint16_t c);
void fillCircle(int cx, int cy, int r, uint16_t c);
void fillEllipse(int cx, int cy, int rx, int ry, uint16_t c);
void blendEllipse(int cx, int cy, int rx, int ry, uint16_t c, uint8_t a);
// 柔和光暈 (加色)：r 半徑，強度 0..255
void glow(int cx, int cy, int r, uint32_t hex, uint8_t intensity);
// 天空遮罩 (以 120 畫布座標；世界座標模式下自動換算)
inline bool isSky(int x, int y) {
  if (world) { x >>= 1; y >>= 1; }
  if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H) return false;
  int i = y * W + x; return skyMask[i >> 3] & (1 << (i & 7));
}
void setSky(int x, int y, bool v);  // 120 畫布座標

// ---- Sprite：字元陣列像素圖，'.' 透明，'1'..'9' 'a'..'f' = 調色盤索引 ----
struct Sprite {
  uint8_t w, h, frames;
  const char* data;  // frames 張，每張 w*h 字元
};
// pal：0xRRGGBB 陣列 (索引 0 不用)；litOn=false 時不套光照 (發光體)
void sprite(const Sprite& s, int frame, int x, int y, bool flip, const uint32_t* pal, bool litOn = true, uint8_t alpha = 255);
// 精靈圖一格在螢幕上的邊長 (原生像素)。0 = 一般的畫布像素模式 (預設)。
// 設成 1 以上時走細緻模式：以圖的底部中心為錨點縮放 (腳底位置不變)、2/3 倍時做邊緣平滑、
// 外圍加一圈深色描邊並提亮夜間顏色，讓角色從背景裡跳出來。畫完要設回 0
extern int spritePx;

// ---- 文字 (Cubic11 12px 繁中點陣字) ----
int textWidth(const char* utf8);
int text(int x, int y, const char* utf8, uint16_t color);           // 回傳寬度
void textShadow(int x, int y, const char* utf8, uint16_t color, uint16_t shadow);
void textAlpha(int x, int y, const char* utf8, uint16_t color, uint8_t alpha);
constexpr int TEXT_H = 13;

}  // namespace gfx
