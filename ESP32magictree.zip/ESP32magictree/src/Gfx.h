// 畫面緩衝與基本繪圖
// 森林以 120x120 的低解析度繪製 (像素風、省記憶體)，送到 240x240 螢幕時每個像素放大成 2x2。
// 文字 UI 則在送畫面時以 240 原生解析度疊在分條緩衝上 (中文字才清楚)。
#pragma once
#include <stdint.h>
#include "Config.h"

namespace gfx {

constexpr int SCALE = 2;
constexpr int W = cfg::W / SCALE, H = cfg::H / SCALE;  // 低解析度畫布 120x120
extern uint16_t* fb;      // 低解析度畫面 (內部 RAM)
extern uint16_t* bg;      // 打光後的靜態背景 (PSRAM)
extern uint8_t* skyMask;  // 1 = 天空像素 (日月星雲只畫在天空)

// 目前的繪製目標：預設 = fb；送畫面時切到 240 寬的分條緩衝畫文字
extern uint16_t* tbuf;
extern int tw, th, ty0;
// 世界座標模式：座標/半徑以 240 世界座標傳入，自動換算到 120 畫布
extern bool world;
void targetScene(bool worldCoords);            // 畫森林
void targetStrip(uint16_t* buf, int y0, int h);  // 畫 UI 到分條 (240 原生座標)

bool begin();  // 配置緩衝區 (只在開機時配置一次)

inline uint16_t rgb(uint8_t r, uint8_t g, uint8_t b) { return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3); }
inline uint16_t rgb(uint32_t hex) { return rgb(hex >> 16, (hex >> 8) & 0xFF, hex & 0xFF); }
inline void unpack(uint16_t c, int& r, int& g, int& b) {
  r = (c >> 8) & 0xF8; r |= r >> 5;
  g = (c >> 3) & 0xFC; g |= g >> 6;
  b = (c << 3) & 0xF8; b |= b >> 5;
}
uint16_t mix(uint16_t a, uint16_t b, uint8_t t);  // t=0 → a, 255 → b
// 快速混色：把 565 展開成 0x07E0F81F 格式，三個色版一次算完 (大面積疊色用)
inline uint32_t expand565(uint16_t c) { return (c | ((uint32_t)c << 16)) & 0x07E0F81Fu; }
inline uint16_t blendFast(uint16_t bgc, uint32_t fgx, uint32_t a32) {  // a32: 0..32
  uint32_t b = expand565(bgc);
  b = (b + (((fgx - b) * a32) >> 5)) & 0x07E0F81Fu;
  return (uint16_t)(b | (b >> 16));
}

// 全域光照：每幀依日夜/天氣算一次，畫物件時把調色盤乘上它
struct Tint { uint16_t r = 256, g = 256, b = 256; };
extern Tint tint;
uint16_t lit(uint32_t hex);          // 0xRRGGBB → 套用光照的 565
uint16_t litc(uint8_t r, uint8_t g, uint8_t b);

// 目標座標換算後回傳指標 (超出範圍回傳 nullptr)
inline uint16_t* at(int x, int y) {
  if (world) { x >>= 1; y >>= 1; }
  y -= ty0;
  if ((unsigned)x >= (unsigned)tw || (unsigned)y >= (unsigned)th) return nullptr;
  return tbuf + y * tw + x;
}
inline void pset(int x, int y, uint16_t c) { if (uint16_t* p = at(x, y)) *p = c; }
inline uint16_t pget(int x, int y) { uint16_t* p = at(x, y); return p ? *p : 0; }
void pblend(int x, int y, uint16_t c, uint8_t a);
void padd(int x, int y, int r, int g, int b);  // 加色 (發光)

void fillRect(int x, int y, int w, int h, uint16_t c);
void blendRect(int x, int y, int w, int h, uint16_t c, uint8_t a);
void hline(int x, int y, int w, uint16_t c);
void vline(int x, int y, int h, uint16_t c);
void line(int x0, int y0, int x1, int y1, uint16_t c);
void fillCircle(int cx, int cy, int r, uint16_t c);
void fillEllipse(int cx, int cy, int rx, int ry, uint16_t c);
void blendEllipse(int cx, int cy, int rx, int ry, uint16_t c, uint8_t a);
// 柔和光暈 (加色)：r 半徑，強度 0..255
void glow(int cx, int cy, int r, uint32_t hex, uint8_t intensity);
// 天空遮罩 (以 120 畫布座標；世界座標模式下自動換算)
inline bool isSky(int x, int y) {
  if (world) { x >>= 1; y >>= 1; }
  if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H) return false;
  int i = y * W + x; return skyMask[i >> 3] & (1 << (i & 7));
}
void setSky(int x, int y, bool v);  // 120 畫布座標

// ---- Sprite：字元陣列像素圖，'.' 透明，'1'..'9' 'a'..'f' = 調色盤索引 ----
struct Sprite {
  uint8_t w, h, frames;
  const char* data;  // frames 張，每張 w*h 字元
};
// pal：0xRRGGBB 陣列 (索引 0 不用)；litOn=false 時不套光照 (發光體)
void sprite(const Sprite& s, int frame, int x, int y, bool flip, const uint32_t* pal, bool litOn = true, uint8_t alpha = 255);
// 精靈放大倍率 (1 = 原尺寸)：以圖的底部中心為錨點放大，腳底位置不變。畫完要設回 1
extern int spriteScale;

// ---- 文字 (Cubic11 12px 繁中點陣字) ----
int textWidth(const char* utf8);
int text(int x, int y, const char* utf8, uint16_t color);           // 回傳寬度
void textShadow(int x, int y, const char* utf8, uint16_t color, uint16_t shadow);
void textAlpha(int x, int y, const char* utf8, uint16_t color, uint8_t alpha);
constexpr int TEXT_H = 13;

}  // namespace gfx
