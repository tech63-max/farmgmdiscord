// 世界演化 (第三階段)：生物個性與記憶、地形長期演化、聚落擴充、跨多日的世界現象
// 全部是固定大小資料，存在 world2 存檔；不修改任何舊版資料結構 (舊存檔相容)
#pragma once
#include <stdint.h>

namespace evo {

// ---- 個性 (每隻生物出現時決定，不存檔) ----
enum Trait : uint8_t { TR_NORMAL, TR_SHY, TR_CURIOUS, TR_GREEDY, TR_LAZY, TR_BRAVE, TR_SOCIAL, TR_COUNT };
uint8_t rollTrait(uint8_t species);
const char* traitName(uint8_t t);

// ---- 地形演化 (依 x 分 6 區) ----
enum TerrainField : uint8_t { TF_WET, TF_MUSH, TF_CLEAR, TF_DEAD, TF_GLOW, TF_COUNT };
constexpr int ZONES = 6;

// ---- 物種記憶 (只記會影響未來行為的事) ----
struct Memory {
  uint8_t fear;      // 對獵人的恐懼 (0..255，慢慢淡忘)
  uint8_t friendSp;  // 曾經幫助自己的物種 (0xFF = 無)
  int16_t homeX;     // 曾經居住的巢穴位置 (-1 = 無)
  int16_t foodX;     // 食物豐富的位置 (-1 = 無)
  int16_t dangerX;   // 曾經發生災害的位置 (-1 = 無)
};
constexpr int MEM_SPECIES = 16;

struct Blob {
  float terrain[TF_COUNT][ZONES];
  Memory mem[MEM_SPECIES];
  float snow;          // 0..1 冬季積雪 (融化很慢)
  float magicDays;     // 持續數天的魔法現象 (剩餘天數)
  float rareNestDays;  // 稀有生物的巢 (剩餘天數)
  float vFood;         // 聚落的食物存量
  uint8_t meteorNear;  // 流星墜落在近處 (留下隕石坑)
  uint8_t vStyle, vTower, vStorage, vLanterns, vTrades;
  uint8_t tunnel, glowCave;
  uint16_t terrainSaid;  // 已寫過日誌的地形里程碑 (bit = 欄位*ZONES+區)
  uint16_t pad;
  uint32_t lastKind[32]; // 各類歷史事件上次發生時間
};

void begin();
void tick(float dtH);
void drawSky(uint32_t ms);     // 魔法極光 (天空層)
void drawGround(uint32_t ms);  // 地形演化、聚落擴充、稀有生物的巢、發光洞穴、地下通道

Memory& mem(uint8_t sp);
void fearHunter(int amount);
void remember(uint8_t sp, int16_t homeX, int16_t foodX);
void setDanger(int16_t x);
void setFriend(uint8_t sp, uint8_t friendSp);
bool dangerous(float x);       // 是否在記得的危險區附近

float terrain(uint8_t f, int worldX);
void addTerrain(uint8_t f, int worldX, float delta);
float plantBias(int slot, uint8_t species);

// 跨多日的世界現象
float snow();
void addSnow(float v);
float magicDays();
void startEnchant(float days);
bool rareNest();
void startRareNest(float days);
bool meteorNear();
void setMeteorNear(bool on);
void setTunnel(bool on);
void setGlowCave(bool on);
uint32_t& doubleRainbowUntil();

// 聚落擴充
uint8_t villageStyle();
bool buildTower();
bool buildStorage();
bool addLantern();
void villageTrade();
float villageFood();

// 歷史 (各類事件上次時間)
void noteKind(uint8_t kind);
uint32_t lastKind(uint8_t kind);

void print();
void exportBlob(Blob& b);
void importBlob(const Blob& b);

}  // namespace evo
