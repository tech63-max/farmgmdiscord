// 場景幾何 (240x240)：渲染、植物、生物共用同一份座標
#pragma once
#include <math.h>

namespace scene {
// 地面高度 (中景地表輪廓)
inline int groundY(int x) { return 168 + (int)(3.0f * sinf(x * 0.045f) + 2.0f * sinf(x * 0.11f + 1.3f)); }

// 古樹
constexpr int TRUNK_X = 46, TRUNK_TOP = 70, TRUNK_BOTTOM = 178, TRUNK_HALF = 14;
constexpr int HOLLOW_X = 52, HOLLOW_Y = 128, HOLLOW_RX = 6, HOLLOW_RY = 8;
constexpr int CANOPY_CX = 52, CANOPY_CY = 34;

// 河流：從右側畫面外流入，向左彎後往下流出畫面 (沿用「池塘」的介面名稱，其他模組不用改)
struct RPt { float x, y, w; };  // 中心線的點與該處半寬
// 上岸高度固定 (y≈199，不擋到生物行走的高度)，加寬時中心線往下移
constexpr RPt RIVER[] = {{252, 213, 14}, {226, 214, 15}, {200, 216, 16}, {182, 221, 17}, {170, 231, 17}, {166, 243, 18}, {168, 259, 19}};
constexpr int RIVER_N = sizeof(RIVER) / sizeof(RIVER[0]);
constexpr int RIVER_X0 = 142, RIVER_X1 = 239, RIVER_Y0 = 194, RIVER_Y1 = 239;  // 含河岸的範圍
constexpr int POND_CX = 196, POND_CY = 212;                                    // 河面上的代表點

// 到中心線的距離；hw = 該處半寬，u = 沿河位置 (0 上游 .. 1 下游)
inline float riverDist(float x, float y, float* hw = nullptr, float* u = nullptr, float* cx = nullptr, float* cy = nullptr) {
  float best = 1e9f, bw = 0, bu = 0, bx = 0, by = 0;
  for (int i = 0; i + 1 < RIVER_N; i++) {
    const RPt &a = RIVER[i], &b = RIVER[i + 1];
    const float vx = b.x - a.x, vy = b.y - a.y;
    float t = ((x - a.x) * vx + (y - a.y) * vy) / (vx * vx + vy * vy);
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    const float px = a.x + vx * t - x, py = a.y + vy * t - y, d = px * px + py * py;
    if (d < best) { best = d; bw = a.w + (b.w - a.w) * t; bu = (i + t) / (RIVER_N - 1); bx = a.x + vx * t; by = a.y + vy * t; }
  }
  if (hw) *hw = bw;
  if (u) *u = bu;
  if (cx) *cx = bx;
  if (cy) *cy = by;
  return sqrtf(best);
}
// 離 (x,y) 最近的河岸點 (在水外 pad 像素)。preferLand：選上岸/左岸 (生物主要活動的一側，避免目標在走不到的對岸)
inline void shorePoint(float x, float y, float& ox, float& oy, float pad = 4, bool preferLand = false) {
  float hw, cx, cy;
  riverDist(x, y, &hw, nullptr, &cx, &cy);
  float vx = x - cx, vy = y - cy, l = sqrtf(vx * vx + vy * vy);
  if (l < 0.5f) { vx = 0; vy = -1; l = 1; }
  vx /= l; vy /= l;
  ox = cx + vx * (hw + pad); oy = cy + vy * (hw + pad);
  const float ax = cx - vx * (hw + pad), ay = cy - vy * (hw + pad);
  if ((preferLand && ax + ay < ox + oy) || oy > 236 || ox > 236 || ox < 4) { ox = ax; oy = ay; }
}
// 沿河位置 u 的中心點、半寬、流向 (單位向量)
inline void riverAt(float u, float& x, float& y, float* hw = nullptr, float* dx = nullptr, float* dy = nullptr) {
  float f = (u < 0 ? 0 : u > 0.9999f ? 0.9999f : u) * (RIVER_N - 1);
  const int i = (int)f;
  const float t = f - i;
  const RPt &a = RIVER[i], &b = RIVER[i + 1];
  x = a.x + (b.x - a.x) * t; y = a.y + (b.y - a.y) * t;
  if (hw) *hw = a.w + (b.w - a.w) * t;
  const float vx = b.x - a.x, vy = b.y - a.y, l = sqrtf(vx * vx + vy * vy);
  if (dx) *dx = vx / l;
  if (dy) *dy = vy / l;
}
// 河面上的隨機點 (r = 0..1，只取畫面內看得清楚的河段)
inline void waterPoint(float r, float& x, float& y) { riverAt(0.12f + r * 0.6f, x, y); }
// margin > 0 往內縮、< 0 往外擴 (與舊池塘介面相同)
inline bool inPond(float x, float y, float margin = 0) {
  if (x < RIVER_X0 - 8 || x > RIVER_X1 + 16 || y < RIVER_Y0 - 8) return false;
  float hw;
  return riverDist(x, y, &hw) < hw - margin * 0.5f;
}

// 前景石頭
constexpr int ROCK1_X = 118, ROCK1_Y = 224;  // 大石
constexpr int ROCK2_X = 18, ROCK2_Y = 216;

// 枯木位置
constexpr int LOG_X0 = 92, LOG_X1 = 146, LOG_Y = 208;

// 小鳥可以停的樹枝末端 (古樹)：都在樹冠下方、看得見樹枝的位置
struct Pt { short x, y; };
constexpr Pt PERCH[] = {{104, 84}, {118, 72}, {84, 94}, {8, 86}, {20, 96}};
constexpr int PERCH_N = sizeof(PERCH) / sizeof(PERCH[0]);
constexpr Pt NEST = {96, 86};  // 在通往 (104,84) 的樹枝上

// 地面活動範圍
constexpr int WALK_MIN_X = 8, WALK_MAX_X = 232;
inline int walkY(int x) {
  // 生物在地面行走的腳底高度 (前排略低一點)
  return groundY(x) + 22;
}
}  // namespace scene
