#pragma once
#include <stdint.h>
#include <math.h>

namespace util {

// xorshift32 —— 不配置記憶體的輕量亂數
struct Rng {
  uint32_t s = 0x9E3779B9u;
  void seed(uint32_t v) { s = v ? v : 0x9E3779B9u; }
  uint32_t next() { s ^= s << 13; s ^= s >> 17; s ^= s << 5; return s; }
  float f() { return (next() >> 8) * (1.0f / 16777216.0f); }          // [0,1)
  float range(float a, float b) { return a + (b - a) * f(); }
  int irange(int a, int b) { return a + (int)(next() % (uint32_t)(b - a + 1)); }  // [a,b]
  bool chance(float p) { return f() < p; }
};
extern Rng rng;

inline uint32_t hash32(uint32_t x) {
  x ^= x >> 16; x *= 0x7feb352dU; x ^= x >> 15; x *= 0x846ca68bU; x ^= x >> 16; return x;
}
inline uint32_t hash2(int x, int y) { return hash32((uint32_t)x * 73856093u ^ (uint32_t)y * 19349663u); }
inline float hashf(int x, int y) { return (hash2(x, y) & 0xFFFF) / 65535.0f; }

// 平滑值雜訊 (背景紋理用)
inline float vnoise(float x, float y) {
  int xi = (int)floorf(x), yi = (int)floorf(y);
  float fx = x - xi, fy = y - yi;
  fx = fx * fx * (3 - 2 * fx); fy = fy * fy * (3 - 2 * fy);
  float a = hashf(xi, yi), b = hashf(xi + 1, yi), c = hashf(xi, yi + 1), d = hashf(xi + 1, yi + 1);
  return a + (b - a) * fx + (c - a) * fy + (a - b - c + d) * fx * fy;
}

template <typename T> inline T clamp(T v, T lo, T hi) { return v < lo ? lo : (v > hi ? hi : v); }
inline float clamp01(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
inline float lerp(float a, float b, float t) { return a + (b - a) * t; }
inline float approach(float v, float target, float rate) {  // rate: 每次最多移動量
  if (v < target) return (v + rate > target) ? target : v + rate;
  return (v - rate < target) ? target : v - rate;
}
inline float smooth(float t) { t = clamp01(t); return t * t * (3 - 2 * t); }
// millis() 溢位安全比較 (PINOUT 坑 #8)
inline bool reached(uint32_t now, uint32_t t) { return (int32_t)(now - t) >= 0; }

}  // namespace util
