#include "SdStorage.h"
#include <Arduino.h>
#include <SD_MMC.h>
#include <string.h>
#include "Config.h"

namespace sdstore {
namespace {
bool mounted = false;
// PINOUT 坑 #1：寫入必須經過內部 RAM、對齊的緩衝區
alignas(16) uint8_t wbuf[256];
constexpr size_t MAX_LOG_BYTES = 4 * 1024 * 1024;  // 超過就輪替成 journal.old.txt
}  // namespace

bool begin() {
  if (!SD_MMC.setPins(cfg::SD_CLK, cfg::SD_CMD, cfg::SD_D0, cfg::SD_D1, cfg::SD_D2, cfg::SD_D3)) return false;
  if (!SD_MMC.begin("/sdcard", false, false, SDMMC_FREQ_DEFAULT, 3)) return false;  // 不自動格式化
  if (SD_MMC.cardType() == CARD_NONE) { SD_MMC.end(); return false; }
  if (!SD_MMC.exists("/forest")) SD_MMC.mkdir("/forest");
  mounted = true;
  return true;
}

bool ok() { return mounted; }

void appendJournal(const char* line) {
  if (!mounted) return;
  File f = SD_MMC.open("/forest/journal.txt", FILE_APPEND);
  if (!f) return;
  const size_t size = f.size();
  size_t len = strlen(line);
  if (len > sizeof(wbuf)) len = sizeof(wbuf);
  memcpy(wbuf, line, len);
  f.write(wbuf, len);
  f.close();
  if (size > MAX_LOG_BYTES) {
    SD_MMC.remove("/forest/journal.old.txt");  // FAT 的 rename 不會覆蓋 (坑 #7)
    SD_MMC.rename("/forest/journal.txt", "/forest/journal.old.txt");
  }
}
}  // namespace sdstore
