#include "Ecosystem.h"
#include <math.h>
#include "TimeManager.h"
#include "SeasonManager.h"
#include "Util.h"
#include "WeatherManager.h"

namespace eco {
Env env;
World world = {2, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0};

namespace {
float targetRain(SkyKind s, float mm) {
  switch (s) {
    case SkyKind::Drizzle: return 0.3f;
    case SkyKind::Rain: return util::clamp(0.5f + mm * 0.08f, 0.5f, 0.85f);
    case SkyKind::Storm: return 1.0f;
    default: return 0;
  }
}
}  // namespace

void update(uint32_t ms, float dt) {
  const weather::Now& w = weather::current();
  env.sky = w.sky;
  env.tempC = w.tempC;
  env.cloud = w.cloud;
  const float dtH = dt / 3600.0f;

  // 視覺量用「真實秒」平滑過渡 (縮時時也不要瞬間跳變)
  float tr = targetRain(w.sky, w.precipMm);
  if (blessing(ms)) tr = fmaxf(tr, 0.35f);
  env.rain = util::approach(env.rain, tr, 0.02f);
  env.snow = util::approach(env.snow, w.sky == SkyKind::Snow ? 0.7f : 0, 0.02f);
  env.storm = util::approach(env.storm, w.sky == SkyKind::Storm ? 1.f : 0, 0.02f);
  float tw = util::clamp01(w.windKmh / 40.0f);
  if (breezing(ms)) tw = fmaxf(tw, 0.75f);
  tw = fmaxf(tw, env.gust);
  env.gust = util::approach(env.gust, 0, 0.02f);
  env.wind = util::approach(env.wind, tw, 0.03f);
  float tf = w.sky == SkyKind::Fog ? 0.75f : 0;
  if (timem::phase() == PH_DAWN && env.airHum > 88) tf = fmaxf(tf, 0.35f);  // 清晨濕氣重 → 薄霧
  env.fog = util::approach(env.fog, tf, 0.01f);
  env.night = 1.0f - timem::dayFactor();
  env.light = timem::dayFactor() * (1.0f - 0.6f * env.cloud) * (1.0f - 0.3f * env.fog);

  // 模擬濕度：往真實濕度靠攏，下雨/魔法雨會額外增加，日曬與風會降低
  float hTarget = w.humidity + env.rain * 15 - env.light * 8 - env.wind * 6;
  env.airHum = util::clamp(util::lerp(env.airHum, hTarget, util::clamp01(dtH * 2)), 5.0f, 100.0f);
  // 土壤水分 (變化慢，時間單位為森林時間)
  float wetIn = env.rain * 0.9f + (env.snow > 0 ? 0.05f : 0);
  float dry = 0.05f + env.light * 0.08f + env.wind * 0.04f + fmaxf(0, env.tempC - 25) * 0.01f;
  env.soil = util::clamp01(env.soil + (wetIn - dry * (1 - env.rain)) * dtH);
  if (env.rain > 0.2f) env.hoursSinceRain = 0;
  else env.hoursSinceRain = fminf(env.hoursSinceRain + dtH, 999);

  env.hot = env.tempC >= 31;
  env.cold = env.tempC <= 12;

  // 魔法殘留緩慢消散 (真實時間)
  if (pulsing(ms)) env.magic = util::approach(env.magic, 1, 0.1f);
  else env.magic = util::approach(env.magic, 0, 0.0015f);

  // 昆蟲：溫暖、潮濕、花蜜多、白天/黃昏多；魔法細雨會吸引昆蟲
  float ti = 0.2f + env.nectar * 0.5f + util::clamp01((env.tempC - 12) / 15) * 0.3f - env.rain * 0.4f - env.wind * 0.3f;
  if (blessing(ms)) ti += 0.4f;
  if (env.cold) ti *= 0.3f;
  env.insects = util::approach(env.insects, util::clamp01(ti), 0.01f);
  env.pollen = util::approach(env.pollen, util::clamp01(env.nectar * (0.3f + env.wind)), 0.02f);
}

Moon moon() {
  const float p = timem::moonPhase();
  if (p < 0.06f || p > 0.94f) return MOON_NEW;
  if (p < 0.2f) return MOON_WAXING;
  if (p < 0.32f) return MOON_FIRST_Q;
  if (p > 0.43f && p < 0.57f) return MOON_FULL;
  if (p > 0.68f && p < 0.8f) return MOON_LAST_Q;
  return p < 0.5f ? MOON_WAXING : MOON_WANING;
}
bool fullMoonNight() { return moon() == MOON_FULL && env.night > 0.6f; }

void worldTick(float dtH) {
  World& w = world;
  // 橡果：秋天由古樹掉落，冬天幾乎沒有
  w.acornsGround = util::clamp(w.acornsGround + dtH * (season::weight(AUTUMN) * 0.25f + season::weight(SUMMER) * 0.03f) - dtH * 0.02f, 0.0f, 10.0f);
  // 連續大雨時數
  if (env.rain > 0.65f) w.heavyRainH += dtH; else w.heavyRainH = fmaxf(0, w.heavyRainH - dtH * 2);
  // 乾旱：很久沒下雨且炎熱 → 加深；下雨很快解除
  bool dry = env.hoursSinceRain > 96 && env.tempC > 24;
  if (env.rain > 0.2f) w.drought = fmaxf(0, w.drought - dtH * 0.2f);
  else if (dry) w.drought = fminf(1, w.drought + dtH * 0.01f);
  else w.drought = fmaxf(0, w.drought - dtH * 0.005f);
  // 池塘水位跟著乾旱/降雨
  float target = 1.0f - w.drought * 0.5f + w.puddle * 0.1f;
  w.pondLevel = util::approach(w.pondLevel, util::clamp(target, 0.4f, 1.1f), dtH * 0.03f);
  // 霜：寒冷晴朗的夜晚形成，日照融化
  if (env.tempC < 3 && env.night > 0.6f && env.cloud < 0.5f) w.frost = fminf(1, w.frost + dtH * 0.3f);
  else w.frost = fmaxf(0, w.frost - dtH * (0.1f + env.light * 0.8f));
  // 積水：慢慢滲入地下或蒸發
  w.puddle = fmaxf(0, w.puddle - dtH * (0.02f + env.light * 0.03f));
  w.burn = fmaxf(0, w.burn - dtH * 0.0008f);    // 焦痕約 50 天淡去
  w.rubble = fmaxf(0, w.rubble - dtH * 0.0006f);
  w.meteorGlow = fmaxf(0, w.meteorGlow - dtH * 0.004f);  // 發光石約 10 天熄滅
}

void bless(uint32_t ms) { env.blessUntil = ms + 25000; }
void breeze(uint32_t ms) { env.breezeUntil = ms + 14000; }
void pulse(uint32_t ms) { env.pulseUntil = ms + 6000; }
bool blessing(uint32_t ms) { return env.blessUntil && !util::reached(ms, env.blessUntil); }
bool breezing(uint32_t ms) { return env.breezeUntil && !util::reached(ms, env.breezeUntil); }
bool pulsing(uint32_t ms) { return env.pulseUntil && !util::reached(ms, env.pulseUntil); }
float wetness() { return util::clamp01(env.rain * 0.6f + (env.airHum - 50) / 100.0f + env.soil * 0.3f); }

}  // namespace eco
