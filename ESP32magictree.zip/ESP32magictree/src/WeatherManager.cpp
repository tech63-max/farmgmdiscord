#include "WeatherManager.h"
#include <Arduino.h>
#include <HTTPClient.h>
#include <WiFi.h>
#include <cJSON.h>
#include <math.h>
#include "Config.h"
#include "SeasonManager.h"
#include "TimeManager.h"
#include "Util.h"

namespace weather {
namespace {

struct Raw {
  bool ok;
  int16_t code;
  float temp, hum, precip, wind, cloud, pop;
  float riseH, setH;
  int32_t utcOff;
  uint32_t at;
};

portMUX_TYPE mux = portMUX_INITIALIZER_UNLOCKED;
volatile bool fetchReq = false;
volatile bool fetchDone = false;
Raw shared{};       // task → 主迴圈 (mux 保護)
Raw last{};         // 最後一次成功資料
TaskHandle_t task = nullptr;

Now cur;
uint32_t nextFetchMs = 0;
bool haveLast = false;

// 本地隨機天氣
SkyKind fbSky = SkyKind::PartCloud;
uint32_t fbNextChange = 0;
bool debugOverride = false;

SkyKind fromCode(int c) {
  if (c == 0) return SkyKind::Clear;
  if (c <= 2) return SkyKind::PartCloud;
  if (c == 3) return SkyKind::Overcast;
  if (c == 45 || c == 48) return SkyKind::Fog;
  if (c >= 51 && c <= 57) return SkyKind::Drizzle;
  if ((c >= 61 && c <= 67) || (c >= 80 && c <= 82)) return SkyKind::Rain;
  if ((c >= 71 && c <= 77) || c == 85 || c == 86) return SkyKind::Snow;
  if (c >= 95) return SkyKind::Storm;
  return SkyKind::PartCloud;
}

int toCode(SkyKind s) {
  switch (s) {
    case SkyKind::Clear: return 0;
    case SkyKind::PartCloud: return 2;
    case SkyKind::Overcast: return 3;
    case SkyKind::Fog: return 45;
    case SkyKind::Drizzle: return 53;
    case SkyKind::Rain: return 63;
    case SkyKind::Storm: return 95;
    case SkyKind::Snow: return 73;
  }
  return 2;
}

float localHourOf(double epoch, int32_t off) {
  double s = fmod(epoch + off, 86400.0);
  if (s < 0) s += 86400;
  return (float)(s / 3600.0);
}

bool fetchOnce(Raw& r) {
  char url[400];
  snprintf(url, sizeof(url),
           "http://api.open-meteo.com/v1/forecast?latitude=%.3f&longitude=%.3f"
           "&current=temperature_2m,relative_humidity_2m,precipitation,weather_code,cloud_cover,wind_speed_10m"
           "&daily=sunrise,sunset,precipitation_probability_max&timezone=auto&timeformat=unixtime&forecast_days=1",
           (double)FOREST_LAT, (double)FOREST_LON);
  HTTPClient http;
  http.setTimeout(10000);
  http.setConnectTimeout(8000);
  if (!http.begin(url)) return false;
  int code = http.GET();
  if (code != 200) { http.end(); return false; }
  String body = http.getString();
  http.end();
  if (body.length() == 0 || body.length() > 8192) return false;

  cJSON* root = cJSON_Parse(body.c_str());
  if (!root) return false;
  bool ok = false;
  cJSON* c = cJSON_GetObjectItem(root, "current");
  cJSON* d = cJSON_GetObjectItem(root, "daily");
  cJSON* off = cJSON_GetObjectItem(root, "utc_offset_seconds");
  if (cJSON_IsObject(c)) {
    auto num = [&](cJSON* o, const char* k, float def) {
      cJSON* v = cJSON_GetObjectItem(o, k);
      return cJSON_IsNumber(v) ? (float)v->valuedouble : def;
    };
    r.code = (int16_t)num(c, "weather_code", 2);
    r.temp = num(c, "temperature_2m", 22);
    r.hum = num(c, "relative_humidity_2m", 70);
    r.precip = num(c, "precipitation", 0);
    r.wind = num(c, "wind_speed_10m", 5);
    r.cloud = num(c, "cloud_cover", 40) / 100.0f;
    r.utcOff = cJSON_IsNumber(off) ? (int32_t)off->valuedouble : 8 * 3600;
    r.riseH = r.setH = -1;
    r.pop = 0.2f;
    if (cJSON_IsObject(d)) {
      cJSON* sr = cJSON_GetArrayItem(cJSON_GetObjectItem(d, "sunrise"), 0);
      cJSON* ss = cJSON_GetArrayItem(cJSON_GetObjectItem(d, "sunset"), 0);
      cJSON* pp = cJSON_GetArrayItem(cJSON_GetObjectItem(d, "precipitation_probability_max"), 0);
      if (cJSON_IsNumber(sr) && cJSON_IsNumber(ss)) {
        r.riseH = localHourOf(sr->valuedouble, r.utcOff);
        r.setH = localHourOf(ss->valuedouble, r.utcOff);
      }
      if (cJSON_IsNumber(pp)) r.pop = (float)pp->valuedouble / 100.0f;
    }
    ok = r.temp > -60 && r.temp < 60 && r.hum >= 0 && r.hum <= 100;
  }
  cJSON_Delete(root);
  return ok;
}

void taskFn(void*) {
  for (;;) {
    if (fetchReq) {
      fetchReq = false;
      Raw r{};
      r.ok = fetchOnce(r);
      r.at = timem::now();
      portENTER_CRITICAL(&mux);
      shared = r;
      fetchDone = true;
      portEXIT_CRITICAL(&mux);
    }
    vTaskDelay(pdMS_TO_TICKS(200));
  }
}

// ---- 本地天氣產生器 (依季節的馬可夫鏈) ----
void fallbackStep(uint32_t now) {
  if (debugOverride) return;
  if (fbNextChange && !util::reached(now, fbNextChange)) return;
  fbNextChange = now + util::rng.irange(30, 100) * 60;
  float wetBias = season::weight(SUMMER) * 0.15f + season::weight(SPRING) * 0.1f;
  float r = util::rng.f();
  switch (fbSky) {
    case SkyKind::Clear: fbSky = r < 0.6f ? SkyKind::Clear : SkyKind::PartCloud; break;
    case SkyKind::PartCloud:
      fbSky = r < 0.3f ? SkyKind::Clear : r < 0.7f ? SkyKind::PartCloud : r < 0.9f ? SkyKind::Overcast : SkyKind::Fog;
      break;
    case SkyKind::Overcast:
      fbSky = r < 0.3f ? SkyKind::PartCloud : r < 0.6f - wetBias ? SkyKind::Overcast : r < 0.85f ? SkyKind::Drizzle : SkyKind::Rain;
      break;
    case SkyKind::Fog: fbSky = r < 0.5f ? SkyKind::PartCloud : SkyKind::Overcast; break;
    case SkyKind::Drizzle: fbSky = r < 0.4f ? SkyKind::Overcast : r < 0.8f ? SkyKind::Rain : SkyKind::Drizzle; break;
    case SkyKind::Rain:
      fbSky = r < 0.45f ? SkyKind::Overcast : r < 0.75f ? SkyKind::Rain : r < 0.75f + season::weight(SUMMER) * 0.2f ? SkyKind::Storm : SkyKind::Drizzle;
      break;
    case SkyKind::Storm: fbSky = r < 0.7f ? SkyKind::Rain : SkyKind::Overcast; break;
    case SkyKind::Snow: fbSky = r < 0.5f ? SkyKind::Overcast : SkyKind::Snow; break;
  }
  // 太冷時把雨變雪
  if (skyWet(fbSky) && cur.tempC < 1) fbSky = SkyKind::Snow;
}

void applyLocal(uint32_t now) {
  fallbackStep(now);
  const timem::Local& l = timem::local();
  float lat = fabsf(FOREST_LAT);
  float seasonal = cosf(2 * PI * (l.yday - 200) / 365.0f) * (FOREST_LAT >= 0 ? 1 : -1);
  float mean = 26 - lat * 0.35f + seasonal * (4 + lat * 0.25f);
  float diurnal = -cosf(2 * PI * (l.hourF - 3) / 24.0f) * 4;  // 下午 3 點最熱
  cur.sky = fbSky;
  cur.tempC = mean + diurnal - (skyWet(fbSky) ? 2 : 0);
  cur.cloud = fbSky == SkyKind::Clear ? 0.05f : fbSky == SkyKind::PartCloud ? 0.4f : 0.9f;
  cur.humidity = skyWet(fbSky) || fbSky == SkyKind::Fog ? 92 : 60 + cur.cloud * 20;
  cur.windKmh = fbSky == SkyKind::Storm ? 35 : 6 + 8 * util::vnoise(now / 3600.0f, 3.3f);
  cur.precipProb = skyWet(fbSky) ? 0.8f : cur.cloud * 0.4f;
  cur.precipMm = fbSky == SkyKind::Rain ? 2 : fbSky == SkyKind::Storm ? 6 : fbSky == SkyKind::Drizzle ? 0.3f : 0;
  cur.live = false;
}

void applyLive(const Raw& r) {
  cur.sky = fromCode(r.code);
  // 有降雨量但代碼沒反映 → 算細雨
  if (r.precip > 0.05f && !skyWet(cur.sky) && cur.sky != SkyKind::Snow) cur.sky = SkyKind::Drizzle;
  cur.tempC = r.temp;
  cur.humidity = r.hum;
  cur.windKmh = r.wind;
  cur.cloud = util::clamp01(r.cloud);
  cur.precipProb = util::clamp01(r.pop);
  cur.precipMm = r.precip;
  cur.live = true;
  cur.fetchedAt = r.at;
  fbSky = cur.sky;  // 之後過期時，本地天氣從這裡接續
  timem::setUtcOffset(r.utcOff);
  timem::setSunTimes(r.riseH, r.setH);
}
}  // namespace

void begin() {
  xTaskCreatePinnedToCore(taskFn, "weather", 8192, nullptr, 1, &task, 0);  // core 0：跟 Wi-Fi 同核心
}

void update(bool wifiUp) {
  const uint32_t ms = millis();
  const uint32_t now = timem::now();
  if (wifiUp && !fetchReq && util::reached(ms, nextFetchMs)) {
    fetchReq = true;
    nextFetchMs = ms + cfg::WEATHER_RETRY_S * 1000;  // 先排重試；成功再延長
  }
  bool done = false;
  Raw r{};
  portENTER_CRITICAL(&mux);
  if (fetchDone) { r = shared; fetchDone = false; done = true; }
  portEXIT_CRITICAL(&mux);
  if (done) {
    if (r.ok) {
      last = r;
      haveLast = true;
      debugOverride = false;
      nextFetchMs = ms + cfg::WEATHER_INTERVAL_S * 1000;
      Serial.printf("[Weather] code %d %.1fC hum %.0f wind %.1f cloud %.2f\n", r.code, r.temp, r.hum, r.wind, r.cloud);
    } else {
      Serial.println("[Weather] fetch failed, keep last data");
    }
  }
  const bool fresh = haveLast && !debugOverride && (now - last.at) < cfg::WEATHER_STALE_S;
  if (fresh) applyLive(last);
  else applyLocal(now);
}

const Now& current() { return cur; }
void forceRefresh() { nextFetchMs = millis(); }

const char* skyName(SkyKind s) {
  switch (s) {
    case SkyKind::Clear: return "晴";
    case SkyKind::PartCloud: return "多雲";
    case SkyKind::Overcast: return "陰";
    case SkyKind::Fog: return "霧";
    case SkyKind::Drizzle: return "細雨";
    case SkyKind::Rain: return "雨";
    case SkyKind::Storm: return "雷雨";
    case SkyKind::Snow: return "雪";
  }
  return "?";
}

void getSnapshot(Snapshot& s) {
  s.fetchedAt = haveLast ? last.at : 0;
  s.code = haveLast ? last.code : toCode(fbSky);
  s.tempX10 = (int16_t)(last.temp * 10);
  s.hum = (uint8_t)last.hum;
  s.cloud = (uint8_t)(last.cloud * 100);
  s.pop = (uint8_t)(last.pop * 100);
  s.wind = (uint8_t)util::clamp(last.wind, 0.0f, 255.0f);
  s.riseH = last.riseH;
  s.setH = last.setH;
  s.utcOff = timem::utcOffset();
}

void restoreSnapshot(const Snapshot& s) {
  fbSky = fromCode(s.code);
  if (s.fetchedAt == 0) return;
  last.ok = true;
  last.at = s.fetchedAt;
  last.code = s.code;
  last.temp = s.tempX10 / 10.0f;
  last.hum = s.hum;
  last.cloud = s.cloud / 100.0f;
  last.pop = s.pop / 100.0f;
  last.wind = s.wind;
  last.precip = 0;
  last.riseH = s.riseH;
  last.setH = s.setH;
  last.utcOff = s.utcOff;
  haveLast = true;
  if (s.riseH >= 0) timem::setSunTimes(s.riseH, s.setH);
}

void debugSet(SkyKind s) {
  debugOverride = true;
  fbSky = s;
  fbNextChange = timem::now() + 3600;
}

}  // namespace weather
