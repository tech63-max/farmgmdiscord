// 森林歷史記憶：記住重要事件，並讓歷史影響現在 (植物偏好、生物棲息、訪客再訪)
// 容量固定：最近 24 筆細節 + 各類累計次數 + 6 個區域的長期地貌 (茂盛度、潮濕度、曾發生過的事)
#pragma once
#include <stdint.h>

namespace history {

enum Kind : uint8_t {
  H_VISITOR, H_CABIN, H_TRAP, H_STRUCT_DECAY, H_STRUCT_GONE, H_RUIN, H_LIGHTNING, H_NEST, H_MIGRATE,
  H_DISASTER, H_MYSTIC, H_FLOOD, H_CAMP, H_BURROW, H_VILLAGE, H_HATCH, H_COUNT
};
constexpr int ZONES = 6;   // 依 x 座標分 6 區 (每區 40 像素)
constexpr int RING = 24;

struct Rec { uint32_t epoch; uint8_t kind, zone, arg, pad; };
struct Zone {
  float lush;      // 0..1 長期茂盛度 (花多的地方越來越茂盛)
  float damp;      // 0..1 長期潮濕度 (形成蘑菇區)
  uint16_t marks;  // bit = Kind，這一區曾經發生過的事
  uint16_t pad;
};
struct Blob {
  Rec ring[RING];
  uint8_t head, n;
  uint16_t counts[H_COUNT];
  Zone zones[ZONES];
  uint32_t firstEpoch;
};

void begin(uint32_t now);
void note(Kind k, int worldX, uint8_t arg = 0);
void tick(float dtH);
int zoneOf(int worldX);
bool zoneHas(int worldX, Kind k);
float lush(int worldX);
float damp(int worldX);
uint16_t count(Kind k);
// 歷史對植物的影響
float plantBias(int slot, uint8_t species);          // 自然冒出的機率乘數
float plantRate(int slot, uint8_t species);          // 生長速度乘數
bool specialVariant(int slot, uint8_t species, uint8_t& variant);  // 舊木屋/雷擊處長出特殊 (發光) 菌類
void print();
void exportBlob(Blob& b);
void importBlob(const Blob& b);

}  // namespace history
