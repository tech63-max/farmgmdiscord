// 生態狀態保存 (NVS，含版本與 CRC)。重開機後恢復植物、枯木、鳥巢、遷徙、事件記憶、日誌、最後天氣。
#pragma once
#include <stdint.h>

namespace save {
bool load();               // 開機時讀取 (先於各模組初始化)
bool loaded();
uint32_t savedEpoch();
int32_t savedUtcOffset();
void applyLoaded();        // 各模組 begin() 之後呼叫，把資料推回去
void applyHuman();         // 訪客與建築、世界 (獨立的存檔區)
bool migrated();           // 這次開機做了舊版存檔轉換 (需要盡快寫入新版)
bool write();              // 寫入 NVS
void erase();              // 重置森林
}
