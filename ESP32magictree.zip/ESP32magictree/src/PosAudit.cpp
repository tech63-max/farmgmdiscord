#include "PosAudit.h"
#include <Arduino.h>
#include <math.h>
#include "CreatureManager.h"
#include "Scene.h"
#include "VisitorManager.h"

namespace audit {
namespace {
enum Kind : uint8_t { K_WATER, K_FLOAT, K_TRUNK, K_OFFSCREEN, K_CROWD, K_FLY_LOW, K_VIS_WATER, K_COUNT };
const char* KN[K_COUNT] = {"ground creature in river", "ground creature above ground", "inside trunk",
                           "offscreen (not enter/leave)", "crowded (<7px, both resting)", "flier below screen", "visitor in river"};
struct Ex { uint8_t sp, state, flags; int16_t x, y; };
uint32_t cnt[K_COUNT];
uint32_t perSp[K_COUNT][creature::C_COUNT];
Ex last[K_COUNT];
uint32_t seconds = 0;
int maxAmbient = 0, maxTotal = 0;  // 同時在場的常駐 (非事件、非螢火蟲) / 全部 (非螢火蟲) 生物最大數
bool on = false;

void hit(Kind k, const creature::Creature& c) {
  cnt[k]++;
  perSp[k][c.sp]++;
  last[k] = {c.sp, c.state, c.flags, (int16_t)c.x, (int16_t)c.y};
}
bool resting(const creature::Creature& c) {
  return c.state == creature::ST_IDLE || c.state == creature::ST_ACT || c.state == creature::ST_SLEEP;
}
bool nearHollow(float x, float y) { return fabsf(x - scene::HOLLOW_X) < 12 && fabsf(y - scene::HOLLOW_Y - 6) < 14; }
}  // namespace

void enable(bool v) { on = v; }
bool enabled() { return on; }
void reset() {
  memset(cnt, 0, sizeof(cnt)); memset(perSp, 0, sizeof(perSp)); memset(last, 0, sizeof(last));
  seconds = 0; maxAmbient = maxTotal = 0;
}

void tick(uint32_t ms) {
  if (!on) return;
  seconds++;
  using namespace creature;
  int amb = 0, tot = 0;
  for (int i = 0; i < CAP; i++) {
    const Creature& c = at(i);
    if (!c.active || c.sp == C_FIREFLY || c.state == ST_LEAVE) continue;
    tot++;
    if (!(c.flags & F_EVENT)) amb++;
  }
  if (amb > maxAmbient) maxAmbient = amb;
  if (tot > maxTotal) maxTotal = tot;
  for (int i = 0; i < CAP; i++) {
    const Creature& c = at(i);
    if (!c.active || c.alpha < 60) continue;
    const bool moving = c.state == ST_ENTER || c.state == ST_LEAVE;
    if (!c.flying) {
      if (c.sp != C_FROG && c.sp != C_TURTLE && scene::inPond(c.x, c.y, 1)) hit(K_WATER, c);
      if (c.sp != C_SQUIRREL && !nearHollow(c.x, c.y) && fabsf(c.x - scene::HOLLOW_X) > 3 && c.y < scene::groundY((int)c.x) + 8) hit(K_FLOAT, c);
      if (!nearHollow(c.x, c.y) && fabsf(c.x - scene::HOLLOW_X) > 3 && fabsf(c.x - scene::TRUNK_X) < scene::TRUNK_HALF - 2 && c.y < scene::TRUNK_BOTTOM - 4) hit(K_TRUNK, c);
    } else if (c.y > 236 && !moving) hit(K_FLY_LOW, c);
    if (!moving && (c.x < -8 || c.x > 248)) hit(K_OFFSCREEN, c);
    if (!c.flying && resting(c))
      for (int j = i + 1; j < CAP; j++) {
        const Creature& o = at(j);
        if (!o.active || o.flying || o.alpha < 60 || !resting(o)) continue;
        if (fabsf(o.x - c.x) < 7 && fabsf(o.y - c.y) < 5) hit(K_CROWD, c);
      }
  }
  float vx, vy;
  if (visitor::position(vx, vy) && scene::inPond(vx, vy, 1)) {
    cnt[K_VIS_WATER]++;
    last[K_VIS_WATER] = {255, 0, 0, (int16_t)vx, (int16_t)vy};
  }
}

void report() {
  Serial.printf("[Audit] %s, %lu s sampled\n", on ? "on" : "off", (unsigned long)seconds);
  Serial.printf("  max ambient %d, max total %d (fireflies excluded)\n", maxAmbient, maxTotal);
  for (int k = 0; k < K_COUNT; k++) {
    Serial.printf("  %-30s %5lu", KN[k], (unsigned long)cnt[k]);
    if (cnt[k]) {
      const Ex& e = last[k];
      Serial.printf("  last: %s st%u fl%02X @(%d,%d)  by:", e.sp < creature::C_COUNT ? creature::speciesName(e.sp) : "visitor",
                    e.state, e.flags, e.x, e.y);
      for (int s = 0; s < creature::C_COUNT; s++) if (perSp[k][s]) Serial.printf(" %s=%lu", creature::speciesName(s), (unsigned long)perSp[k][s]);
    }
    Serial.println();
  }
}

}  // namespace audit
