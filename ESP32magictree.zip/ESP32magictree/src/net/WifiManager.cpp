#include "WifiManager.h"

#include <WiFi.h>
#include <esp_mac.h>
#include <esp_random.h>
#include <string.h>

namespace {
constexpr uint32_t POLL_MS = 500;
constexpr uint32_t RETRY_MIN_MS = 15000;
constexpr uint32_t RETRY_MAX_MS = 120000;
constexpr uint32_t AP_RETRY_MS = 60000;      // 熱點開著時，多久用舊設定再試一次 (沒人連熱點時才試)
constexpr uint32_t AP_STOP_DELAY_MS = 20000; // 連上後過多久關熱點
constexpr uint32_t AP_IDLE_STOP_MS = 180000; // 已連線時手動開的熱點，多久自動關

void copyStr(char *dst, size_t cap, const char *src) {
  strncpy(dst, src ? src : "", cap - 1);
  dst[cap - 1] = '\0';
}
}  // namespace

void WifiManager::begin(const char *ssid, const char *pass, uint32_t now) {
  WiFi.persistent(false);  // 帳密由 WifiConfig (NVS) 管理，不讓 WiFi 函式庫另存一份
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(true);
  offlineSince_ = now ? now : 1;
  setCredentials(ssid, pass, now);
  // 不自動開設定熱點：使用者在「Wi-Fi 連線」畫面按了才開
}

void WifiManager::setCredentials(const char *ssid, const char *pass, uint32_t now) {
  copyStr(ssid_, sizeof(ssid_), ssid);
  copyStr(pass_, sizeof(pass_), pass);
  WiFi.disconnect();
  if (ssid_[0] == '\0') {
    state_ = WifiState::NoCredentials;
    return;
  }
  retryMs_ = RETRY_MIN_MS;
  offlineSince_ = now ? now : 1;
  connect(now);
}

void WifiManager::connect(uint32_t now) {
  WiFi.begin(ssid_, pass_);  // 非阻塞
  lastAttempt_ = now;
  state_ = WifiState::Connecting;
}

bool WifiManager::justConnected() {
  const bool j = justConnected_;
  justConnected_ = false;
  return j;
}

bool WifiManager::apJustStarted() {
  const bool j = apJustStarted_;
  apJustStarted_ = false;
  return j;
}

void WifiManager::startAp(uint32_t now) {
  (void)now;
  if (apActive_) return;
  uint8_t mac[6];
  esp_read_mac(mac, ESP_MAC_WIFI_STA);  // 直接讀 eFuse (Wi-Fi 啟動前 WiFi.macAddress 會是 0)
  snprintf(apSsid_, sizeof(apSsid_), "Forest-%02X%02X", mac[4], mac[5]);
  // 每次開熱點都換一組 8 位數密碼，只顯示在板子螢幕上
  snprintf(apPass_, sizeof(apPass_), "%08lu", (unsigned long)(esp_random() % 100000000UL));
  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP(apSsid_, apPass_);
  apActive_ = true;
  apJustStarted_ = true;
  apStopAt_ = 0;
  Serial.printf("[WiFi] setup hotspot on: %s (password on screen), http://%s/\n", apSsid_,
                WiFi.softAPIP().toString().c_str());
}

void WifiManager::stopAp() {
  if (!apActive_) return;
  WiFi.softAPdisconnect(true);
  WiFi.mode(WIFI_STA);
  apActive_ = false;
  memset(apPass_, 0, sizeof(apPass_));
  Serial.println("[WiFi] setup hotspot off");
}

void WifiManager::update(uint32_t now) {
  if (now - lastPoll_ < POLL_MS) return;
  lastPoll_ = now;

  if (apActive_ && apStopAt_ != 0 && (int32_t)(now - apStopAt_) >= 0) {
    if (WiFi.softAPgetStationNum() > 0) apStopAt_ = now + 60000;  // 還有手機連著：晚點再關
    else stopAp();
  }
  // 已經連上 Wi-Fi 卻開著熱點 (例如手動 ap 指令)：3 分鐘後自動關
  if (apActive_ && apStopAt_ == 0 && state_ == WifiState::Connected) apStopAt_ = now + AP_IDLE_STOP_MS;

  if (state_ == WifiState::NoCredentials) {
    // 還沒設定 Wi-Fi：等使用者手動開熱點
    return;
  }

  if (WiFi.status() == WL_CONNECTED) {
    if (state_ != WifiState::Connected) {
      state_ = WifiState::Connected;
      justConnected_ = true;
      retryMs_ = RETRY_MIN_MS;
      offlineSince_ = 0;
      if (apActive_) apStopAt_ = now + AP_STOP_DELAY_MS;
    }
    return;
  }

  if (state_ == WifiState::Connected) {  // 斷線：先交給自動重連
    state_ = WifiState::Disconnected;
    lastAttempt_ = now;
    offlineSince_ = now ? now : 1;
  }
  if (offlineSince_ == 0) offlineSince_ = now ? now : 1;


  if (apActive_) {
    // 熱點開著時，重試連線會讓 Wi-Fi 換頻道，手機可能斷線；所以只在沒人連熱點時才用舊設定再試
    if (WiFi.softAPgetStationNum() == 0 && now - lastAttempt_ >= AP_RETRY_MS) connect(now);
    return;
  }
  // 太久沒連上就重新發起連線，間隔逐步拉長
  if (now - lastAttempt_ >= retryMs_) {
    WiFi.disconnect();
    connect(now);
    retryMs_ = retryMs_ * 2 > RETRY_MAX_MS ? RETRY_MAX_MS : retryMs_ * 2;
  }
}
