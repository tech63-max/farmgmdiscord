#pragma once
#include <functional>
#include <stdint.h>

// 手機網頁 (沿用桌寵的設定熱點 + 強制登入頁做法)
// - 設定熱點開著時：DNS 全部導向板子，手機會自動跳出 Wi-Fi 設定頁
// - Wi-Fi 設定表單「只」在連到板子熱點 (熱點密碼只顯示在板子螢幕上) 時提供，
//   從一般區網連進來只看得到唯讀狀態頁，避免同網路的人改掉 Wi-Fi 設定
// - 不顯示 Wi-Fi 密碼；欄位在後端驗證長度；輸出一律 HTML 跳脫
class WebPanel {
 public:
  using SaveWifi = std::function<void(const char *ssid, const char *pass)>;
  using Status = std::function<void(char *buf, size_t cap)>;  // 狀態頁內容 (純文字，會跳脫)

  void begin(SaveWifi onSave, Status status);
  void update();
  void setCaptive(bool on);
  bool started() const { return started_; }

 private:
  bool started_ = false;
};
