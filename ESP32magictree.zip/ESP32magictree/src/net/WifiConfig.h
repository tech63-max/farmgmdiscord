#pragma once
#include <Preferences.h>
#include <string.h>

// Wi-Fi 帳密只存在 NVS (namespace "forest")，不寫進程式碼、不印到 log、網頁也不回傳密碼
namespace WifiConfig {
inline bool valid(const char *ssid, const char *pass) {
  const size_t s = ssid ? strlen(ssid) : 0, p = pass ? strlen(pass) : 0;
  return s >= 1 && s <= 32 && (p == 0 || (p >= 8 && p <= 63));
}

inline void load(char *ssid, size_t ssidCap, char *pass, size_t passCap) {
  ssid[0] = pass[0] = '\0';
  Preferences p;
  if (!p.begin("forest", true)) return;
  p.getString("ssid", ssid, ssidCap);
  p.getString("pass", pass, passCap);
  p.end();
}

inline bool save(const char *ssid, const char *pass) {
  if (!valid(ssid, pass)) return false;
  Preferences p;
  if (!p.begin("forest", false)) return false;
  const bool ok = p.putString("ssid", ssid) > 0 && (pass[0] == '\0' ? p.remove("pass") || true : p.putString("pass", pass) > 0);
  p.end();
  return ok;
}
}  // namespace WifiConfig
