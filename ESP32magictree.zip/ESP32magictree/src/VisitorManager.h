// 外來訪客：冒險家、獵人、旅行商人、神祕旅人
// 每次來訪是一個有因果的「故事腳本」(例如：進森林 → 找空地 → 收集木材 → 蓋木屋 → 休息 → 離開)，
// 留下的建築交給 StructureManager 慢慢被森林回收。同一時間最多一位訪客，且出現頻率很低。
#pragma once
#include <stdint.h>

namespace visitor {

enum Type : uint8_t { V_ADV, V_HUNTER, V_MERCHANT, V_MYSTIC, V_COUNT };
enum Story : uint8_t { S_CABIN, S_CAMP, S_LOST, S_GLOW, S_CHASE, S_STUDY, S_HUNT, S_MERCHANT, S_MYSTIC,
                       S_DIG, S_REVISIT,  // 第二階段：挖掘遺跡、重返遺跡
                       S_TASK,            // 第三階段：由事件指定的任務 (探索、砍樹、採菇、追蹤、交易…)
                       S_COUNT };
enum Task : uint8_t { TK_NONE, TK_EXPLORE, TK_CHOP, TK_MUSHROOM, TK_RAREPLANT, TK_TRACK, TK_TRADE };
constexpr int S_LEGACY = 9;  // 第一版存檔記錄的故事數

void begin(uint32_t ms);
void tick(uint32_t ms);              // 每 5 秒：排程訪客、處理離開後的後續影響
void update(float dt, uint32_t ms);  // 每幀：移動與故事步驟
void draw(int yMin, int yMax);       // 世界座標 y 範圍
void drawTracks();                   // 地上的足跡
bool active();
bool force(int story, uint32_t ms);  // 序列埠測試：立刻開始某個故事
const char* storyName(uint8_t s);
bool canStart(uint32_t ms);                               // 現在可以讓新訪客進場嗎
bool startStory(uint8_t story, uint8_t task, uint32_t ms);  // 事件指定的訪客故事
uint8_t activeType();                                     // 目前訪客的類型 (V_COUNT = 沒有)
bool position(float& x, float& y);
uint32_t lastTypeTime(uint8_t type);

struct Stats {
  uint32_t nextAllowed;          // 下一位訪客最早出現時間 (epoch)
  uint32_t lastType[V_COUNT];
  uint32_t lastStory[S_LEGACY];
  uint32_t lastCapture;
  uint8_t lastTypeId;
};
void exportStats(Stats& s);
void importStats(const Stats& s);
struct StatsExt { uint32_t lastStory[S_COUNT - S_LEGACY]; };  // 第二階段的故事 (存在 world 區)
void exportExt(StatsExt& s);
void importExt(const StatsExt& s);

}  // namespace visitor
