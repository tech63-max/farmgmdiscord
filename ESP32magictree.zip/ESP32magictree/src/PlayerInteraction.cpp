#include "PlayerInteraction.h"
#include <Arduino.h>
#include "Config.h"
#include "Ecosystem.h"
#include "EventManager.h"
#include "Journal.h"
#include "TimeManager.h"
#include "Util.h"

namespace input {
namespace {
constexpr uint32_t DEBOUNCE_MS = 25, LONG_MS = 700, DOUBLE_MS = 320, POWER_MS = 2000, COMBO_MS = 1500, UI_MS = 5000;

struct Btn {
  int pin;
  bool stable, raw, ignore;
  uint32_t changedAt, pressedAt;
  bool longSent;
};
Btn btns[3] = {{cfg::PIN_BTN_BOOT}, {cfg::PIN_BTN_PWR}, {cfg::PIN_BTN_PLUS}};
enum { B_BOOT, B_PWR, B_PLUS };

bool combo = false, comboSent = false;
uint8_t comboWhich = 0;  // 1 = 左+右, 2 = 左+中
uint32_t comboAt = 0;
uint32_t plusReleaseAt = 0;
uint8_t plusClicks = 0;

uint32_t lastBless = 0, lastBreeze = 0, lastPulse = 0, lastAny = 0;
uint32_t resting = 0;

// 回傳：0 無, 1 按下, 2 放開
int sample(Btn& b, uint32_t ms) {
  bool down = digitalRead(b.pin) == LOW;
  if (down != b.raw) { b.raw = down; b.changedAt = ms; }
  if (ms - b.changedAt < DEBOUNCE_MS || down == b.stable) return 0;
  b.stable = down;
  if (down) { b.pressedAt = ms; b.longSent = false; return 1; }
  return 2;
}

bool cooled(uint32_t last, uint32_t cdS, uint32_t ms) { return last == 0 || ms - last >= cdS * 1000; }
}  // namespace

void begin(uint32_t ms) {
  for (auto& b : btns) {
    pinMode(b.pin, INPUT_PULLUP);
    b.raw = b.stable = digitalRead(b.pin) == LOW;
    b.ignore = b.stable;  // 開機時按著 (例如按 PWR 開機) → 放開前不算
    b.changedAt = ms;
  }
}

Action poll(uint32_t ms) {
  int ev[3];
  for (int i = 0; i < 3; i++) ev[i] = sample(btns[i], ms);
  for (int i = 0; i < 3; i++) if (ev[i] == 2 && btns[i].ignore) { btns[i].ignore = false; ev[i] = 0; }

  Btn &boot = btns[B_BOOT], &pwr = btns[B_PWR], &plus = btns[B_PLUS];

  // 組合鍵：左+右 → Wi-Fi 設定；左+中 → 顯示/隱藏 UI
  const bool bootPlus = boot.stable && plus.stable && !boot.ignore && !plus.ignore;
  const bool bootPwr = boot.stable && pwr.stable && !boot.ignore && !pwr.ignore;
  if (bootPlus || bootPwr) {
    const uint8_t which = bootPlus ? 1 : 2;
    if (!combo || comboWhich != which) { combo = true; comboWhich = which; comboSent = false; comboAt = ms; plusClicks = 0; }
    if (!comboSent && ms - comboAt >= COMBO_MS) { comboSent = true; return which == 1 ? A_WIFI_SETUP : A_TOGGLE_UI; }
    return A_NONE;
  }
  if (combo) {
    // 所有鍵都放開才結束組合鍵；期間不產生單鍵動作 (也不會觸發中鍵長按關機)
    if (!boot.stable && !plus.stable && !pwr.stable) combo = false;
    return A_NONE;
  }

  // BOOT：短按 (放開時) = 資訊卡；單獨長按 5 秒 = 顯示/隱藏講解 (時鐘、事件提示)
  if (boot.stable && !boot.ignore && !boot.longSent && ms - boot.pressedAt >= UI_MS) { boot.longSent = true; return A_TOGGLE_UI; }
  if (ev[B_BOOT] == 2 && !boot.longSent) return A_INFO;

  // PWR：短按 = 日誌，長按 = 關機
  if (pwr.stable && !pwr.ignore && !pwr.longSent && ms - pwr.pressedAt >= POWER_MS) { pwr.longSent = true; return A_POWEROFF; }
  if (ev[B_PWR] == 2 && !pwr.longSent) return A_JOURNAL;

  // PLUS：短按 / 雙擊 / 長按
  if (plus.stable && !plus.ignore && !plus.longSent && ms - plus.pressedAt >= LONG_MS) {
    plus.longSent = true;
    plusClicks = 0;
    return A_PULSE;
  }
  if (ev[B_PLUS] == 2 && !plus.longSent) {
    plusClicks++;
    plusReleaseAt = ms;
    if (plusClicks >= 2) { plusClicks = 0; return A_BREEZE; }
  }
  if (plusClicks == 1 && !plus.stable && ms - plusReleaseAt > DOUBLE_MS) { plusClicks = 0; return A_BLESS; }
  return A_NONE;
}

bool apply(Action a, uint32_t ms) {
  if (a != A_BLESS && a != A_BREEZE && a != A_PULSE) return true;
  // 冷卻：避免連續按鈕破壞生態平衡
  bool ok = cooled(lastAny, cfg::CD_GLOBAL, ms);
  if (a == A_BLESS) ok = ok && cooled(lastBless, cfg::CD_BLESS, ms);
  if (a == A_BREEZE) ok = ok && cooled(lastBreeze, cfg::CD_BREEZE, ms);
  if (a == A_PULSE) ok = ok && cooled(lastPulse, cfg::CD_PULSE, ms);
  if (!ok) { resting = ms + 1500; return false; }
  lastAny = ms;
  switch (a) {
    case A_BLESS: lastBless = ms; eco::bless(ms); eventm::onBless(ms); journal::add(journal::J_BLESS); break;
    case A_BREEZE: lastBreeze = ms; eco::breeze(ms); eventm::onBreeze(ms); journal::add(journal::J_BREEZE); break;
    case A_PULSE: lastPulse = ms; eco::pulse(ms); eventm::onPulse(ms); journal::add(journal::J_PULSE); break;
    default: break;
  }
  return true;
}

uint32_t restingUntil() { return resting; }

}  // namespace input
