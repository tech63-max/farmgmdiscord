// 植物生命週期與自然演替
#pragma once
#include <stdint.h>

namespace plant {

enum Species : uint8_t { P_NONE, P_MOSS, P_MUSHROOM, P_FLOWER, P_SAPLING, P_VINE, P_GLOW, P_REED, P_LILY, P_COUNT };
enum Stage : uint8_t { S_SEED, S_SPROUT, S_GROW, S_MATURE, S_BLOOM, S_WITHER, S_DORMANT };
enum Zone : uint8_t { Z_GROUND, Z_SHADE, Z_SHORE, Z_WATER, Z_TRUNK, Z_ROCK, Z_LOG };

struct Slot { short x, y; uint8_t zone; bool treeRoom; };
struct Plant {
  uint8_t species, stage, variant, prevStage;
  uint16_t prog;    // 目前階段進度 0..1000
  uint16_t ageH;    // 植株年齡 (小時)
};
struct Deadwood { uint8_t state; uint16_t ageH; };  // 0 無, 1 新倒木, 2 長苔, 3 長菇

constexpr int SLOT_N = 22;
extern const Slot SLOTS[SLOT_N];

void begin();               // 新森林的初始植物
void tick(float dtSimSec);  // 由主迴圈定期呼叫 (森林時間)
const Plant& get(int i);
Plant& mut(int i);
const Deadwood& log();
void formLog();             // 枯木形成 (事件或老樹倒下)
void setLog(const Deadwood& d);  // 讀檔用
bool hasLog();

// 給生態連動與事件使用
int countStage(Species sp, Stage st);
int countSpecies(Species sp);
int bloomingFlowers();      // 花 + 發光植物盛開數
int matureMushrooms();
float treeMaturity();       // 0..1 吸引小鳥築巢
int randomSlotOf(Species sp, Stage minStage);  // -1 = 沒有
void disperseSeeds(int fromSlot, int count, bool visible);
void boostGrowth(float hours);  // 魔法：讓所有植物前進一點
void sproutRandom(Species sp);  // 事件：讓某種植物冒出來
float growthFrac(int i);   // 視覺大小 0..1
const char* name(Species sp);

}  // namespace plant
