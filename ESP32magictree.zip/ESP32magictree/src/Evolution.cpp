#include "Evolution.h"
#include <Arduino.h>
#include <math.h>
#include <string.h>
#include "CreatureManager.h"
#include "Ecosystem.h"
#include "ForestHistory.h"
#include "Gfx.h"
#include "Journal.h"
#include "PlantManager.h"
#include "Scene.h"
#include "SeasonManager.h"
#include "TimeManager.h"
#include "Underground.h"
#include "Util.h"
#include "Village.h"

namespace evo {
namespace {
Blob b;
uint32_t dblRainbow = 0;
uint8_t lastVillageStage = 0;
const char* const TRAITS[TR_COUNT] = {"normal", "shy", "curious", "greedy", "lazy", "brave", "social"};
int zoneOf(int x) { return util::clamp(x / 40, 0, ZONES - 1); }
}  // namespace

void begin() {
  memset(&b, 0, sizeof(b));
  for (auto& m : b.mem) { m.friendSp = 0xFF; m.homeX = m.foodX = m.dangerX = -1; }
  b.vStyle = (uint8_t)util::rng.irange(0, 2);
}

uint8_t rollTrait(uint8_t sp) {
  // 物種有自己的傾向：松鼠貪吃、蝸牛膽小、小精靈好奇、蘑菇生物慵懶
  float r = util::rng.f();
  switch (sp) {
    case creature::C_SQUIRREL: if (r < 0.4f) return TR_GREEDY; break;
    case creature::C_SNAIL: case creature::C_MOLE: if (r < 0.4f) return TR_SHY; break;
    case creature::C_SPRITE: if (r < 0.4f) return TR_CURIOUS; break;
    case creature::C_SHROOM: if (r < 0.4f) return TR_LAZY; break;
    case creature::C_CRITTER: if (r < 0.2f) return TR_SOCIAL; if (r < 0.3f) return TR_BRAVE; break;
    default: break;
  }
  return (uint8_t)util::rng.irange(0, TR_COUNT - 1);
}
const char* traitName(uint8_t t) { return t < TR_COUNT ? TRAITS[t] : "?"; }

Memory& mem(uint8_t sp) { return b.mem[sp < MEM_SPECIES ? sp : 0]; }
void fearHunter(int amount) {
  const uint8_t prey[] = {creature::C_CRITTER, creature::C_SQUIRREL, creature::C_SNAIL, creature::C_MOLE, creature::C_FROG};
  for (uint8_t sp : prey) b.mem[sp].fear = (uint8_t)util::clamp((int)b.mem[sp].fear + amount, 0, 255);
}
void remember(uint8_t sp, int16_t homeX, int16_t foodX) {
  if (sp >= MEM_SPECIES) return;
  if (homeX >= 0) b.mem[sp].homeX = homeX;
  if (foodX >= 0) b.mem[sp].foodX = foodX;
}
void setDanger(int16_t x) { for (auto& m : b.mem) m.dangerX = x; }
void setFriend(uint8_t sp, uint8_t f) { if (sp < MEM_SPECIES) b.mem[sp].friendSp = f; }
bool dangerous(float x) {
  int16_t d = b.mem[creature::C_CRITTER].dangerX;
  return d >= 0 && fabsf(x - d) < 24;
}

float terrain(uint8_t f, int x) { return f < TF_COUNT ? b.terrain[f][zoneOf(x)] : 0; }
void addTerrain(uint8_t f, int x, float d) { if (f < TF_COUNT) { float& v = b.terrain[f][zoneOf(x)]; v = util::clamp01(v + d); } }

float plantBias(int slot, uint8_t sp) {
  const int z = zoneOf(plant::SLOTS[slot].x);
  const float wet = b.terrain[TF_WET][z], mush = b.terrain[TF_MUSH][z], clr = b.terrain[TF_CLEAR][z], dead = b.terrain[TF_DEAD][z], glow = b.terrain[TF_GLOW][z];
  switch (sp) {
    case plant::P_MUSHROOM: return 1.0f + mush * 2.0f + wet * 0.5f;
    case plant::P_MOSS: case plant::P_REED: return 1.0f + wet * 1.5f;
    case plant::P_FLOWER: return (1.0f + clr * 0.8f) * (1.0f - dead * 0.6f);   // 空地重新長出花草
    case plant::P_SAPLING: return 1.0f - clr * 0.5f;
    case plant::P_GLOW: return 1.0f + glow * 2.0f;
    default: return 1.0f;
  }
}

void tick(float dtH) {
  if (dtH <= 0) return;
  const eco::Env& e = eco::env;
  const eco::World& w = eco::world;
  // ---- 地形長期演化 (數天到數週) ----
  float zoneMush[ZONES] = {0}, zoneGlow[ZONES] = {0};
  for (int i = 0; i < plant::SLOT_N; i++) {
    const plant::Plant& p = plant::get(i);
    const int z = zoneOf(plant::SLOTS[i].x);
    if (p.species == plant::P_MUSHROOM && p.stage >= plant::S_MATURE) zoneMush[z] += 1;
    if (p.species == plant::P_GLOW && p.stage >= plant::S_MATURE) zoneGlow[z] += 1;
  }
  for (int z = 0; z < ZONES; z++) {
    const int x = z * 40 + 20;
    float* t = &b.terrain[0][0];
    (void)t;
    b.terrain[TF_WET][z] = util::clamp01(b.terrain[TF_WET][z] + dtH * ((history::damp(x) > 0.65f ? 0.002f : 0) + w.puddle * 0.003f - w.drought * 0.004f - 0.0004f));
    b.terrain[TF_MUSH][z] = util::clamp01(b.terrain[TF_MUSH][z] + dtH * (zoneMush[z] >= 2 && history::damp(x) > 0.5f ? 0.003f : -0.0006f));
    b.terrain[TF_CLEAR][z] = util::clamp01(b.terrain[TF_CLEAR][z] - dtH * 0.0012f);  // 空地無人干擾 → 慢慢長回來
    b.terrain[TF_DEAD][z] = util::clamp01(b.terrain[TF_DEAD][z] + dtH * (w.drought > 0.5f ? 0.003f : -0.0008f - e.rain * 0.002f));
    b.terrain[TF_GLOW][z] = util::clamp01(b.terrain[TF_GLOW][z] + dtH * (zoneGlow[z] * 0.0006f + e.magic * 0.002f + (b.magicDays > 0 ? 0.003f : 0) - 0.0005f));
  }
  // 地形里程碑寫日誌 (每個欄位每區一次；降回去之後可以再記)
  static const journal::Msg TM[TF_COUNT] = {journal::J_T_WETLAND, journal::J_T_MUSHFOREST, journal::J_T_REGROW, journal::J_T_DEADWOOD, journal::J_T_GLOWZONE};
  for (int f = 0; f < TF_COUNT; f++) {
    for (int z = 0; z < ZONES; z++) {
      const int bit = (f * ZONES + z) % 16;
      const float v = b.terrain[f][z];
      if (f == TF_CLEAR) continue;  // 空地由砍伐事件產生，重新長回時另外處理
      if (v > 0.6f && !(b.terrainSaid & (1u << bit))) { b.terrainSaid |= (uint16_t)(1u << bit); journal::add(TM[f], 0xFF, false); }
      if (v < 0.3f) b.terrainSaid &= (uint16_t)~(1u << bit);
    }
  }
  for (int z = 0; z < ZONES; z++) {  // 空地重新長出植物
    static float prevClear[ZONES];
    if (prevClear[z] > 0.35f && b.terrain[TF_CLEAR][z] <= 0.35f) journal::add(journal::J_T_REGROW, 0xFF, false);
    prevClear[z] = b.terrain[TF_CLEAR][z];
  }
  // ---- 記憶淡忘 ----
  for (auto& m : b.mem) if (m.fear > 0) m.fear = (uint8_t)fmaxf(0, m.fear - dtH * 2.0f);
  // ---- 跨多日現象 ----
  if (season::weight(WINTER) > 0.5f && e.tempC < 3 && (e.snow > 0.1f || e.rain > 0.2f)) b.snow = fminf(1, b.snow + dtH * 0.1f);
  else b.snow = fmaxf(0, b.snow - dtH * (e.tempC > 5 ? 0.04f : 0.005f));
  b.magicDays = fmaxf(0, b.magicDays - dtH / 24.0f);
  b.rareNestDays = fmaxf(0, b.rareNestDays - dtH / 24.0f);
  if (b.magicDays > 0) eco::env.magic = fmaxf(eco::env.magic, 0.35f);
  if (w.meteorGlow < 0.02f) b.meteorNear = 0;
  // ---- 聚落擴充：食物、材料、空間限制 ----
  const uint8_t vs = village::stage();
  if (vs == village::VS_GATHER && lastVillageStage == village::VS_NONE) b.vStyle = (uint8_t)util::rng.irange(0, 2);  // 新聚落的建築風格
  if (vs == village::VS_NONE) { b.vTower = b.vStorage = b.vLanterns = 0; b.vFood = 0; }
  else if (vs >= village::VS_COLLECT && vs <= village::VS_EXPAND)
    b.vFood = fminf(20, b.vFood + dtH * (plant::bloomingFlowers() * 0.04f + w.acornsGround * 0.01f) - dtH * 0.02f * (1 + b.vLanterns));
  lastVillageStage = vs;
}

float snow() { return b.snow; }
void addSnow(float v) { b.snow = util::clamp01(b.snow + v); }
float magicDays() { return b.magicDays; }
void startEnchant(float d) { b.magicDays = fmaxf(b.magicDays, d); }
bool rareNest() { return b.rareNestDays > 0; }
void startRareNest(float d) { b.rareNestDays = fmaxf(b.rareNestDays, d); }
bool meteorNear() { return b.meteorNear; }
void setMeteorNear(bool on) { b.meteorNear = on; }
void setTunnel(bool on) { b.tunnel = on; }
void setGlowCave(bool on) { b.glowCave = on; }
uint32_t& doubleRainbowUntil() { return dblRainbow; }

uint8_t villageStyle() { return b.vStyle; }
bool buildTower() {
  if (b.vTower || b.vFood < 4) return false;
  b.vTower = 1; b.vFood -= 4; return true;
}
bool buildStorage() {
  if (b.vStorage || b.vFood < 3) return false;
  b.vStorage = 1; b.vFood -= 3; return true;
}
bool addLantern() {
  if (b.vLanterns >= 3) return false;
  b.vLanterns++; return true;
}
void villageTrade() { b.vTrades = (uint8_t)fminf(255, b.vTrades + 1); b.vFood = fminf(20, b.vFood + 3); }
float villageFood() { return b.vFood; }

void noteKind(uint8_t k) { if (k < 32) b.lastKind[k] = timem::now(); }
uint32_t lastKind(uint8_t k) { return k < 32 ? b.lastKind[k] : 0; }

// ---------------- 繪圖 ----------------
void drawSky(uint32_t ms) {
  if (b.magicDays <= 0 || eco::env.night < 0.4f) return;
  // 持續數天的魔法現象：夜空中緩慢飄動的極光
  const bool w = gfx::world;
  gfx::world = false;
  const float a = eco::env.night * util::clamp01(b.magicDays) * (1 - eco::env.cloud * 0.6f);
  for (int x = 0; x < gfx::W; x++) {
    float y0 = 14 + sinf(x * 0.08f + ms * 0.0004f) * 5 + sinf(x * 0.03f - ms * 0.0002f) * 4;
    for (int k = 0; k < 7; k++) {
      int y = (int)y0 + k;
      if (!gfx::isSky(x, y)) continue;
      float f = (1 - k / 7.0f) * a * (0.6f + 0.4f * sinf(x * 0.2f + ms * 0.001f));
      gfx::padd(x, y, (int)(30 * f), (int)(140 * f), (int)(110 * f + 40 * f * sinf(x * 0.05f)));
    }
  }
  gfx::world = w;
}

void drawGround(uint32_t ms) {
  const eco::Env& e = eco::env;
  const bool w = gfx::world;
  gfx::world = false;
  // 地形演化的痕跡 (每區)
  for (int z = 0; z < ZONES; z++) {
    const int x0 = z * 20;
    for (int f = 0; f < TF_COUNT; f++) {
      const float v = b.terrain[f][z];
      if (v < 0.15f) continue;
      const int n = (int)(v * 10);
      for (int k = 0; k < n; k++) {
        int x = x0 + (int)(util::hashf(k * 7 + f, z * 13) * 20), y = 93 + (int)(util::hashf(z * 5 + f, k * 3) * 25);
        if (scene::inPond(x * 2, y * 2, -4) || y * 2 < scene::groundY(x * 2)) continue;
        switch (f) {
          case TF_WET:  // 濕地：水窪反光與小蘆葦
            gfx::pblend(x, y, gfx::lit(0x46788C), 150); gfx::pblend(x + 1, y, gfx::lit(0x5A8CA0), 120);
            if (k % 3 == 0) { gfx::pset(x, y - 1, gfx::lit(0x5A8C46)); gfx::pset(x, y - 2, gfx::lit(0x6E9A50)); }
            break;
          case TF_MUSH:  // 蘑菇森林：散落的小蘑菇
            gfx::pset(x, y, gfx::lit(0xE6DCC8)); gfx::pset(x, y - 1, gfx::lit(k & 1 ? 0xB45A46 : 0x8C6A50));
            if (e.night > 0.5f && (k % 4 == 0)) gfx::glow(x, y - 1, 2, 0x8CE6C8, (uint8_t)(80 * e.night));
            break;
          case TF_CLEAR:  // 空地：樹樁與較淺的草地
            if (k % 3 == 0) { gfx::pset(x, y, gfx::lit(0x8C6A46)); gfx::pset(x + 1, y, gfx::lit(0xB48C5A)); }
            else gfx::pblend(x, y, gfx::lit(0xB4AA6E), 90);
            break;
          case TF_DEAD:  // 枯木區：灰色枯枝
            gfx::pset(x, y, gfx::lit(0x6E665A)); if (k & 1) gfx::pset(x + 1, y - 1, gfx::lit(0x8A8070));
            break;
          case TF_GLOW:  // 發光植物區：夜裡的小光點
            if (e.night > 0.3f) gfx::glow(x, y - 1, 2, k & 1 ? 0x8CDCFF : 0xC8A0FF, (uint8_t)(e.night * 110 * (0.6f + 0.4f * sinf(ms * 0.002f + k))));
            else gfx::pset(x, y, gfx::lit(0x78B4A0));
            break;
        }
      }
    }
  }
  // 聚落擴充：瞭望台、倉庫、燈籠
  const uint8_t vs = village::stage();
  if (vs >= village::VS_HUT && vs <= village::VS_ABANDONED) {
    const int vx = 18, vy = 103;
    const bool abandoned = vs == village::VS_ABANDONED;
    if (b.vTower) {
      const int tx = vx + 14;
      for (int y = 0; y < 13; y++) { gfx::pset(tx - 2, vy - y, gfx::lit(0x6E4E32)); gfx::pset(tx + 2, vy - y, gfx::lit(0x6E4E32)); }
      for (int x = -3; x <= 3; x++) gfx::pset(tx + x, vy - 10, gfx::lit(0x9A7448));
      for (int x = -2; x <= 2; x++) gfx::pset(tx + x, vy - 14 + (abs(x) / 2), gfx::lit(b.vStyle == 2 ? 0x5A9A46 : 0xB4463C));
      if (!abandoned && e.night > 0.4f) gfx::glow(tx, vy - 12, 3, 0xFFC864, 120);
    }
    if (b.vStorage) {
      const int sx = vx - 13;
      for (int y = 0; y < 4; y++) for (int x = -2; x <= 2; x++) gfx::pset(sx + x, vy - y, gfx::lit(y == 3 ? 0x8C643C : 0xA07848));
      gfx::pset(sx, vy - 1, gfx::lit(0x3A2A20));
    }
    for (int k = 0; k < b.vLanterns; k++) {
      int lx = vx - 8 + k * 9, ly = vy - 4;
      gfx::pset(lx, ly, gfx::lit(0x5A4632)); gfx::pset(lx, ly - 1, gfx::lit(0x5A4632));
      if (!abandoned && e.night > 0.3f) { gfx::glow(lx, ly - 2, 3, 0xFFDC82, (uint8_t)(140 * e.night)); gfx::pset(lx, ly - 2, gfx::rgb(0xFFE6A0)); }
    }
  }
  // 稀有生物的巢 (古樹根部，夜裡發光)
  if (b.rareNestDays > 0) {
    const int nx = (scene::TRUNK_X + 20) >> 1, ny = 95;
    gfx::pset(nx - 1, ny, gfx::lit(0x8C6A46)); gfx::pset(nx, ny, gfx::lit(0xA07848)); gfx::pset(nx + 1, ny, gfx::lit(0x8C6A46));
    if (e.night > 0.3f) gfx::glow(nx, ny - 1, 4, 0xDCE8FF, (uint8_t)(e.night * 150 * (0.7f + 0.3f * sinf(ms * 0.0015f))));
  }
  // 地下：發光洞穴與地下通道
  for (int i = 0; i < under::CAP; i++) {
    const under::Burrow& br = under::at(i);
    if (br.state == under::B_NONE) continue;
    if (b.glowCave && (br.state == under::B_MUSHROOM || br.state == under::B_ABANDONED) && e.night > 0.2f)
      gfx::glow(br.x >> 1, (br.y >> 1) - 1, 4, 0x78F0C8, (uint8_t)(e.night * 160));
  }
  if (b.tunnel) {
    int a = -1, c = -1;
    for (int i = 0; i < under::CAP; i++) if (under::at(i).state != under::B_NONE) { if (a < 0) a = i; else if (c < 0) c = i; }
    if (a >= 0 && c >= 0) {
      const under::Burrow &p = under::at(a), &q = under::at(c);
      for (int k = 1; k < 12; k += 2) {
        int x = ((p.x + (q.x - p.x) * k / 12) >> 1), y = ((p.y + (q.y - p.y) * k / 12) >> 1) + 1;
        gfx::pblend(x, y, gfx::lit(0x5A4632), 110);  // 地面上隱約看得到的隆起
      }
    }
  }
  gfx::world = w;
}

void print() {
  static const char* TF[TF_COUNT] = {"wet", "mush", "clear", "dead", "glow"};
  for (int f = 0; f < TF_COUNT; f++) {
    Serial.printf("  terrain %-5s", TF[f]);
    for (int z = 0; z < ZONES; z++) Serial.printf(" %.2f", b.terrain[f][z]);
    Serial.println();
  }
  Serial.printf("  snow %.2f magicDays %.1f rareNest %.1f meteorNear %u tunnel %u glowCave %u\n", b.snow, b.magicDays, b.rareNestDays, b.meteorNear, b.tunnel, b.glowCave);
  Serial.printf("  village style %u tower %u storage %u lanterns %u food %.1f trades %u\n", b.vStyle, b.vTower, b.vStorage, b.vLanterns, b.vFood, b.vTrades);
  const Memory& m = b.mem[creature::C_CRITTER];
  Serial.printf("  critter memory fear %u home %d food %d danger %d friend %u\n", m.fear, m.homeX, m.foodX, m.dangerX, m.friendSp);
}

void exportBlob(Blob& o) { o = b; }
void importBlob(const Blob& i) { b = i; }

}  // namespace evo
