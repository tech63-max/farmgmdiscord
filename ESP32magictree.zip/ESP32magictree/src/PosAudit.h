// 位置診斷 (除錯用，預設關閉)：每秒檢查生物/訪客是否在不合理的位置，序列埠 "audit on|off|reset" / "audit" 看統計
#pragma once
#include <stdint.h>

namespace audit {
void enable(bool on);
bool enabled();
void reset();
void tick(uint32_t ms);  // 每秒呼叫
void report();
}  // namespace audit
