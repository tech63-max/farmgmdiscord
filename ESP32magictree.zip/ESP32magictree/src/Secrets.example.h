// 複製成 Secrets.h 後填入。WIFI_SSID 留空字串 = 離線模式 (本地模擬天氣)。
#pragma once
#define WIFI_SSID ""
#define WIFI_PASS ""
#define FOREST_LAT 25.033f
#define FOREST_LON 121.565f
