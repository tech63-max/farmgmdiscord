#include "Particles.h"
#include <math.h>
#include "Gfx.h"
#include "Scene.h"
#include "Util.h"

namespace fx {
namespace {
P pool[CAP];
int cursor = 0;
}  // namespace

void spawn(PType t, float x, float y, float vx, float vy, uint16_t lifeMs, uint32_t color, uint8_t a) {
  // 找空位；滿了就覆蓋最舊的游標位置
  for (int k = 0; k < CAP; k++) {
    int i = (cursor + k) % CAP;
    if (pool[i].type == PT_NONE) { cursor = i; break; }
  }
  P& p = pool[cursor];
  cursor = (cursor + 1) % CAP;
  p = {x, y, vx, vy, lifeMs, lifeMs, color, (uint8_t)t, a, 0, 0};
}

void seedFlight(float x0, float y0, float x1, float y1) {
  spawn(PT_SEED, x0, y0, 0, 0, 6000, 0xF4F0E0);
  P& p = pool[(cursor + CAP - 1) % CAP];
  p.tx = x1; p.ty = y1;
}

void ripple(float x, float y, uint8_t size) { spawn(PT_RIPPLE, x, y, 0, 0, 1600, 0xCFE8F0, size); }

void leaves(int n, bool autumn) {
  static const uint32_t GREEN[] = {0x6FA84A, 0x8CBF5A, 0x4E8A3E};
  static const uint32_t AUT[] = {0xE0902E, 0xC9622B, 0xE8C14A, 0xA8452A};
  for (int i = 0; i < n; i++) {
    uint32_t c = autumn ? AUT[util::rng.irange(0, 3)] : GREEN[util::rng.irange(0, 2)];
    spawn(PT_LEAF, util::rng.range(0, 120), util::rng.range(10, 80), util::rng.range(5, 25), util::rng.range(4, 12),
          (uint16_t)util::rng.irange(5000, 9000), c, (uint8_t)util::rng.irange(0, 255));
  }
}

void update(float dt, float wind) {
  for (auto& p : pool) {
    if (p.type == PT_NONE) continue;
    uint32_t dms = (uint32_t)(dt * 1000);
    if (p.life <= dms) { p.type = PT_NONE; continue; }
    p.life -= dms;
    const float t = 1.0f - (float)p.life / p.maxLife;
    switch (p.type) {
      case PT_LEAF:
        p.a += 6;
        p.vx = util::lerp(p.vx, 10 + wind * 45, dt);
        p.x += (p.vx + sinf(p.a * 0.05f) * 10) * dt;
        p.y += (p.vy + cosf(p.a * 0.05f) * 6) * dt;
        if (p.y > scene::walkY((int)p.x) + 6) { p.vy = 0; p.vx *= 0.9f; p.y = scene::walkY((int)p.x) + 6; }
        break;
      case PT_POLLEN: case PT_PETAL:
        p.a += 3;
        p.x += (p.vx + wind * 30) * dt;
        p.y += (p.vy + sinf(p.a * 0.08f) * 5) * dt;
        break;
      case PT_SEED: {
        // 種子沿弧線飄到目標位置
        float dx = p.tx - p.x, dy = p.ty - p.y;
        float d = sqrtf(dx * dx + dy * dy);
        if (d < 2) { p.type = PT_NONE; break; }
        float sp = 18 + wind * 20;
        p.x += dx / d * sp * dt;
        p.y += (dy / d * sp + sinf(t * 18) * 8 - 6 * (1 - t)) * dt;
        break;
      }
      case PT_INSECT:
        p.a += 7;
        p.vx += util::rng.range(-40, 40) * dt;
        p.vy += util::rng.range(-40, 40) * dt;
        p.vx = util::clamp(p.vx, -12.0f, 12.0f);
        p.vy = util::clamp(p.vy, -8.0f, 8.0f);
        p.x += p.vx * dt; p.y += p.vy * dt;
        if (p.y < 130) p.vy += 10 * dt;
        if (p.y > 205) p.vy -= 10 * dt;
        break;
      case PT_ACORN:
        p.vy += 160 * dt;
        p.x += p.vx * dt; p.y += p.vy * dt;
        if (p.y > scene::walkY((int)p.x)) {
          p.y = scene::walkY((int)p.x);
          p.vy = -p.vy * 0.35f; p.vx *= 0.6f;
          if (fabsf(p.vy) < 8) p.vy = 0;
        }
        break;
      default:
        p.x += p.vx * dt; p.y += p.vy * dt;
        if (p.type == PT_SPLASH) p.vy += 90 * dt;
        break;
    }
    if (p.x < -10 || p.x > cfg::W + 10 || p.y < -20 || p.y > cfg::H + 5) p.type = PT_NONE;
  }
}

void drawBack() {
  for (auto& p : pool) {
    if (p.type != PT_RIPPLE) continue;
    float t = 1.0f - (float)p.life / p.maxLife;
    int rx = 1 + (int)(t * p.a), ry = 1 + (int)(t * p.a * 0.35f);
    uint8_t a = (uint8_t)(200 * (1 - t));
    uint16_t c = gfx::lit(p.color);
    // 橢圓外框
    for (int k = 0; k < 24; k++) {
      float ang = k * (6.2832f / 24);
      gfx::pblend((int)(p.x + cosf(ang) * rx), (int)(p.y + sinf(ang) * ry), c, a);
    }
  }
}

void drawFront() {
  for (auto& p : pool) {
    if (p.type == PT_NONE || p.type == PT_RIPPLE) continue;
    const int x = (int)p.x, y = (int)p.y;
    const float lifeT = (float)p.life / p.maxLife;
    switch (p.type) {
      case PT_LEAF: {
        uint16_t c = gfx::lit(p.color);
        gfx::pset(x, y, c);
        if ((p.a >> 5) & 1) gfx::pset(x + 1, y, c); else gfx::pset(x, y + 1, c);
        break;
      }
      case PT_PETAL: gfx::pset(x, y, gfx::lit(p.color)); gfx::pset(x + 1, y, gfx::lit(p.color)); break;
      case PT_POLLEN: gfx::glow(x, y, 2, p.color, (uint8_t)(160 * lifeT)); gfx::pset(x, y, gfx::lit(p.color)); break;
      case PT_SPARKLE: case PT_MAGIC: {
        uint8_t in = (uint8_t)(255 * lifeT);
        gfx::glow(x, y, p.type == PT_MAGIC ? 4 : 3, p.color, in);
        if (lifeT > 0.5f) gfx::padd(x, y, 120, 120, 120);
        break;
      }
      case PT_GLOWDOT: gfx::glow(x, y, 3, p.color, (uint8_t)(200 * lifeT)); break;
      case PT_SEED: gfx::pset(x, y, gfx::lit(0xFFFFF0)); gfx::pblend(x - 1, y - 1, gfx::lit(0xFFFFF0), 120); gfx::pblend(x + 1, y - 1, gfx::lit(0xFFFFF0), 120); break;
      case PT_DEW: {
        uint8_t tw = (uint8_t)(255 * sinf(lifeT * 3.1416f));
        gfx::padd(x, y, tw * 3 / 4, tw * 3 / 4, tw);
        break;
      }
      case PT_SPLASH: gfx::pblend(x, y, gfx::lit(0xD8F0FF), (uint8_t)(220 * lifeT)); break;
      case PT_INSECT: gfx::pset(x, y, gfx::lit(0x302820)); if ((p.a >> 3) & 1) gfx::pblend(x, y - 1, gfx::lit(0xE0E0E0), 140); break;
      case PT_ACORN:
        gfx::pset(x, y - 1, gfx::lit(0x6B4423)); gfx::pset(x + 1, y - 1, gfx::lit(0x6B4423));
        gfx::pset(x, y, gfx::lit(0xB07A3A)); gfx::pset(x + 1, y, gfx::lit(0xB07A3A)); gfx::pset(x, y + 1, gfx::lit(0x8E5E2C));
        break;
      case PT_ZZZ: {
        uint16_t c = gfx::mix(gfx::pget(x, y), gfx::rgb(0xE8E8FF), (uint8_t)(200 * lifeT));
        gfx::hline(x, y, 3, c); gfx::pset(x + 1, y + 1, c); gfx::hline(x, y + 2, 3, c);
        break;
      }
      default: break;
    }
  }
}

int count(PType t) {
  int n = 0;
  for (auto& p : pool) if (p.type == t) n++;
  return n;
}

int nearest(PType t, float x, float y, float maxDist) {
  int best = -1;
  float bd = maxDist * maxDist;
  for (int i = 0; i < CAP; i++) {
    if (pool[i].type != t) continue;
    float dx = pool[i].x - x, dy = pool[i].y - y, d = dx * dx + dy * dy;
    if (d < bd) { bd = d; best = i; }
  }
  return best;
}

P& at(int i) { return pool[i]; }
void kill(int i) { pool[i].type = PT_NONE; }

}  // namespace fx
