// 事件記憶：最近發生過的事件會降低再次被抽中的機率；記錄各分類、各事件上次發生時間
#pragma once
#include <stdint.h>

namespace evmem {

constexpr int HIST = 32;
constexpr int MAX_EVENTS = 200;  // 事件編號仍是 uint8_t (< 255)
constexpr int LEGACY_EVENTS = 40;  // 第一版存檔格式只存前 40 種 (格式不可改)
constexpr int CATS = 5;

struct Rec { uint8_t id; uint32_t epoch; };

void begin(uint32_t now);
void record(uint8_t id, uint8_t cat, uint32_t now);
float penalty(uint8_t id, uint32_t now);     // 0..1 (近期發生越多次越低)
float catHunger(uint8_t cat, uint32_t now);  // >=1 (此分類越久沒發生越高)
uint32_t lastTime(uint8_t id);
uint16_t timesSeen(uint8_t id);
uint8_t lastCat();
uint8_t lastId();
// 存檔：第一版格式 (eco) + 擴充部分 (world)
struct Blob {
  Rec hist[HIST];
  uint8_t histHead, histN;
  uint32_t last[LEGACY_EVENTS];
  uint16_t times[LEGACY_EVENTS];
  uint32_t catLast[CATS];
};
struct BlobExt {
  uint32_t last[MAX_EVENTS - LEGACY_EVENTS];
  uint16_t times[MAX_EVENTS - LEGACY_EVENTS];
};
void exportBlob(Blob& b);
void importBlob(const Blob& b);
void exportExt(BlobExt& b);
void importExt(const BlobExt& b);

}  // namespace evmem
