#include "CreatureManager.h"
#include <Arduino.h>
#include <math.h>
#include "Ecosystem.h"
#include "ForestHistory.h"
#include "Underground.h"
#include "Evolution.h"
#include "VisitorManager.h"
#include "EventManager.h"
#include "Gfx.h"
#include "Journal.h"
#include "Particles.h"
#include "PlantManager.h"
#include "Ruins.h"
#include "Scene.h"
#include "SeasonManager.h"
#include "Sprites.h"
#include "TimeManager.h"
#include "Util.h"

namespace creature {
namespace {

struct Def {
  const char* name;
  uint8_t maxN;
  uint8_t phases;     // 主要活動時段
  float speed;        // px/s
  float spawn;        // 每次檢查的基礎出現機率
  float rainPref;     // -1 討厭雨 .. +1 喜歡雨
  float tMin, tMax;   // 舒適溫度
  float windTol;      // 0..1
  uint16_t stayMin, stayMax;  // 一次拜訪停留秒數
  uint16_t restMin, restMax;  // 休息/睡覺秒數
  bool migrates;
};
const Def DEFS[] = {

    //  名稱        max  時段                               速度  出現  雨偏好  tMin tMax 風   停留          休息      遷徙
    {"小精靈",      3, PM_DUSK | PM_NIGHT | PM_MORNING,      16, 0.20f, -0.6f,  8, 32, 0.5f, 120, 420,  25, 70,  false},
    {"蘑菇生物",    2, PM_DUSK | PM_NIGHT | PM_DAWN,          5, 0.12f,  0.7f,  6, 30, 0.7f, 200, 600,  20, 60,  false},
    {"森林小獸",    2, PM_MORNING | PM_AFTERNOON | PM_DUSK,  18, 0.15f, -0.8f,  4, 33, 0.6f, 150, 480,  40, 120, true},
    {"蝸牛",        2, PM_ALL,                              1.6f, 0.10f,  1.0f,  8, 30, 0.8f, 300, 900,  30, 90,  false},
    {"青蛙",        2, PM_DUSK | PM_NIGHT | PM_MORNING,      30, 0.15f,  0.9f, 12, 34, 0.7f, 200, 600,  20, 60,  false},
    {"小鳥",        3, PM_DAWN | PM_MORNING | PM_NOON | PM_AFTERNOON, 46, 0.20f, -0.9f, 2, 34, 0.45f, 90, 360, 20, 60, true},
    {"蝴蝶",        3, PM_MORNING | PM_NOON | PM_AFTERNOON,  14, 0.18f, -1.0f, 15, 34, 0.4f, 60, 240,   8, 20,  true},
    {"螢火蟲",     10, PM_NIGHT | PM_DUSK,                    7, 0.50f, -0.4f, 14, 33, 0.5f, 300, 1200, 0, 0,   false},
    {"白鹿",        1, PM_ALL,                               10, 0,      0,    -20, 50, 1.0f, 40, 60,    6, 10,  false},
    {"未知生物",    1, PM_ALL,                                8, 0,      0,    -20, 50, 1.0f, 25, 35,    0, 0,   false},
    {"發光蝴蝶",    6, PM_ALL,                               16, 0,      0,    -20, 50, 1.0f, 30, 45,    0, 0,   false},
    {"地鼠",        1, PM_DAWN | PM_DUSK | PM_NIGHT | PM_MORNING, 8, 0.12f, 0.3f, 2, 32, 0.8f, 150, 400, 30, 80, false},
    {"蜜蜂",        3, PM_MORNING | PM_NOON | PM_AFTERNOON,  20, 0.20f, -1.0f, 14, 35, 0.4f, 60, 200,   5, 10,  true},
    {"松鼠",        1, PM_MORNING | PM_AFTERNOON | PM_DUSK,  30, 0.12f, -0.7f,  0, 32, 0.6f, 120, 360, 20, 60,  true},
    {"遠古巨龜",    1, PM_ALL,                                3, 0,      0,    -20, 50, 1.0f, 100, 120,   0, 0,   false},
};

Creature cs[CAP];
float nest = 0;
uint32_t seen[C_COUNT];
uint32_t away[C_COUNT];
static_assert(sizeof(DEFS) / sizeof(DEFS[0]) == C_COUNT, "DEFS 與物種數量不符");
uint32_t lastMigrateCheck = 0;
Species pendingFriend = C_COUNT;

float rnd(float a, float b) { return util::rng.range(a, b); }

// ---- 環境適合度 ----
float foodLevel(uint8_t sp) {
  const eco::Env& e = eco::env;
  const eco::World& w = eco::world;
  switch (sp) {
    case C_BIRD: case C_FROG: return util::clamp01(0.2f + e.insects);
    case C_BUTTERFLY: case C_BEE: return util::clamp01(0.1f + e.nectar * 1.5f);
    case C_CRITTER: return util::clamp01(0.3f + (w.acornsGround + w.acornCache) / 12.0f + e.insects * 0.3f);
    case C_SQUIRREL: return util::clamp01(0.15f + w.acornsGround / 6.0f + w.acornCache / 20.0f);
    case C_MOLE: return util::clamp01(0.3f + under::moisture() * 0.7f);
    default: return 1.0f;
  }
}

float suitability(Species sp) {
  const Def& d = DEFS[sp];
  const eco::Env& e = eco::env;
  float s = (timem::phaseMask() & d.phases) ? 1.0f : 0.12f;
  if (e.rain > 0.1f) s *= util::clamp(1.0f + d.rainPref * e.rain * 1.6f, 0.05f, 3.0f);
  else if (d.rainPref > 0.5f) s *= 0.5f + util::clamp01(e.airHum / 100.0f) + (e.hoursSinceRain < 6 ? 1.0f : 0);  // 雨後
  if (e.storm > 0.5f && d.rainPref < 0.9f) s *= 0.1f;
  if (e.tempC < d.tMin || e.tempC > d.tMax) s *= 0.2f;
  if (e.wind > d.windTol) s *= 0.2f;
  if (e.cold) s *= 0.6f;
  if (e.hot && sp != C_FROG) s *= 0.7f;
  // 生態連動
  switch (sp) {
    case C_BUTTERFLY: s *= 0.2f + plant::bloomingFlowers() * 0.5f; s *= 0.6f + e.light; break;
    case C_SPRITE: s *= 0.3f + (plant::bloomingFlowers() + plant::countStage(plant::P_GLOW, plant::S_MATURE)) * 0.4f; break;
    case C_SHROOM: s *= plant::matureMushrooms() > 0 ? 1.0f + plant::matureMushrooms() * 0.6f : 0.05f; break;
    case C_BIRD: s *= 0.4f + plant::treeMaturity() + e.insects * 0.5f; s *= 1.0f - season::weight(WINTER) * 0.5f; break;
    case C_FROG: s *= 0.5f + e.insects; break;
    case C_FIREFLY: s *= (0.4f + plant::matureMushrooms() * 0.3f + plant::countSpecies(plant::P_GLOW) * 0.3f) * (1.0f - season::weight(WINTER)); break;
    case C_CRITTER: s *= 1.0f - season::weight(WINTER) * 0.6f; break;
    case C_BEE: s *= 0.1f + plant::bloomingFlowers() * 0.6f; break;
    case C_MOLE: s *= (0.3f + under::moisture()) * (eco::world.frost > 0.3f ? 0.1f : 1.0f) * (1.0f - eco::world.drought * 0.7f); break;
    case C_SQUIRREL: s *= 0.2f + season::weight(AUTUMN) * 1.5f + eco::world.acornsGround * 0.15f; break;
    default: break;
  }
  // 食物不足 → 降低出現機率
  s *= 0.4f + 0.6f * foodLevel(sp);
  // 森林乾燥：蝸牛與青蛙活動減少
  if ((sp == C_SNAIL || sp == C_FROG) && (eco::world.drought > 0.3f || (e.soil < 0.2f && e.airHum < 45))) s *= 0.3f;
  if (eco::world.frost > 0.5f) s *= 0.5f;
  // 月相：新月時夜行生物活躍；下弦月時螢火蟲與小精靈增加
  if (e.night > 0.5f) {
    const eco::Moon mn = eco::moon();
    if (mn == eco::MOON_NEW && (sp == C_SHROOM || sp == C_FROG || sp == C_FIREFLY || sp == C_MOLE)) s *= 1.3f;
    if (mn == eco::MOON_LAST_Q && (sp == C_FIREFLY || sp == C_SPRITE)) s *= 1.4f;
  }
  // 枯木長出菇 → 蝸牛被吸引 (暴風後的恢復故事)
  if (sp == C_SNAIL && plant::log().state >= 3) s *= 1.8f;
  // 太久沒出現 → 提高權重 (避免某種生物長期消失)
  s *= 1.0f + fminf(hoursSinceSeen(sp), 8.0f) * 0.15f;
  return s;
}

int freeSlot() {
  for (int i = 0; i < CAP; i++) if (!cs[i].active) return i;
  return -1;
}

void setState(Creature& c, State st, uint32_t ms, float sMin, float sMax) {
  c.state = st;
  c.until = ms + (uint32_t)(rnd(sMin, sMax) * 1000);
}

// 走在地面上的生物 (不會飛、不是青蛙/巨龜這種會下水的)
bool groundWalker(const Creature& c) { return !c.flying && c.sp != C_FROG && c.sp != C_TURTLE; }
bool onTrunk(float x, float y) { return y < scene::groundY((int)x) + 8; }  // 高於地面 = 在樹幹上爬

bool moveTo(Creature& c, float speed, float dt) {
  // 除了進場/離場，目標都在畫面內
  if (c.state != ST_ENTER && c.state != ST_LEAVE) c.tx = util::clamp(c.tx, 6.0f, (float)cfg::W - 6);
  float tx = c.tx, ty = c.ty;
  if (groundWalker(c)) {
    if (scene::inPond(c.tx, c.ty, -3)) { scene::shorePoint(c.tx, c.ty, c.tx, c.ty, 4, true); tx = c.tx; ty = c.ty; }  // 不走進河裡
    // 進出樹洞：先走到樹幹底下再垂直爬，不在半空中斜著飄
    const bool high = onTrunk(c.x, c.y), targetHigh = onTrunk(tx, ty);
    if (targetHigh && fabsf(c.x - tx) > 2) { if (high) tx = c.x; ty = scene::walkY((int)tx); }
    else if (high && !targetHigh && fabsf(c.x - tx) > 2) { tx = c.x; ty = scene::walkY((int)c.x); }
  }
  float dx = tx - c.x, dy = ty - c.y;
  float d = sqrtf(dx * dx + dy * dy);
  if (d < 1.0f) { c.x = tx; c.y = ty; return tx == c.tx && ty == c.ty; }
  float step = fminf(speed * dt, d);
  const float nx = c.x + dx / d * step, ny = c.y + dy / d * step;
  if (groundWalker(c) && !scene::inPond(c.x, c.y, 1) && scene::inPond(nx, ny, 1)) {
    scene::shorePoint(nx, ny, c.x, c.y, 1.5f);  // 下一步會踩進河裡 → 沿著河岸滑過去
  } else { c.x = nx; c.y = ny; }
  if (fabsf(dx) > 0.5f) c.flip = dx < 0;
  return false;
}

void pickGroundTarget(Creature& c, int minX = scene::WALK_MIN_X, int maxX = scene::WALK_MAX_X) {
  // 地面行走避開池塘
  for (int k = 0; k < 6; k++) {
    float x = rnd(minX, maxX);
    if (evo::dangerous(x) && k < 5) continue;  // 記得的危險區 (災害發生過的地方) 盡量避開
    float y = scene::walkY((int)x) + rnd(-4, 10);
    if (!scene::inPond(x, y, -6)) { c.tx = x; c.ty = y; return; }
  }
  c.tx = rnd(20, 120); c.ty = scene::walkY((int)c.tx);
}

void exitPoint(Creature& c) {
  bool left = c.x < 120;
  c.tx = left ? -20 : cfg::W + 20;
  c.ty = c.flying ? rnd(20, 90) : scene::walkY(left ? 0 : cfg::W - 1);
  if (!c.flying && c.sp != C_TURTLE && util::rng.chance(0.3f)) { c.tx = scene::HOLLOW_X; c.ty = scene::HOLLOW_Y + 6; }  // 鑽進樹洞
}

// 青蛙的落腳點
bool frogSpot(int k, float& x, float& y) {
  switch (k) {
    case 0: x = 152; y = 228; return true;  // 左岸
    case 1: x = 216; y = 198; return true;  // 上岸
    case 2: x = 228; y = 231; return true;  // 下岸
    case 3: case 4: {
      int slot = k == 3 ? 12 : 13;
      if (plant::get(slot).species != plant::P_LILY) return false;
      x = plant::SLOTS[slot].x; y = plant::SLOTS[slot].y - 1; return true;
    }
    default: scene::waterPoint(util::rng.f(), x, y); return true;  // 水中 (游泳)
  }
}

void begin(Creature& c, Species sp, uint32_t ms, bool ev) {
  const Def& d = DEFS[sp];
  c = {};
  c.active = true;
  c.sp = sp;
  c.variant = (uint8_t)util::rng.irange(0, 3);
  c.trait = evo::rollTrait(sp);
  c.flying = sp == C_SPRITE || sp == C_BIRD || sp == C_BUTTERFLY || sp == C_FIREFLY || sp == C_VISITOR || sp == C_GLOWMOTH || sp == C_BEE;
  c.phase = rnd(0, 6.28f);
  c.flags = ev ? F_EVENT : 0;
  c.alpha = 255;
  c.leaveAt = ms + (uint32_t)(rnd(d.stayMin, d.stayMax) * 1000);
  c.slot = -1;
  bool fromLeft = util::rng.chance(0.5f);
  c.state = ST_ENTER;
  switch (sp) {
    case C_SHROOM: {
      int s = plant::randomSlotOf(plant::P_MUSHROOM, plant::S_MATURE);
      c.x = s >= 0 ? plant::SLOTS[s].x : rnd(20, 100);
      c.y = s >= 0 ? plant::SLOTS[s].y + 4 : scene::walkY((int)c.x);
      c.alpha = 0;  // 從蘑菇旁慢慢現身
      pickGroundTarget(c, (int)c.x - 30, (int)c.x + 30);
      break;
    }
    case C_FROG: {
      scene::waterPoint(util::rng.f(), c.x, c.y);
      c.state = ST_HOP;
      float x, y;
      int k = util::rng.irange(0, 4);
      if (!frogSpot(k, x, y)) frogSpot(0, x, y);
      c.sx = c.x; c.sy = c.y; c.tx = x; c.ty = y; c.hopT = 0;
      fx::ripple(c.x, c.y + 3, 7);
      break;
    }
    case C_SNAIL:
      c.x = util::rng.chance(0.5f) ? scene::ROCK1_X + rnd(-8, 8) : rnd(20, 130);
      c.y = scene::walkY((int)c.x) + rnd(4, 14);
      c.alpha = 0;
      pickGroundTarget(c, (int)c.x - 40, (int)c.x + 40);
      break;
    case C_FIREFLY:
      c.x = rnd(10, 230); c.y = rnd(150, 215);
      c.alpha = 0;
      c.tx = c.x; c.ty = c.y;
      c.state = ST_MOVE;
      break;
    case C_VISITOR:
      c.x = rnd(60, 180); c.y = rnd(110, 160);
      c.alpha = 0;
      c.tx = c.x; c.ty = c.y; c.state = ST_MOVE;
      break;
    case C_MOLE: {
      // 地鼠住在洞裡：找自己的洞，沒有就挖一個
      int bi = -1;
      for (int k = 0; k < under::CAP && bi < 0; k++) {
        const under::Burrow& b = under::at(k);
        if ((b.state == under::B_OCCUPIED || b.state == under::B_FRESH) && b.occupant == C_MOLE) bi = k;
      }
      if (bi < 0) bi = under::digNear(C_MOLE, ms);
      if (bi < 0) { float bx, by; bi = under::nearest(c.x, bx, by); }
      if (bi < 0) { c.x = rnd(40, 120); c.y = scene::walkY((int)c.x) + 6; c.variant = 255; break; }
      under::Burrow& b = under::at(bi);
      if (b.state == under::B_ABANDONED) { b.occupant = C_MOLE; b.generation++; under::setState(bi, under::B_OCCUPIED); }
      c.x = c.sx = b.x; c.y = c.sy = b.y; c.tx = c.x; c.ty = c.y;
      c.variant = (uint8_t)bi;
      c.flags |= F_FADE;  // 離開時回到洞裡
      c.alpha = 0; c.state = ST_IDLE; c.until = ms + 2500;
      break;
    }
    case C_SQUIRREL:
      c.x = scene::TRUNK_X + 16; c.y = scene::walkY((int)c.x) + 3;  // 從古樹上爬下來
      c.alpha = 0; c.state = ST_IDLE; c.until = ms + 1500;
      break;
    case C_DEER:
      c.x = cfg::W + 22; c.y = scene::walkY(220) - 2;
      c.tx = 214; c.ty = c.y;
      break;
    default:
      if (c.flying) {
        c.x = fromLeft ? -10 : cfg::W + 10;
        c.y = rnd(30, 120);
      } else {
        c.x = fromLeft ? -16 : cfg::W + 16;
        c.y = scene::walkY(fromLeft ? 0 : cfg::W - 1);
        // 小獸有時從樹洞出來
        if (sp == C_CRITTER && util::rng.chance(0.35f)) { c.x = scene::HOLLOW_X; c.y = scene::HOLLOW_Y + 6; c.alpha = 0; }
      }
      c.tx = rnd(30, 210);
      c.ty = c.flying ? rnd(50, 150) : scene::walkY((int)c.tx);
      if (!c.flying) pickGroundTarget(c);
      if (sp == C_BIRD) {  // 小鳥一進場就飛向樹枝
        int k = util::rng.irange(0, scene::PERCH_N - 1);
        c.tx = scene::PERCH[k].x; c.ty = scene::PERCH[k].y - 2; c.slot = k;
      }
      break;
  }
}

void leave(Creature& c, uint32_t ms) {
  if (c.state == ST_LEAVE) return;
  if ((c.flags & F_FADE) && c.sp != C_FROG) {  // 從洞口出來的生物：回到洞裡淡出
    c.state = ST_LEAVE; c.until = ms + 60000; c.tx = c.sx; c.ty = c.sy;
    return;
  }
  c.state = ST_LEAVE;
  c.until = ms + 60000;
  if (c.sp == C_FROG) scene::waterPoint(util::rng.f(), c.tx, c.ty);
  else if (c.sp == C_SHROOM || c.sp == C_SNAIL || c.sp == C_FIREFLY || c.sp == C_VISITOR || c.sp == C_GLOWMOTH) { c.tx = c.x; c.ty = c.y; }
  else if (c.sp == C_DEER) { c.tx = -24; c.ty = c.y; }
  else exitPoint(c);
}

// ---- 各物種行為 ----
// 個性影響行為：膽小躲人、好奇探索、貪吃找食物、慵懶多休息、勇敢靠近冒險家、合群找同伴
bool personality(Creature& c, uint32_t ms) {
  if (c.flags & (F_EVENT | F_CHASER)) return false;
  float vx, vy;
  const bool vis = visitor::position(vx, vy);
  switch (c.trait) {
    case evo::TR_SHY:
      if (vis && fabsf(vx - c.x) < 70) { c.tx = util::clamp(c.x + (c.x < vx ? -50.0f : 50.0f), 10.0f, 230.0f); c.ty = 228; c.slot = 111; c.state = ST_MOVE; return true; }
      break;
    case evo::TR_BRAVE:
      if (vis && util::rng.chance(0.4f)) { c.tx = vx + (c.x < vx ? -16 : 16); c.ty = vy + 2; c.state = ST_MOVE; return true; }
      break;
    case evo::TR_LAZY:
      if (util::rng.chance(0.3f)) { setState(c, c.sp == C_CRITTER ? ST_SLEEP : ST_IDLE, ms, 15, 40); return true; }
      break;
    case evo::TR_GREEDY: {
      const int16_t f = evo::mem(c.sp).foodX;
      if (f >= 0 && util::rng.chance(0.3f)) { c.tx = f; c.ty = scene::walkY(f) + 4; c.state = ST_MOVE; return true; }
      break;
    }
    case evo::TR_CURIOUS:
      if (util::rng.chance(0.2f)) {
        if (vis) { c.tx = vx + rnd(-24, 24); c.ty = vy + 4; }
        else { int r = ruins::excavated(); if (r < 0) break; int rx, ry; ruins::pos(r, rx, ry); c.tx = rx + 10; c.ty = ry + 2; }
        c.state = ST_MOVE; return true;
      }
      break;
    case evo::TR_SOCIAL:
      if (util::rng.chance(0.25f))
        for (auto& o : cs) if (&o != &c && o.active && !o.flying && o.state != ST_LEAVE) { c.tx = o.x + rnd(-14, 14); c.ty = o.y; c.state = ST_MOVE; return true; }
      break;
    default: break;
  }
  return false;
}

void think(Creature& c, uint32_t ms) {
  const eco::Env& e = eco::env;
  const Species sp = (Species)c.sp;
  if ((sp == C_CRITTER || sp == C_SQUIRREL || sp == C_SHROOM) && personality(c, ms)) return;
  switch (sp) {
    case C_SPRITE: {
      int s = plant::randomSlotOf(plant::P_FLOWER, plant::S_BLOOM);
      if (s < 0) s = plant::randomSlotOf(plant::P_GLOW, plant::S_MATURE);
      if (c.state == ST_ACT && s >= 0 && ((c.flags & F_LIT) || e.night > 0.6f || util::rng.chance(0.25f))) {
        c.flags &= ~F_LIT;
        setState(c, ST_SLEEP, ms, DEFS[sp].restMin, DEFS[sp].restMax);  // 停在花上睡覺
        c.y += 6;
        if (util::rng.chance(0.3f)) journal::add(journal::J_SLEEP, sp, false);
        return;
      }
      if (s >= 0 && util::rng.chance(0.75f)) {
        c.slot = s; c.tx = plant::SLOTS[s].x - 4 + rnd(-2, 2); c.ty = plant::SLOTS[s].y - 26;
      } else { c.slot = -1; c.tx = rnd(20, 220); c.ty = rnd(70, 170); }
      setState(c, ST_MOVE, ms, 2, 4);
      break;
    }
    case C_SHROOM:
      if (e.rain > 0.3f) { setState(c, ST_HIDE, ms, 20, 40); return; }
      if (util::rng.chance(0.25f)) setState(c, ST_ACT, ms, 2, 3);  // 伸懶腰
      else if (util::rng.chance(0.5f)) { pickGroundTarget(c, (int)c.x - 40, (int)c.x + 40); c.state = ST_MOVE; }
      else setState(c, ST_IDLE, ms, 6, 18);
      break;
    case C_CRITTER: {
      float r = util::rng.f();
      if (c.flags & F_CHASER) { pickGroundTarget(c); c.state = ST_MOVE; return; }
      if ((timem::phase() == PH_AFTERNOON || e.night > 0.5f) && r < 0.25f) {
        const int16_t home = evo::mem(C_CRITTER).homeX;  // 記得的巢穴
        c.tx = home >= 0 ? home : rnd(60, 90); c.ty = scene::walkY((int)c.tx) + 2; c.state = ST_MOVE; c.slot = 100;  // 回巢/樹根睡覺
      } else if (r < 0.45f) {
        bool l = util::rng.chance(0.5f);
        c.tx = l ? 176 : 226; c.ty = l ? 202 : 197; c.state = ST_MOVE; c.slot = 101;  // 去河邊喝水
      } else if (r < 0.7f) setState(c, ST_ACT, ms, 3, 6);  // 覓食
      else if (r < 0.85f) setState(c, ST_IDLE, ms, 4, 10);
      else { pickGroundTarget(c); c.state = ST_MOVE; c.slot = -1; }
      break;
    }
    case C_SNAIL:
      if (e.airHum < 40 || e.wind > 0.7f) { setState(c, ST_HIDE, ms, 30, 90); return; }
      if (util::rng.chance(0.3f)) setState(c, ST_IDLE, ms, 10, 30);
      else { pickGroundTarget(c, (int)c.x - 25, (int)c.x + 25); c.state = ST_MOVE; }
      break;
    case C_FROG: {
      // 附近有蟲 → 吐舌捕捉
      int bug = fx::nearest(fx::PT_INSECT, c.x + (c.flip ? -6 : 6), c.y - 4, 28);
      if (bug >= 0 && c.state != ST_HOP) {
        fx::P& p = fx::at(bug);
        c.flip = p.x < c.x;
        c.tx = p.x; c.ty = p.y;
        fx::kill(bug);
        setState(c, ST_ACT, ms, 0.4f, 0.5f);
        if (util::rng.chance(0.2f)) journal::add(journal::J_FROG_CATCH, 0xFF, false);
        return;
      }
      if (util::rng.chance(0.45f)) {
        float x, y;
        int k = util::rng.irange(0, 5);
        if (!frogSpot(k, x, y)) frogSpot(util::rng.irange(0, 2), x, y);
        c.sx = c.x; c.sy = c.y; c.tx = x; c.ty = y; c.hopT = 0; c.state = ST_HOP;
        c.flip = x < c.x;
      } else setState(c, ST_IDLE, ms, 4, 14);
      break;
    }
    case C_BIRD: {
      const bool landed = c.flags & F_LIT;  // 小鳥的 F_LIT = 已經落在樹枝/巢/地面
      c.flags &= ~F_LIT;
      float r = util::rng.f();
      bool nestWork = nest < 1.0f && plant::treeMaturity() > 0.55f &&
                      (season::weight(SPRING) + season::weight(SUMMER)) > 0.5f;
      if (e.night > 0.5f && nest >= 1.0f) { c.tx = scene::NEST.x; c.ty = scene::NEST.y - 2; c.slot = 50; c.state = ST_MOVE; return; }
      if (nestWork && r < 0.3f && !(c.flags & F_TWIG)) {
        c.tx = rnd(95, 135); c.ty = scene::walkY((int)c.tx); c.slot = 51; c.state = ST_MOVE;  // 去撿樹枝
      } else if (r < 0.55f) {
        int k = util::rng.irange(0, scene::PERCH_N - 1);
        c.tx = scene::PERCH[k].x; c.ty = scene::PERCH[k].y - 2; c.slot = k; c.state = ST_MOVE;
      } else if (r < 0.8f) {
        pickGroundTarget(c, 90, 230); c.slot = 52; c.state = ST_MOVE;  // 地面覓食
      } else if (landed) { c.flags |= F_LIT; setState(c, ST_IDLE, ms, 3, 9); }
      else { int k = util::rng.irange(0, scene::PERCH_N - 1); c.tx = scene::PERCH[k].x; c.ty = scene::PERCH[k].y - 2; c.slot = k; c.state = ST_MOVE; }
      break;
    }
    case C_BUTTERFLY: case C_GLOWMOTH: {
      int s = plant::randomSlotOf(plant::P_FLOWER, plant::S_BLOOM);
      if (s < 0 && util::rng.chance(0.4f)) s = plant::randomSlotOf(plant::P_MUSHROOM, plant::S_MATURE);
      if (s >= 0 && util::rng.chance(0.6f)) { c.slot = s; c.tx = plant::SLOTS[s].x - 2; c.ty = plant::SLOTS[s].y - 16; }
      else { c.slot = -1; c.tx = rnd(10, 230); c.ty = rnd(60, 190); }
      c.state = ST_MOVE;
      break;
    }
    case C_MOLE: {
      const float hx = c.sx, hy = c.sy;
      float r = util::rng.f();
      if (r < 0.35f) {  // 挖土
        setState(c, ST_ACT, ms, 3, 6);
        if (c.variant < under::CAP) under::at(c.variant).dirt = fminf(1, under::at(c.variant).dirt + 0.3f);
        if (util::rng.chance(0.3f)) c.flags |= F_TWIG;  // 挖到食物
      } else if ((c.flags & F_TWIG) && r < 0.6f) {
        c.tx = hx; c.ty = hy; c.slot = 122; c.state = ST_MOVE;  // 把食物搬回洞裡
      } else if (r < 0.75f) {
        c.tx = util::clamp(hx + rnd(-26, 26), 8.0f, 232.0f); c.ty = hy + rnd(-2, 6);
        if (scene::inPond(c.tx, c.ty, -6)) c.tx = hx;
        c.state = ST_MOVE;
      } else setState(c, ST_IDLE, ms, 2, 6);
      break;
    }
    case C_BEE: {
      int s = plant::randomSlotOf(plant::P_FLOWER, plant::S_BLOOM);
      if (s < 0) s = plant::randomSlotOf(plant::P_GLOW, plant::S_BLOOM);
      if (s < 0) { leave(c, ms); return; }
      c.slot = s; c.tx = plant::SLOTS[s].x + rnd(-4, 4); c.ty = plant::SLOTS[s].y - 14 + rnd(-3, 3); c.state = ST_MOVE;
      break;
    }
    case C_SQUIRREL:
      if (c.flags & F_TWIG) { c.tx = scene::TRUNK_X - 18; c.ty = scene::walkY(scene::TRUNK_X - 18) + 4; c.slot = 121; c.state = ST_MOVE; }
      else if (eco::world.acornsGround >= 1 && util::rng.chance(0.7f)) { c.tx = rnd(14, 110); c.ty = scene::walkY((int)c.tx) + rnd(2, 8); c.slot = 120; c.state = ST_MOVE; }
      else if (util::rng.chance(0.5f)) { pickGroundTarget(c, 10, 140); c.state = ST_MOVE; }
      else setState(c, ST_IDLE, ms, 3, 8);
      break;
    case C_FIREFLY: case C_VISITOR:
      c.tx = util::clamp(c.x + rnd(-30, 30), 5.0f, 235.0f);
      c.ty = util::clamp(c.y + rnd(-20, 20), sp == C_VISITOR ? 90.0f : 120.0f, 220.0f);
      c.state = ST_MOVE;
      break;
    case C_DEER:
      setState(c, ST_ACT, ms, 6, 9);  // 喝水/環顧
      break;
    default: break;
  }
}

void arrive(Creature& c, uint32_t ms) {
  const Species sp = (Species)c.sp;
  if (c.slot == 110) {  // 前往指定地點 (訪客互動)：小獸睡覺，其他停留
    c.slot = -1;
    if (sp == C_BIRD) c.flags |= F_LIT;  // 停在背包/巢上
    if (sp == C_CRITTER) setState(c, ST_SLEEP, ms, 30, 60);
    else if (sp == C_SPRITE || sp == C_BUTTERFLY) setState(c, ST_ACT, ms, 15, 30);
    else setState(c, ST_IDLE, ms, 15, 30);
    return;
  }
  if (c.slot == 120) {  // 松鼠撿起橡果
    c.slot = -1;
    if (eco::world.acornsGround >= 1) { eco::world.acornsGround -= 1; c.flags |= F_TWIG; }
    setState(c, ST_ACT, ms, 1.5f, 2.5f);
    return;
  }
  if (c.slot == 121) {  // 松鼠把橡果藏進樹根
    c.slot = -1; c.flags &= ~F_TWIG;
    eco::world.acornCache = fminf(12, eco::world.acornCache + 1);
    setState(c, ST_ACT, ms, 2, 3);
    return;
  }
  if (c.slot == 122) { c.slot = -1; c.flags &= ~F_TWIG; leave(c, ms); return; }  // 地鼠帶食物回洞
  if (c.slot == 111) {  // 逃到草叢 → 躲起來
    c.slot = -1;
    c.flags |= F_GRASS;
    setState(c, ST_HIDE, ms, 40, 80);
    return;
  }
  switch (sp) {
    case C_SPRITE:
      if (c.slot >= 0) { setState(c, ST_ACT, ms, 4, 8); return; }
      break;
    case C_CRITTER:
      if (c.slot == 100) { setState(c, ST_SLEEP, ms, DEFS[sp].restMin, DEFS[sp].restMax); c.slot = -1; return; }
      if (c.slot == 101) { setState(c, ST_ACT, ms, 4, 7); c.slot = -1; c.flip = c.x > 180;
        static uint32_t lastDrinkLog = 0;  // 喝水很頻繁：30 分鐘只記一次，避免洗掉日誌裡的重要歷史
        const uint32_t now = timem::now();
        if (lastDrinkLog == 0 || now - lastDrinkLog >= 1800) { lastDrinkLog = now; journal::add(journal::J_DRINK, 0xFF, false); }
        return; }
      break;
    case C_BIRD:
      c.flags |= F_LIT;  // 抵達 = 落在某個表面上
      if (c.slot == 50) { setState(c, ST_SLEEP, ms, 600, 1200); return; }
      if (c.slot == 51) { c.flags |= F_TWIG; c.tx = scene::NEST.x; c.ty = scene::NEST.y - 2; c.slot = 53; c.state = ST_MOVE; return; }
      if (c.slot == 53) {
        c.flags &= ~F_TWIG;
        float before = nest;
        nest = fminf(1.0f, nest + 0.1f);
        if (before < 1.0f && nest >= 1.0f) journal::add(journal::J_NEST);
        setState(c, ST_IDLE, ms, 3, 6);
        return;
      }
      if (c.slot == 52) { setState(c, ST_ACT, ms, 3, 6); return; }  // 啄食
      if (c.slot >= 0 && c.slot < scene::PERCH_N) { setState(c, ST_IDLE, ms, 4, 12); return; }
      c.flags &= ~F_LIT;  // 目標不是樹枝 → 繼續飛去找樹枝
      think(c, ms);
      return;
    case C_BEE:
      if (c.slot >= 0) { setState(c, ST_ACT, ms, 3, 6); return; }
      break;
    case C_BUTTERFLY: case C_GLOWMOTH:
      if (c.slot >= 0) { setState(c, ST_ACT, ms, 4, 10); return; }
      break;
    case C_DEER:
      if (c.state == ST_ENTER) { think(c, ms); return; }
      break;
    default: break;
  }
  if (sp == C_FIREFLY || sp == C_VISITOR) { think(c, ms); return; }
  setState(c, ST_IDLE, ms, 2, 8);
}

void updateOne(Creature& c, float dt, uint32_t ms) {
  if (c.flags & F_TRAPPED) { c.phase += dt * 6; c.alpha = 255; return; }  // 被陷阱困住：原地掙扎，等同伴救援
  if (c.sp == C_TURTLE && c.state != ST_LEAVE && (c.state == ST_IDLE || c.state == ST_ACT) && util::reached(ms, c.until)) {
    c.tx = c.x < 120 ? 200 : 40; c.ty = scene::walkY((int)c.tx) + 6; c.state = ST_MOVE;  // 巨龜慢慢走過整片森林
  }
  const Def& d = DEFS[c.sp];
  const eco::Env& e = eco::env;
  c.phase += dt * (c.state == ST_MOVE || c.state == ST_ENTER || c.state == ST_LEAVE || c.flying ? 8.0f : 2.0f);

  // 淡入
  if ((c.flags & F_GRASS) && c.state == ST_HIDE) c.alpha = (uint8_t)fmaxf(70, c.alpha - dt * 200);  // 躲在草叢裡只露一點
  else if (c.state != ST_LEAVE && c.alpha < 255) c.alpha = (uint8_t)fminf(255, c.alpha + dt * 200);

  // 拜訪時間到 / 環境不適合 → 離開
  if (c.state != ST_LEAVE && !(c.flags & F_EVENT) && util::reached(ms, c.leaveAt)) leave(c, ms);
  if (c.state != ST_LEAVE && (c.flags & F_EVENT) && util::reached(ms, c.leaveAt)) leave(c, ms);

  float speed = d.speed * (e.cold ? 0.7f : 1.0f);
  switch (c.state) {
    case ST_ENTER:
    case ST_MOVE: {
      if (c.sp == C_FIREFLY) speed *= 0.6f + 0.4f * sinf(c.phase * 0.3f);
      if (c.sp == C_SNAIL && e.rain > 0.2f) speed *= 1.4f;  // 下雨時蝸牛比較有精神
      bool done = moveTo(c, speed, dt);
      if (done) arrive(c, ms);
      break;
    }
    case ST_HOP: {
      c.hopT += dt / 0.55f;
      float t = fminf(c.hopT, 1.0f);
      c.x = util::lerp(c.sx, c.tx, t);
      c.y = util::lerp(c.sy, c.ty, t) - sinf(t * 3.1416f) * 12;
      if (c.hopT >= 1) {
        c.x = c.tx; c.y = c.ty;
        if (scene::inPond(c.x, c.y)) fx::ripple(c.x + 4, c.y + 4, 6);
        setState(c, ST_IDLE, ms, 3, 10);
      }
      break;
    }
    case ST_IDLE: case ST_ACT: case ST_SLEEP: case ST_HIDE:
      // 青蛙在水裡游動時慢慢漂
      if (c.sp == C_FROG && scene::inPond(c.x, c.y) && c.state == ST_IDLE && util::rng.chance(dt * 0.3f)) fx::ripple(c.x + 4, c.y + 5, 5);
      if (c.sp == C_SPRITE && c.state == ST_ACT && util::rng.chance(dt * 3)) fx::spawn(fx::PT_SPARKLE, c.x + rnd(0, 9), c.y + rnd(0, 8), 0, rnd(4, 10), 900, 0xFFF0A0);
      if (c.state == ST_SLEEP && util::rng.chance(dt * 0.25f)) fx::spawn(fx::PT_ZZZ, c.x + 8, c.y - 4, 2, -5, 2500, 0);
      if (c.sp == C_CRITTER && c.state == ST_ACT && util::rng.chance(dt * 0.4f)) {
        int ac = fx::nearest(fx::PT_ACORN, c.x, c.y, 20);  // 吃掉附近的橡果
        if (ac >= 0) fx::kill(ac);
      }
      if (c.sp == C_MOLE && c.state == ST_ACT && util::rng.chance(dt * 4)) fx::spawn(fx::PT_PETAL, c.x + rnd(-3, 3), c.y - 2, rnd(-12, 12), -14, 600, 0x7A5A3C);
      if (c.sp == C_BEE && c.state == ST_ACT) { c.x += sinf(c.phase * 3) * dt * 12; c.y += cosf(c.phase * 2.3f) * dt * 8; }  // 繞著花飛
      if (c.sp == C_DEER && c.state == ST_ACT && util::rng.chance(dt * 2)) fx::spawn(fx::PT_GLOWDOT, c.x + rnd(0, 20), c.y + rnd(0, 18), 0, -6, 1500, 0xB4FFE6);
      // 躲雨結束
      if (c.state == ST_HIDE && e.rain < 0.2f && e.storm < 0.3f && util::reached(ms, c.until)) { c.flags &= ~F_GRASS; think(c, ms); }
      else if (c.state != ST_HIDE && util::reached(ms, c.until)) think(c, ms);
      break;
    case ST_LEAVE: {
      bool fade = c.sp == C_SHROOM || c.sp == C_SNAIL || c.sp == C_FIREFLY || c.sp == C_VISITOR || c.sp == C_GLOWMOTH ||
                  (c.tx == scene::HOLLOW_X && !c.flying) || (c.flags & F_FADE);
      bool done = c.sp == C_FROG ? false : moveTo(c, speed * 1.2f, dt);
      if (c.sp == C_FROG) {
        c.alpha = (uint8_t)fmaxf(0, c.alpha - dt * 255);
        if (c.alpha == 0) { fx::ripple(c.x + 4, c.y + 4, 8); c.active = false; }
        break;
      }
      if (fade && (done || (c.sp != C_DEER && !(c.flags & F_FADE)))) {
        // F_FADE：走到目的地 (洞口/樹洞) 才淡出
        if (done || (!(c.flags & F_FADE) && (c.sp == C_SHROOM || c.sp == C_SNAIL || c.sp == C_FIREFLY || c.sp == C_VISITOR || c.sp == C_GLOWMOTH))) {
          c.alpha = (uint8_t)fmaxf(0, c.alpha - dt * 160);
          if (c.alpha == 0) c.active = false;
        }
      } else if (done || util::reached(ms, c.until)) {
        c.active = false;
      }
      break;
    }
  }
  if (c.active) seen[c.sp] = timem::now();
}

bool phaseLeaving(Species sp) {
  // 活動時段外，自然生物逐漸離開
  return !(timem::phaseMask() & DEFS[sp].phases);
}
}  // namespace

void begin() {
  for (auto& c : cs) c.active = false;
  uint32_t now = timem::now();
  for (int i = 0; i < C_COUNT; i++) { seen[i] = now; away[i] = 0; }
}

// 常駐 (非事件) 的生物數；fireflies = true 時只算螢火蟲
int ambientCount(bool fireflies = false) {
  int n = 0;
  for (auto& c : cs)
    if (c.active && !(c.flags & F_EVENT) && c.state != ST_LEAVE && (c.sp == C_FIREFLY) == fireflies) n++;
  return n;
}

int spawn(Species sp, uint32_t ms, bool ev) {
  if (sp != C_FIREFLY && !ev && activeCount() >= MAX_ACTIVE) return -1;
  if (!ev && ambientCount(sp == C_FIREFLY) >= (sp == C_FIREFLY ? cfg::AMBIENT_FIREFLY_MAX : cfg::AMBIENT_MAX)) return -1;
  if (sp >= C_DEER && count(sp) >= DEFS[sp].maxN) return -1;  // 白鹿/未知生物/發光蝴蝶群有數量上限
  int i = freeSlot();
  if (i < 0) return -1;
  begin(cs[i], sp, ms, ev);
  seen[sp] = timem::now();
  return i;
}

int count(Species sp) {
  int n = 0;
  for (auto& c : cs) if (c.active && c.sp == sp && c.state != ST_LEAVE) n++;
  return n;
}

int activeCount() {
  int n = 0;
  for (auto& c : cs) if (c.active && c.sp != C_FIREFLY) n++;
  return n;
}

Creature& at(int i) { return cs[i]; }

// 休息中的地面生物：停在水裡的推回岸上；兩隻擠在一起的往兩側慢慢分開
void keepApart(float dt) {
  auto resting = [](const Creature& c) {
    return c.active && groundWalker(c) && !(c.flags & F_TRAPPED) && c.sp != C_MOLE &&
           (c.state == ST_IDLE || c.state == ST_ACT || c.state == ST_SLEEP || c.state == ST_HIDE);
  };
  const float step = 10.0f * dt;
  for (int i = 0; i < CAP; i++) {
    Creature& a = cs[i];
    if (!resting(a)) continue;
    if (scene::inPond(a.x, a.y, 1)) {
      float sx, sy;
      scene::shorePoint(a.x, a.y, sx, sy);
      a.x = util::approach(a.x, sx, step * 2); a.y = util::approach(a.y, sy, step * 2);
    }
    for (int j = i + 1; j < CAP; j++) {
      Creature& b = cs[j];
      if (!resting(b) || fabsf(a.x - b.x) >= 8 || fabsf(a.y - b.y) >= 5) continue;
      const float dir = a.x < b.x || (a.x == b.x && i < j) ? -1.0f : 1.0f;
      const float ax = a.x + dir * step, bx = b.x - dir * step;
      if (ax > 6 && ax < cfg::W - 6 && !scene::inPond(ax, a.y, 1) && !onTrunk(ax, a.y)) a.x = ax;
      if (bx > 6 && bx < cfg::W - 6 && !scene::inPond(bx, b.y, 1) && !onTrunk(bx, b.y)) b.x = bx;
    }
  }
}

void update(float dt, uint32_t ms) {
  for (auto& c : cs) if (c.active) updateOne(c, dt, ms);
  keepApart(dt);
  // 追逐：追的那隻一直往被追的位置跑
  for (auto& c : cs) {
    if (!c.active || !(c.flags & F_CHASER) || c.state == ST_LEAVE) continue;
    for (auto& o : cs) {
      if (&o == &c || !o.active || (o.sp != C_CRITTER && o.sp != C_SQUIRREL) || (o.flags & F_CHASER)) continue;
      c.tx = o.x - (o.flip ? -10 : 10); c.ty = o.y; c.state = ST_MOVE;
      break;
    }
  }
}

void populationTick(uint32_t ms) {
  const uint32_t now = timem::now();
  const eco::Env& e = eco::env;
  // 1) 不適合的生物離開，或躲雨
  for (auto& c : cs) {
    if (!c.active || (c.flags & F_EVENT) || c.state == ST_LEAVE) continue;
    Species sp = (Species)c.sp;
    // 暴雨或乾旱：小動物躲進地下洞穴
    if ((e.storm > 0.6f && (sp == C_CRITTER || sp == C_SNAIL || sp == C_SQUIRREL)) || (sp == C_SNAIL && eco::world.drought > 0.3f)) {
      float bx, by;
      if (under::nearest(c.x, bx, by) >= 0) { c.state = ST_LEAVE; c.tx = bx; c.ty = by; c.flags |= F_FADE; c.until = ms + 30000; continue; }
    }
    if (e.storm > 0.6f && (sp == C_BIRD || sp == C_BUTTERFLY || sp == C_CRITTER || sp == C_SPRITE || sp == C_BEE || sp == C_SQUIRREL)) { leave(c, ms); continue; }
    if (e.rain > 0.35f && sp == C_SHROOM && c.state != ST_HIDE) { setState(c, ST_HIDE, ms, 20, 40); continue; }
    if (phaseLeaving(sp) && !(sp == C_BIRD && c.state == ST_SLEEP) && util::rng.chance(0.08f)) leave(c, ms);
  }
  // 常駐生物超過上限 (例如事件結束、舊版本留下的) → 每次讓一隻停留最久的自然離開
  for (int ff = 0; ff < 2; ff++) {
    if (ambientCount(ff) <= (ff ? cfg::AMBIENT_FIREFLY_MAX : cfg::AMBIENT_MAX)) continue;
    Creature* oldest = nullptr;
    for (auto& c : cs)
      if (c.active && !(c.flags & F_EVENT) && c.state != ST_LEAVE && (c.sp == C_FIREFLY) == (ff == 1) && (!oldest || c.leaveAt < oldest->leaveAt)) oldest = &c;
    if (oldest) leave(*oldest, ms);
  }
  // 2) 遷徙 (每森林時間一小時檢查一次)
  if (now - lastMigrateCheck >= 3600) {
    lastMigrateCheck = now;
    for (int s = 0; s < C_COUNT; s++) {
      if (!ambient(s) || !DEFS[s].migrates || away[s]) continue;
      // 食物不足時更容易遷徙
      float p = 0.03f + (s == C_BIRD ? season::weight(AUTUMN) * 0.08f : 0) + (e.wind > 0.7f ? 0.03f : 0) + (1.0f - foodLevel(s)) * 0.05f;
      if (util::rng.chance(p)) {
        away[s] = now + util::shortS(util::rng.irange(2, 10) * 3600.0f);  // 遷徙離開壓縮到 0.5~3 小時
        for (auto& c : cs) if (c.active && c.sp == s && !(c.flags & F_EVENT)) leave(c, ms);
        journal::add(journal::J_MIGRATE, s, false);
        history::note(history::H_MIGRATE, 120, (uint8_t)s);
      }
    }
  }
  // 3) 遷徙回來 (可能帶朋友)
  for (int s = 0; s < C_COUNT; s++) {
    if (!away[s] || !util::reached(now, away[s])) continue;
    away[s] = 0;
    if (util::rng.chance(0.35f)) {
      static const Species FRIENDS[] = {C_BUTTERFLY, C_BIRD, C_CRITTER, C_SPRITE};
      Species f = FRIENDS[util::rng.irange(0, 3)];
      if (f == s) f = C_SNAIL;
      journal::add(journal::J_RETURN_FRIEND, s);
      spawn((Species)s, ms);
      pendingFriend = f;
    } else {
      journal::add(journal::J_RETURN, s, false);
      spawn((Species)s, ms);
    }
  }
  if (pendingFriend != C_COUNT && spawn(pendingFriend, ms) >= 0) pendingFriend = C_COUNT;

  // 4) 自然出現：每次最多出現一隻，避免同時湧入
  int order[C_COUNT];
  for (int i = 0; i < C_COUNT; i++) order[i] = i;
  for (int i = C_COUNT - 1; i > 0; i--) { int j = util::rng.irange(0, i); int t = order[i]; order[i] = order[j]; order[j] = t; }
  for (int k = 0; k < C_COUNT; k++) {
    Species sp = (Species)order[k];
    if (!ambient(sp) || away[sp] || count(sp) >= DEFS[sp].maxN) continue;
    float s = suitability(sp);
    if (sp == C_FIREFLY) {
      if (e.night < 0.6f || s < 0.3f) continue;
      int target = (int)util::clamp(s * 6.0f, 0.0f, (float)DEFS[sp].maxN);
      if (count(sp) < target && util::rng.chance(0.6f)) spawn(sp, ms);
      continue;
    }
    if (util::rng.chance(DEFS[sp].spawn * s * 0.35f)) {
      bool first = count(sp) == 0;
      if (spawn(sp, ms) >= 0) {
        if (first && hoursSinceSeen(sp) > 2) journal::add(journal::J_ARRIVE, sp, false);
        break;
      }
    }
  }
  // 5) 昆蟲粒子數量跟著環境
  int want = (int)(e.insects * 8);
  if (fx::count(fx::PT_INSECT) < want && e.night < 0.8f)
    fx::spawn(fx::PT_INSECT, rnd(100, 230), rnd(160, 200), 0, 0, (uint16_t)util::rng.irange(20000, 50000), 0);
}

void wakeAll(uint32_t ms) {
  bool any = false;
  for (auto& c : cs) {
    if (!c.active) continue;
    if (c.state == ST_SLEEP || c.state == ST_HIDE) { any = true; think(c, ms); if (c.state == ST_SLEEP || c.state == ST_HIDE) setState(c, ST_IDLE, ms, 1, 3); }
  }
  if (any) journal::add(journal::J_WAKE_UP, 0xFF, false);
}

void scare(uint32_t ms) {
  for (auto& c : cs) {
    if (!c.active || (c.flags & F_EVENT)) continue;
    if (c.sp == C_SNAIL || c.sp == C_SHROOM) setState(c, ST_HIDE, ms, 8, 20);
    else if (c.sp == C_BIRD && c.state != ST_MOVE) { int k = util::rng.irange(0, scene::PERCH_N - 1); c.tx = scene::PERCH[k].x; c.ty = scene::PERCH[k].y - 2; c.slot = k; c.state = ST_MOVE; }
  }
}

void startChase(uint32_t ms) {
  int a = -1;
  for (int i = 0; i < CAP; i++) if (cs[i].active && cs[i].sp == C_CRITTER && cs[i].state != ST_LEAVE) { a = i; break; }
  if (a < 0) a = spawn(C_CRITTER, ms, true);
  int b = spawn(C_CRITTER, ms, true);
  if (a < 0 || b < 0) return;
  cs[b].flags |= F_CHASER;
  cs[b].variant = (cs[a].variant + 1) % 4;
  cs[a].state = ST_MOVE;
  pickGroundTarget(cs[a]);
  cs[a].leaveAt = cs[b].leaveAt = ms + 25000;
}

void gatherFireflies(float x, float y, uint32_t ms, int n) {
  for (int k = 0; k < n; k++) {
    int i = spawn(C_FIREFLY, ms, true);
    if (i < 0) break;
    cs[i].leaveAt = ms + 60000;
  }
  for (auto& c : cs) {
    if (!c.active || c.sp != C_FIREFLY) continue;
    c.x = c.x * 0.5f + x * 0.5f;
    c.tx = x + rnd(-14, 14); c.ty = y + rnd(-10, 6); c.state = ST_MOVE;
  }
}

int hideFrom(float x, float radius, uint32_t ms) {
  int n = 0;
  for (auto& c : cs) {
    if (!c.active || c.state == ST_LEAVE || c.state == ST_HIDE) continue;
    if (c.sp != C_CRITTER && c.sp != C_SNAIL && c.sp != C_FROG) continue;
    if (fabsf(c.x - x) > radius) continue;
    n++;
    if (c.sp == C_SNAIL) { setState(c, ST_HIDE, ms, 30, 60); continue; }       // 縮進殼裡
    if (c.sp == C_FROG) { leave(c, ms); continue; }                            // 潛進池塘
    // 往遠離獵人的方向跑進前景草叢
    c.tx = util::clamp(c.x + (c.x < x ? -50.0f : 50.0f), 10.0f, 230.0f);
    c.ty = 228 + rnd(0, 6);
    if (scene::inPond(c.tx, c.ty, -6)) c.tx = c.x < x ? 20 : 120;
    c.slot = 111;
    c.state = ST_MOVE;
    c.leaveAt = ms + 150000;
  }
  return n;
}

int visitPoint(Species sp, float x, float y, uint32_t ms, uint32_t stayMs) {
  int i = -1;
  for (int k = 0; k < CAP; k++) if (cs[k].active && cs[k].sp == sp && cs[k].state != ST_LEAVE && cs[k].state != ST_SLEEP) { i = k; break; }
  if (i < 0) i = spawn(sp, ms, true);
  if (i < 0) return -1;
  Creature& c = cs[i];
  c.tx = x; c.ty = y; c.slot = 110; c.state = ST_MOVE;
  c.flags |= F_EVENT;
  c.leaveAt = ms + stayMs;
  return i;
}

bool find(Species sp, float& x, float& y) {
  for (auto& c : cs) if (c.active && c.sp == sp && c.state != ST_LEAVE) { x = c.x; y = c.y; return true; }
  return false;
}

bool captureOne(Species sp) {
  for (auto& c : cs) {
    if (!c.active || c.sp != sp || c.state == ST_LEAVE) continue;
    c.state = ST_LEAVE; c.flags |= F_FADE; c.tx = c.x; c.ty = c.y; c.until = millis() + 10000;
    return true;
  }
  return false;
}

bool hideInHollow(Species sp, uint32_t ms) {
  for (auto& c : cs) {
    if (!c.active || c.sp != sp || c.state == ST_LEAVE) continue;
    c.state = ST_LEAVE; c.flags |= F_FADE; c.tx = scene::HOLLOW_X - 4; c.ty = scene::HOLLOW_Y - 2; c.until = ms + 20000;
    return true;
  }
  return false;
}

bool ambient(uint8_t sp) { return sp < C_COUNT && DEFS[sp].spawn > 0; }
float foodFor(uint8_t sp) { return foodLevel(sp); }

int emergeAt(Species sp, float x, float y, uint32_t ms, uint32_t stayMs) {
  int i = spawn(sp, ms, true);
  if (i < 0) return -1;
  Creature& c = cs[i];
  c.x = c.sx = c.tx = x; c.y = c.sy = c.ty = y;
  c.alpha = 0; c.state = ST_IDLE; c.until = ms + stayMs / 2; c.leaveAt = ms + stayMs;
  c.flags |= F_FADE;
  return i;
}

void foodFight(uint32_t ms) {
  int a = -1;
  for (int k = 0; k < CAP; k++) if (cs[k].active && cs[k].sp == C_SQUIRREL && cs[k].state != ST_LEAVE) { a = k; break; }
  if (a < 0) a = spawn(C_SQUIRREL, ms, true);
  int b = spawn(C_CRITTER, ms, true);
  if (a < 0 || b < 0) return;
  cs[b].flags |= F_CHASER;
  cs[a].leaveAt = cs[b].leaveAt = ms + 25000;
  if (cs[a].flags & F_TWIG) { cs[a].flags &= ~F_TWIG; eco::world.acornsGround += 1; }  // 搶的時候掉了橡果
}

const char* speciesName(uint8_t sp) { return sp < C_COUNT ? DEFS[sp].name : ""; }
float nestProgress() { return nest; }
void setNestProgress(float v) { nest = util::clamp01(v); }
uint32_t lastSeen(uint8_t sp) { return seen[sp]; }
void setLastSeen(uint8_t sp, uint32_t e) { seen[sp] = e; }
uint32_t awayUntil(uint8_t sp) { return away[sp]; }
void setAwayUntil(uint8_t sp, uint32_t e) { away[sp] = e; }
float hoursSinceSeen(uint8_t sp) {
  uint32_t now = timem::now();
  return now > seen[sp] ? (now - seen[sp]) / 3600.0f : 0;
}

// ---- 繪圖 ----
namespace {
void drawBody(const Creature& c, int x, int y, int px);

// 頭上的狀態小圖示 (畫布像素，不縮放)：讓小螢幕上看得出生物在做什麼。px = 精靈圖一格的螢幕像素數
void drawEmote(const Creature& c, int x, int y, int px) {
  if (!cfg::CREATURE_EMOTES || c.alpha < 120) return;
  int h;
  switch (c.sp) {
    case C_CRITTER: h = 9; break;
    case C_SHROOM: h = 10; x += 4; break;  // 蘑菇生物的圖以左上角定位
    case C_SNAIL: h = 6; break;
    case C_FROG: h = 7; break;
    case C_MOLE: h = 6; break;
    case C_SQUIRREL: h = 8; break;
    default: return;
  }
  const int top = y - (h * px + 1) / 2 - 3;
  // 不畫驚嘆號 (使用者要求：生物頭上不要有驚嘆號)；受困/躲藏改由身上繩子等其他表現呈現
  if (c.state == ST_SLEEP && !(c.flags & F_TRAPPED)) {  // 慢慢往上飄的 z
    const int rise = ((int)c.phase) % 5;
    const uint16_t k = gfx::rgb(0xE6F0FF);
    const int zx = x + 3, zy = top - rise;
    const uint8_t a = (uint8_t)(230 - rise * 35);
    for (int i = 0; i < 3; i++) { gfx::pblend(zx + i, zy - 2, k, a); gfx::pblend(zx + i, zy, k, a); }
    gfx::pblend(zx + 1, zy - 1, k, a);
  }
}

void drawOne(const Creature& c) {
  // 位置換算成畫布座標；小型生物的精靈圖以 CREATURE_PX 顆螢幕像素為一格 (腳底為錨點)，白鹿/巨龜維持畫布大小
  const int x = (int)c.x >> 1, y = (int)c.y >> 1;
  const bool big = c.sp == C_DEER || c.sp == C_TURTLE;
  const int px = big ? 2 : cfg::CREATURE_PX;
  gfx::spritePx = big ? 0 : px;
  if (big) {  // 白鹿、巨龜以畫布像素畫：走物件圖層，同樣得到邊緣平滑與描邊
    gfx::Layer layer;
    drawBody(c, x, y, px);
  } else drawBody(c, x, y, px);
  gfx::spritePx = 0;
  drawEmote(c, x, y, px);
}

// x, y = 畫布座標的腳底；px = 精靈圖一格的螢幕像素數。隨身物品用細緻模式畫 (原生座標 = 畫布座標 x2)
void drawBody(const Creature& c, int x, int y, int px) {
  const int X = x * 2, Y = y * 2;
  auto item = [&](int i, int j, uint32_t col) {  // 以精靈圖的格子為單位，相對於腳底
    gfx::Fine f;
    const uint16_t k = gfx::lit(col);
    gfx::fillRect(X + i * px - 1, Y + j * px - 1, px + 2, px + 2, gfx::rgb(0x140E12));
    gfx::fillRect(X + i * px, Y + j * px, px, px, k);
  };
  auto stick = [&](int x0, int y0, int x1, int y1, uint32_t col) {  // 原生座標，2 像素粗
    gfx::Fine f;
    const uint16_t k = gfx::lit(col);
    gfx::line(x0, y0, x1, y1, k); gfx::line(x0, y0 + 1, x1, y1 + 1, k);
  };
  const eco::Env& e = eco::env;
  const bool moving = c.state == ST_MOVE || c.state == ST_ENTER || c.state == ST_LEAVE;
  const int step = ((int)c.phase) & 1;
  if (c.flags & F_MAGIC) {  // 受魔法影響：身上帶著變色的光暈
    float h = c.phase * 0.1f;
    uint32_t col = ((uint32_t)(150 + 100 * sinf(h)) << 16) | ((uint32_t)(150 + 100 * sinf(h + 2.1f)) << 8) | (uint32_t)(150 + 100 * sinf(h + 4.2f));
    gfx::glow(x, y - 4, 8, col, 140);
  }
  if (c.flags & F_TRAPPED) {  // 陷阱的繩子
    for (int k = -4; k <= 4; k++) gfx::pset(x + k, y - 3 + ((k + (int)c.phase) & 1), gfx::lit(0xC8B48C));
  }
  switch (c.sp) {
    case C_SPRITE: {
      int bob = (int)(sinf(c.phase * 0.5f) * 2);
      gfx::glow(x + 4, y + 4 + bob, 9, 0xFFE6A0, (uint8_t)(60 + e.night * 90));
      int fr = c.state == ST_SLEEP ? 2 : (((int)(c.phase * 1.5f)) & 1);
      gfx::sprite(spr::FAIRY, fr, x, y + (c.state == ST_SLEEP ? 0 : bob), c.flip, spr::FAIRY_PAL, false, c.alpha);
      break;
    }
    case C_SHROOM: {
      uint32_t pal[7] = {0, 0xF5E6CD, 0x281E28, 0x966E5A, spr::SHROOM_CAPS[c.variant], 0xFAF0D2, 0xDCBEA0};
      int fr = c.state == ST_HIDE ? 2 : c.state == ST_ACT ? 3 : (moving ? step : 0);
      if (e.night > 0.4f) gfx::glow(x + 4, y + 3, 10, pal[4], (uint8_t)(e.night * 110));
      gfx::sprite(spr::SHROOM, fr, x, y - 10, c.flip, pal, e.night < 0.4f, c.alpha);
      break;
    }
    case C_CRITTER: {
      int fr = c.state == ST_SLEEP ? 2 : c.state == ST_ACT ? 3 : (moving ? step : 0);
      if (c.variant == 9) {  // 月光狐：白色、自己發光
        gfx::glow(x, y - 4, 10, 0xDCE8FF, 90);
        gfx::sprite(spr::CRITTER, fr, x - 7, y - 9, c.flip, spr::CRITTER_PAL_MOON, false, c.alpha);
      } else gfx::sprite(spr::CRITTER, fr, x - 7, y - 9, c.flip, (c.variant & 1) ? spr::CRITTER_PAL2 : spr::CRITTER_PAL, true, c.alpha);
      break;
    }
    case C_SNAIL: {
      int fr = c.state == ST_HIDE ? 2 : (moving ? (((int)(c.phase * 0.25f)) & 1) : 0);
      gfx::sprite(spr::SNAIL, fr, x - 5, y - 6, c.flip, spr::SNAIL_PAL, true, c.alpha);
      break;
    }
    case C_FROG: {
      bool water = scene::inPond(c.x, c.y) && c.state != ST_HOP;
      bool lily = false;
      for (int s = 12; s <= 13; s++) if (plant::get(s).species == plant::P_LILY && fabsf(c.x - plant::SLOTS[s].x) < 3 && fabsf(c.y - plant::SLOTS[s].y) < 4) lily = true;
      int fr = c.state == ST_HOP ? 1 : c.state == ST_ACT ? 3 : (water && !lily) ? 2 : 0;
      gfx::sprite(spr::FROG, fr, x - 4, y - 7, c.flip, spr::FROG_PAL, true, c.alpha);
      if (c.state == ST_ACT) {  // 舌頭
        stick(c.flip ? X - 4 * px : X + 5 * px, Y - 4 * px, (int)c.tx, (int)c.ty, 0xE6646E);
      }
      break;
    }
    case C_BIRD: {
      uint32_t pal[7] = {0, spr::BIRD_BODY[c.variant % 3][0], spr::BIRD_BODY[c.variant % 3][1], 0x141414, 0xF0AA3C, 0xF0E6D2, 0x785A3C};
      int fr = moving ? 1 + (((int)(c.phase * 1.4f)) & 1) : c.state == ST_ACT ? (step ? 3 : 0) : 0;
      if (!moving && !(c.flags & F_LIT) && c.state != ST_SLEEP) fr = 1 + (((int)(c.phase * 1.4f)) & 1);  // 沒有落地就拍翅
      gfx::sprite(spr::BIRD, fr, x - 4, y - 5, c.flip, pal, true, c.alpha);  // 定位點 = 腳的位置 (站在樹枝上)
      if (c.flags & F_TWIG) stick(c.flip ? X - 7 * px : X + 2 * px, Y - 3 * px, c.flip ? X - 1 * px : X + 8 * px, Y - 2 * px, 0x8C643C);
      break;
    }
    case C_BUTTERFLY: case C_GLOWMOTH: {
      bool glowing = c.sp == C_GLOWMOTH;
      uint32_t pal[4] = {0, glowing ? 0xB4F0FF : spr::BFLY_COLORS[c.variant][0], glowing ? 0xFFFFFF : spr::BFLY_COLORS[c.variant][1], 0x3C3232};
      int bob = c.state == ST_ACT ? 0 : (int)(sinf(c.phase * 0.7f) * 2);
      int fr = c.state == ST_ACT ? (((int)(c.phase * 0.3f)) & 1) : (((int)(c.phase * 1.6f)) & 1);
      if (glowing) gfx::glow(x + 2, y + 2 + bob, 7, 0x78DCFF, 140);
      gfx::sprite(spr::BFLY, fr, x, y + bob, c.flip, pal, !glowing, c.alpha);
      break;
    }
    case C_FIREFLY: {
      float pulse = 0.5f + 0.5f * sinf(c.phase * 0.4f);
      uint8_t in = (uint8_t)(c.alpha * (0.25f + 0.75f * pulse));
      gfx::glow(x, y, 4, 0xC8FF64, in);
      gfx::padd(x, y, in, in, in / 3);
      break;
    }
    case C_DEER: {
      gfx::glow(x + 10, y + 8, 22, 0x9CDCFF, 70);
      int fr = moving ? (((int)(c.phase * 0.5f)) & 1) : 0;
      gfx::sprite(spr::DEER, fr, x, y - 18, !c.flip ? false : true, spr::DEER_PAL, false, c.alpha);
      break;
    }
    case C_MOLE: {
      int fr = c.state == ST_ACT ? 2 : (moving ? step : 0);
      gfx::sprite(spr::MOLE, fr, x - 4, y - 6, c.flip, spr::MOLE_PAL, true, c.alpha);
      if (c.flags & F_TWIG) item(c.flip ? -5 : 4, -3, 0xB07A3A);  // 搬著食物
      break;
    }
    case C_BEE: {
      int bob = (int)(sinf(c.phase * 1.3f) * 1);
      gfx::pset(x, y + bob, gfx::lit(0xF0C83C)); gfx::pset(x + 1, y + bob, gfx::lit(0x282018)); gfx::pset(x + 2, y + bob, gfx::lit(0xF0C83C));
      if (((int)(c.phase * 3)) & 1) gfx::pblend(x + 1, y - 1 + bob, gfx::lit(0xF0F8FF), 180);
      break;
    }
    case C_TURTLE: {
      gfx::sprite(spr::TURTLE, moving ? (((int)(c.phase * 0.3f)) & 1) : 0, x - 8, y - 9, c.flip, spr::TURTLE_PAL, true, c.alpha);
      if (e.night > 0.4f) gfx::glow(x, y - 6, 9, 0x9CE6B4, (uint8_t)(e.night * 60));  // 背上的苔蘚隱隱發光
      break;
    }
    case C_SQUIRREL: {
      gfx::sprite(spr::SQUIRREL, moving ? step : 0, x - 5, y - 8, c.flip, spr::SQUIRREL_PAL, true, c.alpha);
      if (c.flags & F_TWIG) { const int ai = c.flip ? -6 : 5; item(ai, -3, 0xB07A3A); item(ai, -4, 0x6B4423); }
      break;
    }
    case C_VISITOR: {
      // 半透明的光之生物：顏色緩慢變換，兩顆眼睛
      float hue = c.phase * 0.05f;
      uint8_t r = (uint8_t)(150 + 100 * sinf(hue)), g = (uint8_t)(150 + 100 * sinf(hue + 2.1f)), b = (uint8_t)(200 + 55 * sinf(hue + 4.2f));
      uint32_t col = ((uint32_t)r << 16) | ((uint32_t)g << 8) | b;
      if (c.variant == 9) col = 0xDCE8FF;   // 滿月的月光精靈
      if (c.variant == 10) col = 0x8CDC78;  // 樹精
      if (c.variant == 11) col = 0xFFE68C;  // 神祕光球
      if (c.variant == 12) col = 0xB48CFF;  // 洞穴裡的稀有生物
      if (c.variant == 11) { int bob = (int)(sinf(c.phase * 0.3f) * 2); gfx::glow(x, y + bob, 8, col, c.alpha); gfx::pset(x, y + bob, gfx::rgb(0xFFFFF0)); break; }
      int bob = (int)(sinf(c.phase * 0.3f) * 3);
      gfx::glow(x, y + bob, 14, col, (uint8_t)(c.alpha * 0.6f));
      gfx::blendEllipse(x, y + bob, 6, 5, gfx::rgb(col), c.alpha / 2);
      for (int k = 0; k < 4; k++) {
        int tx = x - 4 + k * 3, ty = y + bob + 5 + (int)(sinf(c.phase * 0.5f + k) * 2);
        gfx::pblend(tx, ty, gfx::rgb(col), c.alpha / 2); gfx::pblend(tx, ty + 1, gfx::rgb(col), c.alpha / 3);
      }
      gfx::pblend(x - 2, y + bob - 1, gfx::rgb(0x141428), c.alpha); gfx::pblend(x + 2, y + bob - 1, gfx::rgb(0x141428), c.alpha);
      break;
    }
  }
}
}  // namespace

void drawGround(int yMin, int yMax) {
  // 依 y 由小到大畫 (後面先畫)
  int idx[CAP], n = 0;
  for (int i = 0; i < CAP; i++) {
    const Creature& c = cs[i];
    if (!c.active || c.flying || c.alpha == 0) continue;
    if (c.y < yMin || c.y >= yMax) continue;
    idx[n++] = i;
  }
  for (int i = 1; i < n; i++) { int v = idx[i], j = i - 1; while (j >= 0 && cs[idx[j]].y > cs[v].y) { idx[j + 1] = idx[j]; j--; } idx[j + 1] = v; }
  gfx::world = false;
  for (int i = 0; i < n; i++) drawOne(cs[idx[i]]);
  gfx::world = true;
}

void drawFliers() {
  gfx::world = false;
  for (auto& c : cs) if (c.active && c.flying && c.alpha > 0) drawOne(c);
  gfx::world = true;
}

}  // namespace creature
