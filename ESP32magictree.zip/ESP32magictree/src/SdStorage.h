// microSD (選配)：把觀察日誌長期存檔到 /forest/journal.txt。沒插卡時一切照常運作。
// 美術素材是程式內嵌的小型像素圖 (總計數 KB)，不需要從 SD 載入。
#pragma once

namespace sdstore {
bool begin();
bool ok();
void appendJournal(const char* line);
}
