#include "PlantManager.h"
#include <Arduino.h>
#include <math.h>
#include "Ecosystem.h"
#include "EventManager.h"
#include "Journal.h"
#include "Particles.h"
#include "SeasonManager.h"
#include "Util.h"
#include "ForestHistory.h"
#include "Underground.h"
#include "Evolution.h"

namespace plant {

const Slot SLOTS[SLOT_N] = {
    // Z_OFF = 和背景衝突而停用：3 在瀑布小溪水面上、4/5 在右側樹拱裡、19 在瀑布石堆上 (小樹位置改到 0、21)
    {100, 176, Z_GROUND, true},  {114, 180, Z_GROUND, false}, {132, 175, Z_GROUND, false}, {150, 172, Z_OFF, false},
    {208, 171, Z_OFF, false},    {226, 176, Z_OFF, false}, {84, 184, Z_SHADE, false},  {12, 190, Z_SHADE, false},
    {30, 200, Z_SHADE, false},   {70, 197, Z_SHADE, false},   {170, 206, Z_SHORE, false}, {234, 198, Z_SHORE, false},
    {204, 217, Z_WATER, false},  {170, 234, Z_WATER, false},  {46, 150, Z_TRUNK, false},  {118, 216, Z_ROCK, false},
    {18, 209, Z_ROCK, false},    {104, 204, Z_LOG, false},    {134, 203, Z_LOG, false},   {172, 168, Z_OFF, false},
    {56, 216, Z_GROUND, false},  {90, 228, Z_GROUND, true},
};

namespace {
Plant plants[SLOT_N];
Deadwood deadwood{};
// 年齡的小數部分：存檔格式是整數小時，但每次更新只增加零點幾小時，必須另外累積
float ageFrac[SLOT_N];
float logAgeFrac = 0;
inline void addAge(uint16_t& age, float& frac, float dtH) {
  frac += dtH;
  if (frac >= 1.0f) { int whole = (int)frac; frac -= whole; age = (uint16_t)fminf(age + whole, 65000); }
}
float spontaneousAcc = 0;

// 各階段所需時數 (森林時間)：SEED SPROUT GROW MATURE BLOOM WITHER
struct Def { float h[6]; float tOpt; bool perennial; };
const Def DEFS[P_COUNT] = {
    {{1, 1, 1, 1, 1, 1}, 20, false},                // NONE
    {{4, 10, 30, 9999, 0, 30}, 18, true},           // 苔蘚：成熟後長期存在
    {{1.5f, 1, 2, 7, 0, 2}, 19, false},             // 蘑菇：無開花，成熟後凋萎
    {{2, 3, 6, 2, 14, 4}, 22, false},               // 花
    {{6, 18, 96, 600, 0, 48}, 22, false},           // 小樹 (約一個月壽命)
    {{3, 8, 48, 200, 24, 24}, 23, true},            // 藤蔓
    {{3, 4, 8, 3, 20, 4}, 18, false},               // 發光植物
    {{4, 8, 24, 9999, 0, 24}, 22, true},            // 水邊蘆葦
    {{3, 6, 12, 6, 10, 24}, 25, true},              // 睡蓮
};

bool zoneAllows(uint8_t zone, Species sp) {
  switch (zone) {
    case Z_GROUND: return sp == P_FLOWER || sp == P_MUSHROOM || sp == P_GLOW || sp == P_SAPLING;
    case Z_SHADE: return sp == P_MUSHROOM || sp == P_GLOW || sp == P_MOSS || sp == P_FLOWER;
    case Z_SHORE: return sp == P_REED || sp == P_FLOWER;
    case Z_WATER: return sp == P_LILY;
    case Z_TRUNK: return sp == P_VINE || sp == P_MOSS;
    case Z_ROCK: return sp == P_MOSS;
    case Z_LOG: return sp == P_MUSHROOM || sp == P_MOSS;
  }
  return false;
}

bool slotUsable(int i, Species sp) {
  const Slot& s = SLOTS[i];
  if (s.zone == Z_LOG && !deadwood.state) return false;
  if (sp == P_SAPLING && !s.treeRoom) return false;
  return zoneAllows(s.zone, sp);
}

float gauss(float x, float mu, float w) { float d = (x - mu) / w; return expf(-d * d); }

float rate(Species sp, const Plant& p) {
  const eco::Env& e = eco::env;
  const Def& d = DEFS[sp];
  float r = 0.15f + 0.85f * gauss(e.tempC, d.tOpt, 11);
  switch (sp) {
    case P_MOSS: r *= 0.2f + util::clamp01((e.airHum - 40) / 50) * 1.3f + e.rain; break;
    case P_MUSHROOM: r *= util::clamp01((e.airHum - 55) / 35) * 1.4f + e.soil * 0.6f + e.rain * 0.8f; r *= 1.2f - e.light * 0.5f; break;
    case P_FLOWER: r *= (0.3f + e.light * 0.9f) * (0.4f + util::clamp01(e.soil * 1.6f)); break;
    case P_SAPLING: r *= (0.4f + e.light * 0.6f) * (0.5f + e.soil); break;
    case P_VINE: r *= 0.5f + e.soil * 0.5f + e.airHum / 200; break;
    case P_GLOW: r *= 0.6f + e.night * 0.6f + e.magic * 1.5f; break;
    case P_REED: case P_LILY: r *= 0.6f + e.light * 0.5f; break;
    default: break;
  }
  // 季節
  float sf = season::weight(SPRING) * 1.3f + season::weight(SUMMER) * 1.1f + season::weight(AUTUMN) * 0.7f +
             season::weight(WINTER) * 0.3f;
  if (sp == P_MUSHROOM) sf = 0.8f + season::weight(AUTUMN) * 0.6f;  // 秋天菇類多
  r *= sf;
  r *= 1.0f + e.magic * 1.5f;
  // 第二階段：地下水/菌絲、區域歷史 (茂盛度/潮濕度)、霜凍
  const int slot = (int)(&p - plants);
  r *= under::growthBonus(sp) * history::plantRate(slot, sp);
  r *= 1.0f - eco::world.frost * 0.6f;
  (void)p;
  return fmaxf(r, 0.0f);
}

bool shouldDormant(Species sp) {
  const eco::Env& e = eco::env;
  if (sp == P_MOSS || sp == P_MUSHROOM || sp == P_SAPLING) return false;
  return (e.tempC < 6) || (season::weight(WINTER) > 0.7f && e.tempC < 14);
}

void plantAt(int i, Species sp) {
  Plant& p = plants[i];
  p.species = sp;
  p.stage = S_SEED;
  p.prog = 0;
  p.ageH = 0;
  p.variant = (uint8_t)util::rng.irange(0, 3);
}

void notify(int i, Stage st) {
  const Plant& p = plants[i];
  journal::Msg m = journal::J_NONE;
  bool toast = false;
  switch (p.species) {
    case P_FLOWER: if (st == S_BLOOM) m = journal::J_FLOWER_BLOOM; break;
    case P_MUSHROOM: if (st == S_MATURE) { m = journal::J_MUSH_MATURE; toast = true; } break;
    case P_SAPLING:
      if (st == S_SPROUT) { m = journal::J_SAPLING_SPROUT; toast = true; }
      if (st == S_MATURE) { m = journal::J_TREE_MATURE; toast = true; }
      break;
    case P_VINE: if (st == S_MATURE) m = journal::J_VINE; break;
    case P_MOSS: if (st == S_MATURE && SLOTS[i].zone == Z_ROCK) m = journal::J_MOSS; break;
    case P_GLOW: if (st == S_BLOOM) m = journal::J_GLOW_BLOOM; break;
    case P_LILY: if (st == S_BLOOM) m = journal::J_LILY; break;
    default: break;
  }
  if (m != journal::J_NONE) journal::add(m, 0xFF, toast);
  eventm::onPlantStage(i, p.species, st);
}

void advance(int i) {
  Plant& p = plants[i];
  const Species sp = (Species)p.species;
  const Def& d = DEFS[sp];
  p.prog = 0;
  switch (p.stage) {
    case S_SEED: p.stage = S_SPROUT; break;
    case S_SPROUT: p.stage = S_GROW; break;
    case S_GROW: p.stage = S_MATURE; break;
    case S_MATURE:
      if (d.h[S_BLOOM] > 0) p.stage = S_BLOOM;
      else p.stage = d.perennial ? S_MATURE : S_WITHER;
      break;
    case S_BLOOM:
      p.stage = d.perennial ? S_MATURE : S_WITHER;  // 多年生植物開完花回到成熟期
      break;
    case S_WITHER:
      if (sp == P_FLOWER || sp == P_GLOW) {
        disperseSeeds(i, util::rng.irange(1, 2) + (eco::env.wind > 0.5f ? 1 : 0), true);
        journal::add(journal::J_FLOWER_WITHER, 0xFF, false);
      } else if (sp == P_SAPLING) {
        // 老樹倒下 → 枯木 (演替)
        if (!deadwood.state) { formLog(); journal::add(journal::J_TREE_FALL); }
      } else if (sp == P_MUSHROOM && util::rng.chance(0.5f)) {
        disperseSeeds(i, 1, false);  // 孢子
      }
      p.species = P_NONE;
      return;
  }
  notify(i, (Stage)p.stage);
}

void tickPlant(int i, float dtH) {
  Plant& p = plants[i];
  if (p.species == P_NONE) return;
  const Species sp = (Species)p.species;
  // 枯木消失後，上面的植物也跟著消失
  if (SLOTS[i].zone == Z_LOG && !deadwood.state) { p.species = P_NONE; return; }
  if (SLOTS[i].zone == Z_OFF) { p = {}; return; }  // 停用格位 (舊存檔留下的植物) 直接清掉
  addAge(p.ageH, ageFrac[i], dtH);

  // 休眠
  if (p.stage == S_DORMANT) {
    if (!shouldDormant(sp) && season::weight(WINTER) < 0.5f) {
      p.stage = p.prevStage;
      journal::add(journal::J_PLANT_WAKE, 0xFF, false);
    }
    return;
  }
  if (shouldDormant(sp) && p.stage >= S_SPROUT && p.stage <= S_BLOOM) {
    p.prevStage = p.stage == S_BLOOM ? S_MATURE : p.stage;
    p.stage = S_DORMANT;
    return;
  }

  float r = rate(sp, p);
  // 壓力：乾燥讓蘑菇快速凋萎、苔蘚退縮；高溫讓花加速凋謝
  const eco::Env& e = eco::env;
  if (sp == P_MUSHROOM && p.stage >= S_MATURE && e.airHum < 50 && e.soil < 0.3f) r = 3;
  if (sp == P_FLOWER && p.stage == S_BLOOM && e.hot) r *= 1.6f;
  if ((sp == P_FLOWER || sp == P_GLOW) && p.stage == S_BLOOM && eco::world.drought > 0.3f) r *= 1.0f + eco::world.drought * 1.5f;  // 乾旱讓花凋謝
  if (sp == P_MOSS && p.stage == S_MATURE && e.airHum < 35 && e.soil < 0.15f) {
    p.stage = S_GROW;  // 太乾 → 苔蘚退縮
    p.prog = 900;
    return;
  }
  float stageH = DEFS[sp].h[p.stage == S_DORMANT ? S_MATURE : p.stage];
  if (stageH <= 0 || stageH >= 9999) return;  // 長期穩定狀態
  float add = dtH / stageH * 1000.0f * r;
  float np = p.prog + add;
  if (np >= 1000) advance(i);
  else p.prog = (uint16_t)np;
}

void spontaneous(float dtH) {
  // 空地偶爾自然冒出新植物 (風、鳥、動物帶來的種子)
  spontaneousAcc += dtH;
  if (spontaneousAcc < 0.33f) return;
  spontaneousAcc = 0;
  const eco::Env& e = eco::env;
  float springBoost = 1.0f + season::weight(SPRING) * 1.5f - season::weight(WINTER) * 0.7f;
  for (int i = 0; i < SLOT_N; i++) {
    if (plants[i].species != P_NONE) continue;
    const Slot& s = SLOTS[i];
    if (s.zone == Z_LOG && !deadwood.state) continue;
    float p = 0.04f * springBoost;
    Species sp = P_NONE;
    float r = util::rng.f();
    switch (s.zone) {
      case Z_GROUND: sp = r < 0.55f ? P_FLOWER : r < 0.75f ? P_MUSHROOM : r < 0.9f ? P_GLOW : P_SAPLING; break;
      case Z_SHADE: sp = r < 0.4f ? P_MUSHROOM : r < 0.6f ? P_MOSS : r < 0.85f ? P_GLOW : P_FLOWER; break;
      case Z_SHORE: sp = r < 0.6f ? P_REED : P_FLOWER; break;
      case Z_WATER: sp = P_LILY; break;
      case Z_TRUNK: sp = r < 0.7f ? P_VINE : P_MOSS; break;
      case Z_ROCK: sp = P_MOSS; p *= 0.5f + e.airHum / 100; break;
      case Z_LOG: sp = r < 0.7f ? P_MUSHROOM : P_MOSS; p *= 2; break;
    }
    if (sp == P_MUSHROOM) p *= (0.3f + eco::wetness() * 2) * (1.0f + under::mycelium());
    if (sp == P_MOSS && e.hoursSinceRain < 6) p *= 2.5f;  // 雨後苔蘚容易生長
    if (!slotUsable(i, sp)) continue;
    p *= history::plantBias(i, sp) * evo::plantBias(i, sp);  // 歷史與地形演化：舊木屋/雷擊處長菇、濕地、蘑菇森林、空地
    if (util::rng.chance(p)) {
      plantAt(i, sp);
      history::specialVariant(i, sp, plants[i].variant);
    }
  }
}

void tickLog(float dtH) {
  if (!deadwood.state) return;
  addAge(deadwood.ageH, logAgeFrac, dtH);
  const float logH = deadwood.ageH + logAgeFrac;  // 時間經 util::shortH 壓縮到 0.5~3 小時
  if (deadwood.state == 1 && logH > util::shortH(30) && eco::wetness() > 0.5f) deadwood.state = 2;
  if (deadwood.state == 2) {
    bool fungi = false;
    for (int i = 0; i < SLOT_N; i++) if (SLOTS[i].zone == Z_LOG && plants[i].species == P_MUSHROOM && plants[i].stage >= S_MATURE) fungi = true;
    if (fungi) { deadwood.state = 3; journal::add(journal::J_LOG_FUNGI); }
  }
  if (logH >= util::shortH(240)) {  // 約 3 小時後化為土壤
    deadwood = {};
    journal::add(journal::J_LOG_GONE, 0xFF, false);
    for (int i = 0; i < SLOT_N; i++) if (plants[i].species == P_NONE && SLOTS[i].zone == Z_GROUND && util::rng.chance(0.5f)) plantAt(i, P_FLOWER);
  }
}
}  // namespace

void begin() {
  for (auto& p : plants) p = {};
  // 新森林：少量初始植物，之後自然演替
  plantAt(0, P_FLOWER); plants[0].stage = S_BLOOM;
  plantAt(2, P_FLOWER); plants[2].stage = S_GROW;
  plantAt(6, P_MUSHROOM); plants[6].stage = S_MATURE;
  plantAt(9, P_GLOW); plants[9].stage = S_MATURE;
  plantAt(10, P_REED); plants[10].stage = S_MATURE;
  plantAt(12, P_LILY); plants[12].stage = S_MATURE;
  plantAt(14, P_VINE); plants[14].stage = S_GROW; plants[14].prog = 500;
  plantAt(15, P_MOSS); plants[15].stage = S_GROW;
  plantAt(16, P_MOSS); plants[16].stage = S_MATURE;
  plantAt(21, P_SAPLING); plants[21].stage = S_SPROUT;
  plantAt(20, P_FLOWER); plants[20].stage = S_MATURE;
}

void tick(float dtSimSec) {
  const float dtH = dtSimSec / 3600.0f;
  int nectar = 0;
  for (int i = 0; i < SLOT_N; i++) {
    tickPlant(i, dtH);
    if ((plants[i].species == P_FLOWER || plants[i].species == P_VINE || plants[i].species == P_LILY) && plants[i].stage == S_BLOOM) nectar++;
  }
  eco::env.nectar = util::clamp01(nectar / 5.0f);
  spontaneous(dtH);
  tickLog(dtH);
}

const Plant& get(int i) { return plants[i]; }
Plant& mut(int i) { return plants[i]; }
const Deadwood& log() { return deadwood; }
bool hasLog() { return deadwood.state != 0; }
void formLog() { if (!deadwood.state) deadwood = {1, 0}; }
void setLog(const Deadwood& d) { deadwood = d.state <= 3 ? d : Deadwood{}; }

int countStage(Species sp, Stage st) {
  int n = 0;
  for (auto& p : plants) if (p.species == sp && p.stage == st) n++;
  return n;
}
int countSpecies(Species sp) {
  int n = 0;
  for (auto& p : plants) if (p.species == sp) n++;
  return n;
}
int bloomingFlowers() { return countStage(P_FLOWER, S_BLOOM) + countStage(P_GLOW, S_BLOOM); }
int matureMushrooms() { return countStage(P_MUSHROOM, S_MATURE); }

float treeMaturity() {
  float m = 0.5f;  // 古樹本身
  for (auto& p : plants) if (p.species == P_SAPLING) m += p.stage >= S_MATURE ? 0.3f : p.stage == S_GROW ? 0.1f : 0;
  return util::clamp01(m);
}

int randomSlotOf(Species sp, Stage minStage) {
  int pick = -1, seen = 0;
  for (int i = 0; i < SLOT_N; i++) {
    const Plant& p = plants[i];
    if (p.species != sp || p.stage == S_DORMANT || p.stage < minStage || p.stage == S_WITHER) continue;
    if (minStage == S_BLOOM && p.stage != S_BLOOM) continue;
    if (util::rng.irange(0, seen++) == 0) pick = i;
  }
  return pick;
}

void disperseSeeds(int from, int count, bool visible) {
  const Species sp = (Species)plants[from].species;
  for (int k = 0; k < count; k++) {
    int target = -1, seen = 0;
    for (int i = 0; i < SLOT_N; i++) {
      if (i == from || plants[i].species != P_NONE || !slotUsable(i, sp)) continue;
      if (util::rng.irange(0, seen++) == 0) target = i;
    }
    if (target < 0) return;
    if (visible) fx::seedFlight(SLOTS[from].x, SLOTS[from].y - 8, SLOTS[target].x, SLOTS[target].y);
    plantAt(target, sp);
    plants[target].variant = plants[from].variant;  // 遺傳顏色
    if (k == 0) journal::add(journal::J_SEED_LAND, 0xFF, false);
  }
}

void boostGrowth(float hours) {
  for (int i = 0; i < SLOT_N; i++) {
    Plant& p = plants[i];
    if (p.species == P_NONE || p.stage == S_WITHER || p.stage == S_DORMANT) continue;
    float sh = DEFS[p.species].h[p.stage];
    if (sh <= 0 || sh >= 9999) continue;
    float np = p.prog + hours / sh * 1000.0f;
    if (np >= 1000) advance(i);
    else p.prog = (uint16_t)np;
  }
}

void sproutRandom(Species sp) {
  int target = -1, seen = 0;
  for (int i = 0; i < SLOT_N; i++) {
    if (plants[i].species != P_NONE || !slotUsable(i, sp)) continue;
    if (util::rng.irange(0, seen++) == 0) target = i;
  }
  if (target >= 0) plantAt(target, sp);
}

float growthFrac(int i) {
  const Plant& p = plants[i];
  const float t = p.prog / 1000.0f;
  uint8_t st = p.stage == S_DORMANT ? p.prevStage : p.stage;
  switch (st) {
    case S_SEED: return 0.05f;
    case S_SPROUT: return 0.1f + 0.2f * t;
    case S_GROW: return 0.3f + 0.6f * t;
    case S_WITHER: return 1.0f - 0.3f * t;
    default: return 1.0f;
  }
}

const char* name(Species sp) {
  static const char* N[P_COUNT] = {"", "苔蘚", "蘑菇", "花朵", "小樹", "藤蔓", "發光植物", "蘆葦", "睡蓮"};
  return N[sp];
}

}  // namespace plant
