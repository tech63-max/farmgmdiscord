// 資料驅動的事件配方 (第三階段 100 個事件)：條件、效果、變體都由 EventRecipeTable.h 描述
// EventManager 對配方事件呼叫這裡的 cond / start / update / finish
#pragma once
#include <stdint.h>
#include "EventManager.h"

namespace recipes {

struct OpDef { uint8_t op, a; int8_t b; uint8_t place; };
struct Recipe {
  uint8_t phases, seasons, weather, moon;
  uint64_t needs;
  uint8_t group, variant;
  uint16_t altMsg;
  OpDef ops[3];
  OpDef alt[3];
};

bool is(uint8_t id);
float cond(uint8_t id);
void start(uint8_t id, eventm::Active& a, uint32_t ms);
void update(eventm::Active& a, float dt, uint32_t ms);
void finish(eventm::Active& a, uint32_t ms);
uint16_t journalMsg(uint8_t id, uint16_t normal);  // 變體時改用另一段文字
float weightFactor(uint8_t id);                     // 相似事件、同一地點的限制

}  // namespace recipes
