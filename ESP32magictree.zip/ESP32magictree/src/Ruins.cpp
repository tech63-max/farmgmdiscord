#include "Ruins.h"
#include <Arduino.h>
#include <math.h>
#include "Ecosystem.h"
#include "EventManager.h"
#include "ForestHistory.h"
#include "Gfx.h"
#include "Journal.h"
#include "Particles.h"
#include "PlantManager.h"
#include "TimeManager.h"
#include "Util.h"

namespace ruins {
namespace {
Blob s;
uint32_t glowUntil[CAP];
// 遺跡位置 (避開池塘、石頭、建築與洞穴位置)
const short SITE_X[CAP] = {178, 6, 232, 98}, SITE_Y[CAP] = {180, 212, 236, 238};
// 發現順序：石碑 → 石門 → 寶箱 → 其他 (遺跡之間有關聯)
const uint8_t ORDER[] = {R_STELE, R_GATE, R_CHEST, R_PILLAR, R_STATUE, R_ENTRANCE, R_STONEBRIDGE};
}  // namespace

void begin() {
  s = {};
  for (auto& r : s.r) r.type = R_COUNT;
}

void tick(float dtH) {
  if (dtH <= 0) return;
  const eco::Env& e = eco::env;
  for (int i = 0; i < CAP; i++) {
    Ruin& r = s.r[i];
    if (r.type >= R_COUNT || r.reveal < 0.15f) continue;
    // 植物逐漸覆蓋遺跡 (不會消失，只會被包圍)
    r.moss = fminf(1, r.moss + dtH * (0.002f + e.soil * 0.004f));
    r.roots = fminf(0.9f, r.roots + dtH * 0.0012f * (0.5f + plant::treeMaturity()));
    // 已出土的石碑偶爾在夜裡浮現符文 (EventManager 的 A_RUIN_GLOW 事件會處理)
  }
}

bool erode(uint32_t ms) {
  if (exposed() >= 0) return false;  // 一次只露出一處
  int site = -1, seen = 0;
  for (int i = 0; i < CAP; i++) {
    if (s.r[i].type < R_COUNT) continue;
    if (util::rng.irange(0, seen++) == 0) site = i;
  }
  if (site < 0) return false;
  Ruin& r = s.r[site];
  r = {};
  r.type = ORDER[s.nextType % (sizeof(ORDER))];
  s.nextType++;
  r.reveal = 0.2f;
  (void)ms;
  return true;
}

int exposed() {
  for (int i = 0; i < CAP; i++) if (s.r[i].type < R_COUNT && s.r[i].reveal < 0.9f) return i;
  return -1;
}
int excavated() {
  int pick = -1, seen = 0;
  for (int i = 0; i < CAP; i++) if (s.r[i].type < R_COUNT && s.r[i].reveal >= 0.9f && util::rng.irange(0, seen++) == 0) pick = i;
  return pick;
}

void excavate(int i, uint32_t ms) {
  if (i < 0) return;
  Ruin& r = s.r[i];
  r.reveal = 1;
  r.found = timem::now();
  s.lastFind = r.found;
  history::note(history::H_RUIN, SITE_X[i], r.type);
  switch (r.type) {
    case R_STELE: eventm::trigger(eventm::A_STELE, ms, true); break;
    case R_GATE: eventm::trigger(eventm::A_GATE, ms, true); break;
    case R_CHEST:
      eventm::trigger(eventm::A_CHEST, ms, true);
      r.flags |= F_OPENED;
      plant::sproutRandom(plant::P_GLOW);  // 遺跡藏著特殊植物的種子
      journal::add(journal::J_X_SEEDS);
      break;
    default: journal::add(journal::J_A_STELE, 0xFF, false); break;
  }
}

void study(int i) { if (i >= 0) s.r[i].flags |= F_STUDIED; }
void mark(int i) { if (i >= 0) s.r[i].flags |= F_MARKED; }
void glow(int i, uint32_t ms) {
  if (i < 0) return;
  glowUntil[i] = ms + 25000;
  if (s.r[i].type == R_GATE) s.r[i].flags |= F_RUNES;
}
int find(Type t) {
  for (int i = 0; i < CAP; i++) if (s.r[i].type == t && s.r[i].reveal >= 0.9f) return i;
  return -1;
}
bool hasFreeSite() { for (auto& r : s.r) if (r.type >= R_COUNT) return true; return false; }
bool gateHasRunes() { int g = find(R_GATE); return g >= 0 && (s.r[g].flags & F_RUNES); }
Ruin& at(int i) { return s.r[i]; }
void pos(int i, int& x, int& y) { x = SITE_X[i]; y = SITE_Y[i]; }
const char* name(uint8_t t) {
  static const char* N[R_COUNT] = {"stele", "gate", "chest", "pillar", "statue", "entrance", "stonebridge"};
  return t < R_COUNT ? N[t] : "-";
}

// ---------------- 繪圖 (120 畫布) ----------------
namespace {
inline void P(int x, int y, uint32_t c) { gfx::pset(x, y, gfx::lit(c)); }
}  // namespace

void draw(uint32_t ms) {
  const bool w = gfx::world;
  gfx::world = false;
  for (int i = 0; i < CAP; i++) {
    const Ruin& r = s.r[i];
    if (r.type >= R_COUNT) continue;
    const int bx = SITE_X[i] >> 1, by = SITE_Y[i] >> 1;
    // 露出的高度：埋著時只看得到一角
    const float rv = r.reveal;
    const uint32_t st = 0x8C8C96, stD = 0x5E5E6A, stL = 0xB4B4BE;
    int h = 0, wdt = 0;
    switch (r.type) {
      case R_STELE: h = 10; wdt = 5; break;
      case R_GATE: h = 14; wdt = 14; break;
      case R_CHEST: h = 4; wdt = 6; break;
      case R_PILLAR: h = 12; wdt = 3; break;
      case R_STATUE: h = 8; wdt = 6; break;
      case R_ENTRANCE: h = 5; wdt = 10; break;
      case R_STONEBRIDGE: h = 4; wdt = 14; break;
    }
    const int vis = rv >= 0.9f ? h : (int)fmaxf(1, h * rv);
    const int x0 = bx - wdt / 2;
    for (int y = 0; y < vis; y++) {
      for (int x = 0; x < wdt; x++) {
        bool on = true;
        uint32_t c = (x == 0 || y == vis - 1) ? stL : (x == wdt - 1 ? stD : st);
        switch (r.type) {
          case R_STELE:  // 上方圓弧的石碑，刻著橫紋
            if (y == h - 1 && (x == 0 || x == wdt - 1)) on = false;
            if (x > 0 && x < wdt - 1 && y > 1 && y < h - 2 && (y % 2 == 0)) c = stD;
            break;
          case R_GATE:  // 拱門：中間是黑暗的通道
            if (x >= 4 && x <= 9 && y < 10) c = (y >= 9) ? stD : 0x1A1622;
            if (y >= h - 2 && (x < 2 || x > 11)) on = false;
            break;
          case R_CHEST:
            c = (y == vis - 1) ? 0x8C6440 : (x == wdt / 2 && y == 1 ? 0xE6C850 : 0x6E4E32);
            if (r.flags & F_OPENED && y == vis - 1) c = 0x3A2A20;
            break;
          case R_PILLAR: if (y == h - 1) c = stL; if (y > 8 && x == 2) on = false; break;  // 斷掉的柱子
          case R_STATUE: if (y > 5 && (x == 0 || x == wdt - 1)) on = false; if (y == 7 && x == 4) on = false; break;  // 破損石雕
          case R_ENTRANCE: if (x >= 3 && x <= 6 && y < 3) c = 0x14100C; break;
          case R_STONEBRIDGE: if (y < 2 && x >= 3 && x <= 10) on = false; break;  // 橋拱
        }
        if (!on) continue;
        // 苔蘚覆蓋
        if (util::hashf(x + i * 17, y) < r.moss * 0.6f) c = ((x + y) & 1) ? 0x5E8A4A : 0x7CAA5A;
        P(x0 + x, by - y - 1, c);
      }
    }
    // 埋著的部分：泥土
    if (rv < 0.9f) for (int x = -1; x <= wdt; x++) P(x0 + x, by, ((x + i) & 1) ? 0x6E5A41 : 0x7A6448);
    // 樹根包圍
    int nr = (int)(r.roots * 6);
    for (int k = 0; k < nr; k++) {
      int rx = x0 - 1 + (int)(util::hashf(k, i * 3) * (wdt + 2));
      int rl = 2 + (int)(util::hashf(i, k * 7) * (vis * 0.6f));
      for (int y = 0; y < rl; y++) P(rx + ((y / 2) & 1), by - 1 - y, 0x6E5034);
    }
    // 記號 / 符文 / 夜間微光
    if (r.flags & F_MARKED) P(x0 + wdt + 1, by - 2, 0xC83C3C);
    bool glowing = !util::reached(ms, glowUntil[i]);
    if (glowing || ((r.flags & F_RUNES) && eco::env.night > 0.6f)) {
      uint8_t in = (uint8_t)((glowing ? 150 : 50) + 40 * sinf(ms * 0.003f + i));
      gfx::glow(bx, by - vis / 2 - 1, wdt / 2 + 3, 0x8CB4FF, in);
      for (int k = 0; k < 3; k++) P(bx - 1 + k, by - vis / 2 - 1 + (k & 1), 0xC8E6FF);
    }
  }
  gfx::world = w;
}

void exportBlob(Blob& b) { b = s; }
void importBlob(const Blob& b) {
  s = b;
  for (auto& r : s.r) if (r.type > R_COUNT) r.type = R_COUNT;
}

}  // namespace ruins
