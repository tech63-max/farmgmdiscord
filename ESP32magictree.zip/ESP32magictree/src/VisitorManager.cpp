#include "VisitorManager.h"
#include <Arduino.h>
#include <math.h>
#include "Config.h"
#include "CreatureManager.h"
#include "Ecosystem.h"
#include "EventManager.h"
#include "Gfx.h"
#include "Journal.h"
#include "Particles.h"
#include "ForestHistory.h"
#include "Ruins.h"
#include "Evolution.h"
#include "PlantManager.h"
#include "Scene.h"
#include "SeasonManager.h"
#include "Sprites.h"
#include "StructureManager.h"
#include "TimeManager.h"
#include "Util.h"

namespace visitor {
namespace {
using structure::SITES;
constexpr uint8_t LEAVING = 99;
enum Pose : uint8_t { P_STAND, P_CROUCH, P_SLEEP, P_HIDDEN };
enum After : uint8_t { A_NONE, A_FIRE_OUT, A_PREY_RETURN, A_EXPLORE, A_ALTAR };

struct V {
  bool on;
  uint8_t type, story, step, pose;
  float x, y, tx, ty, phase;
  bool flip, walking, following, flagA, flagB;
  uint8_t followSp;
  uint32_t until;
  uint8_t alpha;
  int8_t useIdx;   // 正在使用的建築
  int8_t aux;      // 故事用的暫存 (位置/植物格)
  uint8_t task;    // S_TASK 的任務
};
V v;
Stats stats;
StatsExt statsExt;
uint32_t storyTime(int s) { return s < S_LEGACY ? stats.lastStory[s] : statsExt.lastStory[s - S_LEGACY]; }
uint32_t nextRealMs = 0;
After after = A_NONE;
uint32_t afterAt = 0;
int8_t afterIdx = -1;

struct Track { float x, y; float life; };
Track tracks[10];

const char* const STORY_NAMES[S_COUNT] = {"cabin", "camp", "lost", "glow", "chase", "study", "hunt", "merchant", "mystic", "dig", "revisit", "task"};
const uint8_t STORY_TYPE[S_COUNT] = {V_ADV, V_ADV, V_ADV, V_ADV, V_ADV, V_ADV, V_HUNTER, V_MERCHANT, V_MYSTIC, V_ADV, V_ADV, V_ADV};
uint8_t pendingTask = TK_NONE;

float rnd(float a, float b) { return util::rng.range(a, b); }
float groundAt(float x) { return scene::walkY((int)x) + 4; }

void walkTo(float x, float y) { v.tx = util::clamp(x, -20.0f, 260.0f); v.ty = y; v.walking = true; v.following = false; }
void act(Pose p, float sMin, float sMax) { v.walking = false; v.following = false; v.pose = p; v.until = millis() + (uint32_t)(rnd(sMin, sMax) * 1000); }
void follow(uint8_t sp, float sMin, float sMax) { v.following = true; v.walking = true; v.followSp = sp; v.until = millis() + (uint32_t)(rnd(sMin, sMax) * 1000); }

void addTracks(float x0, float y0, float x1, float y1) {
  for (int k = 0; k < 10; k++) {
    float t = (k + 0.5f) / 10;
    tracks[k] = {x0 + (x1 - x0) * t, y0 + (y1 - y0) * t + ((k & 1) ? 2 : -1), 240};
  }
}
void clearTracks() { for (auto& t : tracks) t.life = fminf(t.life, 3); }
bool anyTracks() { for (auto& t : tracks) if (t.life > 5) return true; return false; }

void startLeave(uint32_t ms);
void advance(uint32_t ms);

void beginStep(uint32_t ms) {
  const uint32_t now = timem::now();
  switch (v.story) {
    // ---------- 故事 A：冒險家的木屋 ----------
    case S_CABIN:
      switch (v.step) {
        case 0: walkTo(SITES[0].x - 28, SITES[0].y + 4); break;
        case 1: journal::add(journal::J_S_CLEARING, 0xFF, false); act(P_STAND, 3, 5); break;
        case 2: journal::add(journal::J_S_WOOD, 0xFF, false); walkTo(scene::TRUNK_X + 34, 198); break;
        case 3: v.flagA = true; act(P_CROUCH, 8, 12); break;   // 收集木材
        case 4: v.flagA = false; walkTo(SITES[0].x - 4, SITES[0].y + 3); break;
        case 5: v.flagA = true; act(P_CROUCH, 15, 25); break;  // 搭建
        case 6:
          v.flagA = false;
          v.useIdx = (int8_t)structure::create(structure::T_CABIN, 0, ms);
          if (v.useIdx < 0) { startLeave(ms); return; }
          structure::setUse(v.useIdx, true);
          journal::add(journal::J_S_CABIN);
          history::note(history::H_CABIN, SITES[0].x);
          act(P_HIDDEN, 40, 80);  // 進屋休息
          break;
        case 7: structure::setUse(v.useIdx, false); v.useIdx = -1; act(P_STAND, 3, 4); break;
        default: startLeave(ms); break;
      }
      break;
    // ---------- 故事 C：營地 ----------
    case S_CAMP:
      switch (v.step) {
        case 0: walkTo(SITES[1].x + 12, SITES[1].y); break;
        case 1: v.flagA = true; act(P_CROUCH, 10, 14); break;
        case 2: {
          v.flagA = false;
          v.useIdx = (int8_t)structure::create(structure::T_CAMPFIRE, 1, ms);
          if (v.useIdx < 0) { startLeave(ms); return; }
          structure::setLit(v.useIdx, true);
          structure::setUse(v.useIdx, true);
          journal::add(journal::J_S_CAMP);
          history::note(history::H_CAMP, SITES[1].x);
          v.aux = (int8_t)structure::freeSite(structure::T_TENT);
          if (v.aux >= 0) walkTo(SITES[v.aux].x + 10, SITES[v.aux].y + 1);
          else { v.step = 3; advance(ms); return; }
          break;
        }
        case 3: v.flagA = true; act(P_CROUCH, 8, 10); break;
        case 4:
          v.flagA = false;
          if (v.aux >= 0) structure::create(structure::T_TENT, v.aux, ms);
          walkTo(SITES[1].x + 14, SITES[1].y + 1);
          break;
        case 5: v.flagB = false; act(P_CROUCH, 40, 80); break;  // 坐在營火旁 (森林互動在 update)
        case 6:
          journal::add(journal::J_S_SLEEP, 0xFF, false);
          act(P_SLEEP, 40, 70);
          if (eco::env.night > 0.5f && util::rng.chance(0.6f)) {
            creature::visitPoint(creature::C_SPRITE, v.x + 10, v.y - 16, ms, 50000);
            journal::add(journal::J_I_SPRITE_WATCH);
          }
          break;
        default: startLeave(ms); break;
      }
      break;
    // ---------- 迷路 ----------
    case S_LOST:
      switch (v.step) {
        case 0: journal::add(journal::J_S_LOST); walkTo(rnd(170, 220), groundAt(200)); break;
        case 1: case 3: v.flip = !v.flip; act(P_STAND, 2, 3); break;
        case 2: walkTo(rnd(20, 60), groundAt(40) + rnd(0, 8)); break;
        case 4: walkTo(rnd(90, 150), groundAt(120) + rnd(0, 6)); break;
        case 5:
          v.aux = util::rng.chance(0.45f) ? (int8_t)structure::freeSite(structure::T_SIGN) : (int8_t)-1;
          if (v.aux >= 0) walkTo(SITES[v.aux].x + 8, SITES[v.aux].y + 1);
          else { startLeave(ms); return; }
          break;
        case 6: v.flagA = true; act(P_CROUCH, 6, 8); break;
        case 7:
          v.flagA = false;
          if (structure::create(structure::T_SIGN, v.aux, ms) >= 0) journal::add(journal::J_S_SIGN, 0xFF, false);
          startLeave(ms);
          break;
        default: startLeave(ms); break;
      }
      break;
    // ---------- 發光蘑菇 ----------
    case S_GLOW:
      switch (v.step) {
        case 0: {
          int s = plant::randomSlotOf(plant::P_GLOW, plant::S_MATURE);
          if (s < 0) s = plant::randomSlotOf(plant::P_MUSHROOM, plant::S_MATURE);
          if (s < 0) { startLeave(ms); return; }
          walkTo(plant::SLOTS[s].x + 12, plant::SLOTS[s].y + 8);
          break;
        }
        case 1: journal::add(journal::J_S_GLOWSHROOM); v.flagB = true; act(P_CROUCH, 10, 15); break;
        default: v.flagB = false; startLeave(ms); break;
      }
      break;
    // ---------- 追小精靈 ----------
    case S_CHASE:
      switch (v.step) {
        case 0: {
          float sx, sy;
          if (!creature::find(creature::C_SPRITE, sx, sy)) creature::visitPoint(creature::C_SPRITE, 160, 165, ms, 60000);
          journal::add(journal::J_S_CHASE_SPRITE);
          follow(creature::C_SPRITE, 12, 16);
          break;
        }
        case 1:
          creature::hideInHollow(creature::C_SPRITE, ms);
          journal::add(journal::J_S_SPRITE_HOLLOW);
          walkTo(scene::HOLLOW_X + 16, groundAt(scene::HOLLOW_X + 16));
          break;
        case 2: v.flip = true; act(P_STAND, 4, 6); break;
        default: startLeave(ms); break;
      }
      break;
    // ---------- 研究古代石碑 ----------
    case S_STUDY:
      switch (v.step) {
        case 0: {
          int a = structure::find(structure::T_ALTAR);
          if (a < 0) { startLeave(ms); return; }
          v.aux = (int8_t)a;
          walkTo(SITES[structure::at(a).site].x + 12, SITES[structure::at(a).site].y + 1);
          break;
        }
        case 1: journal::add(journal::J_S_STUDY); structure::setUse(v.aux, true); act(P_CROUCH, 15, 25); break;
        default:
          structure::setUse(v.aux, false);
          if (util::rng.chance(0.3f)) structure::glowAltar(ms);
          startLeave(ms);
          break;
      }
      break;
    // ---------- 故事 B：獵人的追蹤 ----------
    case S_HUNT:
      switch (v.step) {
        case 0: walkTo(rnd(50, 100), groundAt(80) + 2); break;
        case 1: {
          float cx, cy;
          v.flagB = false;  // 足跡是否被雨沖掉
          if (creature::find(creature::C_CRITTER, cx, cy)) {
            journal::add(journal::J_S_TRACKS);
            addTracks(v.x, v.y, cx, cy);
            follow(creature::C_CRITTER, 10, 15);
          } else { v.step = 1; advance(ms); return; }  // 沒有獵物 → 直接進入下一步
          break;
        }
        case 2: {
          int n = creature::hideFrom(v.x, 110, ms);
          if (n > 0) journal::add(journal::J_S_HIDE);
          act(P_STAND, 3, 4);
          break;
        }
        case 3:
          v.aux = (int8_t)structure::freeSite(structure::T_TRAP);
          if (v.aux >= 0) walkTo(SITES[v.aux].x - 10, SITES[v.aux].y + 1);
          else { v.step = 4; advance(ms); return; }
          break;
        case 4:
          if (v.aux >= 0) { v.flagA = true; act(P_CROUCH, 8, 10); }
          else act(P_STAND, 1, 2);
          break;
        case 5:
          v.flagA = false;
          if (v.aux >= 0) {
            v.useIdx = (int8_t)structure::create(structure::T_TRAP, v.aux, ms);
            if (v.useIdx >= 0) { journal::add(journal::J_S_TRAP, 0xFF, false); history::note(history::H_TRAP, SITES[v.aux].x); }
          }
          act(P_STAND, 40, 80);  // 等待 (下雨會沖掉足跡，見 update)
          break;
        case 6: {
          const bool canCapture = (now - stats.lastCapture > util::shortS(3 * 86400.0f)) && eco::env.rain < 0.2f &&
                                  (creature::count(creature::C_CRITTER) + creature::count(creature::C_SNAIL)) > 0;
          float r = util::rng.f();
          if (v.flagB) {
            // 足跡被沖掉：找不到目標
          } else if (canCapture && r < 0.25f) {
            if (!creature::captureOne(creature::C_SNAIL)) creature::captureOne(creature::C_CRITTER);
            stats.lastCapture = now;
            if (v.useIdx >= 0) structure::at(v.useIdx).flags |= structure::F_TRIGGERED;
            journal::add(journal::J_S_CAPTURE);
          } else if (v.useIdx >= 0 && r < 0.6f) {
            structure::Structure& t = structure::at(v.useIdx);
            t.flags |= structure::F_TRIGGERED;
            t.decay = fmaxf(t.decay, 0.5f);
            journal::add(journal::J_S_TRAP_BROKEN);
          } else {
            journal::add(journal::J_S_NOTHING);
          }
          v.useIdx = -1;
          act(P_STAND, 2, 3);
          break;
        }
        default: after = A_PREY_RETURN; afterAt = ms + (uint32_t)rnd(30, 60) * 1000; startLeave(ms); break;
      }
      break;
    // ---------- 事件指定的任務 (第三階段) ----------
    case S_TASK:
      switch (v.step) {
        case 0: {
          int s = -1;
          float tx = rnd(40, 200), ty = groundAt(120) + rnd(0, 6);
          switch (v.task) {
            case TK_CHOP: s = plant::randomSlotOf(plant::P_SAPLING, plant::S_MATURE); break;
            case TK_MUSHROOM: s = plant::randomSlotOf(plant::P_MUSHROOM, plant::S_MATURE); break;
            case TK_RAREPLANT:
              for (int i = 0; i < plant::SLOT_N && s < 0; i++) if (plant::get(i).species != plant::P_NONE && (plant::get(i).variant & 0x10)) s = i;
              if (s < 0) s = plant::randomSlotOf(plant::P_GLOW, plant::S_BLOOM);
              break;
            case TK_EXPLORE: {  // 變體：附近有遺跡就先去遺跡
              int r = ruins::excavated();
              if (r >= 0) { int rx, ry; ruins::pos(r, rx, ry); tx = rx + 14; ty = ry + 1; }
              break;
            }
            case TK_TRACK: {
              float cx, cy;
              if (creature::find(creature::C_CRITTER, cx, cy)) { addTracks(v.x, v.y, cx, cy); follow(creature::C_CRITTER, 10, 14); return; }
              break;
            }
            case TK_TRADE: tx = rnd(170, 210); ty = groundAt(190) + 2; break;
          }
          v.aux = (int8_t)s;
          if (s >= 0) { tx = plant::SLOTS[s].x + 12; ty = plant::SLOTS[s].y + 8; }
          walkTo(tx, ty);
          break;
        }
        case 1:
          if (v.task == TK_TRACK) { if (creature::hideFrom(v.x, 110, ms) > 0) journal::add(journal::J_S_HIDE); evo::fearHunter(60); act(P_STAND, 3, 4); break; }
          if (v.task == TK_TRADE) { creature::visitPoint(creature::C_CRITTER, v.x + 12, v.y, ms, 30000); act(P_STAND, 25, 35); break; }
          v.flagA = v.task == TK_CHOP || v.task == TK_MUSHROOM;
          v.flagB = v.task == TK_RAREPLANT;
          act(P_CROUCH, v.task == TK_EXPLORE ? 4 : 8, v.task == TK_EXPLORE ? 6 : 14);
          break;
        case 2:
          v.flagA = v.flagB = false;
          if (v.task == TK_CHOP && v.aux >= 0 && plant::get(v.aux).species == plant::P_SAPLING) {
            plant::mut(v.aux).species = plant::P_NONE;  // 砍下小樹
            if (!plant::hasLog()) plant::formLog();
            evo::addTerrain(evo::TF_CLEAR, plant::SLOTS[v.aux].x, 0.5f);
            journal::add(journal::J_T_CLEARING);
          } else if (v.task == TK_MUSHROOM && v.aux >= 0 && plant::get(v.aux).species == plant::P_MUSHROOM) {
            plant::mut(v.aux).species = plant::P_NONE;  // 採走蘑菇
          } else if (v.task == TK_EXPLORE) {
            walkTo(rnd(30, 210), groundAt(120) + rnd(0, 6));  // 繼續探索一段
            v.step = 3;
            return;
          }
          startLeave(ms);
          break;
        case 4: v.flip = !v.flip; act(P_STAND, 2, 4); break;  // 四處張望
        default: startLeave(ms); break;
      }
      break;
    // ---------- 故事：失落文明 (挖掘遺跡) ----------
    case S_DIG:
      switch (v.step) {
        case 0: {
          int i = ruins::exposed();
          if (i < 0) { startLeave(ms); return; }
          v.aux = (int8_t)i;
          int x, y; ruins::pos(i, x, y);
          walkTo(x + (x < 120 ? 14 : -14), y + 1);
          break;
        }
        case 1: eventm::trigger(eventm::A_DIG, ms, true); act(P_STAND, 3, 4); break;  // 注意到異常
        case 2: v.flagA = true; act(P_CROUCH, 20, 30); break;  // 挖掘
        case 3:
          v.flagA = false;
          ruins::excavate(v.aux, ms);
          ruins::study(v.aux);
          journal::add(journal::J_X_STUDY_RUIN, 0xFF, false);
          act(P_CROUCH, 10, 15);
          break;
        case 4: ruins::mark(v.aux); journal::add(journal::J_X_MARK, 0xFF, false); act(P_CROUCH, 3, 4); break;
        default: startLeave(ms); break;
      }
      break;
    // ---------- 重返遺跡 (歷史影響：曾經發現遺跡的地方會再被探索) ----------
    case S_REVISIT:
      switch (v.step) {
        case 0: {
          int i = ruins::excavated();
          if (i < 0) { startLeave(ms); return; }
          v.aux = (int8_t)i;
          int x, y; ruins::pos(i, x, y);
          journal::add(journal::J_X_REVISIT);
          walkTo(x + (x < 120 ? 14 : -14), y + 1);
          break;
        }
        case 1: ruins::study(v.aux); act(P_CROUCH, 12, 20); break;
        default:
          if (ruins::at(v.aux).type == ruins::R_GATE && util::rng.chance(0.3f)) ruins::glow(v.aux, ms);
          startLeave(ms);
          break;
      }
      break;
    // ---------- 旅行商人 ----------
    case S_MERCHANT:
      switch (v.step) {
        case 0:
          v.aux = (int8_t)structure::freeSite(structure::T_STALL);
          if (v.aux >= 0) walkTo(SITES[v.aux].x - 14, SITES[v.aux].y + 2);
          else walkTo(rnd(180, 220), groundAt(200));
          break;
        case 1: v.flagA = v.aux >= 0; act(P_CROUCH, 10, 14); break;
        case 2:
          v.flagA = false;
          if (v.aux >= 0) v.useIdx = (int8_t)structure::create(structure::T_STALL, v.aux, ms);
          structure::setUse(v.useIdx, true);
          journal::add(journal::J_S_STALL);
          act(P_STAND, 50, 80);
          break;
        case 3: act(P_CROUCH, 40, 60); break;  // 整理貨物
        case 4: act(P_SLEEP, 25, 35); break;   // 休息
        case 5: v.flagA = true; act(P_CROUCH, 6, 8); break;  // 收攤
        default: {
          v.flagA = false;
          if (v.useIdx >= 0) {
            if (util::rng.chance(0.5f)) structure::remove(v.useIdx);  // 帶走攤位
            else structure::setUse(v.useIdx, false);                  // 留下攤位
          }
          v.useIdx = -1;
          if (util::rng.chance(0.5f)) {
            int s = structure::freeSite(structure::T_CRATE);
            if (s >= 0) afterIdx = (int8_t)structure::create(structure::T_CRATE, s, ms);
          }
          after = A_EXPLORE;
          afterAt = ms + (uint32_t)rnd(30, 60) * 1000;
          startLeave(ms);
          break;
        }
      }
      break;
    // ---------- 神祕旅人 ----------
    case S_MYSTIC:
      switch (v.step) {
        case 0: {
          // 有古代石門時，神祕旅人常常前往石門
          int g = ruins::find(ruins::R_GATE);
          if (g >= 0 && util::rng.chance(0.6f)) { int gx, gy; ruins::pos(g, gx, gy); v.aux = (int8_t)g; walkTo(gx + 14, gy + 1); break; }
          v.aux = -1;
          int r = util::rng.irange(0, 2);
          int s = plant::randomSlotOf(plant::P_MUSHROOM, plant::S_MATURE);
          if (r == 0 || (r == 2 && s < 0)) walkTo(scene::TRUNK_X + 22, groundAt(scene::TRUNK_X + 22));
          else if (r == 1) walkTo(134, 198);
          else walkTo(plant::SLOTS[s].x + 12, plant::SLOTS[s].y + 8);
          break;
        }
        case 1:
          journal::add(journal::J_S_RITUAL); v.flagB = true; act(P_CROUCH, 30, 50);
          if (v.aux >= 0) eventm::trigger(eventm::A_GATE_GLOW, ms, true);  // 石門的符文亮起
          break;
        default:
          v.flagB = false;
          if (util::rng.chance(0.4f)) {
            static const eventm::EvId MYST[] = {eventm::M_RUNES, eventm::R_ANCIENT, eventm::M_EYES, eventm::R_DEEP_LIGHTS};
            eventm::trigger(MYST[util::rng.irange(0, 3)], ms, true);
          }
          after = A_ALTAR;
          afterAt = ms + 20000;
          startLeave(ms);
          break;
      }
      break;
  }
}

void advance(uint32_t ms) {
  v.step++;
  beginStep(ms);
}

void startLeave(uint32_t ms) {
  // 冒險家偶爾遺落東西
  if (v.type == V_ADV && util::rng.chance(0.2f)) {
    int s = structure::freeSite(structure::T_ITEM);
    if (s >= 0 && structure::create(structure::T_ITEM, s, ms) >= 0) journal::add(journal::J_S_DROP, 0xFF, false);
  }
  if (v.story == S_CAMP && v.useIdx >= 0) { after = A_FIRE_OUT; afterAt = ms + 15000; afterIdx = v.useIdx; v.useIdx = -1; }
  if (v.useIdx >= 0) { structure::setUse(v.useIdx, false); v.useIdx = -1; }
  v.step = LEAVING;
  v.pose = P_STAND;
  v.alpha = 255;
  walkTo(v.x < 120 ? -18 : 258, v.y);
}

void finish(uint32_t ms) {
  static const journal::Msg LEAVE[V_COUNT] = {journal::J_V_LEAVE_ADV, journal::J_V_LEAVE_HUNTER, journal::J_V_LEAVE_MERCHANT, journal::J_V_LEAVE_MYSTIC};
  journal::add(LEAVE[v.type], 0xFF, false);
  v.on = false;
  // 下一位訪客至少要過 2~6 小時 (森林時間)，真實時間也至少 5 分鐘
  stats.nextAllowed = timem::now() + util::shortS(rnd(2, 6) * 3600);
  nextRealMs = ms + 300000;
  Serial.printf("[Visitor] %s left\n", STORY_NAMES[v.story]);
}

bool start(Story s, uint32_t ms) {
  static const journal::Msg ARRIVE[V_COUNT] = {journal::J_V_ADV, journal::J_V_HUNTER, journal::J_V_MERCHANT, journal::J_V_MYSTIC};
  v = {};
  v.on = true;
  v.story = s;
  v.type = STORY_TYPE[s];
  v.task = pendingTask;
  pendingTask = TK_NONE;
  if (s == S_TASK) v.type = v.task == TK_TRACK ? V_HUNTER : v.task == TK_TRADE ? V_MERCHANT : V_ADV;
  v.useIdx = -1;
  v.aux = -1;
  v.alpha = 255;
  bool left = util::rng.chance(0.5f);
  v.x = left ? -14 : 254;
  v.y = groundAt(left ? 10 : 230) + rnd(0, 4);
  v.flip = !left;
  const uint32_t now = timem::now();
  stats.lastType[v.type] = now;
  if (s < S_LEGACY) stats.lastStory[s] = now; else statsExt.lastStory[s - S_LEGACY] = now;
  history::note(history::H_VISITOR, (int)v.x, v.type);
  stats.lastTypeId = v.type;
  journal::add(ARRIVE[v.type]);
  Serial.printf("[Visitor] story %s\n", STORY_NAMES[s]);
  // 記憶：記得獵人的小動物會提前躲起來；獵人來過後恐懼加深
  if ((v.type == V_ADV || v.type == V_HUNTER) && evo::mem(creature::C_CRITTER).fear > 60) creature::hideFrom(120, 240, ms);
  if (v.type == V_HUNTER) evo::fearHunter(100);
  v.step = 0;
  beginStep(ms);
  return true;
}

float hoursSince(uint32_t t, uint32_t now) { return (t == 0 || t > now) ? 9999 : (now - t) / 3600.0f; }

// 依時間、天氣、季節與冷卻挑一個故事
int chooseStory(uint32_t now) {
  const eco::Env& e = eco::env;
  const uint8_t pm = timem::phaseMask();
  const bool day = pm & (PM_MORNING | PM_NOON | PM_AFTERNOON);
  const bool dusk = pm & (PM_DUSK | PM_NIGHT);
  float w[S_COUNT] = {0};
  auto cd = [&](int s, float h) { return hoursSince(storyTime(s), now) >= util::shortH(h); };  // 冷卻壓縮到 0.5~3 小時
  float adv = day ? 1.0f : (pm & PM_DUSK) ? 0.3f : 0.05f;  // 冒險家多在白天
  if (hoursSince(stats.lastType[V_ADV], now) >= util::shortH(4)) {
    if (cd(S_CABIN, 7 * 24) && structure::find(structure::T_CABIN) < 0 && structure::freeSite(structure::T_CABIN) == 0) w[S_CABIN] = 1.2f * adv;
    if (cd(S_CAMP, 48) && structure::freeSite(structure::T_CAMPFIRE) >= 0 && e.rain < 0.3f) w[S_CAMP] = 1.5f * ((pm & (PM_AFTERNOON | PM_DUSK)) ? 1.5f : 0.6f);
    if (cd(S_LOST, 12)) w[S_LOST] = 1.0f * adv;
    if (cd(S_GLOW, 12) && (plant::randomSlotOf(plant::P_GLOW, plant::S_MATURE) >= 0 || plant::matureMushrooms() > 0)) w[S_GLOW] = 1.2f * (adv + e.night * 0.5f);
    if (cd(S_CHASE, 24)) w[S_CHASE] = 0.8f * adv;
    if (cd(S_STUDY, 24) && structure::find(structure::T_ALTAR) >= 0) w[S_STUDY] = 2.0f * adv;
    if (cd(S_DIG, 12) && ruins::exposed() >= 0) w[S_DIG] = 3.0f * adv;              // 露出的石板吸引冒險家
    if (cd(S_REVISIT, 72) && ruins::excavated() >= 0) w[S_REVISIT] = 0.8f * adv;
  }
  if (cd(S_HUNT, 20) && !creature::awayUntil(creature::C_CRITTER) && (pm & (PM_DAWN | PM_MORNING | PM_AFTERNOON)) && season::weight(WINTER) < 0.7f) w[S_HUNT] = 1.0f;
  if (cd(S_MERCHANT, 20) && day && e.storm < 0.3f) w[S_MERCHANT] = 1.0f;
  if (cd(S_MYSTIC, 36) && dusk) w[S_MYSTIC] = (0.8f + e.magic + e.fog) * (ruins::gateHasRunes() ? 3.0f : 1.0f) * (eco::fullMoonNight() ? 1.5f : 1.0f);
  // 上一位是同類型的訪客 → 降低
  for (int s = 0; s < S_COUNT; s++) if (STORY_TYPE[s] == stats.lastTypeId) w[s] *= 0.4f;
  // 建築太多時，不再選會蓋東西的故事
  if (structure::count() >= structure::CAP - 1) { w[S_CABIN] *= 0.3f; w[S_CAMP] *= 0.3f; w[S_MERCHANT] *= 0.3f; }
  float total = 0;
  for (float x : w) total += x;
  if (total <= 0) return -1;
  float r = util::rng.f() * total;
  for (int s = 0; s < S_COUNT; s++) { r -= w[s]; if (r <= 0) return s; }
  return -1;
}

void handleAfter(uint32_t ms) {
  switch (after) {
    case A_FIRE_OUT:
      structure::setLit(afterIdx, false);
      structure::setUse(afterIdx, false);
      journal::add(journal::J_B_FIRE_OUT, 0xFF, false);
      break;
    case A_PREY_RETURN: {
      // 獵人走後，小動物重新出現
      creature::visitPoint(creature::C_CRITTER, rnd(60, 120), groundAt(90) + 4, ms, 90000);
      journal::add(journal::J_S_RETURN);
      break;
    }
    case A_EXPLORE: {
      if (afterIdx >= 0 && structure::at(afterIdx).type == structure::T_CRATE) {
        const auto& s = SITES[structure::at(afterIdx).site];
        creature::visitPoint(creature::C_SNAIL, s.x + 6, s.y - 4, ms, 120000);
        journal::add(journal::J_I_SNAIL_CRATE);
      } else {
        creature::visitPoint(creature::C_CRITTER, rnd(150, 220), groundAt(200) + 4, ms, 60000);
        journal::add(journal::J_S_EXPLORE);
      }
      break;
    }
    case A_ALTAR: {
      int s = structure::freeSite(structure::T_ALTAR);
      if (structure::find(structure::T_ALTAR) < 0 && s >= 0 && util::rng.chance(0.5f)) {
        structure::create(structure::T_ALTAR, s, ms);
        journal::add(journal::J_S_ALTAR);
      } else {
        eventm::trigger(eventm::M_RUNES, ms, true);  // 留下短暫的魔法痕跡
      }
      break;
    }
    default: break;
  }
  after = A_NONE;
  afterIdx = -1;
}
}  // namespace

void begin(uint32_t ms) {
  v.on = false;
  for (auto& t : tracks) t.life = 0;
  stats = {};
  statsExt = {};
  stats.nextAllowed = timem::now() + 3600;  // 新森林：先安靜一小時
  nextRealMs = ms + 180000;
}

void tick(uint32_t ms) {
  if (after != A_NONE && util::reached(ms, afterAt)) handleAfter(ms);
  if (v.on) return;
  const uint32_t now = timem::now();
  if (now < stats.nextAllowed || !util::reached(ms, nextRealMs)) return;
  // 低頻率：天氣不好時更少 (但不完全禁止)
  const eco::Env& e = eco::env;
  float p = 0.035f * (e.storm > 0.5f ? 0.08f : e.rain > 0.2f ? 0.3f : 1.0f) * (e.cold ? 0.6f : 1.0f);
  if (!util::rng.chance(p)) return;
  int s = chooseStory(now);
  if (s >= 0) start((Story)s, ms);
  else stats.nextAllowed = now + 1800;
}

void update(float dt, uint32_t ms) {
  for (auto& t : tracks) if (t.life > 0) t.life -= dt * (eco::env.rain > 0.2f ? 25 : 1);  // 雨水沖掉足跡
  if (!v.on) return;
  v.phase += dt * (v.walking ? 7.0f : 1.5f);
  // 進屋 → 淡出；出來 → 淡入
  if (v.pose == P_HIDDEN && !v.walking) v.alpha = (uint8_t)fmaxf(0, v.alpha - dt * 300);
  else v.alpha = (uint8_t)fminf(255, v.alpha + dt * 300);

  if (v.following) {
    float fx_, fy_;
    if (creature::find((creature::Species)v.followSp, fx_, fy_)) { v.tx = util::clamp(fx_ - (fx_ > v.x ? 20 : -20), 0.0f, 240.0f); v.ty = fmaxf(groundAt(fx_), 192.0f); }
    if (util::reached(ms, v.until)) { v.following = false; v.walking = false; advance(ms); return; }
  }
  if (v.walking) {
    float speed = v.type == V_MERCHANT ? 10 : v.following ? 18 : 13;
    float dx = v.tx - v.x, dy = v.ty - v.y, d = sqrtf(dx * dx + dy * dy);
    if (fabsf(dx) > 0.5f) v.flip = dx < 0;
    if (d < 1.0f) {
      v.x = v.tx; v.y = v.ty;
      if (!v.following) {
        v.walking = false;
        if (v.step == LEAVING) { finish(ms); return; }
        advance(ms);
        return;
      }
    } else {
      float st = fminf(speed * dt, d);
      v.x += dx / d * st; v.y += dy / d * st;
    }
    return;
  }
  // 停留中的效果
  if (v.flagA && util::rng.chance(dt * 4)) fx::spawn(fx::PT_SPARKLE, v.x + (v.flip ? -8 : 8), v.y - 4, rnd(-8, 8), rnd(-14, -4), 500, 0xD2AA6E);  // 木屑
  if (v.flagB && v.story == S_MYSTIC && util::rng.chance(dt * 5)) fx::spawn(fx::PT_MAGIC, v.x + rnd(-10, 10), v.y - rnd(0, 20), 0, -6, 1600, 0x8CB4FF);
  if (v.flagB && v.story == S_GLOW && util::rng.chance(dt * 2)) fx::spawn(fx::PT_SPARKLE, v.x + (v.flip ? -10 : 10), v.y - 6, 0, -5, 900, 0x8CFFDC);
  if (v.pose == P_SLEEP && util::rng.chance(dt * 0.4f)) fx::spawn(fx::PT_ZZZ, v.x + 4, v.y - 22, 2, -5, 2500, 0);
  // 營火旁的森林互動 (只發生一次)
  if (v.story == S_CAMP && v.step == 5 && !v.flagB && ms + 20000 > v.until) {
    v.flagB = true;
    if (eco::env.night > 0.5f) {
      creature::gatherFireflies(SITES[1].x, SITES[1].y - 16, ms, 5);
      journal::add(journal::J_I_FIREFLY_FIRE);
    } else if (util::rng.chance(0.6f)) {
      creature::visitPoint(creature::C_BIRD, v.x + (v.flip ? 4 : -4), v.y - 18, ms, 30000);
      journal::add(journal::J_I_BIRD_BAG);
    }
  }
  // 獵人等待時下雨：足跡被沖掉，提早結束
  if (v.story == S_HUNT && v.step == 5 && !v.flagB && eco::env.rain > 0.3f && anyTracks()) {
    v.flagB = true;
    clearTracks();
    journal::add(journal::J_S_WASHED);
    v.until = ms + 3000;
  }
  if (util::reached(ms, v.until)) advance(ms);
}

void draw(int yMin, int yMax) {
  if (!v.on || v.alpha == 0 || v.y < yMin || v.y >= yMax) return;
  const bool w = gfx::world;
  gfx::world = false;
  const int x = (int)v.x >> 1, y = (int)v.y >> 1;
  // 和生物一樣的比例：精靈圖一格 = CREATURE_PX 顆螢幕像素，身體與配件都以腳底 (x,y) 為中心縮放。
  // 配件以「精靈圖格子」為單位 (px,py 是畫布座標)，用細緻模式畫在原生像素上
  const int sc = cfg::CREATURE_PX;
  const int X = x * 2, Y = y * 2;
  auto SP = [&](int px, int py, uint16_t c) { gfx::Fine f; gfx::fillRect(X + (px - x) * sc, Y + (py - y) * sc, sc, sc, c); };
  auto SB = [&](int px, int py, uint16_t c, uint8_t a) { gfx::Fine f; gfx::blendRect(X + (px - x) * sc, Y + (py - y) * sc, sc, sc, c, a); };
  auto SG = [&](int px, int py, int r, uint32_t col, uint8_t in) { gfx::glow(x + (px - x) * sc / 2, y + (py - y) * sc / 2, r * sc / 2, col, in); };
  int fr = v.walking ? (((int)v.phase) & 1) : (v.pose == P_STAND ? 2 : 3);
  const uint32_t* pal = spr::HUMAN_PAL[v.type];
  // 商人走路時拉著小推車 (在身後)
  if (v.type == V_MERCHANT && (v.walking || v.step < 2)) {
    int cx = v.flip ? x + 4 : x - 12;
    for (int j = 0; j < 4; j++) for (int i = 0; i < 8; i++) SP(cx + i, y - 6 + j, gfx::lit(j == 0 ? 0xC8A064 : 0x8C6440));
    SP(cx + 1, y - 1, gfx::lit(0x3A2A20)); SP(cx + 6, y - 1, gfx::lit(0x3A2A20));
    SP(cx + 3, y - 7, gfx::lit(0x6EC8E6)); SP(cx + 5, y - 7, gfx::lit(0xE6C850));
  }
  gfx::spritePx = sc;
  gfx::sprite(spr::HUMAN, fr, x - 4, y - 12, v.flip, pal, v.type != V_MYSTIC, v.alpha);
  gfx::spritePx = 0;
  int hx = v.flip ? x - 4 : x + 3;  // 前手位置
  // 通用變體：夜晚拿火把、下雨撐傘
  if (v.alpha > 120 && (v.type == V_ADV || v.type == V_HUNTER) && eco::env.night > 0.5f) {
    SP(hx, y - 7, gfx::lit(0x6E4E32)); SP(hx, y - 8, gfx::rgb(0xFFC850));
    SG(hx, y - 9, 6, 0xFF9A3C, (uint8_t)(150 + 30 * sinf(v.phase * 3)));
  }
  if (v.alpha > 120 && (v.type == V_ADV || v.type == V_MERCHANT) && eco::env.rain > 0.25f) {
    const uint32_t uc = v.type == V_MERCHANT ? 0x8C3C78 : 0x3C6EA0;
    for (int k = -3; k <= 3; k++) SP(x + k, y - 14 + (abs(k) == 3), gfx::lit(uc));
    SP(x, y - 13, gfx::lit(0x5A4632)); SP(x, y - 12, gfx::lit(0x5A4632));
  }
  if (v.alpha > 120) {
    if (v.type == V_HUNTER) {  // 弓
      int bx = v.flip ? x - 5 : x + 4;
      for (int i = 0; i < 7; i++) SP(bx + ((i == 0 || i == 6) ? 0 : (v.flip ? -1 : 1)), y - 11 + i, gfx::lit(0x7A4A28));
      for (int i = 1; i < 6; i++) SB(bx, y - 11 + i, gfx::lit(0xDCDCC8), 140);
    } else if (v.type == V_MYSTIC) {  // 發光提燈
      SG(hx, y - 6, 5, 0x8CDCFF, (uint8_t)(120 + 60 * sinf(v.phase)));
      SP(hx, y - 6, gfx::rgb(0xE6FFFF));
    } else if (v.type == V_ADV && fr == 2) {  // 地圖
      SP(hx, y - 8, gfx::lit(0xF0E6C8)); SP(hx, y - 9, gfx::lit(0xF0E6C8));
    }
  }
  gfx::world = w;
}

void drawTracks() {
  const bool w = gfx::world;
  gfx::world = false;
  for (auto& t : tracks) {
    if (t.life <= 0) continue;
    uint8_t a = (uint8_t)(t.life > 60 ? 140 : t.life * 140 / 60);
    gfx::pblend((int)t.x >> 1, (int)t.y >> 1, gfx::lit(0x4A3A28), a);
  }
  gfx::world = w;
}

bool active() { return v.on; }
bool canStart(uint32_t ms) { return !v.on && util::reached(ms, nextRealMs); }
bool startStory(uint8_t story, uint8_t task, uint32_t ms) {
  if (story >= S_COUNT || !canStart(ms)) return false;
  pendingTask = task;
  return start((Story)story, ms);
}
uint8_t activeType() { return v.on ? v.type : V_COUNT; }
bool position(float& x, float& y) { if (!v.on || v.alpha < 100) return false; x = v.x; y = v.y; return true; }
uint32_t lastTypeTime(uint8_t t) { return t < V_COUNT ? stats.lastType[t] : 0; }
bool force(int s, uint32_t ms) {
  if (s < 0 || s >= S_COUNT) return false;
  if (v.on) finish(ms);
  return start((Story)s, ms);
}
const char* storyName(uint8_t s) { return s < S_COUNT ? STORY_NAMES[s] : "?"; }
void exportStats(Stats& s) { s = stats; }
void importStats(const Stats& s) { stats = s; }
void exportExt(StatsExt& s) { s = statsExt; }
void importExt(const StatsExt& s) { statsExt = s; }

}  // namespace visitor
