#include "EventMemory.h"
#include <math.h>
#include <string.h>

namespace evmem {
namespace {
Rec hist[HIST];
uint8_t histHead = 0, histN = 0;
uint32_t last[MAX_EVENTS];
uint16_t times[MAX_EVENTS];
uint32_t catLast[CATS];
}  // namespace

void begin(uint32_t now) {
  memset(hist, 0, sizeof(hist));
  histHead = histN = 0;
  memset(last, 0, sizeof(last));
  memset(times, 0, sizeof(times));
  for (auto& c : catLast) c = now;
}

void record(uint8_t id, uint8_t cat, uint32_t now) {
  if (id >= MAX_EVENTS || cat >= CATS) return;
  hist[histHead] = {id, now};
  histHead = (histHead + 1) % HIST;
  if (histN < HIST) histN++;
  last[id] = now;
  if (times[id] < 65535) times[id]++;
  catLast[cat] = now;
}

float penalty(uint8_t id, uint32_t now) {
  // 每一次近期出現都讓權重下降；時間常數 3 小時 (森林時間)
  float sum = 0;
  for (int i = 0; i < histN; i++) {
    const Rec& r = hist[i];
    if (r.id != id || r.epoch > now) continue;
    sum += expf(-((now - r.epoch) / 3600.0f) / 3.0f);
  }
  // 上一個事件剛好是同一個 → 再大幅降低
  if (histN && hist[(histHead + HIST - 1) % HIST].id == id) sum += 2;
  return 1.0f / (1.0f + sum * 1.5f);
}

float catHunger(uint8_t cat, uint32_t now) {
  if (cat >= CATS || catLast[cat] > now) return 1;
  float h = (now - catLast[cat]) / 3600.0f;
  return 1.0f + fminf(h, 6.0f) * 0.25f;
}

uint32_t lastTime(uint8_t id) { return id < MAX_EVENTS ? last[id] : 0; }
uint16_t timesSeen(uint8_t id) { return id < MAX_EVENTS ? times[id] : 0; }
uint8_t lastId() { return histN ? hist[(histHead + HIST - 1) % HIST].id : 0xFF; }
uint8_t lastCat() {
  uint8_t best = 0;
  for (uint8_t c = 1; c < CATS; c++) if (catLast[c] > catLast[best]) best = c;
  return best;
}

void exportBlob(Blob& b) {
  memcpy(b.hist, hist, sizeof(hist));
  b.histHead = histHead; b.histN = histN;
  memcpy(b.last, last, sizeof(b.last));
  memcpy(b.times, times, sizeof(b.times));
  memcpy(b.catLast, catLast, sizeof(catLast));
}
void importBlob(const Blob& b) {
  memcpy(hist, b.hist, sizeof(hist));
  histHead = b.histHead % HIST; histN = b.histN > HIST ? HIST : b.histN;
  memcpy(last, b.last, sizeof(b.last));
  memcpy(times, b.times, sizeof(b.times));
  memcpy(catLast, b.catLast, sizeof(catLast));
}
void exportExt(BlobExt& b) {
  memcpy(b.last, last + LEGACY_EVENTS, sizeof(b.last));
  memcpy(b.times, times + LEGACY_EVENTS, sizeof(b.times));
}
void importExt(const BlobExt& b) {
  memcpy(last + LEGACY_EVENTS, b.last, sizeof(b.last));
  memcpy(times + LEGACY_EVENTS, b.times, sizeof(b.times));
}

}  // namespace evmem
