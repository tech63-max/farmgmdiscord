// 玩家按鈕互動 (玩家是觀察者，不是管理者)
//   PLUS 短按：自然祝福 (魔法細雨)   PLUS 雙擊：森林微風   PLUS 長按：魔法脈動
//   BOOT 短按：短暫顯示時間/天氣     PWR 短按：觀察日誌 (再按翻頁)   PWR 長按 2 秒：關機 (電池供電時)
//   BOOT + PLUS 同時長按 1.5 秒：開/關 Wi-Fi 設定熱點
//   BOOT + PWR  同時長按 1.5 秒：顯示/隱藏 UI (時鐘、事件提示)
#pragma once
#include <stdint.h>

namespace input {

enum Action : uint8_t { A_NONE, A_BLESS, A_BREEZE, A_PULSE, A_INFO, A_JOURNAL, A_POWEROFF, A_WIFI_SETUP, A_TOGGLE_UI };

void begin(uint32_t ms);
Action poll(uint32_t ms);             // 每幀呼叫，回傳一個動作
bool apply(Action a, uint32_t ms);    // 森林互動 (含冷卻)；false = 冷卻中
uint32_t restingUntil();              // 冷卻提示用

}  // namespace input
