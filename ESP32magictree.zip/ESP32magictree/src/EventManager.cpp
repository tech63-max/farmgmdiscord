#include "EventManager.h"
#include <Arduino.h>
#include <math.h>
#include "Config.h"
#include "CreatureManager.h"
#include "Ecosystem.h"
#include "EventMemory.h"
#include "Journal.h"
#include "Particles.h"
#include "PlantManager.h"
#include "Scene.h"
#include "SeasonManager.h"
#include "TimeManager.h"
#include "Util.h"
#include "Families.h"
#include "ForestHistory.h"
#include "Ruins.h"
#include "StructureManager.h"
#include "Underground.h"
#include "Village.h"
#include "EventRecipes.h"

namespace eventm {
namespace {
using namespace creature;
using journal::Msg;

struct Follow { uint8_t id; uint8_t pct; uint16_t delayS; };
struct Def {
  uint8_t cat;
  Msg msg;
  float weight;
  uint32_t cooldownS;  // 森林時間
  uint16_t durS;       // 視覺持續 (真實秒)
  int8_t species;      // 相關物種 (太久沒出現時加權)，-1 = 無
  Follow next[2];
};
constexpr uint8_t NO = 0xFF;
const Def DEFS[] = {
    // 日常
    {CAT_DAILY, journal::J_EV_BUTTERFLY, 10, 25 * 60, 40, C_BUTTERFLY, {{V_POLLEN, 20, 30}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_EV_BIRD_LAND, 10, 25 * 60, 40, C_BIRD, {{I_TWIG, 25, 40}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_EV_SNAIL_ROCK, 8, 60 * 60, 120, C_SNAIL, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_EV_ACORN, 7, 40 * 60, 8, C_CRITTER, {{I_CHASE, 12, 20}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_EV_SPRITE_NAP, 8, 60 * 60, 90, C_SPRITE, {{I_SPRITE_GATHER, 15, 60}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_EV_DEW, 10, 6 * 3600, 20, -1, {{E_BIRD_LAND, 30, 20}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_EV_SHROOM_EMERGE, 9, 50 * 60, 60, C_SHROOM, {{E_FIREFLY_GATHER, 55, 40}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_EV_FIREFLY_GATHER, 9, 50 * 60, 60, C_FIREFLY, {{R_GLOW_BUTTERFLY, 8, 60}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_EV_MOSS_SPREAD, 8, 3 * 3600, 15, -1, {{E_SHROOM_EMERGE, 30, 120}, {NO, 0, 0}}},
    // 稀有
    {CAT_RARE, journal::J_EV_METEOR, 1.4f, 5 * 3600, 3, -1, {{M_STARSIGN, 15, 8}, {R_DEEP_LIGHTS, 10, 20}}},
    {CAT_RARE, journal::J_EV_DEER, 0.8f, 18 * 3600, 60, C_DEER, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_EV_GLOW_BUTTERFLY, 1.0f, 10 * 3600, 45, C_GLOWMOTH, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_EV_ANCIENT, 0.6f, 24 * 3600, 25, -1, {{R_GLOW_BUTTERFLY, 25, 10}, {M_EYES, 20, 30}}},
    {CAT_RARE, journal::J_EV_DEEP_LIGHTS, 1.0f, 8 * 3600, 30, -1, {{M_VISITOR, 12, 20}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_EV_RAINBOW, 2.0f, 8 * 3600, 90, -1, {{E_BUTTERFLY, 40, 30}, {NO, 0, 0}}},
    // 生物互動
    {CAT_INTERACT, journal::J_EV_CHASE, 5, 90 * 60, 25, C_CRITTER, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_EV_TWIG, 6, 60 * 60, 60, C_BIRD, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_EV_BUTTERFLY_SHROOM, 5, 2 * 3600, 40, C_BUTTERFLY, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_EV_FROG_HUNT, 5, 90 * 60, 30, C_FROG, {{V_RIPPLES, 30, 10}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_EV_SPRITE_GATHER, 4, 3 * 3600, 60, C_SPRITE, {{NO, 0, 0}, {NO, 0, 0}}},
    // 環境
    {CAT_ENV, journal::J_EV_GUST, 6, 40 * 60, 10, -1, {{E_ACORN, 35, 4}, {V_POLLEN, 30, 6}}},
    {CAT_ENV, journal::J_EV_DEADWOOD, 2, 3 * 24 * 3600, 6, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_EV_RIPPLES, 6, 40 * 60, 15, -1, {{V_FISH, 20, 8}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_EV_FOG_ROLL, 4, 6 * 3600, 120, -1, {{R_DEER, 12, 30}, {M_VISITOR, 8, 40}}},
    {CAT_ENV, journal::J_EV_POLLEN, 5, 60 * 60, 15, -1, {{E_BUTTERFLY, 25, 15}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_EV_FISH, 5, 50 * 60, 3, -1, {{V_RIPPLES, 15, 3}, {NO, 0, 0}}},
    // 神秘
    {CAT_MYSTERY, journal::J_EV_RUNES, 0.8f, 10 * 3600, 25, -1, {{M_PORTAL, 15, 15}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_EV_EYES, 1.0f, 8 * 3600, 15, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_EV_PORTAL, 0.3f, 24 * 3600, 30, -1, {{M_VISITOR, 60, 6}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_EV_STARSIGN, 0.7f, 12 * 3600, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_EV_VISITOR, 0.6f, 12 * 3600, 30, C_VISITOR, {{NO, 0, 0}, {NO, 0, 0}}},
    // ---- 第二階段 ----
    {CAT_DAILY, journal::J_E_BEES, 7.0f, 3600, 40, C_BEE, {{V_POLLEN, 20, 20}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_I_SQUIRREL, 6.0f, 7200, 60, C_SQUIRREL, {{I_FOOD_STEAL, 25, 45}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_I_SNAIL_MUSH, 4.0f, 10800, 90, C_SNAIL, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_I_SPRITE_OBSERVE, 4.0f, 10800, 40, C_SPRITE, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_I_FOOD_FIGHT, 3.0f, 21600, 30, C_SQUIRREL, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_I_FOOD_STEAL, 3.0f, 28800, 40, C_CRITTER, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_I_SHARE_HOME, 0.0f, 43200, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_U_HOLE, 4.0f, 43200, 30, C_MOLE, {{U_PEEK, 40, 40}, {U_CARRY, 30, 70}}},
    {CAT_DAILY, journal::J_U_PEEK, 5.0f, 7200, 25, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_U_POOL, 3.0f, 43200, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_U_MYCELIUM, 3.0f, 36000, 25, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_U_CARRY, 4.0f, 14400, 40, C_MOLE, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_U_EYES, 1.0f, 86400, 15, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_U_FLOOD_RELOCATE, 0.0f, 86400, 10, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_U_MUSH_HOLE, 0.0f, 86400, 10, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_U_FOUNDATION, 2.0f, 172800, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_U_HIDDEN, 0.0f, 86400, 10, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_U_FIREFLY_CAVE, 3.0f, 28800, 30, C_FIREFLY, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_A_EROSION, 2.0f, 172800, 10, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_A_DIG, 0.0f, 3600, 10, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_A_STELE, 0.0f, 3600, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_A_GATE, 0.0f, 3600, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_A_CHEST, 0.0f, 3600, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_A_GATE_GLOW, 0.8f, 129600, 30, -1, {{R_ANCIENT, 30, 20}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_A_RUIN_GLOW, 1.0f, 72000, 25, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_D_STORM, 3.0f, 345600, 15, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_D_FLOOD, 3.0f, 432000, 20, -1, {{U_POOL, 50, 40}, {E_MOSS_SPREAD, 60, 150}}},
    {CAT_ENV, journal::J_D_STRIKE, 1.5f, 518400, 6, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_D_ROCKFALL, 1.0f, 864000, 8, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_D_DROUGHT, 2.0f, 864000, 10, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_D_COLDSNAP, 2.0f, 604800, 10, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_D_FROST, 3.0f, 172800, 10, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_F_EGGS, 0.0f, 86400, 10, C_BIRD, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_F_HATCH, 0.0f, 86400, 20, C_BIRD, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_F_FEED, 0.0f, 14400, 20, C_BIRD, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_F_PRACTICE, 0.0f, 43200, 30, C_BIRD, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_F_FLEDGE, 0.0f, 86400, 20, C_BIRD, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_F_FROGSPAWN, 0.0f, 86400, 10, C_FROG, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_F_TADPOLE, 0.0f, 86400, 10, C_FROG, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_F_FROGLET, 0.0f, 86400, 20, C_FROG, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_F_CRITTER_BABY, 0.0f, 86400, 40, C_CRITTER, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_F_GROWN, 0.0f, 86400, 10, C_CRITTER, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_N_FIREFLY_PATH, 2.0f, 72000, 40, C_FIREFLY, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_N_SPRITE_PARTY, 2.0f, 86400, 50, C_SPRITE, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_N_MOONFLOWER, 1.5f, 172800, 60, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_N_TREE_GLOW, 1.5f, 86400, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_N_MOON_SPIRIT, 2.0f, 259200, 40, C_VISITOR, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_N_FALLEN_STAR, 1.0f, 345600, 4, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_N_MIDNIGHT_TRADE, 1.0f, 259200, 30, C_SHROOM, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_N_MOON_REFLECT, 1.5f, 86400, 10, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_VL_GATHER, 0.0f, 86400, 40, C_SPRITE, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_VL_COLLECT, 0.0f, 43200, 30, C_SPRITE, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_VL_HUT, 0.0f, 86400, 20, C_SPRITE, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_VL_SETTLE, 0.0f, 86400, 20, C_SPRITE, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_VL_EXPAND, 0.0f, 86400, 20, C_SPRITE, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_VL_DAMAGE, 0.0f, 86400, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_VL_ABANDON, 0.0f, 86400, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_VL_OVERGROWN, 0.0f, 86400, 10, -1, {{NO, 0, 0}, {NO, 0, 0}}},

    // ---- 第三階段 (配方) ----
    {CAT_INTERACT, journal::J_X_PLAY_CHASE, 4.0f, 10800, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_FRUIT_HOME, 5.0f, 7200, 50, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_SHARE_FOOD, 3.0f, 28800, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_TIDY_NEST, 3.0f, 28800, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_SQUABBLE, 2.0f, 36000, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_STARTLED, 3.0f, 14400, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_TREE_NAP, 4.0f, 10800, 60, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_RAIN_BURROW, 4.0f, 10800, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_SPLASH, 3.0f, 14400, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_NEW_PLANT, 3.0f, 14400, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_HELP_FORAGE, 3.0f, 21600, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_NIGHT_GATHER, 3.0f, 28800, 50, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_MOVE_HOUSE, 2.0f, 86400, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_CARE_YOUNG, 2.0f, 86400, 50, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_FIND_ITEM, 3.0f, 28800, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_ADV_EXPLORE, 2.0f, 43200, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_ADV_RUIN, 2.0f, 86400, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_ADV_CAMP, 1.5f, 172800, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_ADV_CABIN, 1.0f, 604800, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_ADV_CHOP, 1.0f, 259200, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_ADV_MUSHROOM, 2.0f, 86400, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_ADV_RARE_PLANT, 1.5f, 172800, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_HUNT_TRAP, 1.0f, 172800, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_TRAP_AVOID, 3.0f, 21600, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_TRAP_RESCUE, 2.0f, 86400, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_HUNT_TRACK, 1.0f, 129600, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_HUNT_HIDE, 3.0f, 21600, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_MERCHANT_ARRIVE, 1.0f, 129600, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_MERCHANT_TRADE, 3.0f, 43200, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_MERCHANT_DROP, 3.0f, 172800, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_VL_BUILD, 3.0f, 86400, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_VL_GROW, 2.0f, 172800, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_BUILD_BRIDGE, 1.5f, 345600, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_BUILD_TOWER, 1.5f, 345600, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_BUILD_STORAGE, 1.5f, 345600, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_REPAIR, 3.0f, 86400, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_STORM_DAMAGE, 2.0f, 259200, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_LIGHTNING_BUILD, 1.0f, 432000, 10, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_VINE_RUIN, 2.0f, 172800, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_ROOTS_RUIN, 2.0f, 259200, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_RUIN_NEST, 2.0f, 259200, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_SWALLOWED, 2.0f, 259200, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_X_RARE_BLOOM, 1.5f, 259200, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_MUSH_CLUSTER, 3.0f, 86400, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_TREE_FRUIT, 3.0f, 172800, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_DROUGHT_WITHER, 3.0f, 86400, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_RAIN_SPURT, 4.0f, 43200, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_SEED_DRIFT, 3.0f, 43200, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_ANIMAL_SEED, 3.0f, 43200, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_X_MUTATION, 1.0f, 345600, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_MUSH_FOREST, 2.0f, 259200, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_LOG_HABITAT, 3.0f, 86400, 50, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_INSECT_SWARM, 3.0f, 43200, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_PLANT_GONE, 2.0f, 172800, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_GALE_FRUIT, 3.0f, 43200, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_LOCAL_FLOOD, 3.0f, 86400, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_TREE_STRIKE, 1.0f, 345600, 8, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_WATER_SHRINK, 3.0f, 172800, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_THICK_FOG, 2.0f, 86400, 90, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_SNOW_COVER, 3.0f, 172800, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_STORM_WRECK, 2.0f, 345600, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_X_DOUBLE_RAINBOW, 1.0f, 345600, 90, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_SPRING_POOL, 2.0f, 259200, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_MUDSLIDE, 1.0f, 604800, 10, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_TUNNEL, 3.0f, 86400, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_HIDDEN_CAVE, 2.0f, 259200, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_X_CAVE_GLOW, 2.0f, 172800, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_UNDER_SPRING, 2.0f, 172800, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_X_CAVE_CREATURE, 1.0f, 345600, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_X_ARTIFACT, 1.0f, 432000, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_MYCEL_SPREAD, 3.0f, 86400, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_CAVE_COLLAPSE, 1.0f, 345600, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_X_METEOR_CRASH, 0.6f, 604800, 4, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_X_METEOR_SHARDS, 3.0f, 86400, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_X_TREE_STIR, 1.5f, 172800, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_X_SPIRIT_HEAL, 2.0f, 172800, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_X_LIGHT_ORB, 2.0f, 86400, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_X_RUNE_RING, 1.5f, 172800, 25, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_X_PORTAL_FLICKER, 1.0f, 259200, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_X_MAGIC_CREATURE, 2.0f, 86400, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_X_MOON_GLOW, 2.0f, 86400, 60, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_MYSTIC_ARRIVE, 1.0f, 172800, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_X_ALTAR_WAKE, 1.5f, 259200, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_MYSTERY, journal::J_X_MAGIC_RAIN, 1.5f, 172800, 25, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_PRE_HIBERNATE, 3.0f, 172800, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_STORE_FOOD, 3.0f, 86400, 40, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_FLOCK, 2.0f, 172800, 25, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_WAKE_UP, 3.0f, 259200, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_SPRING_SPROUT, 3.0f, 172800, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_DAILY, journal::J_X_AUTUMN_LEAVES, 4.0f, 86400, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_ENV, journal::J_X_FOOD_MIGRATE, 1.5f, 432000, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_INTERACT, journal::J_X_NEW_COMPANION, 2.0f, 259200, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_X_ANCIENT_TURTLE, 0.25f, 2592000, 120, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_X_TREE_SPIRIT, 0.4f, 1209600, 50, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_X_MOON_FOX, 1.5f, 864000, 50, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_X_FESTIVAL, 0.5f, 864000, 60, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_X_TREASURE, 0.4f, 1728000, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_X_GRAND_GATHER, 0.3f, 1728000, 60, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_X_RARE_NEST, 0.3f, 2592000, 20, -1, {{NO, 0, 0}, {NO, 0, 0}}},
    {CAT_RARE, journal::J_X_ENCHANT_DAYS, 0.15f, 5184000, 30, -1, {{NO, 0, 0}, {NO, 0, 0}}},
};
const char* const NAMES[] = {
    "butterfly", "bird_land", "snail_rock", "acorn", "sprite_nap", "dew", "shroom_emerge", "firefly_gather", "moss_spread",
    "meteor", "deer", "glow_butterfly", "ancient", "deep_lights", "rainbow",
    "chase", "twig", "butterfly_shroom", "frog_hunt", "sprite_gather",
    "gust", "deadwood", "ripples", "fog_roll", "pollen", "fish",
    "runes", "eyes", "portal", "starsign", "visitor",
    "e_bees", "i_squirrel", "i_snail_mush", "i_sprite_observe", "i_food_fight", "i_food_steal", "i_share_home", "u_hole", "u_peek", "u_pool", "u_mycelium", "u_carry", "u_eyes", "u_flood_relocate", "u_mush_hole", "u_foundation", "u_hidden", "u_firefly_cave", "a_erosion", "a_dig", "a_stele", "a_gate", "a_chest", "a_gate_glow", "a_ruin_glow", "d_storm", "d_flood", "d_strike", "d_rockfall", "d_drought", "d_coldsnap", "d_frost", "f_eggs", "f_hatch", "f_feed", "f_practice", "f_fledge", "f_frogspawn", "f_tadpole", "f_froglet", "f_critter_baby", "f_grown", "n_firefly_path", "n_sprite_party", "n_moonflower", "n_tree_glow", "n_moon_spirit", "n_fallen_star", "n_midnight_trade", "n_moon_reflect", "vl_gather", "vl_collect", "vl_hut", "vl_settle", "vl_expand", "vl_damage", "vl_abandon", "vl_overgrown",
    // 第三階段名稱
    "x_play_chase", "x_fruit_home", "x_share_food", "x_tidy_nest", "x_squabble", "x_startled", "x_tree_nap", "x_rain_burrow", "x_splash", "x_new_plant", "x_help_forage", "x_night_gather", "x_move_house", "x_care_young", "x_find_item", "x_adv_explore", "x_adv_ruin", "x_adv_camp", "x_adv_cabin", "x_adv_chop", "x_adv_mushroom", "x_adv_rare_plant", "x_hunt_trap", "x_trap_avoid", "x_trap_rescue", "x_hunt_track", "x_hunt_hide", "x_merchant_arrive", "x_merchant_trade", "x_merchant_drop", "x_vl_build", "x_vl_grow", "x_build_bridge", "x_build_tower", "x_build_storage", "x_repair", "x_storm_damage", "x_lightning_build", "x_vine_ruin", "x_roots_ruin", "x_ruin_nest", "x_swallowed", "x_rare_bloom", "x_mush_cluster", "x_tree_fruit", "x_drought_wither", "x_rain_spurt", "x_seed_drift", "x_animal_seed", "x_mutation", "x_mush_forest", "x_log_habitat", "x_insect_swarm", "x_plant_gone", "x_gale_fruit", "x_local_flood", "x_tree_strike", "x_water_shrink", "x_thick_fog", "x_snow_cover", "x_storm_wreck", "x_double_rainbow", "x_spring_pool", "x_mudslide", "x_tunnel", "x_hidden_cave", "x_cave_glow", "x_under_spring", "x_cave_creature", "x_artifact", "x_mycel_spread", "x_cave_collapse", "x_meteor_crash", "x_meteor_shards", "x_tree_stir", "x_spirit_heal", "x_light_orb", "x_rune_ring", "x_portal_flicker", "x_magic_creature", "x_moon_glow", "x_mystic_arrive", "x_altar_wake", "x_magic_rain", "x_pre_hibernate", "x_store_food", "x_flock", "x_wake_up", "x_spring_sprout", "x_autumn_leaves", "x_food_migrate", "x_new_companion", "x_ancient_turtle", "x_tree_spirit", "x_moon_fox", "x_festival", "x_treasure", "x_grand_gather", "x_rare_nest", "x_enchant_days",
};

static_assert(sizeof(DEFS) / sizeof(DEFS[0]) == EV_COUNT, "DEFS 與 EvId 數量不符");
static_assert(EV_COUNT <= evmem::MAX_EVENTS, "事件數超過事件記憶容量");

Active act[ACTIVE_CAP];
struct Pending { uint8_t id; uint32_t at; };
Pending pend[8];
uint32_t nextAllowed = 0;
uint32_t lastEventMs = 0;  // 上一個排程/連鎖事件的時間 (真實 millis)，用來保底
uint32_t nextLightning = 0, flashAt = 0;

// 環境轉換偵測
SkyKind lastSky = SkyKind::PartCloud;
bool wasWet = false, wasFog = false, wasWindy = false, wasHot = false, wasCold = false, wasStorm = false;
DayPhase lastPhase = PH_COUNT;
Season lastSeason = (Season)255;
bool envInit = false;
bool floodSeen = false, droughtSeen = false, rubbleSeen = false;

void disaster(uint32_t now) { eco::world.lastDisaster = now; }
// 大型事件 (稀有/災害) 不同時發生
bool isMajor(uint8_t id) { return DEFS[id].cat == CAT_RARE || (id >= D_STORM && id <= D_COLDSNAP); }
// 已崩塌、可以被挖成巢穴的建築
int ruinedShelter() {
  for (int i = 0; i < structure::CAP; i++) {
    const structure::Structure& s = structure::at(i);
    if (s.type == structure::T_CABIN || s.type == structure::T_TENT || s.type == structure::T_STALL)
      if (s.stage >= structure::ST_COLLAPSED) return i;
  }
  return -1;
}

float rnd(float a, float b) { return util::rng.range(a, b); }

float cond(EvId id) {
  const eco::Env& e = eco::env;
  const float night = e.night, day = 1 - night;
  const DayPhase ph = timem::phase();
  switch (id) {
    case E_BUTTERFLY: return (day > 0.6f && e.rain < 0.1f && e.tempC > 14) ? (0.4f + e.nectar) * (0.4f + e.light) : 0;
    case E_BIRD_LAND: return (day > 0.5f && e.storm < 0.3f && e.wind < 0.6f && !awayUntil(C_BIRD)) ? 1 : 0;
    case E_SNAIL_ROCK: return (eco::wetness() > 0.4f || e.hoursSinceRain < 6) ? 1 + eco::wetness() : 0;
    case E_ACORN: return day > 0.3f ? 0.3f + season::weight(AUTUMN) * 2 : 0;
    case E_SPRITE_NAP: return plant::bloomingFlowers() > 0 && e.rain < 0.2f ? 1 + night * 0.5f : 0;
    case E_DEW: return ((ph == PH_DAWN || ph == PH_MORNING) && timem::local().hourF < 9 && e.airHum > 60 && e.rain < 0.1f) ? 1.5f : 0;
    case E_SHROOM_EMERGE: return plant::matureMushrooms() > 0 ? 1 : 0;
    case E_FIREFLY_GATHER: return (night > 0.7f && e.tempC > 12 && season::weight(WINTER) < 0.6f && e.rain < 0.3f) ? 1 : 0;
    case E_MOSS_SPREAD: return e.hoursSinceRain < 4 && e.rain < 0.3f ? 1 : 0;
    case R_METEOR: return (night > 0.8f && e.cloud < 0.5f && e.fog < 0.3f) ? 1 : 0;
    case R_DEER: return (ph == PH_DAWN || ph == PH_DUSK || e.fog > 0.4f) && e.storm < 0.3f ? 1 + e.fog : 0;
    case R_GLOW_BUTTERFLY: return (night > 0.5f && e.rain < 0.2f) ? 0.5f + e.nectar + e.magic : 0;
    case R_ANCIENT: return 0.3f + e.magic * 3 + night * 0.3f;
    case R_DEEP_LIGHTS: return (night > 0.6f || e.fog > 0.4f) ? 1 : 0;
    case R_RAINBOW: return (day > 0.6f && e.hoursSinceRain < 1.5f && e.rain < 0.05f && e.cloud < 0.85f) ? 2 : 0;
    case I_CHASE: return (day > 0.3f && e.rain < 0.2f && !awayUntil(C_CRITTER) && e.tempC > 5) ? 1 : 0;
    case I_TWIG: return (nestProgress() < 1 && day > 0.5f && plant::treeMaturity() > 0.55f && e.rain < 0.2f &&
                         season::weight(SPRING) + season::weight(SUMMER) > 0.4f && !awayUntil(C_BIRD)) ? 1.5f : 0;
    case I_BUTTERFLY_SHROOM: return (plant::matureMushrooms() > 0 && day > 0.6f && e.rain < 0.1f) ? 1 : 0;
    case I_FROG_HUNT: return ((ph == PH_DUSK || ph == PH_NIGHT || ph == PH_MORNING) && e.tempC > 12) ? 0.5f + e.insects : 0;
    case I_SPRITE_GATHER: return plant::bloomingFlowers() >= 2 && e.rain < 0.2f ? 1 : 0;
    case V_GUST: return e.wind > 0.35f ? e.wind * 2 : season::weight(AUTUMN) * 0.5f;
    case V_DEADWOOD: return plant::hasLog() ? 0 : (e.storm > 0.5f || e.wind > 0.7f) ? 1 : 0.04f;
    case V_RIPPLES: return e.rain > 0.2f ? 2 : 0.3f;
    case V_FOG_ROLL: return (e.airHum > 85 && (ph == PH_DAWN || ph == PH_NIGHT) && e.fog < 0.5f) ? 1 : 0;
    case V_POLLEN: return (plant::bloomingFlowers() > 0 && e.wind > 0.2f && e.rain < 0.1f) ? 1 : 0;
    case V_FISH: return e.rain < 0.4f && !e.cold ? 0.6f : 0;
    case M_RUNES: return night > 0.6f ? 0.4f + e.magic * 3 : 0;
    case M_EYES: return night > 0.6f ? 0.6f : 0;
    case M_PORTAL: return 0.05f + e.magic * 2;
    case M_STARSIGN: return (night > 0.85f && e.cloud < 0.4f) ? 1 : 0;
    case M_VISITOR: return (night > 0.5f || e.fog > 0.4f) ? 0.4f : 0;
    // ---- 第二階段：生態鏈 ----
    case E_BEES: return (day > 0.6f && e.rain < 0.1f && plant::bloomingFlowers() > 0 && e.tempC > 14) ? 0.5f + e.nectar : 0;
    case I_SQUIRREL: return (day > 0.4f && eco::world.acornsGround >= 1 && e.rain < 0.3f) ? 0.5f + season::weight(AUTUMN) : 0;
    case I_SNAIL_MUSH: return (plant::matureMushrooms() > 0 && eco::wetness() > 0.35f) ? 1 : 0;
    case I_SPRITE_OBSERVE: return (activeCount() > 1 && e.rain < 0.3f) ? 1 : 0;
    case I_FOOD_FIGHT: return (day > 0.4f && eco::world.acornsGround >= 1 && !awayUntil(C_CRITTER) && !awayUntil(C_SQUIRREL)) ? 1 : 0;
    case I_FOOD_STEAL: return (eco::world.acornCache >= 2 && !awayUntil(C_CRITTER)) ? 1 : 0;
    // ---- 地下世界 ----
    case U_HOLE: return (under::count() < under::CAP && under::moisture() > 0.25f && eco::world.frost < 0.3f) ? 1 : 0;
    case U_PEEK: return under::findState(under::B_OCCUPIED) >= 0 ? 1 : 0;
    case U_POOL: return (under::water() > 0.65f && (under::findState(under::B_OCCUPIED) >= 0 || under::findState(under::B_ABANDONED) >= 0)) ? 1 : 0;
    case U_MYCELIUM: return (night > 0.6f && under::mycelium() > 0.3f) ? 1 : 0;
    case U_CARRY: return (under::findState(under::B_OCCUPIED) >= 0 && (night > 0.3f || ph == PH_DAWN || ph == PH_DUSK)) ? 1 : 0;
    case U_EYES: return (night > 0.6f && under::count() > 0) ? 1 : 0;
    case U_FOUNDATION: return (ruinedShelter() >= 0 && under::count() < under::CAP) ? 1 : 0;
    case U_FIREFLY_CAVE: return (night > 0.7f && count(C_FIREFLY) >= 2 && under::count() > 0) ? 1 : 0;
    // ---- 考古 ----
    case A_EROSION: return (eco::world.heavyRainH > 2 && ruins::exposed() < 0) ? 1 : 0;
    case A_GATE_GLOW: return (night > 0.6f && ruins::find(ruins::R_GATE) >= 0) ? 1 : 0;
    case A_RUIN_GLOW: return (night > 0.6f && ruins::find(ruins::R_STELE) >= 0) ? 1 : 0;
    // ---- 自然災害 ----
    case D_STORM: return (e.storm > 0.5f && e.wind > 0.55f) ? 1 : 0;
    case D_FLOOD: return eco::world.heavyRainH > 1.5f ? 1 : 0;
    case D_STRIKE: return e.storm > 0.6f ? 1 : 0;
    case D_ROCKFALL: return (eco::world.heavyRainH > 3 || eco::world.puddle > 0.6f) ? 1 : 0;
    case D_DROUGHT: return eco::world.drought > 0.5f ? 1 : 0;
    case D_COLDSNAP: return e.tempC < 8 ? 1 : 0;
    case D_FROST: return (eco::world.frost > 0.4f && (ph == PH_DAWN || ph == PH_MORNING)) ? 1 : 0;
    // ---- 夜間 (月相) ----
    case N_FIREFLY_PATH: return (night > 0.7f && e.tempC > 12 && season::weight(WINTER) < 0.6f && e.rain < 0.2f) ? 1 : 0;
    case N_SPRITE_PARTY: return (night > 0.6f && plant::bloomingFlowers() + plant::countStage(plant::P_GLOW, plant::S_MATURE) > 0 && e.rain < 0.2f) ? 1 : 0;
    case N_MOONFLOWER: {
      const eco::Moon m = eco::moon();
      return (night > 0.6f && e.cloud < 0.6f && (m == eco::MOON_FULL || m == eco::MOON_FIRST_Q) && plant::countSpecies(plant::P_FLOWER) > 0) ? 1 : 0;
    }
    case N_TREE_GLOW: return night > 0.7f ? (ruins::gateHasRunes() ? 2.0f : 1.0f) : 0;
    case N_MOON_SPIRIT: return eco::fullMoonNight() ? 1 : 0;
    case N_FALLEN_STAR: return (night > 0.8f && e.cloud < 0.5f) ? 1 : 0;
    case N_MIDNIGHT_TRADE: { const float h = timem::local().hourF; return ((h > 23 || h < 1.5f) && e.rain < 0.3f) ? 1 : 0; }
    case N_MOON_REFLECT: return (night > 0.7f && e.cloud < 0.4f && eco::moon() != eco::MOON_NEW && e.rain < 0.1f) ? 1 : 0;
    default: return recipes::cond(id);  // 第三階段：資料驅動的事件配方
  }
}

int freeActive() {
  for (int i = 0; i < ACTIVE_CAP; i++) if (!act[i].on) return i;
  return -1;
}

void startEffect(EvId id, Active& a, uint32_t ms) {
  const eco::Env& e = eco::env;
  switch (id) {
    case E_BUTTERFLY: case E_BIRD_LAND: {
      int i = spawn(id == E_BUTTERFLY ? C_BUTTERFLY : C_BIRD, ms, true);
      if (i >= 0) at(i).leaveAt = ms + (uint32_t)rnd(40, 70) * 1000;
      break;
    }
    case E_SNAIL_ROCK: {
      int i = spawn(C_SNAIL, ms, true);
      if (i >= 0) {
        Creature& c = at(i);
        c.x = scene::ROCK1_X - 14; c.y = scene::ROCK1_Y - 6; c.tx = scene::ROCK1_X + 16; c.ty = scene::ROCK1_Y - 4;
        c.state = ST_MOVE; c.leaveAt = ms + 150000;
      }
      break;
    }
    case E_ACORN: {
      a.x = rnd(20, 105); a.y = rnd(55, 80);
      fx::spawn(fx::PT_ACORN, a.x, a.y, rnd(-12, 12), 0, 30000, 0);
      // 橡果偶爾發芽成小樹
      if (util::rng.chance(0.2f)) plant::sproutRandom(plant::P_SAPLING);
      break;
    }
    case E_SPRITE_NAP: {
      int s = plant::randomSlotOf(plant::P_FLOWER, plant::S_BLOOM);
      if (s < 0) s = plant::randomSlotOf(plant::P_GLOW, plant::S_BLOOM);
      int i = spawn(C_SPRITE, ms, true);
      if (i >= 0 && s >= 0) {
        Creature& c = at(i);
        c.slot = s; c.tx = plant::SLOTS[s].x - 4; c.ty = plant::SLOTS[s].y - 20; c.state = ST_MOVE;
        c.flags |= F_LIT;  // F_LIT 在小精靈身上代表「想睡覺」
        c.leaveAt = ms + 120000;
      }
      break;
    }
    case E_DEW:
      for (int k = 0; k < 28; k++) fx::spawn(fx::PT_DEW, rnd(4, 236), rnd(176, 236), 0, 0, (uint16_t)rnd(2000, 9000), 0);
      break;
    case E_SHROOM_EMERGE: {
      int i = spawn(C_SHROOM, ms, true);
      if (i >= 0) at(i).leaveAt = ms + 200000;
      break;
    }
    case E_FIREFLY_GATHER: {
      int s = plant::randomSlotOf(plant::P_MUSHROOM, plant::S_MATURE);
      if (s < 0) s = plant::randomSlotOf(plant::P_GLOW, plant::S_MATURE);
      float x = s >= 0 ? plant::SLOTS[s].x : scene::POND_CX, y = s >= 0 ? plant::SLOTS[s].y - 14 : scene::POND_CY - 18;
      gatherFireflies(x, y, ms, 6);
      break;
    }
    case E_MOSS_SPREAD: {
      // 雨後苔蘚舒展 → 也讓蘑菇加速 (連鎖的開端)
      bool anyMush = false;
      for (int i = 0; i < plant::SLOT_N; i++) {
        plant::Plant& p = plant::mut(i);
        if (p.species == plant::P_MOSS && p.stage < plant::S_MATURE) p.prog = (uint16_t)fminf(999, p.prog + 300);
        if (p.species == plant::P_MUSHROOM && p.stage == plant::S_GROW) { p.prog = (uint16_t)fminf(999, p.prog + 450); anyMush = true; }
      }
      plant::sproutRandom(plant::P_MOSS);
      if (!anyMush) plant::sproutRandom(plant::P_MUSHROOM);
      for (int k = 0; k < 14; k++) fx::spawn(fx::PT_SPARKLE, rnd(5, 130), rnd(190, 230), 0, -3, (uint16_t)rnd(1500, 4000), 0x9CE67A);
      break;
    }
    case R_METEOR: a.x = rnd(140, 230); a.y = rnd(5, 30); break;
    case R_DEER: {
      int i = spawn(C_DEER, ms, true);
      if (i >= 0) at(i).leaveAt = ms + 50000;
      break;
    }
    case R_GLOW_BUTTERFLY:
      for (int k = 0; k < 5; k++) { int i = spawn(C_GLOWMOTH, ms, true); if (i >= 0) { at(i).leaveAt = ms + 45000; at(i).x = rnd(-10, 250); at(i).y = rnd(80, 180); } }
      break;
    case R_ANCIENT:
      eco::env.magic = fminf(1, e.magic + 0.3f);
      wakeAll(ms);
      break;
    case R_DEEP_LIGHTS: case M_RUNES: case M_STARSIGN: case M_EYES: case R_RAINBOW: case V_RIPPLES: break;
    case M_PORTAL: a.x = rnd(120, 200); a.y = scene::walkY(150) - 14; break;
    case I_CHASE: startChase(ms); break;
    case I_TWIG: {
      int b = -1;
      for (int i = 0; i < CAP; i++) if (at(i).active && at(i).sp == C_BIRD && at(i).state != ST_LEAVE) { b = i; break; }
      if (b < 0) b = spawn(C_BIRD, ms, true);
      if (b >= 0) {
        Creature& c = at(b);
        c.tx = rnd(95, 135); c.ty = scene::walkY((int)c.tx); c.slot = 51; c.state = ST_MOVE;
        c.leaveAt = ms + 90000;
      }
      break;
    }
    case I_BUTTERFLY_SHROOM: {
      int s = plant::randomSlotOf(plant::P_MUSHROOM, plant::S_MATURE);
      int i = spawn(C_BUTTERFLY, ms, true);
      if (i >= 0 && s >= 0) {
        Creature& c = at(i);
        c.slot = s; c.tx = plant::SLOTS[s].x - 2; c.ty = plant::SLOTS[s].y - 14; c.state = ST_MOVE; c.leaveAt = ms + 50000;
      }
      break;
    }
    case I_FROG_HUNT:
      if (count(C_FROG) == 0) spawn(C_FROG, ms, true);
      for (int k = 0; k < 6; k++) fx::spawn(fx::PT_INSECT, rnd(140, 225), rnd(180, 200), 0, 0, 30000, 0);
      break;
    case I_SPRITE_GATHER: {
      int s = plant::randomSlotOf(plant::P_FLOWER, plant::S_BLOOM);
      for (int k = 0; k < 3; k++) {
        int i = spawn(C_SPRITE, ms, true);
        if (i < 0 || s < 0) continue;
        Creature& c = at(i);
        c.slot = s; c.tx = plant::SLOTS[s].x - 4 + rnd(-10, 10); c.ty = plant::SLOTS[s].y - 24 + rnd(-6, 6); c.state = ST_MOVE;
        c.leaveAt = ms + 70000;
      }
      break;
    }
    case V_GUST:
      eco::env.gust = 0.9f;
      fx::leaves(16, season::weight(AUTUMN) > 0.4f);
      scare(ms);
      break;
    case V_DEADWOOD:
      plant::formLog();
      fx::leaves(20, true);
      break;
    case V_FOG_ROLL: break;
    case V_POLLEN: {
      int s = plant::randomSlotOf(plant::P_FLOWER, plant::S_BLOOM);
      if (s >= 0) {
        for (int k = 0; k < 18; k++)
          fx::spawn(fx::PT_POLLEN, plant::SLOTS[s].x + rnd(-6, 6), plant::SLOTS[s].y - rnd(8, 16), rnd(4, 14), rnd(-6, 2), (uint16_t)rnd(4000, 8000), 0xFFE680);
        plant::disperseSeeds(s, 1, true);
      }
      break;
    }
    case V_FISH: {
      scene::waterPoint(util::rng.f(), a.x, a.y);
      fx::ripple(a.x, a.y, 9);
      for (int k = 0; k < 8; k++) fx::spawn(fx::PT_SPLASH, a.x, a.y, rnd(-15, 15), rnd(-40, -20), 900, 0);
      break;
    }
    case M_VISITOR: {
      int i = spawn(C_VISITOR, ms, true);
      if (i >= 0) {
        at(i).leaveAt = ms + 30000;
        if (isActive(M_PORTAL)) for (int k = 0; k < ACTIVE_CAP; k++) if (act[k].on && act[k].id == M_PORTAL) { at(i).x = act[k].x; at(i).y = act[k].y; }
      }
      break;
    }
    // ================= 第二階段 =================
    case E_BEES:
      for (int k = 0; k < 2; k++) { int i = spawn(C_BEE, ms, true); if (i >= 0) at(i).leaveAt = ms + 60000; }
      break;
    case I_SQUIRREL: { int i = spawn(C_SQUIRREL, ms, true); if (i >= 0) at(i).leaveAt = ms + 90000; break; }
    case I_SNAIL_MUSH: {
      int s = plant::randomSlotOf(plant::P_MUSHROOM, plant::S_MATURE);
      if (s < 0) break;
      int i = emergeAt(C_SNAIL, plant::SLOTS[s].x - 12, plant::SLOTS[s].y + 4, ms, 150000);
      if (i >= 0) { Creature& c = at(i); c.tx = plant::SLOTS[s].x + 12; c.ty = plant::SLOTS[s].y + 3; c.state = ST_MOVE; }
      break;
    }
    case I_SPRITE_OBSERVE: {
      float x, y;
      const Species T[] = {C_CRITTER, C_FROG, C_SNAIL, C_SQUIRREL, C_SHROOM, C_MOLE};
      for (Species t : T) if (find(t, x, y)) { visitPoint(C_SPRITE, x, y - 22, ms, 40000); break; }
      break;
    }
    case I_FOOD_FIGHT: foodFight(ms); break;
    case I_FOOD_STEAL:
      eco::world.acornCache = fmaxf(0, eco::world.acornCache - 2);
      visitPoint(C_CRITTER, scene::TRUNK_X - 18, scene::walkY(scene::TRUNK_X - 18) + 4, ms, 40000);
      break;
    case I_SHARE_HOME: {
      int b = under::findState(under::B_OCCUPIED);
      if (b >= 0) emergeAt((Species)util::clamp<int>(under::at(b).occupant, 0, C_COUNT - 1), under::at(b).x, under::at(b).y, ms, 40000);
      break;
    }
    case U_HOLE: {
      int b = under::digNear(C_MOLE, ms);
      if (b >= 0) { spawn(C_MOLE, ms, true); history::note(history::H_BURROW, under::at(b).x); }
      break;
    }
    case U_PEEK: {
      int b = under::findState(under::B_OCCUPIED);
      if (b >= 0) {
        uint8_t occ = under::at(b).occupant;
        emergeAt(occ < C_COUNT ? (Species)occ : C_MOLE, under::at(b).x, under::at(b).y, ms, 20000);
      }
      break;
    }
    case U_POOL:
      for (int k = 0; k < under::CAP; k++)
        if (under::at(k).state == under::B_OCCUPIED || under::at(k).state == under::B_ABANDONED) { under::setState(k, under::B_FLOODED); break; }
      eco::world.puddle = fminf(1, eco::world.puddle + 0.3f);
      break;
    case U_MYCELIUM: under::glowMycelium(ms); break;
    case U_CARRY: {
      int b = under::findState(under::B_OCCUPIED);
      if (b < 0) break;
      int i = emergeAt(C_MOLE, under::at(b).x + rnd(-30, 30), under::at(b).y + 2, ms, 30000);
      if (i >= 0) {
        Creature& c = at(i);
        c.flags |= F_TWIG;
        c.sx = under::at(b).x; c.sy = under::at(b).y; c.tx = c.sx; c.ty = c.sy; c.slot = 122; c.state = ST_MOVE;
      }
      break;
    }
    case U_EYES: {
      int b = under::findState(under::B_OCCUPIED);
      if (b < 0) b = under::findState(under::B_ABANDONED);
      if (b < 0) b = under::findState(under::B_HIDDEN);
      if (b < 0) b = 0;
      under::eyes(b, ms);
      break;
    }
    case U_FLOOD_RELOCATE: under::digNear(C_MOLE, ms); history::note(history::H_FLOOD, 120); break;
    case U_MUSH_HOLE: {  // 廢棄洞穴被蘑菇佔據 → 新的小精靈出現
      int b = under::findState(under::B_MUSHROOM);
      if (b >= 0) visitPoint(C_SPRITE, under::at(b).x, under::at(b).y - 14, ms, 60000);
      break;
    }
    case U_FOUNDATION: {
      int s = ruinedShelter();
      if (s < 0) break;
      const structure::Site& site = structure::SITES[structure::at(s).site];
      if (under::dig(site.x + 6, site.y + 2, C_CRITTER, ms) >= 0) history::note(history::H_BURROW, site.x);
      structure::at(s).flags |= structure::F_NEST;
      break;
    }
    case U_FIREFLY_CAVE: {
      float bx = 120, by = 220;
      if (under::nearest(120, bx, by) < 0 && under::count() > 0) { bx = under::at(0).x; by = under::at(0).y; }
      int n = 0;
      for (int k = 0; k < CAP && n < 3; k++) {
        Creature& c = at(k);
        if (!c.active || c.sp != C_FIREFLY || c.state == ST_LEAVE) continue;
        c.state = ST_LEAVE; c.tx = bx; c.ty = by - 2; c.flags |= F_FADE; c.until = ms + 30000; n++;
      }
      break;
    }
    case A_EROSION: ruins::erode(ms); break;
    case A_GATE_GLOW: ruins::glow(ruins::find(ruins::R_GATE), ms); history::note(history::H_MYSTIC, 120); break;
    case A_RUIN_GLOW: ruins::glow(ruins::find(ruins::R_STELE), ms); break;
    // ---- 自然災害 (災害後由各模組逐漸恢復) ----
    case D_STORM: {
      const uint32_t now = timem::now();
      eco::env.gust = 1.0f;
      fx::leaves(26, true);
      scare(ms);
      if (!plant::hasLog()) plant::formLog();  // 折斷的樹枝成為枯木 → 之後長出蘑菇、吸引蝸牛
      for (int k = 0; k < 2; k++) { int s = plant::randomSlotOf(plant::P_FLOWER, plant::S_BLOOM); if (s >= 0) plant::disperseSeeds(s, 2, true); }
      if (!awayUntil(C_BIRD)) { setAwayUntil(C_BIRD, now + util::shortS(util::rng.irange(4, 10) * 3600.0f)); journal::add(journal::J_X_STORM_BIRDS, 0xFF, false); }
      village::damage(0.4f);
      disaster(now);
      history::note(history::H_DISASTER, scene::TRUNK_X, D_STORM);
      break;
    }
    case D_FLOOD: {
      eco::world.puddle = 1;
      scare(ms);
      for (int i = 0; i < plant::SLOT_N; i++) {  // 部分花朵受損
        plant::Plant& p = plant::mut(i);
        if (p.species == plant::P_FLOWER && p.stage == plant::S_BLOOM && util::rng.chance(0.4f)) { p.stage = plant::S_WITHER; p.prog = 500; }
      }
      ruins::erode(ms);  // 泥土被沖走
      village::damage(0.5f);
      disaster(timem::now());
      history::note(history::H_FLOOD, 150);
      history::note(history::H_DISASTER, 150, D_FLOOD);
      break;
    }
    case D_STRIKE: {
      flashAt = ms;
      eco::world.burn = 1;  // 古樹留下焦痕 → 歷史讓這裡更容易長發光菌類
      history::note(history::H_LIGHTNING, scene::TRUNK_X);
      int s = plant::randomSlotOf(plant::P_SAPLING, plant::S_MATURE);
      if (s >= 0 && util::rng.chance(0.5f)) { plant::mut(s).stage = plant::S_WITHER; plant::mut(s).prog = 900; }
      disaster(timem::now());
      break;
    }
    case D_ROCKFALL: {
      eco::world.rubble = 1;
      const int BURY[] = {21, 20, 15};
      for (int i : BURY) if (plant::get(i).species != plant::P_NONE) { plant::mut(i).species = plant::P_NONE; journal::add(journal::J_X_PLANT_BURIED, 0xFF, false); break; }
      disaster(timem::now());
      history::note(history::H_DISASTER, 100, D_ROCKFALL);
      break;
    }
    case D_DROUGHT: disaster(timem::now()); history::note(history::H_DISASTER, 180, D_DROUGHT); break;
    case D_COLDSNAP: scare(ms); hideFrom(120, 240, ms); disaster(timem::now()); history::note(history::H_DISASTER, 120, D_COLDSNAP); break;
    // ---- 生物家庭 (由 Families 依時間推進) ----
    case F_FLEDGE:
      for (int k = 0; k < 2; k++) { int i = spawn(C_BIRD, ms, true); if (i >= 0) { at(i).x = scene::NEST.x; at(i).y = scene::NEST.y - 4; at(i).leaveAt = ms + 20000; } }
      break;
    case F_FROGLET: { int i = spawn(C_FROG, ms, true); if (i >= 0) at(i).leaveAt = ms + 60000; break; }
    case F_CRITTER_BABY: families::startCritterFamily(ms); break;
    // ---- 夜間 ----
    case N_FIREFLY_PATH: gatherFireflies(60, 180, ms, 6); break;
    case N_SPRITE_PARTY: {
      int s = plant::randomSlotOf(plant::P_FLOWER, plant::S_BLOOM);
      if (s < 0) s = plant::randomSlotOf(plant::P_GLOW, plant::S_MATURE);
      if (s < 0) break;
      a.x = plant::SLOTS[s].x; a.y = plant::SLOTS[s].y - 16;
      for (int k = 0; k < 3; k++) {
        int i = spawn(C_SPRITE, ms, true);
        if (i < 0) break;
        Creature& c = at(i);
        c.tx = a.x + rnd(-12, 12); c.ty = a.y + rnd(-6, 4); c.state = ST_MOVE; c.leaveAt = ms + 50000;
      }
      break;
    }
    case N_MOONFLOWER: {
      int s = -1, seen = 0;
      for (int i = 0; i < plant::SLOT_N; i++)
        if (plant::get(i).species == plant::P_FLOWER && plant::get(i).stage >= plant::S_GROW && util::rng.irange(0, seen++) == 0) s = i;
      a.x = (float)s;
      break;
    }
    case N_MOON_SPIRIT: {
      int i = spawn(C_VISITOR, ms, true);
      if (i >= 0) { at(i).leaveAt = ms + 40000; at(i).variant = 9; }  // variant 9 = 月光色
      history::note(history::H_MYSTIC, 120);
      break;
    }
    case N_FALLEN_STAR:
      eco::world.meteorX = (int16_t)rnd(130, 230);
      eco::world.meteorGlow = 1;
      a.x = eco::world.meteorX;
      history::note(history::H_MYSTIC, eco::world.meteorX);
      break;
    case N_MIDNIGHT_TRADE: {
      float x = rnd(60, 110);
      a.x = x; a.y = scene::walkY((int)x) - 2;
      visitPoint(C_SPRITE, x - 6, a.y - 10, ms, 30000);
      int j = spawn(C_SHROOM, ms, true);
      if (j >= 0) { at(j).tx = x + 6; at(j).ty = a.y + 6; at(j).state = ST_MOVE; at(j).leaveAt = ms + 30000; }
      break;
    }
    default: recipes::start(id, a, ms); break;
  }
}

void environmentTransitions(uint32_t ms) {
  const eco::Env& e = eco::env;
  const bool wet = e.rain > 0.2f, fog = e.fog > 0.4f, windy = e.wind > 0.6f, storm = e.storm > 0.5f;
  const DayPhase ph = timem::phase();
  const Season se = season::dominant();
  if (!envInit) {  // 開機不要把現況當成「轉換」
    envInit = true;
    wasWet = wet; wasFog = fog; wasWindy = windy; wasHot = e.hot; wasCold = e.cold; wasStorm = storm;
    lastPhase = ph; lastSeason = se; lastSky = e.sky;
    return;
  }
  if (storm && !wasStorm) { journal::add(journal::J_STORM); scare(ms); }
  else if (wet && !wasWet) { journal::add(journal::J_RAIN_START); queue(V_RIPPLES, ms, 8000); }
  if (!wet && wasWet) {
    journal::add(journal::J_RAIN_STOP);
    queue(E_MOSS_SPREAD, ms, 60000);  // 下雨 → 苔蘚 → 蘑菇 → 蘑菇生物 → 螢火蟲
    queue(R_RAINBOW, ms, 30000);
    queue(E_SNAIL_ROCK, ms, 90000);
  }
  if (fog && !wasFog) { journal::add(journal::J_FOG); queue(R_DEER, ms, 40000); }
  if (windy && !wasWindy) { journal::add(journal::J_WINDY); queue(V_GUST, ms, 3000); }
  if (e.hot && !wasHot) journal::add(journal::J_HOT, 0xFF, false);
  if (e.cold && !wasCold) journal::add(journal::J_COLD, 0xFF, false);
  if (e.sky == SkyKind::Clear && lastSky != SkyKind::Clear && !wet) journal::add(journal::J_CLEAR, 0xFF, false);
  if (e.sky == SkyKind::Snow && lastSky != SkyKind::Snow) journal::add(journal::J_SNOW);
  if (ph != lastPhase) {
    if (ph == PH_DAWN) { journal::add(journal::J_DAWN, 0xFF, false); queue(E_DEW, ms, 20000); }
    if (ph == PH_DUSK) journal::add(journal::J_DUSK, 0xFF, false);
    if (ph == PH_NIGHT) journal::add(journal::J_NIGHT, 0xFF, false);
  }
  if (se != lastSeason) {
    static const Msg SM[4] = {journal::J_SPRING, journal::J_SUMMER, journal::J_AUTUMN, journal::J_WINTER};
    journal::add(SM[se]);
  }
  wasWet = wet; wasFog = fog; wasWindy = windy; wasHot = e.hot; wasCold = e.cold; wasStorm = storm;
  lastPhase = ph; lastSeason = se; lastSky = e.sky;
  // 災害後的恢復
  const eco::World& w = eco::world;
  if (w.puddle > 0.5f) floodSeen = true;
  if (floodSeen && w.puddle < 0.1f) {
    floodSeen = false;
    journal::add(journal::J_X_RECOVER);
    queue(E_MOSS_SPREAD, ms, 30000);
    plant::sproutRandom(plant::P_MUSHROOM);  // 潮濕的地方長出新蘑菇
  }
  if (w.drought > 0.5f) droughtSeen = true;
  if (droughtSeen && w.drought < 0.1f) { droughtSeen = false; journal::add(journal::J_X_RECOVER); }
  if (w.rubble > 0.6f) rubbleSeen = true;
  if (rubbleSeen && w.rubble < 0.5f) { rubbleSeen = false; journal::add(journal::J_X_MOSS_ROCKS, 0xFF, false); }
}

bool inCooldown(EvId id, uint32_t now, float factor) {
  uint32_t last = evmem::lastTime(id);
  if (!last || last > now) return false;
  return (now - last) < util::shortS(DEFS[id].cooldownS * factor);  // 冷卻壓縮到 0.5~3 小時
}

float weightOf(EvId id, uint32_t now) {
  if (isActive(id)) return 0;
  if (inCooldown(id, now, 1.0f)) return 0;
  float c = cond(id);
  if (c <= 0) return 0;
  const Def& d = DEFS[id];
  float w = d.weight * c * evmem::penalty(id, now);
  float hunger = evmem::catHunger(d.cat, now);
  // 稀有/神秘事件越久沒發生越容易出現 (保底機制)
  if (d.cat == CAT_RARE || d.cat == CAT_MYSTERY) hunger *= hunger;
  w *= hunger;
  if (d.species >= 0) w *= 1.0f + fminf(hoursSinceSeen(d.species), 6.0f) * 0.2f;
  // 連續兩次同分類 → 降低
  if (evmem::lastCat() == d.cat && evmem::lastId() != 0xFF) w *= 0.6f;
  w *= recipes::weightFactor(id);  // 相似事件、同一地點限制
  // 月相：滿月時神秘/稀有事件更常見，新月時較少
  if (eco::env.night > 0.5f && (d.cat == CAT_MYSTERY || d.cat == CAT_RARE)) {
    const eco::Moon m = eco::moon();
    if (m == eco::MOON_FULL) w *= 2.5f;
    else if (m == eco::MOON_NEW) w *= 0.7f;
  }
  // 古代石門出現符文後，神秘事件更頻繁 (遺跡連鎖)
  if (ruins::gateHasRunes() && (id == M_RUNES || id == N_TREE_GLOW || id == M_VISITOR)) w *= 2.0f;
  // 曾經有營地的地方容易被挖成巢穴 (歷史影響)
  if (id == U_FOUNDATION && history::count(history::H_CAMP) > 0) w *= 1.5f;
  return w;
}
}  // namespace

void begin(uint32_t ms) {
  for (auto& a : act) a.on = false;
  for (auto& p : pend) p.id = NO;
  nextAllowed = ms + 45000;  // 開機先安靜一下
  lastEventMs = ms;
}

bool trigger(EvId id, uint32_t ms, bool force) {
  if (id >= EV_COUNT) return false;
  if (!force && cond(id) <= 0) return false;
  if (isActive(id)) return false;  // 同一事件不重疊
  if (!force && isMajor(id))         // 大型事件不同時發生
    for (auto& o : act) if (o.on && isMajor(o.id)) return false;
  int s = freeActive();
  if (s < 0) return false;
  Active& a = act[s];
  a.id = id; a.on = true; a.start = ms; a.end = ms + DEFS[id].durS * 1000u;
  a.x = 0; a.y = 0; a.seed = util::rng.next();
  const uint32_t now = timem::now();
  evmem::record(id, DEFS[id].cat, now);
  startEffect(id, a, ms);
  journal::add((journal::Msg)recipes::journalMsg(id, DEFS[id].msg), 0xFF, DEFS[id].cat != CAT_DAILY || util::rng.chance(0.5f));
  if (id == R_DEER || id == M_VISITOR || id == R_GLOW_BUTTERFLY) history::note(history::H_MYSTIC, 120);
  Serial.printf("[Event] %s\n", NAMES[id]);
  // 後續事件
  for (const Follow& f : DEFS[id].next) {
    if (f.id == NO) continue;
    if (util::rng.irange(0, 99) < f.pct) queue((EvId)f.id, ms, f.delayS * 1000u);
  }
  return true;
}

void queue(EvId id, uint32_t ms, uint32_t delayMs) {
  for (auto& p : pend) {
    if (p.id == id) return;  // 已排過
  }
  for (auto& p : pend) {
    if (p.id == NO) { p.id = id; p.at = ms + delayMs; return; }
  }
}

void tick(uint32_t ms) {
  const uint32_t now = timem::now();
  environmentTransitions(ms);

  // 雷雨閃電
  if (eco::env.storm > 0.5f) {
    if (!nextLightning) nextLightning = ms + (uint32_t)rnd(6, 20) * 1000;
    if (util::reached(ms, nextLightning)) {
      flashAt = ms;
      nextLightning = ms + (uint32_t)rnd(8, 30) * 1000;
      scare(ms);
    }
  } else nextLightning = 0;

  // 結束的事件
  for (auto& a : act) if (a.on && util::reached(ms, a.end)) { recipes::finish(a, ms); a.on = false; }

  // 連鎖事件 (要符合條件、冷卻減半；和一般事件共用間隔，時間未到就延後到下一個空檔)
  const uint32_t gap = (uint32_t)rnd(cfg::QUIET_MIN, cfg::QUIET_MAX) * 1000;
  for (auto& p : pend) {
    if (p.id == NO || !util::reached(ms, p.at)) continue;
    if (!util::reached(ms, nextAllowed)) { p.at = nextAllowed; continue; }
    EvId id = (EvId)p.id;
    p.id = NO;
    if (!inCooldown(id, now, 0.5f) && cond(id) > 0 && trigger(id, ms)) {
      nextAllowed = ms + gap;
      lastEventMs = ms;
      return;
    }
  }

  // 一般排程：每 QUIET_MIN..QUIET_MAX 秒一個事件
  if (!util::reached(ms, nextAllowed)) return;
  float w[EV_COUNT], total = 0;
  for (int i = 0; i < EV_COUNT; i++) { w[i] = weightOf((EvId)i, now); total += w[i]; }
  // 保底：超過 QUIET_MAX 還沒有事件、而且全部在冷卻中 → 放寬冷卻，只從條件符合的日常事件挑
  if (total <= 0 && ms - lastEventMs >= cfg::QUIET_MAX * 1000) {
    for (int i = 0; i < EV_COUNT; i++) {
      w[i] = 0;
      if (DEFS[i].cat != CAT_DAILY || isActive((EvId)i)) continue;
      const float c = cond((EvId)i);
      if (c > 0) w[i] = DEFS[i].weight * c * evmem::penalty(i, now);
      total += w[i];
    }
  }
  if (total <= 0) { nextAllowed = ms + 10000; return; }
  float r = util::rng.f() * total;
  for (int i = 0; i < EV_COUNT; i++) {
    r -= w[i];
    if (r <= 0) {
      if (trigger((EvId)i, ms)) { nextAllowed = ms + gap; lastEventMs = ms; }
      else nextAllowed = ms + 10000;
      return;
    }
  }
}

void update(float dt, uint32_t ms) {
  for (auto& a : act) {
    if (!a.on) continue;
    float t = progress(a, ms);
    switch (a.id) {
      case V_RIPPLES:
        if (util::rng.chance(dt * 3)) { float rx, ry; scene::waterPoint(util::rng.f(), rx, ry); fx::ripple(rx, ry, (uint8_t)rnd(4, 9)); }
        break;
      case V_FOG_ROLL:
        eco::env.fog = util::approach(eco::env.fog, t < 0.85f ? 0.75f : 0.2f, dt * 0.05f);
        break;
      case R_ANCIENT:
        if (util::rng.chance(dt * 6)) fx::spawn(fx::PT_MAGIC, rnd(0, 110), rnd(5, 85), 0, rnd(-4, 4), 1800, 0x9CFFC8);
        break;
      case M_RUNES:
        if (util::rng.chance(dt * 2)) fx::spawn(fx::PT_MAGIC, rnd(70, 170), rnd(205, 225), 0, -8, 1600, 0x8CB4FF);
        break;
      case M_PORTAL:
        if (util::rng.chance(dt * 5)) fx::spawn(fx::PT_SPARKLE, a.x + rnd(-8, 8), a.y + rnd(-14, 14), rnd(-6, 6), rnd(-6, 6), 1000, 0xC8A0FF);
        break;
      case R_DEEP_LIGHTS: break;
      case N_FIREFLY_PATH: {  // 螢火蟲沿著一條弧線排成光之路徑
        int k = 0;
        for (int i = 0; i < CAP; i++) {
          Creature& c = at(i);
          if (!c.active || c.sp != C_FIREFLY || c.state == ST_LEAVE) continue;
          float u = fmodf(t * 0.6f + k * 0.13f, 1.0f);
          c.tx = 20 + u * 200; c.ty = 172 + sinf(u * 9.0f) * 10; c.state = ST_MOVE;
          k++;
        }
        break;
      }
      case N_SPRITE_PARTY:
        if (util::rng.chance(dt * 4)) fx::spawn(fx::PT_SPARKLE, a.x + rnd(-14, 14), a.y + rnd(-8, 6), 0, -6, 1200, 0xFFE6A0);
        break;
      case N_MIDNIGHT_TRADE:
        if (t > 0.3f && t < 0.7f && util::rng.chance(dt * 3)) fx::spawn(fx::PT_SPARKLE, a.x + rnd(-4, 4), a.y - rnd(4, 12), 0, -4, 900, 0xC8F0FF);
        break;
      default: recipes::update(a, dt, ms); break;
    }
  }
}

void onPlantStage(int slot, uint8_t species, uint8_t stage) {
  const uint32_t ms = millis();
  if (species == plant::P_MUSHROOM && stage == plant::S_MATURE && util::rng.chance(0.6f)) queue(E_SHROOM_EMERGE, ms, (uint32_t)rnd(20, 60) * 1000);
  if (species == plant::P_FLOWER && stage == plant::S_BLOOM && util::rng.chance(0.4f)) queue(E_BUTTERFLY, ms, (uint32_t)rnd(30, 90) * 1000);
  if (species == plant::P_SAPLING && stage == plant::S_MATURE) queue(I_TWIG, ms, 120000);
  (void)slot;
}

void onBless(uint32_t ms) {
  plant::boostGrowth(0.5f);
  eco::env.soil = fminf(1, eco::env.soil + 0.15f);
  if (util::rng.chance(0.3f)) queue(util::rng.chance(0.5f) ? E_SNAIL_ROCK : I_FROG_HUNT, ms, 12000);
}

void onBreeze(uint32_t ms) {
  fx::leaves(10, season::weight(AUTUMN) > 0.4f);
  int s = plant::randomSlotOf(plant::P_FLOWER, plant::S_BLOOM);
  if (s >= 0) {
    for (int k = 0; k < 12; k++)
      fx::spawn(fx::PT_POLLEN, plant::SLOTS[s].x + rnd(-6, 6), plant::SLOTS[s].y - rnd(6, 14), rnd(8, 20), rnd(-6, 2), (uint16_t)rnd(3000, 6000), 0xFFE680);
    if (util::rng.chance(0.5f)) plant::disperseSeeds(s, 1, true);
  }
  // 可能觸發特殊生物活動
  if (util::rng.chance(0.25f)) {
    if (eco::env.night > 0.5f) trigger(R_GLOW_BUTTERFLY, ms);
    else trigger(util::rng.chance(0.5f) ? E_BUTTERFLY : I_SPRITE_GATHER, ms);
  }
}

void onPulse(uint32_t ms) {
  wakeAll(ms);
  for (int k = 0; k < 24; k++) fx::spawn(fx::PT_MAGIC, rnd(0, 240), rnd(60, 235), 0, rnd(-10, -2), (uint16_t)rnd(1500, 3500), 0xB4A0FF);
  // 隱藏事件
  if (util::rng.chance(0.4f)) {
    static const EvId HIDDEN[] = {M_RUNES, M_EYES, R_ANCIENT, M_PORTAL, R_DEEP_LIGHTS};
    EvId id = HIDDEN[util::rng.irange(0, 4)];
    const uint32_t now = timem::now();
    if (!inCooldown(id, now, 0.3f) && trigger(id, ms, true)) journal::add(journal::J_HIDDEN, 0xFF, false);
  }
}

const Active& active(int i) { return act[i]; }
bool isActive(EvId id) {
  for (auto& a : act) if (a.on && a.id == id) return true;
  return false;
}
float progress(const Active& a, uint32_t ms) {
  if (a.end <= a.start) return 1;
  return util::clamp01((float)(ms - a.start) / (float)(a.end - a.start));
}
float lightning(uint32_t ms) {
  if (!flashAt) return 0;
  uint32_t age = ms - flashAt;
  if (age > 600) return 0;
  // 兩段閃光
  float f = age < 120 ? 1.0f - age / 120.0f : (age > 200 && age < 450) ? 0.6f * (1 - (age - 200) / 250.0f) : 0;
  return f;
}
const char* name(uint8_t id) { return id < EV_COUNT ? NAMES[id] : "?"; }
void flash(uint32_t ms) { flashAt = ms; }
uint8_t category(uint8_t id) { return id < EV_COUNT ? DEFS[id].cat : 0; }

}  // namespace eventm
