#include "StructureManager.h"
#include <Arduino.h>
#include <math.h>
#include "CreatureManager.h"
#include "Ecosystem.h"
#include "Gfx.h"
#include "Journal.h"
#include "ForestHistory.h"
#include "Particles.h"
#include "PlantManager.h"
#include "SeasonManager.h"
#include "TimeManager.h"
#include "Util.h"

namespace structure {

#define M(t) (1u << (t))
// 位置 (世界座標，y = 落地點)。每個位置同時只放一個物件。
const Site SITES[SITE_N] = {
    {212, 186, M(T_CABIN) | M(T_TENT) | M(T_STALL)},                           // 0 森林右側邊緣空地
    {72, 226, M(T_CAMPFIRE) | M(T_CRATE) | M(T_ALTAR) | M(T_ITEM)},           // 1 古樹前
    {30, 230, M(T_TENT) | M(T_STALL) | M(T_SIGN) | M(T_CRATE)},                // 2 左前方
    {134, 236, M(T_TRAP) | M(T_CRATE) | M(T_ALTAR) | M(T_FENCE) | M(T_ITEM)},  // 3 河邊前方
    {152, 222, M(T_BRIDGE)},                                                   // 4 河的左岸 (棧橋伸進河面)
    {124, 197, M(T_SIGN) | M(T_CRATE) | M(T_FENCE) | M(T_TRAP) | M(T_ITEM)},   // 5 中央後方
};
#undef M

namespace {
Structure st[CAP];
uint32_t appearAt[CAP];   // 新建時淡入 (不存檔)
uint32_t altarGlowUntil = 0;

struct Def { float lifeH; bool wood; uint8_t w, h; };  // w/h：120 畫布像素 (用於排序/覆蓋範圍)
const Def DEFS[T_COUNT] = {
    {480, true, 22, 17},   // 木屋 (約 20 天)
    {72, true, 8, 5},      // 營火
    {150, true, 14, 10},   // 帳篷
    {360, true, 7, 10},    // 路標
    {200, true, 7, 6},     // 木箱
    {260, true, 18, 6},    // 圍欄
    {72, true, 7, 3},      // 陷阱
    {320, true, 14, 4},    // 棧橋
    {2400, false, 10, 8},  // 石頭祭壇 (約 100 天後成為永久遺跡)
    {120, true, 16, 13},   // 商人攤位
    {48, true, 3, 3},      // 遺落物品
};

float rnd(float a, float b) { return util::rng.range(a, b); }

uint8_t stageOf(float d) { return d < 0.15f ? ST_NEW : d < 0.35f ? ST_WEATHERED : d < 0.6f ? ST_OVERGROWN : d < 0.85f ? ST_COLLAPSED : ST_MERGING; }

void tickOne(int i, float dtH) {
  Structure& s = st[i];
  const Def& d = DEFS[s.type];
  const eco::Env& e = eco::env;
  // 潮濕：下雨變濕，日曬與風讓它變乾
  if (e.rain > 0.2f) s.wet = fminf(1, s.wet + dtH * (0.4f + e.rain * 0.6f));
  else s.wet = fmaxf(0, s.wet - dtH * (0.06f + e.light * 0.15f + e.wind * 0.1f));
  // 腐朽：木材越濕越快；石頭幾乎不受影響
  float rate = (1.0f + (d.wood ? s.wet * 2.2f : s.wet * 0.3f)) / d.lifeH;
  if (s.flags & F_INUSE) rate *= 0.3f;  // 有人使用時會被維護
  float before = s.decay;
  s.decay += dtH * rate;
  // 強風：帳篷、圍欄、攤位、路標受損
  if (e.wind > 0.7f && (s.type == T_FENCE || s.type == T_TENT || s.type == T_STALL || s.type == T_SIGN)) {
    s.decay += dtH * 0.02f;
    if (s.type == T_FENCE && !(s.flags & F_WIND_HIT) && util::rng.chance(fminf(1, dtH * 0.5f))) {
      s.flags |= F_WIND_HIT;
      s.decay = fmaxf(s.decay, 0.4f);
      journal::add(journal::J_B_FENCE);
    }
  }
  // 大雨讓長滿植物的木造建築崩塌
  if (d.wood && s.stage == ST_OVERGROWN && e.rain > 0.6f && s.wet > 0.8f && util::rng.chance(fminf(1, dtH * 0.15f))) {
    s.decay = fmaxf(s.decay, 0.62f);
    journal::add(journal::J_B_COLLAPSE);
  }
  // 石頭祭壇最後停在遺跡狀態
  if (s.type == T_ALTAR && s.decay >= 0.84f) {
    if (before < 0.84f) journal::add(journal::J_B_ALTAR_RUIN);
    s.decay = 0.84f;
  }
  // 植物入侵：苔蘚 → 蘑菇 → 藤蔓
  if (s.decay > 0.08f) s.moss = fminf(1, s.moss + dtH * (0.002f + s.wet * 0.03f) * (d.wood ? 1.0f : 1.5f));  // 乾燥時幾乎不長
  if (d.wood && s.moss > 0.25f) {
    if (s.wet > 0.4f) s.mush = fminf(1, s.mush + dtH * 0.05f * s.wet);
    else s.mush = fmaxf(0, s.mush - dtH * 0.01f);
  }
  if (s.decay > 0.3f) s.vine = fminf(1, s.vine + dtH * 0.012f * (1 + season::weight(SUMMER) + season::weight(SPRING) * 0.5f) * (season::weight(WINTER) > 0.6f ? 0.2f : 1.0f));
  // 日誌 (每件事只記一次)
  if (d.wood && s.wet > 0.6f && !(s.flags & F_SAID_WET) && (s.type == T_CABIN || s.type == T_STALL || s.type == T_TENT)) { s.flags |= F_SAID_WET; journal::add(journal::J_B_WET, 0xFF, false); }
  const bool small = s.type == T_ITEM || s.type == T_TRAP;  // 小物件不寫日誌
  if (small) s.flags |= F_SAID_MOSS | F_SAID_MUSH | F_SAID_VINE;
  if (s.moss > 0.3f && !(s.flags & F_SAID_MOSS)) { s.flags |= F_SAID_MOSS; journal::add(journal::J_B_MOSS, 0xFF, false); }
  if (s.mush > 0.3f && !(s.flags & F_SAID_MUSH)) { s.flags |= F_SAID_MUSH; journal::add(journal::J_B_MUSH); }
  if (s.vine > 0.3f && !(s.flags & F_SAID_VINE) && s.type != T_ITEM) { s.flags |= F_SAID_VINE; journal::add(journal::J_B_VINE); }

  // 廢墟成為棲息地：小動物在裡面築巢
  bool shelter = s.type == T_CABIN || s.type == T_TENT || s.type == T_STALL || s.type == T_CRATE;
  if (shelter && s.stage >= ST_OVERGROWN && s.stage <= ST_COLLAPSED && !(s.flags & F_NEST) && util::rng.chance(fminf(1, dtH * 0.06f))) {
    s.flags |= F_NEST;
    journal::add(journal::J_B_NEST);
  }
  // 古老祭壇偶爾在夜裡發光
  if (s.type == T_ALTAR && e.night > 0.7f && util::rng.chance(fminf(1, dtH * (0.05f + e.magic * 0.3f)))) glowAltar(millis());

  uint8_t ns = stageOf(s.decay);
  if (ns != s.stage) {
    if (ns == ST_COLLAPSED && !small) history::note(history::H_STRUCT_DECAY, SITES[s.site].x, s.type);
    if (ns == ST_COLLAPSED && s.type != T_ALTAR && !small) journal::add(journal::J_B_RUIN, 0xFF, s.type == T_CABIN);
    if (ns == ST_MERGING && s.type == T_CABIN && !(s.flags & F_SAID_SAPLING)) {
      s.flags |= F_SAID_SAPLING;
      plant::sproutRandom(plant::P_SAPLING);  // 廢墟旁長出小樹
      journal::add(journal::J_B_SAPLING);
    }
    s.stage = ns;
  }
  if (s.decay >= 1.0f) {
    // 完全融入大地：留下蘑菇/苔蘚等新的自然地貌
    if (!small) journal::add(s.type == T_CAMPFIRE || s.type == T_TENT ? journal::J_B_CAMP_COVERED : journal::J_B_RETURN, 0xFF, s.type == T_CABIN);
    plant::sproutRandom(util::rng.chance(0.6f) ? plant::P_MUSHROOM : plant::P_MOSS);
    if (!small) history::note(history::H_STRUCT_GONE, SITES[s.site].x, s.type);
    s.type = T_COUNT;
  }
}
}  // namespace

void begin() {
  for (auto& s : st) s.type = T_COUNT;
}

void tick(float dtSimSec) {
  const float dtH = dtSimSec / 3600.0f;
  if (dtH <= 0) return;
  for (int i = 0; i < CAP; i++) if (st[i].type < T_COUNT) tickOne(i, dtH);
}

void update(float dt, uint32_t ms) {
  const eco::Env& e = eco::env;
  for (int i = 0; i < CAP; i++) {
    const Structure& s = st[i];
    if (s.type >= T_COUNT) continue;
    const Site& p = SITES[s.site];
    // 營火的煙與火星
    if (s.type == T_CAMPFIRE && (s.flags & F_LIT)) {
      if (util::rng.chance(dt * 3)) fx::spawn(fx::PT_GLOWDOT, p.x + rnd(-2, 2), p.y - 6, rnd(-3, 3), -14, 900, 0xFFA03C);
      if (util::rng.chance(dt * 1.5f)) fx::spawn(fx::PT_POLLEN, p.x + rnd(-2, 2), p.y - 10, rnd(-2, 2) + e.wind * 10, -8, 3000, 0x9A9A9A);
    }
    // 木屋有人時煙囪冒煙
    if (s.type == T_CABIN && (s.flags & F_INUSE) && s.stage < ST_COLLAPSED && util::rng.chance(dt * 1.2f))
      fx::spawn(fx::PT_POLLEN, p.x + 12, p.y - 36, rnd(-2, 2) + e.wind * 12, -9, 3500, 0xB4B4B4);
    // 下雨時屋簷滴水
    if (e.rain > 0.3f && (s.type == T_CABIN || s.type == T_STALL || s.type == T_TENT) && s.stage <= ST_OVERGROWN && util::rng.chance(dt * 2))
      fx::spawn(fx::PT_SPLASH, p.x + rnd(-20, 20), p.y - (s.type == T_CABIN ? 20 : 14), 0, 30, 700, 0);
  }
  (void)ms;
}

int freeSite(Type t) {
  int pick = -1, seen = 0;
  for (int k = 0; k < SITE_N; k++) {
    if (!(SITES[k].allowMask & (1u << t))) continue;
    bool used = false;
    for (auto& s : st) if (s.type < T_COUNT && s.site == k) used = true;
    if (used) continue;
    if (util::rng.irange(0, seen++) == 0) pick = k;
  }
  return pick;
}

int create(Type t, int site, uint32_t ms) {
  if (site < 0 || site >= SITE_N) return -1;
  for (auto& s : st) if (s.type < T_COUNT && s.site == site) return -1;
  int slot = -1;
  for (int i = 0; i < CAP; i++) if (st[i].type >= T_COUNT) { slot = i; break; }
  if (slot < 0) return -1;
  Structure& s = st[slot];
  s = {};
  s.type = t;
  s.site = (uint8_t)site;
  s.variant = (uint8_t)util::rng.irange(0, 3);
  s.built = timem::now();
  appearAt[slot] = ms;
  return slot;
}

int find(Type t) {
  for (int i = 0; i < CAP; i++) if (st[i].type == t) return i;
  return -1;
}
int count() {
  int n = 0;
  for (auto& s : st) if (s.type < T_COUNT) n++;
  return n;
}
Structure& at(int i) { return st[i]; }
void setUse(int i, bool u) { if (i >= 0) { if (u) st[i].flags |= F_INUSE; else st[i].flags &= ~F_INUSE; } }
void setLit(int i, bool l) { if (i >= 0) { if (l) st[i].flags |= F_LIT; else st[i].flags &= ~F_LIT; } }
void remove(int i) { if (i >= 0) st[i].type = T_COUNT; }
void glowAltar(uint32_t ms) {
  if (find(T_ALTAR) < 0 || !util::reached(ms, altarGlowUntil)) return;
  altarGlowUntil = ms + 30000;
  journal::add(journal::J_B_ALTAR_GLOW);
}
const char* name(uint8_t t) {
  static const char* N[T_COUNT] = {"cabin", "campfire", "tent", "sign", "crate", "fence", "trap", "bridge", "altar", "stall", "item"};
  return t < T_COUNT ? N[t] : "?";
}

// ================= 繪圖 (120 畫布，像素 1:1) =================
namespace {
uint8_t gA = 255;  // 目前物件的整體透明度 (淡入/融入大地)

uint32_t mixh(uint32_t a, uint32_t b, float t) {
  t = util::clamp01(t);
  int ar = a >> 16, ag = (a >> 8) & 255, ab = a & 255, br = b >> 16, bg = (b >> 8) & 255, bb = b & 255;
  return ((uint32_t)(ar + (br - ar) * t) << 16) | ((uint32_t)(ag + (bg - ag) * t) << 8) | (uint32_t)(ab + (bb - ab) * t);
}
inline void P(int x, int y, uint32_t hex) {
  if (gA >= 250) gfx::pset(x, y, gfx::lit(hex));
  else if (gA > 8) gfx::pblend(x, y, gfx::lit(hex), gA);
}
inline void R(int x, int y, int w, int h, uint32_t hex) { for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) P(x + i, y + j, hex); }
// 腐朽的木材：潮濕變深、老化變灰
uint32_t woodC(const Structure& s, uint32_t base) {
  uint32_t c = mixh(base, 0x3A2A20, s.wet * 0.35f + s.decay * 0.25f);
  return mixh(c, 0x7A7468, s.decay * 0.35f);
}
// 缺損：越腐朽越多像素不見
inline bool gone(const Structure& s, int x, int y, float start) { return util::hashf(x * 7 + s.site, y * 3) < (s.decay - start) * 1.6f; }

// 共用的植物入侵層：苔蘚、蘑菇、藤蔓、地面小草小花
void overgrow(const Structure& s, int bx, int by, int w, int h, uint32_t ms) {
  const int x0 = bx - w / 2;
  int nMoss = (int)(s.moss * w * 1.4f);
  for (int k = 0; k < nMoss; k++) {
    int x = x0 + (int)(util::hashf(k, s.site * 13) * w);
    int y = by - h + (int)(util::hashf(s.site, k * 5) * h * (0.4f + s.decay * 0.6f));
    if (s.stage >= ST_COLLAPSED) y = by - (int)(util::hashf(k, 3) * h * 0.5f);
    P(x, y, k % 3 ? 0x5E9A46 : 0x7CB45A);
  }
  int nMush = (int)(s.mush * 5);
  for (int k = 0; k < nMush; k++) {
    int x = x0 + 1 + (int)(util::hashf(k * 9, s.site) * (w - 2));
    uint32_t cap = k & 1 ? 0xC8643C : 0xE6D2AA;
    P(x, by - 1, 0xF0E6D2); P(x - 1, by - 2, cap); P(x, by - 2, cap); P(x + 1, by - 2, cap);
  }
  if (s.vine > 0.05f) {
    int vh = (int)(s.vine * (h + 2));
    for (int side = 0; side < 2; side++) {
      int vx = side ? x0 + w - 1 : x0;
      for (int i = 0; i < vh; i++) {
        int x = vx + ((i / 2) & 1) * (side ? -1 : 1);
        P(x, by - i, 0x4E8C3C);
        if (i % 3 == 1) P(x + (side ? -1 : 1), by - i, 0x6EB450);
      }
    }
  }
  if (s.stage >= ST_OVERGROWN) {  // 地面附近長出小草與花
    int n = (int)((s.decay - 0.3f) * w * 1.2f);
    for (int k = 0; k < n; k++) {
      int x = x0 - 2 + (int)(util::hashf(k, s.site * 31) * (w + 4));
      P(x, by, 0x5A9A46); P(x, by - 1, 0x6EAA4E);
      if (k % 5 == 2) P(x, by - 2, k & 1 ? 0xFF9AC0 : 0xFFE070);
    }
  }
  (void)ms;
}

void drawCabin(const Structure& s, int bx, int by, uint32_t ms) {
  const uint32_t log1 = woodC(s, 0x8C6440), log2 = woodC(s, 0x6E4E32), roof = woodC(s, 0x7A3A2A), roofD = woodC(s, 0x5A2A20);
  if (s.stage <= ST_OVERGROWN) {
    for (int y = 1; y <= 9; y++) for (int x = -10; x <= 10; x++) {
      if (s.stage == ST_OVERGROWN && gone(s, x, y, 0.4f)) continue;
      P(bx + x, by - y, (y & 1) ? log1 : log2);
    }
    for (int y = 1; y <= 6; y++) for (int x = -2; x <= 1; x++) P(bx + x, by - y, 0x2A1C14);  // 門
    bool lit = (s.flags & F_INUSE) && eco::env.night > 0.3f;
    R(bx + 5, by - 7, 3, 3, lit ? 0xFFDC82 : 0x3C4650);  // 窗
    if (lit) gfx::glow(bx + 6, by - 6, 5, 0xFFC864, 120);
    for (int r = 0; r < 7; r++) {  // 屋頂
      int half = 12 - r * 2 + (r > 4 ? 1 : 0);
      for (int x = -half; x <= half; x++) {
        if (s.stage == ST_OVERGROWN && gone(s, x, r, 0.45f)) continue;
        P(bx + x, by - 10 - r, (x + r) & 3 ? roof : roofD);
      }
    }
    R(bx + 6, by - 17, 2, 4, 0x7A7A80);  // 煙囪
  } else if (s.stage == ST_COLLAPSED) {
    // 倒塌：牆變矮、屋頂歪斜塌下
    for (int y = 1; y <= 5; y++) for (int x = -10; x <= 10; x++) if (!gone(s, x, y, 0.5f)) P(bx + x, by - y, (y & 1) ? log1 : log2);
    for (int r = 0; r < 5; r++) for (int x = -11; x <= 9; x++) if (!gone(s, x, r + 9, 0.55f)) P(bx + x + r, by - 6 - r + (x > 0 ? x / 4 : 0), roof);
  } else {
    // 融入大地：只剩低矮的木堆，被泥土與苔蘚蓋住
    for (int k = 0; k < 6; k++) R(bx - 9 + k * 3, by - 1 - (k & 1), 4, 1, k & 1 ? log2 : roof);
    R(bx - 6, by - 3, 3, 2, 0x8A8A8A); R(bx + 4, by - 2, 2, 2, 0x7A7A7A);  // 留下的石頭
  }
  overgrow(s, bx, by, 22, s.stage >= ST_COLLAPSED ? 6 : 16, ms);
}

void drawTent(const Structure& s, int bx, int by) {
  const uint32_t cloth = mixh(mixh(0xD8C8A0, 0x6E6450, s.wet * 0.3f + s.decay * 0.4f), 0x7A8A5A, s.moss * 0.3f);
  const uint32_t clothD = mixh(cloth, 0x3A3028, 0.35f);
  float sway = sinf(millis() * 0.004f) * eco::env.wind * 1.5f;
  int h = s.stage <= ST_OVERGROWN ? 9 : s.stage == ST_COLLAPSED ? 4 : 2;
  for (int r = 0; r < h; r++) {
    int half = (h - r) * 7 / h;
    int off = (int)(sway * r / h);
    for (int x = -half; x <= half; x++) {
      if (s.stage >= ST_OVERGROWN && gone(s, x, r, 0.4f)) continue;
      bool door = s.stage <= ST_OVERGROWN && x >= -1 && x <= 1 && r < h - 2;
      P(bx + x + off, by - 1 - r, door ? 0x2A2218 : (x < 0 ? cloth : clothD));
    }
  }
  if (s.stage <= ST_WEATHERED) P(bx, by - 1 - h, 0x6E4E32);  // 帳篷頂端木桿
  overgrow(s, bx, by, 14, h, 0);
}

void drawCampfire(const Structure& s, int bx, int by, uint32_t ms) {
  const uint32_t stone = mixh(0x8A8A90, 0x5E8A4A, s.moss * 0.6f);
  const int sx[6] = {-4, -2, 0, 2, 4, 0}, sy[6] = {0, 1, 1, 1, 0, -1};
  for (int k = 0; k < 5; k++) R(bx + sx[k], by - 1 + sy[k] - 1, 2, 1, k & 1 ? stone : mixh(stone, 0x5A5A60, 0.3f));
  if (s.stage <= ST_WEATHERED) {
    uint32_t w = woodC(s, 0x7A5032);
    for (int i = -2; i <= 2; i++) { P(bx + i, by - 2 - (i + 2) / 2, w); P(bx + i, by - 2 - (2 - i) / 2, w); }
  }
  if (s.flags & F_LIT) {
    int f = (ms / 120) % 3;
    P(bx, by - 4 - f % 2, 0xFFE68C); P(bx - 1, by - 3, 0xFF8C32); P(bx + 1, by - 3 - (f == 2), 0xFF8C32); P(bx, by - 3, 0xFFC850);
    gfx::glow(bx, by - 3, 9, 0xFF9A3C, (uint8_t)(110 + 40 * sinf(ms * 0.01f)));
  } else if (s.stage <= ST_WEATHERED) {
    P(bx, by - 2, 0x3A3A3A); P(bx - 1, by - 2, 0x4A4A4A);  // 灰燼
  }
  overgrow(s, bx, by, 10, 3, ms);
}

void drawSign(const Structure& s, int bx, int by) {
  const uint32_t w = woodC(s, 0x8C6A44), wd = woodC(s, 0x5E4430);
  int tilt = (int)(s.decay * 4);
  int h = s.stage >= ST_COLLAPSED ? 3 : 9;
  for (int i = 0; i < h; i++) P(bx + (i * tilt) / 9, by - 1 - i, wd);
  if (s.stage < ST_COLLAPSED) {
    int ty = by - 9, tx = bx + tilt - 3;
    R(tx, ty, 7, 3, w);
    P(tx + 7, ty + 1, w);  // 箭頭
    P(tx + 2, ty + 1, wd); P(tx + 4, ty + 1, wd);
  } else {
    R(bx - 2, by - 1, 6, 1, w);  // 倒在地上的木板
  }
  overgrow(s, bx, by, 8, h, 0);
}

void drawCrate(const Structure& s, int bx, int by) {
  const uint32_t w = woodC(s, 0xA07848), wd = woodC(s, 0x6E5032);
  int h = s.stage >= ST_COLLAPSED ? 3 : 6;
  for (int y = 1; y <= h; y++) for (int x = -3; x <= 3; x++) {
    if (gone(s, x, y, 0.35f)) continue;
    bool edge = x == -3 || x == 3 || y == 1 || y == h || x == y - 3;
    P(bx + x, by - y, edge ? wd : w);
  }
  overgrow(s, bx, by, 7, h, 0);
}

void drawFence(const Structure& s, int bx, int by) {
  const uint32_t w = woodC(s, 0x9A7448), wd = woodC(s, 0x6A4E32);
  for (int k = 0; k < 5; k++) {
    int px = bx - 8 + k * 4;
    bool down = gone(s, k, 0, 0.3f) || ((s.flags & F_WIND_HIT) && (k == 3 || k == 4));
    if (down) { R(px, by - 1, 4, 1, wd); continue; }  // 倒下的柱子
    for (int i = 0; i < 6; i++) P(px, by - 1 - i, wd);
    if (k < 4 && !gone(s, k, 1, 0.25f)) { R(px + 1, by - 3, 3, 1, w); R(px + 1, by - 5, 3, 1, w); }
  }
  overgrow(s, bx, by, 18, 5, 0);
}

void drawTrap(const Structure& s, int bx, int by) {
  const uint32_t rope = mixh(0xC8B48C, 0x6E6450, s.decay + s.wet * 0.3f), stake = woodC(s, 0x6E4E32);
  for (int i = 0; i < 4; i++) P(bx + 3, by - 1 - i, stake);
  if (s.flags & F_TRIGGERED) { R(bx - 2, by - 2, 5, 1, rope); P(bx + 2, by - 3, rope); }
  else for (int k = 0; k < 10; k++) { float a = k * 0.628f; P(bx + (int)(cosf(a) * 3), by - 1 + (int)(sinf(a) * 1), rope); }
  overgrow(s, bx, by, 7, 2, 0);
}

void drawBridge(const Structure& s, int bx, int by) {
  const uint32_t w = woodC(s, 0x9A7448), wd = woodC(s, 0x5E4430);
  for (int k = 0; k < 7; k++) {
    if (gone(s, k, 2, 0.3f)) continue;
    R(bx - 2 + k * 2, by - 2, 2, 2, k & 1 ? w : mixh(w, wd, 0.3f));
  }
  P(bx - 2, by, wd); P(bx + 10, by, wd);  // 支柱
  overgrow(s, bx + 4, by, 12, 2, 0);
}

void drawAltar(const Structure& s, int bx, int by, uint32_t ms) {
  const uint32_t stone = mixh(0x9A9AA4, 0x5E8A4A, s.moss * 0.5f), stoneD = mixh(0x6A6A74, 0x4A7040, s.moss * 0.5f);
  int pillarH = s.stage >= ST_COLLAPSED ? 3 : 5;
  R(bx - 4, by - pillarH, 2, pillarH, stoneD); R(bx + 2, by - pillarH, 2, pillarH, stoneD);
  if (s.stage < ST_COLLAPSED) R(bx - 5, by - pillarH - 2, 10, 2, stone);
  else { R(bx - 5, by - 2, 4, 2, stone); R(bx + 1, by - 1, 4, 1, stone); }  // 倒塌的石板
  bool glowing = !util::reached(ms, altarGlowUntil) || (s.flags & F_INUSE);
  if (glowing) {
    uint8_t in = (uint8_t)(120 + 80 * sinf(ms * 0.004f));
    gfx::glow(bx, by - pillarH - 1, 7, 0x8CB4FF, in);
    P(bx - 2, by - pillarH - 1, 0xC8DCFF); P(bx + 1, by - pillarH - 1, 0xC8DCFF);
  } else {
    P(bx - 2, by - pillarH - 1, 0x5A6A8C); P(bx + 1, by - pillarH - 1, 0x5A6A8C);  // 刻紋
  }
  overgrow(s, bx, by, 10, pillarH + 2, ms);
}

void drawStall(const Structure& s, int bx, int by) {
  const uint32_t w = woodC(s, 0x8C6440), wd = woodC(s, 0x5E4430);
  const uint32_t red = mixh(0xC83C3C, 0x6E5A50, s.decay * 0.8f + s.wet * 0.2f), white = mixh(0xF0E6D2, 0x8A8070, s.decay * 0.8f);
  bool standing = s.stage <= ST_OVERGROWN;
  int h = standing ? 12 : 4;
  for (int i = 0; i < h; i++) { P(bx - 7, by - 1 - i, wd); P(bx + 7, by - 1 - i, wd); }
  if (standing) {
    for (int x = -8; x <= 8; x++) for (int y = 0; y < 3; y++) {
      if (s.stage == ST_OVERGROWN && gone(s, x, y, 0.4f)) continue;
      P(bx + x, by - 13 + y + (abs(x) < 3 ? 1 : 0) * (s.decay > 0.3f), ((x + 8) / 3) & 1 ? red : white);
    }
    R(bx - 6, by - 5, 13, 2, w);  // 櫃檯
    if (s.flags & F_INUSE) {      // 擺出的貨物
      P(bx - 4, by - 6, 0xE6C850); P(bx - 2, by - 6, 0x6EC8E6); P(bx + 1, by - 6, 0xC86EA0); P(bx + 4, by - 6, 0x8CDC6E);
    }
  } else {
    for (int x = -8; x <= 8; x++) P(bx + x, by - 1 - (x & 1), (x / 3) & 1 ? red : white);  // 倒在地上的棚布
  }
  overgrow(s, bx, by, 16, h, 0);
}

void drawItem(const Structure& s, int bx, int by) {
  if (s.variant & 1) {  // 背包
    uint32_t c = woodC(s, 0xB4823C);
    R(bx - 1, by - 3, 3, 3, c); P(bx, by - 4, mixh(c, 0x3A2A20, 0.4f));
  } else {              // 地圖
    uint32_t c = mixh(0xF0E6C8, 0x8A8070, s.decay + s.wet * 0.3f);
    R(bx - 1, by - 2, 4, 2, c); P(bx, by - 2, 0xC8643C);
  }
  overgrow(s, bx, by, 4, 2, 0);
}

void drawOne(int i, uint32_t ms) {
  const Structure& s = st[i];
  const Site& p = SITES[s.site];
  const int bx = p.x >> 1, by = p.y >> 1;
  // 淡入 (剛建好) 與融入大地時的淡出
  float a = 1.0f;
  if (appearAt[i] && ms - appearAt[i] < 3000) a = (ms - appearAt[i]) / 3000.0f;
  if (s.stage == ST_MERGING) a *= 1.0f - (s.decay - 0.85f) / 0.15f * 0.85f;
  gA = (uint8_t)(255 * util::clamp01(a));
  switch (s.type) {
    case T_CABIN: drawCabin(s, bx, by, ms); break;
    case T_CAMPFIRE: drawCampfire(s, bx, by, ms); break;
    case T_TENT: drawTent(s, bx, by); break;
    case T_SIGN: drawSign(s, bx, by); break;
    case T_CRATE: drawCrate(s, bx, by); break;
    case T_FENCE: drawFence(s, bx, by); break;
    case T_TRAP: drawTrap(s, bx, by); break;
    case T_BRIDGE: drawBridge(s, bx, by); break;
    case T_ALTAR: drawAltar(s, bx, by, ms); break;
    case T_STALL: drawStall(s, bx, by); break;
    case T_ITEM: drawItem(s, bx, by); break;
    default: break;
  }
}
}  // namespace

void draw(int yMin, int yMax, uint32_t ms) {
  int idx[CAP], n = 0;
  for (int i = 0; i < CAP; i++) {
    if (st[i].type >= T_COUNT) continue;
    int y = SITES[st[i].site].y;
    if (y >= yMin && y < yMax) idx[n++] = i;
  }
  for (int a = 1; a < n; a++) { int v = idx[a], b = a - 1; while (b >= 0 && SITES[st[idx[b]].site].y > SITES[st[v].site].y) { idx[b + 1] = idx[b]; b--; } idx[b + 1] = v; }
  const bool w = gfx::world;
  gfx::world = false;
  for (int k = 0; k < n; k++) drawOne(idx[k], ms);
  gfx::world = w;
}

void exportBlob(Blob& b) { for (int i = 0; i < CAP; i++) b.s[i] = st[i]; }
void importBlob(const Blob& b) {
  for (int i = 0; i < CAP; i++) {
    st[i] = b.s[i];
    if (st[i].type >= T_COUNT || st[i].site >= SITE_N) { st[i].type = T_COUNT; continue; }
    st[i].flags &= ~(F_INUSE | F_LIT);  // 重開機時訪客已不在
    appearAt[i] = 0;
  }
}

}  // namespace structure
