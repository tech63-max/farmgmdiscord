#include "EventRecipes.h"
#include <Arduino.h>
#include <math.h>
#include "CreatureManager.h"
#include "Ecosystem.h"
#include "Evolution.h"
#include "Families.h"
#include "ForestHistory.h"
#include "Journal.h"
#include "Particles.h"
#include "PlantManager.h"
#include "Ruins.h"
#include "Scene.h"
#include "SeasonManager.h"
#include "StructureManager.h"
#include "TimeManager.h"
#include "Underground.h"
#include "Util.h"
#include "Village.h"
#include "VisitorManager.h"

namespace recipes {
namespace {
// ---- 配方表用到的常數 ----
enum Op : uint8_t { O_NONE, O_SPAWN, O_VISIT, O_EMERGE, O_FX, O_WORLD, O_PLANT, O_STRUCT, O_STORY, O_UNDER, O_RUIN, O_VILLAGE,
                    O_HIST, O_MEM, O_TERRAIN, O_TRIGGER, O_SPECIAL, O_HIDE, O_FIREFLY };
enum Place : uint8_t { PL_NONE, PL_EDGE, PL_TREE, PL_CANOPY, PL_POND, PL_GROUND, PL_BURROW, PL_RUIN, PL_VILLAGE, PL_STRUCT, PL_FLOWER,
                       PL_MUSH, PL_LOG, PL_SPROUT, PL_FOOD, PL_HOME, PL_TRAP, PL_ITEM, PL_ALTAR, PL_METEOR, PL_SKY };
enum Variant : uint8_t { VA_NONE, VA_NIGHT, VA_WET, VA_HUNTER, VA_CAMP, VA_RUIN, VA_FULLMOON };
constexpr uint8_t SE_SP = 1, SE_SU = 2, SE_AU = 4, SE_WI = 8;
enum WorldField : uint8_t { WF_ACORNS, WF_CACHE, WF_PUDDLE, WF_DROUGHT, WF_POND, WF_RUBBLE, WF_FOG, WF_MAGIC };
enum PlantOp : uint8_t { PO_SPROUT, PO_SPROUT3, PO_BOOST, PO_WITHER, PO_RAREBLOOM, PO_MUTATE, PO_REMOVE, PO_DISPERSE, PO_HEAL, PO_LOGSPROUT };
enum StructOp : uint8_t { SO_CREATE, SO_DAMAGE, SO_REPAIR, SO_VINE, SO_FINISH, SO_STRIKE, SO_WRECK };
enum UnderOp : uint8_t { UO_TIDY, UO_MOVE, UO_REVEAL, UO_GLOWCAVE, UO_MYCEL, UO_SPRING, UO_COLLAPSE, UO_TUNNEL, UO_DIG_RUIN };
enum RuinOp : uint8_t { RO_ERODE, RO_GLOW, RO_ROOTS };
enum VillageOp : uint8_t { VO_BUILD, VO_EXPAND, VO_TOWER, VO_STORAGE, VO_LANTERN, VO_REPAIR, VO_DAMAGE };
enum MemOp : uint8_t { MO_FEAR, MO_HOME, MO_FOOD, MO_DANGER, MO_FRIEND };
enum FxKind : uint8_t { FXK_SPARKLE, FXK_MAGIC, FXK_LEAVES, FXK_AUTUMN, FXK_SPLASH, FXK_DIRT, FXK_SEED, FXK_INSECT, FXK_GOLD, FXK_GREEN, FXK_ACORN, FXK_POLLEN, FXK_GLOW };
enum Special : uint8_t {
  SP_PLAYCHASE, SP_FOODFIGHT, SP_RAIN_BURROW, SP_FAMILY, SP_TRAP_AVOID, SP_TRAP_RESCUE, SP_MERCH_TRADE, SP_ANIMAL_SEED, SP_TREE_STRIKE,
  SP_SNOW, SP_DOUBLE_RAINBOW, SP_METEOR_CRASH, SP_HEAL, SP_LIGHT_ORB, SP_MAGIC_CREATURE, SP_ALTAR_WAKE, SP_MAGIC_RAIN, SP_FLOCK,
  SP_MASS_MIGRATE, SP_TURTLE, SP_TREE_SPIRIT, SP_MOON_FOX, SP_FESTIVAL, SP_TREASURE, SP_GATHERING, SP_RARE_NEST, SP_ENCHANT, SP_CAVE_CREATURE
};
#define NB(n) (1ULL << (n))
#include "EventRecipeTable.h"
#undef NB

uint8_t lastGroup = 0xFF;
bool lastVariant = false;
int8_t lastStruct = -1;
float rnd(float a, float b) { return util::rng.range(a, b); }
const Recipe& R(uint8_t id) { return RECIPES[id - FIRST_RECIPE]; }

bool seasonOk(uint8_t m) {
  const float w[4] = {season::weight(SPRING), season::weight(SUMMER), season::weight(AUTUMN), season::weight(WINTER)};
  for (int i = 0; i < 4; i++) if ((m & (1 << i)) && w[i] > 0.35f) return true;
  return false;
}

bool weatherOk(uint8_t wx) {
  const eco::Env& e = eco::env;
  const eco::World& w = eco::world;
  switch (wx) {
    case WX_ANY: return true;
    case WX_AFTER_RAIN: return e.hoursSinceRain < 3 && e.rain < 0.1f;
    case WX_CALM: return e.storm < 0.2f && e.wind < 0.5f && e.rain < 0.3f;
    case WX_CLEAR: return e.cloud < 0.5f && e.rain < 0.1f && e.fog < 0.4f;
    case WX_COLD: return e.tempC < 10;
    case WX_COOL: return e.tempC < 18;
    case WX_DROUGHT: return w.drought > 0.3f;
    case WX_DRY: return e.rain < 0.1f;
    case WX_HEAVY: return w.heavyRainH > 1 || e.rain > 0.7f;
    case WX_HUMID: return e.airHum > 78 || e.rain > 0.2f || e.hoursSinceRain < 6;
    case WX_MILD: return e.tempC > 10;
    case WX_STORM: return e.storm > 0.5f;
    case WX_STRESS: return w.drought > 0.3f || w.frost > 0.3f || w.puddle > 0.5f;
    case WX_WARM: return e.tempC > 20;
    case WX_WET: return e.rain > 0.2f;
    case WX_WINDY: return e.wind > 0.5f;
    default: return true;
  }
}

bool anyPlant(bool (*pred)(const plant::Plant&)) {
  for (int i = 0; i < plant::SLOT_N; i++) if (pred(plant::get(i))) return true;
  return false;
}
int ruinedStructure() {
  for (int i = 0; i < structure::CAP; i++) {
    const structure::Structure& s = structure::at(i);
    if (s.type < structure::T_COUNT && s.type != structure::T_ALTAR && s.stage >= structure::ST_COLLAPSED) return i;
  }
  return -1;
}
int structWhere(bool (*pred)(const structure::Structure&)) {
  int pick = -1, seen = 0;
  for (int i = 0; i < structure::CAP; i++) {
    const structure::Structure& s = structure::at(i);
    if (s.type < structure::T_COUNT && pred(s) && util::rng.irange(0, seen++) == 0) pick = i;
  }
  return pick;
}
bool villageIn(uint8_t lo, uint8_t hi) { uint8_t s = village::stage(); return s >= lo && s <= hi; }

bool needOk(uint8_t n, uint32_t ms) {
  using namespace creature;
  const eco::World& w = eco::world;
  const uint32_t now = timem::now();
  switch (n) {
    case N_ACORNS: return w.acornsGround >= 1;
    case N_ALTAR: return structure::find(structure::T_ALTAR) >= 0;
    case N_BRIDGE_FREE: return structure::freeSite(structure::T_BRIDGE) >= 0;
    case N_BUILDINGS: return structure::count() > 0 || villageIn(village::VS_HUT, village::VS_DAMAGED);
    case N_BURROW: return under::count() > 0;
    case N_BURROW_OCC: return under::findState(under::B_OCCUPIED) >= 0;
    case N_BURROW_ROOM: return under::count() < under::CAP;
    case N_CACHE: return w.acornCache >= 1;
    case N_CREATURES2: return activeCount() >= 2;
    case N_CRITTER: return !awayUntil(C_CRITTER);
    case N_DAMAGED:
      return village::stage() == village::VS_DAMAGED ||
             structWhere([](const structure::Structure& s) { return s.type != structure::T_ALTAR && s.stage >= structure::ST_WEATHERED && s.stage <= structure::ST_OVERGROWN; }) >= 0;
    case N_DAMP_ZONE: for (int x = 20; x < 240; x += 40) if (history::damp(x) > 0.6f) return true; return false;
    case N_FESTIVAL: return villageIn(village::VS_HUT, village::VS_EXPAND) || (count(C_SPRITE) + count(C_SHROOM) + count(C_FIREFLY)) >= 3;
    case N_FLOWERS2: return plant::bloomingFlowers() >= 2;
    case N_FLOWER_ANY: return plant::countSpecies(plant::P_FLOWER) > 0;
    case N_HIDDEN_OR_ROOM: return under::findState(under::B_HIDDEN) >= 0 || under::count() < under::CAP;
    case N_HUNTER_NEAR: return visitor::activeType() == visitor::V_HUNTER || evo::mem(C_CRITTER).fear > 60;
    case N_ITEM: return structure::find(structure::T_ITEM) >= 0 || structure::find(structure::T_CRATE) >= 0;
    case N_LOG2: return plant::log().state >= 2;
    case N_LOWFOOD: return (foodFor(C_CRITTER) + foodFor(C_BIRD) + foodFor(C_BUTTERFLY)) / 3 < 0.4f;
    case N_MAGIC_OR_FULL: return eco::env.magic > 0.2f || eco::fullMoonNight() || evo::magicDays() > 0;
    case N_MAGIC_OR_RARE:
      return eco::env.magic > 0.2f || w.meteorGlow > 0.3f || evo::magicDays() > 0 || anyPlant([](const plant::Plant& p) { return p.species != plant::P_NONE && (p.variant & 0x10); });
    case N_MERCHANT: return visitor::activeType() == visitor::V_MERCHANT || structure::find(structure::T_STALL) >= 0;
    case N_MERCHANT_GONE: { uint32_t t = visitor::lastTypeTime(visitor::V_MERCHANT); return !visitor::active() && t && now - t < 48 * 3600UL; }
    case N_METEOR: return w.meteorGlow > 0.3f;
    case N_MIGRATED: return history::count(history::H_MIGRATE) > 0;
    case N_MUSH: return plant::matureMushrooms() > 0;
    case N_MYCEL: return under::mycelium() > 0.3f;
    case N_NO_CABIN: return structure::find(structure::T_CABIN) < 0 && structure::freeSite(structure::T_CABIN) >= 0;
    case N_PLANT_ANY: return anyPlant([](const plant::Plant& p) { return p.species == plant::P_FLOWER || p.species == plant::P_MUSHROOM || p.species == plant::P_GLOW; });
    case N_RARE_PLANT: return plant::countStage(plant::P_GLOW, plant::S_BLOOM) > 0 || anyPlant([](const plant::Plant& p) { return p.species != plant::P_NONE && (p.variant & 0x10); });
    case N_RUIN_ANY: return ruins::exposed() >= 0 || ruins::excavated() >= 0;
    case N_RUIN_EXC: return ruins::excavated() >= 0;
    case N_RUIN_OR_WRECK: return ruins::excavated() >= 0 || ruinedStructure() >= 0;
    case N_RUIN_SLOT: return ruins::exposed() < 0 && ruins::hasFreeSite();
    case N_SAPLING_MATURE: return plant::randomSlotOf(plant::P_SAPLING, plant::S_MATURE) >= 0;
    case N_SPRITES_OR_VILLAGE: return count(C_SPRITE) > 0 || villageIn(village::VS_GATHER, village::VS_EXPAND);
    case N_SPROUT: return anyPlant([](const plant::Plant& p) { return p.species != plant::P_NONE && p.stage == plant::S_SPROUT; });
    case N_SQUIRREL: return !awayUntil(C_SQUIRREL);
    case N_STRUCT: return structure::count() > 0;
    case N_STRUCT_MERGING: return structWhere([](const structure::Structure& s) { return s.stage == structure::ST_MERGING && s.type != structure::T_ALTAR; }) >= 0;
    case N_STRUCT_OLD: return structWhere([](const structure::Structure& s) { return s.stage >= structure::ST_OVERGROWN && s.type != structure::T_ALTAR; }) >= 0;
    case N_TRAP: return structure::find(structure::T_TRAP) >= 0;
    case N_UNDER_WATER: return under::water() > 0.6f && under::count() > 0;
    case N_VILLAGE: return villageIn(village::VS_GATHER, village::VS_EXPAND);
    case N_VILLAGE_SETTLE: return villageIn(village::VS_HUT, village::VS_EXPAND);
    case N_VISITOR_OK: return visitor::canStart(ms);
    case N_WITHER: return anyPlant([](const plant::Plant& p) { return p.species != plant::P_NONE && p.stage == plant::S_WITHER; });
    default: return true;
  }
}

bool variantOn(uint8_t v) {
  switch (v) {
    case VA_NIGHT: return eco::env.night > 0.5f;
    case VA_WET: return eco::env.rain > 0.2f;
    case VA_HUNTER: return evo::mem(creature::C_CRITTER).fear > 60;
    case VA_CAMP: return history::count(history::H_CAMP) > 0;
    case VA_RUIN: return ruins::excavated() >= 0;
    case VA_FULLMOON: return eco::fullMoonNight();
    default: return false;
  }
}

// ---- 地點 → 世界座標 ----
bool slotPos(int s, float& x, float& y) { if (s < 0) return false; x = plant::SLOTS[s].x; y = plant::SLOTS[s].y; return true; }
void groundPos(float& x, float& y) {
  for (int k = 0; k < 6; k++) { x = rnd(16, 224); y = scene::walkY((int)x) + rnd(2, 10); if (!scene::inPond(x, y, -6)) return; }
  x = 60; y = scene::walkY(60) + 4;
}
void place(uint8_t pl, float& x, float& y) {
  switch (pl) {
    case PL_EDGE: x = util::rng.chance(0.5f) ? -10 : 250; y = scene::walkY(120); return;
    case PL_TREE: x = scene::TRUNK_X + rnd(14, 30); y = scene::walkY((int)x) + 2; return;
    case PL_CANOPY: x = rnd(10, 110); y = rnd(30, 80); return;
    case PL_POND: { bool l = util::rng.chance(0.5f); x = l ? 178 : 226; y = l ? 203 : 198; return; }  // 河岸
    case PL_BURROW: for (int i = 0; i < under::CAP; i++) if (under::at(i).state != under::B_NONE) { x = under::at(i).x; y = under::at(i).y; return; } break;
    case PL_RUIN: { int r = ruins::excavated(); if (r < 0) r = ruins::exposed(); if (r >= 0) { int ix, iy; ruins::pos(r, ix, iy); x = ix; y = iy; return; } break; }
    case PL_VILLAGE: x = 36; y = 206; return;
    case PL_STRUCT: {
      int s = lastStruct >= 0 && structure::at(lastStruct).type < structure::T_COUNT ? lastStruct : structWhere([](const structure::Structure&) { return true; });
      if (s >= 0) { x = structure::SITES[structure::at(s).site].x; y = structure::SITES[structure::at(s).site].y; return; }
      break;
    }
    case PL_FLOWER: { int s = plant::randomSlotOf(plant::P_FLOWER, plant::S_BLOOM); if (s < 0) s = plant::randomSlotOf(plant::P_FLOWER, plant::S_SPROUT); if (slotPos(s, x, y)) return; break; }
    case PL_MUSH: { int s = plant::randomSlotOf(plant::P_MUSHROOM, plant::S_SPROUT); if (slotPos(s, x, y)) return; x = 60; y = 198; return; }
    case PL_LOG: x = (scene::LOG_X0 + scene::LOG_X1) / 2; y = scene::LOG_Y - 2; return;
    case PL_SPROUT:
      for (int i = 0; i < plant::SLOT_N; i++) if (plant::get(i).species != plant::P_NONE && plant::get(i).stage == plant::S_SPROUT && slotPos(i, x, y)) return;
      break;
    case PL_FOOD: { int16_t f = evo::mem(creature::C_SQUIRREL).foodX; x = f >= 0 ? f : rnd(20, 100); y = scene::walkY((int)x) + 4; return; }
    case PL_HOME: x = scene::TRUNK_X - 18; y = scene::walkY(scene::TRUNK_X - 18) + 4; return;
    case PL_TRAP: case PL_ITEM: case PL_ALTAR: {
      int s = pl == PL_TRAP ? structure::find(structure::T_TRAP) : pl == PL_ALTAR ? structure::find(structure::T_ALTAR) : structure::find(structure::T_ITEM);
      if (s < 0 && pl == PL_ITEM) s = structure::find(structure::T_CRATE);
      if (s >= 0) { x = structure::SITES[structure::at(s).site].x; y = structure::SITES[structure::at(s).site].y; return; }
      break;
    }
    case PL_METEOR: x = eco::world.meteorX; y = evo::meteorNear() ? 206 : 168; return;
    case PL_SKY: x = rnd(20, 220); y = rnd(20, 60); return;
    default: break;
  }
  groundPos(x, y);
}

void burst(uint8_t kind, int n, float x, float y) {
  for (int k = 0; k < n; k++) {
    float px = x + rnd(-10, 10), py = y - rnd(0, 14);
    switch (kind) {
      case FXK_SPARKLE: fx::spawn(fx::PT_SPARKLE, px, py, 0, -6, (uint16_t)rnd(900, 1600), 0xFFF0A0); break;
      case FXK_MAGIC: fx::spawn(fx::PT_MAGIC, px, py, 0, rnd(-10, -2), (uint16_t)rnd(1200, 2600), k & 1 ? 0xB4A0FF : 0x8CDCFF); break;
      case FXK_LEAVES: fx::leaves(1, false); break;
      case FXK_AUTUMN: fx::leaves(1, true); break;
      case FXK_SPLASH: fx::spawn(fx::PT_SPLASH, px, y, rnd(-15, 15), rnd(-40, -20), 900, 0); if (k % 3 == 0) fx::ripple(px, y + 4, 6); break;
      case FXK_DIRT: fx::spawn(fx::PT_PETAL, px, y - 2, rnd(-12, 12), -14, 700, 0x7A5A3C); break;
      case FXK_SEED: fx::seedFlight(px, py, rnd(10, 230), scene::walkY((int)rnd(10, 230))); break;
      case FXK_INSECT: fx::spawn(fx::PT_INSECT, px, py, 0, 0, 25000, 0); break;
      case FXK_GOLD: fx::spawn(fx::PT_SPARKLE, px, py, 0, -8, (uint16_t)rnd(1200, 2400), 0xFFD24B); break;
      case FXK_GREEN: fx::spawn(fx::PT_SPARKLE, px, py, 0, -4, (uint16_t)rnd(1200, 2400), 0x9CE67A); break;
      case FXK_ACORN: fx::spawn(fx::PT_ACORN, rnd(20, 105), rnd(55, 85), rnd(-12, 12), 0, 30000, 0); break;
      case FXK_POLLEN: fx::spawn(fx::PT_POLLEN, px, py, rnd(4, 14), rnd(-6, 2), 5000, 0xFFE680); break;
      case FXK_GLOW: fx::spawn(fx::PT_GLOWDOT, px, py, rnd(-4, 4), -10, 1200, 0xFFA03C); break;
    }
  }
}

int spawnAt(creature::Species sp, float x, float y, uint32_t ms, uint32_t stayMs) {
  int i = creature::spawn(sp, ms, true);
  if (i < 0) return -1;
  creature::Creature& c = creature::at(i);
  c.tx = x + rnd(-8, 8); c.ty = y + rnd(-4, 4); c.state = creature::ST_MOVE; c.leaveAt = ms + stayMs;
  return i;
}

void plantOp(uint8_t sp, uint8_t op, float x) {
  (void)x;
  switch (op) {
    case PO_SPROUT: plant::sproutRandom((plant::Species)sp); break;
    case PO_SPROUT3: for (int k = 0; k < 3; k++) plant::sproutRandom((plant::Species)sp); break;
    case PO_BOOST:
      if (sp == plant::P_NONE) { plant::boostGrowth(3); break; }
      for (int i = 0; i < plant::SLOT_N; i++) { plant::Plant& p = plant::mut(i); if (p.species == sp && p.stage < plant::S_WITHER) p.prog = (uint16_t)fminf(999, p.prog + 350); }
      break;
    case PO_WITHER: {
      int n = 0;
      for (int i = 0; i < plant::SLOT_N && n < 2; i++) { plant::Plant& p = plant::mut(i); if (p.species == sp && p.stage == plant::S_BLOOM) { p.stage = plant::S_WITHER; p.prog = 400; n++; } }
      break;
    }
    case PO_RAREBLOOM: {
      int s = plant::randomSlotOf(plant::P_FLOWER, plant::S_GROW);
      if (s < 0) s = plant::randomSlotOf(plant::P_FLOWER, plant::S_SPROUT);
      if (s >= 0) { plant::Plant& p = plant::mut(s); p.stage = plant::S_BLOOM; p.prog = 0; p.variant |= 0x10; }  // 0x10 = 稀有/變異 (畫成金色光彩)
      break;
    }
    case PO_MUTATE: {
      int pick = -1, seen = 0;
      for (int i = 0; i < plant::SLOT_N; i++) {
        const plant::Plant& p = plant::get(i);
        if ((p.species == plant::P_FLOWER || p.species == plant::P_MUSHROOM || p.species == plant::P_GLOW) && !(p.variant & 0x10) && util::rng.irange(0, seen++) == 0) pick = i;
      }
      if (pick >= 0) plant::mut(pick).variant |= 0x10;
      break;
    }
    case PO_REMOVE: {
      int pick = -1, seen = 0;
      for (int i = 0; i < plant::SLOT_N; i++) {
        const plant::Plant& p = plant::get(i);
        if ((p.species == plant::P_FLOWER || p.species == plant::P_MUSHROOM) && util::rng.irange(0, seen++) == 0) pick = i;
      }
      if (pick >= 0) { plant::mut(pick).stage = plant::S_WITHER; plant::mut(pick).prog = 950; }  // 枯萎後自然消失 (不瞬間刪除)
      break;
    }
    case PO_DISPERSE: { int s = plant::randomSlotOf(plant::P_FLOWER, plant::S_BLOOM); if (s >= 0) plant::disperseSeeds(s, 2, true); break; }
    case PO_HEAL: break;  // 由 SP_HEAL 處理
    case PO_LOGSPROUT:
      for (int i = 0; i < plant::SLOT_N; i++)
        if (plant::SLOTS[i].zone == plant::Z_LOG && plant::get(i).species == plant::P_NONE && plant::hasLog()) { plant::sproutRandom(plant::P_MUSHROOM); break; }
      break;
  }
}

void structOp(uint8_t type, uint8_t op, uint32_t ms) {
  auto any = [](const structure::Structure& s) { return s.type != structure::T_ALTAR; };
  switch (op) {
    case SO_CREATE: { int s = structure::freeSite((structure::Type)type); if (s >= 0) lastStruct = (int8_t)structure::create((structure::Type)type, s, ms); break; }
    case SO_DAMAGE: { int i = structWhere(any); if (i >= 0) { structure::at(i).decay = fminf(0.84f, structure::at(i).decay + 0.2f); lastStruct = (int8_t)i; } break; }
    case SO_STRIKE: { int i = structWhere(any); if (i >= 0) { structure::at(i).decay = fminf(0.84f, structure::at(i).decay + 0.35f); lastStruct = (int8_t)i; eventm::flash(ms); } break; }
    case SO_WRECK: {
      for (int i = 0; i < structure::CAP; i++) {
        structure::Structure& s = structure::at(i);
        if (s.type == structure::T_TENT || s.type == structure::T_SIGN || s.type == structure::T_FENCE || s.type == structure::T_STALL || s.type == structure::T_CRATE) {
          s.decay = fminf(0.84f, s.decay + 0.3f); lastStruct = (int8_t)i;
        }
      }
      break;
    }
    case SO_REPAIR: {
      int best = -1;
      for (int i = 0; i < structure::CAP; i++) {
        const structure::Structure& s = structure::at(i);
        if (s.type < structure::T_COUNT && s.type != structure::T_ALTAR && s.stage <= structure::ST_OVERGROWN && (best < 0 || s.decay > structure::at(best).decay)) best = i;
      }
      if (best >= 0) { structure::Structure& s = structure::at(best); s.decay = fmaxf(0, s.decay - 0.2f); s.wet = 0; lastStruct = (int8_t)best; }
      break;
    }
    case SO_VINE: {
      int i = structWhere([](const structure::Structure& s) { return s.stage >= structure::ST_OVERGROWN && s.type != structure::T_ALTAR; });
      if (i >= 0) { structure::at(i).vine = 1; structure::at(i).moss = fminf(1, structure::at(i).moss + 0.2f); lastStruct = (int8_t)i; }
      break;
    }
    case SO_FINISH: {
      int i = structWhere([](const structure::Structure& s) { return s.stage == structure::ST_MERGING && s.type != structure::T_ALTAR; });
      if (i >= 0) { structure::at(i).decay = 0.995f; lastStruct = (int8_t)i; }
      break;
    }
  }
}

void underOp(uint8_t op, uint32_t ms) {
  switch (op) {
    case UO_TIDY: { int b = under::findState(under::B_OCCUPIED); if (b >= 0) under::at(b).dirt = 1; break; }
    case UO_MOVE: {
      int b = under::findState(under::B_OCCUPIED);
      if (b < 0) break;
      uint8_t occ = under::at(b).occupant;
      under::setState(b, under::B_ABANDONED);
      int n = under::digNear(occ, ms);
      if (n >= 0) evo::remember(creature::C_CRITTER, under::at(n).x, -1);
      break;
    }
    case UO_REVEAL: {
      int b = under::findState(under::B_HIDDEN);
      if (b >= 0) under::setState(b, under::B_ABANDONED);
      else { int n = under::digNear(creature::C_CRITTER, ms); if (n >= 0) under::setState(n, under::B_ABANDONED); }
      break;
    }
    case UO_GLOWCAVE: {
      evo::setGlowCave(true);
      int b = under::findState(under::B_ABANDONED);
      if (b >= 0) under::setState(b, under::B_MUSHROOM);
      break;
    }
    case UO_MYCEL: under::addMycelium(0.15f); under::glowMycelium(ms); break;
    case UO_SPRING: {
      under::addWater(0.15f);
      for (int i = 0; i < under::CAP; i++) if (under::at(i).state == under::B_ABANDONED || under::at(i).state == under::B_OCCUPIED) { under::setState(i, under::B_FLOODED); break; }
      break;
    }
    case UO_COLLAPSE: {
      int b = under::findState(under::B_OCCUPIED);
      if (b < 0) break;
      uint8_t occ = under::at(b).occupant;
      float ox = under::at(b).x;
      under::setState(b, under::B_NONE);
      eco::world.rubble = fmaxf(eco::world.rubble, 0.3f);
      burst(FXK_DIRT, 10, ox, scene::walkY((int)ox) + 4);
      int n = under::digNear(occ, ms);
      if (n >= 0) creature::emergeAt(occ < creature::C_COUNT ? (creature::Species)occ : creature::C_CRITTER, under::at(n).x, under::at(n).y, ms, 30000);
      break;
    }
    case UO_TUNNEL: if (under::digNear(creature::C_MOLE, ms) >= 0) evo::setTunnel(true); break;
    case UO_DIG_RUIN: {
      float x, y;
      int s = ruinedStructure();
      if (ruins::excavated() >= 0) place(PL_RUIN, x, y);
      else if (s >= 0) { x = structure::SITES[structure::at(s).site].x; y = structure::SITES[structure::at(s).site].y; structure::at(s).flags |= structure::F_NEST; }
      else break;
      if (under::dig(x + 8, y + 2, creature::C_CRITTER, ms) >= 0) history::note(history::H_BURROW, (int)x);
      break;
    }
  }
}

void special(uint8_t sp, eventm::Active& a, uint32_t ms) {
  using namespace creature;
  const uint32_t now = timem::now();
  float x, y;
  switch (sp) {
    case SP_PLAYCHASE: startChase(ms); break;
    case SP_FOODFIGHT: foodFight(ms); break;
    case SP_RAIN_BURROW:
      for (int i = 0; i < CAP; i++) {
        Creature& c = at(i);
        if (!c.active || c.state == ST_LEAVE || (c.sp != C_CRITTER && c.sp != C_SNAIL && c.sp != C_SQUIRREL && c.sp != C_MOLE)) continue;
        float bx, by;
        if (under::nearest(c.x, bx, by) < 0) break;
        c.state = ST_LEAVE; c.tx = bx; c.ty = by; c.flags |= F_FADE; c.until = ms + 30000;
      }
      break;
    case SP_FAMILY: families::startCritterFamily(ms); break;
    case SP_TRAP_AVOID: {
      place(PL_TRAP, x, y);
      visitPoint(C_CRITTER, x + (x < 120 ? -22 : 22), y, ms, 25000);  // 走近後停在陷阱旁，不踩上去
      burst(FXK_SPARKLE, 3, x, y);
      break;
    }
    case SP_TRAP_RESCUE: {
      place(PL_TRAP, x, y);
      int i = emergeAt(C_CRITTER, x, y + 1, ms, 60000);
      if (i < 0) break;
      at(i).flags |= F_TRAPPED;
      at(i).state = ST_ACT; at(i).until = ms + 60000;
      a.seed = (uint32_t)i;  // 記住被困的是哪一隻，事件結束時救出
      int j = spawnAt(C_CRITTER, x + 12, y, ms, 40000);
      if (j >= 0) at(j).flags |= F_LIT;
      break;
    }
    case SP_MERCH_TRADE: {
      float vx, vy;
      if (visitor::position(vx, vy)) visitPoint(C_CRITTER, vx + 12, vy, ms, 30000);
      else if (!visitor::startStory(visitor::S_TASK, visitor::TK_TRADE, ms)) { place(PL_ITEM, vx, vy); visitPoint(C_CRITTER, vx, vy, ms, 30000); }
      eco::world.acornCache = fmaxf(0, eco::world.acornCache - 1);
      if (village::stage() >= village::VS_GATHER && village::stage() <= village::VS_EXPAND) evo::villageTrade();
      journal::add(journal::J_X3_TRADE_GOODS, 0xFF, false);
      break;
    }
    case SP_ANIMAL_SEED: { place(PL_GROUND, x, y); visitPoint(C_CRITTER, x, y, ms, 30000); a.x = x; break; }
    case SP_TREE_STRIKE: {
      eventm::flash(ms);
      int s = plant::randomSlotOf(plant::P_SAPLING, plant::S_MATURE);
      if (s >= 0) { plant::mut(s).stage = plant::S_WITHER; plant::mut(s).prog = 900; x = plant::SLOTS[s].x; }
      else x = 196;  // 遠處的樹
      burst(FXK_GLOW, 10, x, 130);
      history::note(history::H_LIGHTNING, (int)x);
      evo::addTerrain(evo::TF_DEAD, (int)x, 0.2f);
      evo::setDanger((int16_t)x);
      break;
    }
    case SP_SNOW: evo::addSnow(0.5f); break;
    case SP_DOUBLE_RAINBOW: eventm::trigger(eventm::R_RAINBOW, ms, true); evo::doubleRainbowUntil() = ms + 90000; break;
    case SP_METEOR_CRASH:
      eco::world.meteorX = (int16_t)rnd(150, 220);
      eco::world.meteorGlow = 1;
      evo::setMeteorNear(true);
      eco::world.rubble = fmaxf(eco::world.rubble, 0.3f);
      history::note(history::H_MYSTIC, eco::world.meteorX);
      a.x = eco::world.meteorX;
      break;
    case SP_HEAL: {
      int n = 0;
      for (int i = 0; i < plant::SLOT_N && n < 3; i++) {
        plant::Plant& p = plant::mut(i);
        if (p.species != plant::P_NONE && p.stage == plant::S_WITHER) {
          p.stage = plant::S_MATURE; p.prog = 0; n++;
          burst(FXK_GREEN, 6, plant::SLOTS[i].x, plant::SLOTS[i].y);
          if (n == 1) visitPoint(C_SPRITE, plant::SLOTS[i].x, plant::SLOTS[i].y - 18, ms, 30000);
        }
      }
      break;
    }
    case SP_LIGHT_ORB: {
      int i = spawn(C_VISITOR, ms, true);
      if (i >= 0) { at(i).variant = 11; at(i).leaveAt = ms + 40000; at(i).x = -8; at(i).y = rnd(120, 170); }
      break;
    }
    case SP_MAGIC_CREATURE: {
      int pick = -1, seen = 0;
      for (int i = 0; i < CAP; i++) if (at(i).active && at(i).state != ST_LEAVE && at(i).sp != C_FIREFLY && util::rng.irange(0, seen++) == 0) pick = i;
      if (pick >= 0) { at(pick).flags |= F_MAGIC; at(pick).leaveAt = ms + 60000; }
      break;
    }
    case SP_ALTAR_WAKE:
      structure::glowAltar(ms);
      eco::env.magic = fminf(1, eco::env.magic + 0.3f);
      place(PL_ALTAR, x, y);
      for (int k = 0; k < 3; k++) spawnAt(C_SPRITE, x, y - 16, ms, 40000);
      history::note(history::H_MYSTIC, (int)x);
      break;
    case SP_MAGIC_RAIN: eco::bless(ms); plant::boostGrowth(1); burst(FXK_MAGIC, 16, 120, 120); break;
    case SP_FLOCK:
      for (int k = 0; k < 4; k++) {
        int i = spawn(C_BIRD, ms, true);
        if (i < 0) break;
        Creature& c = at(i);
        c.x = -10 - k * 9; c.y = 30 + k * 6; c.state = ST_LEAVE; c.tx = 262; c.ty = c.y - 10; c.until = ms + 30000;
      }
      break;
    case SP_MASS_MIGRATE: {
      const Species S[] = {C_BUTTERFLY, C_BIRD, C_CRITTER, C_BEE, C_SQUIRREL};
      int n = 0;
      for (Species s : S) {
        if (n >= 2 || awayUntil(s) || foodFor(s) > 0.5f) continue;
        setAwayUntil(s, now + util::shortS(util::rng.irange(6, 14) * 3600.0f));
        for (int i = 0; i < CAP; i++) if (at(i).active && at(i).sp == s && at(i).state != ST_LEAVE) { at(i).state = ST_LEAVE; at(i).tx = at(i).x < 120 ? -20 : 260; at(i).until = ms + 40000; }
        history::note(history::H_MIGRATE, 120, s);
        n++;
      }
      break;
    }
    case SP_TURTLE: { int i = spawn(C_TURTLE, ms, true); if (i >= 0) at(i).leaveAt = ms + 110000; history::note(history::H_MYSTIC, 120); break; }
    case SP_TREE_SPIRIT: {
      int i = spawn(C_VISITOR, ms, true);
      if (i >= 0) { at(i).variant = 10; at(i).x = scene::TRUNK_X + 18; at(i).y = 150; at(i).leaveAt = ms + 45000; }
      history::note(history::H_MYSTIC, scene::TRUNK_X);
      break;
    }
    case SP_MOON_FOX: { int i = spawn(C_CRITTER, ms, true); if (i >= 0) { at(i).variant = 9; at(i).leaveAt = ms + 45000; } history::note(history::H_MYSTIC, 120); break; }
    case SP_FESTIVAL: {
      place(villageIn(village::VS_HUT, village::VS_EXPAND) ? PL_VILLAGE : PL_TREE, x, y);
      a.x = x; a.y = y - 12;
      for (int k = 0; k < 3; k++) spawnAt(C_SPRITE, x, y - 18, ms, 55000);
      visitPoint(C_SHROOM, x + 10, y + 2, ms, 50000);
      gatherFireflies(x, y - 16, ms, 6);
      evo::addLantern();
      history::note(history::H_VILLAGE, (int)x, 2);
      break;
    }
    case SP_TREASURE: {
      int r = ruins::excavated();
      if (r < 0) break;
      int ix, iy; ruins::pos(r, ix, iy);
      a.x = ix; a.y = iy - 8;
      burst(FXK_GOLD, 20, ix, iy);
      eco::env.magic = fminf(1, eco::env.magic + 0.3f);
      plant::sproutRandom(plant::P_GLOW);
      ruins::mark(r);
      history::note(history::H_RUIN, ix, 9);
      break;
    }
    case SP_GATHERING: {
      const Species S[] = {C_CRITTER, C_SQUIRREL, C_FROG, C_SNAIL, C_SHROOM, C_BIRD};
      int k = 0;
      for (Species s : S) visitPoint(s, 140 + (k++) * 14, 196 + (k & 1) * 6, ms, 50000);
      break;
    }
    case SP_RARE_NEST: {
      evo::startRareNest(10);
      int i = spawn(C_CRITTER, ms, true);
      if (i >= 0) { at(i).variant = 9; at(i).tx = scene::TRUNK_X + 20; at(i).ty = scene::walkY(scene::TRUNK_X + 20) + 2; at(i).state = ST_MOVE; at(i).leaveAt = ms + 40000; }
      history::note(history::H_MYSTIC, scene::TRUNK_X);
      break;
    }
    case SP_ENCHANT:
      evo::startEnchant(3);
      eco::env.magic = 1;
      burst(FXK_MAGIC, 24, 120, 100);
      history::note(history::H_MYSTIC, 120, 100);
      break;
    case SP_CAVE_CREATURE: {
      place(PL_BURROW, x, y);
      int i = emergeAt(C_VISITOR, x, y - 4, ms, 30000);
      if (i >= 0) at(i).variant = 12;
      break;
    }
  }
}

void runOp(const OpDef& o, eventm::Active& a, uint32_t ms) {
  float x = 0, y = 0;
  if (o.place != PL_NONE) place(o.place, x, y);
  const uint32_t dur = a.end - a.start;
  switch (o.op) {
    case O_SPAWN: for (int k = 0; k < (o.b > 0 ? o.b : 1); k++) spawnAt((creature::Species)o.a, x, y, ms, dur); break;
    case O_VISIT: creature::visitPoint((creature::Species)o.a, x, y, ms, (o.b > 0 ? o.b : 30) * 1000u); break;
    case O_EMERGE: creature::emergeAt((creature::Species)o.a, x, y, ms, dur); break;
    case O_FX: burst(o.a, o.b, x, y); break;
    case O_WORLD: {
      eco::World& w = eco::world;
      const float d = o.b / 10.0f;
      switch (o.a) {
        case WF_ACORNS: w.acornsGround = util::clamp(w.acornsGround + d, 0.0f, 10.0f); break;
        case WF_CACHE: w.acornCache = util::clamp(w.acornCache + d, 0.0f, 12.0f); break;
        case WF_PUDDLE: w.puddle = util::clamp01(w.puddle + d); break;
        case WF_DROUGHT: w.drought = util::clamp01(w.drought + d); break;
        case WF_POND: w.pondLevel = util::clamp(w.pondLevel + d, 0.4f, 1.1f); break;
        case WF_RUBBLE: w.rubble = fmaxf(w.rubble, d); break;
        case WF_FOG: eco::env.fog = fmaxf(eco::env.fog, d); break;
        case WF_MAGIC: eco::env.magic = util::clamp01(eco::env.magic + d); break;
      }
      break;
    }
    case O_PLANT: plantOp(o.a, (uint8_t)o.b, x); break;
    case O_STRUCT: structOp(o.a, (uint8_t)o.b, ms); break;
    case O_STORY: visitor::startStory(o.a, (uint8_t)o.b, ms); break;
    case O_UNDER: underOp(o.a, ms); break;
    case O_RUIN:
      if (o.a == RO_ERODE) ruins::erode(ms);
      else { int r = ruins::excavated(); if (r >= 0) { if (o.a == RO_GLOW) ruins::glow(r, ms); else ruins::at(r).roots = fminf(0.9f, ruins::at(r).roots + 0.3f); } }
      break;
    case O_VILLAGE:
      switch (o.a) {
        case VO_BUILD: village::boost(); break;
        case VO_EXPAND: village::grow(); break;
        case VO_TOWER: evo::buildTower(); break;
        case VO_STORAGE: evo::buildStorage(); break;
        case VO_LANTERN: evo::addLantern(); break;
        case VO_REPAIR: village::repair(); break;
        case VO_DAMAGE: village::damage(0.4f); break;
      }
      break;
    case O_HIST: history::note((history::Kind)o.a, (int)x); break;
    case O_MEM: {
      const uint8_t sp = (uint8_t)o.b;
      switch (o.a) {
        case MO_FEAR: evo::fearHunter(o.b); break;
        case MO_HOME: { float bx = x, by = y; if (under::nearest(120, bx, by) < 0) bx = x; evo::remember(sp, (int16_t)bx, -1); break; }
        case MO_FOOD: evo::remember(sp, -1, (int16_t)x); break;
        case MO_DANGER: evo::setDanger((int16_t)(x > 0 ? x : 120)); break;
        case MO_FRIEND: evo::setFriend(sp, sp == creature::C_CRITTER ? creature::C_SQUIRREL : creature::C_CRITTER); break;
      }
      break;
    }
    case O_TERRAIN: evo::addTerrain(o.a, (int)(x > 0 ? x : 120), o.b / 100.0f); break;
    case O_TRIGGER:
      if (o.b <= 1) eventm::trigger((eventm::EvId)o.a, ms, true);
      else eventm::queue((eventm::EvId)o.a, ms, o.b * 1000u);
      break;
    case O_SPECIAL: special(o.a, a, ms); break;
    case O_HIDE: creature::hideFrom(x, o.b * 2, ms); break;
    case O_FIREFLY: creature::gatherFireflies(x, y - 14, ms, o.b > 0 ? o.b : 4); break;
    default: break;
  }
}
}  // namespace

bool is(uint8_t id) { return id >= FIRST_RECIPE && id < FIRST_RECIPE + RECIPE_N; }

float cond(uint8_t id) {
  if (!is(id)) return 0;
  const Recipe& r = R(id);
  if (r.phases && !(timem::phaseMask() & r.phases)) return 0;
  if (r.seasons && !seasonOk(r.seasons)) return 0;
  if (r.moon && !(r.moon & (1 << eco::moon()))) return 0;
  if (!weatherOk(r.weather)) return 0;
  const uint32_t ms = millis();
  for (uint8_t n = 0; n < N_COUNT; n++) if ((r.needs & (1ULL << n)) && !needOk(n, ms)) return 0;
  float m = 1.0f;
  // 記憶影響權重：記得朋友 → 更常分享/互助；記得獵人 → 更常躲藏
  if (r.group == G_FOOD && evo::mem(creature::C_CRITTER).friendSp != 0xFF) m *= 1.3f;
  if (r.group == G_HIDE && evo::mem(creature::C_CRITTER).fear > 60) m *= 1.5f;
  return m;
}

void start(uint8_t id, eventm::Active& a, uint32_t ms) {
  if (!is(id)) return;
  const Recipe& r = R(id);
  lastStruct = -1;
  lastVariant = r.variant != VA_NONE && variantOn(r.variant);
  const OpDef* ops = (lastVariant && r.alt[0].op != O_NONE) ? r.alt : r.ops;  // 變體：另一組演出
  for (int k = 0; k < 3; k++) if (ops[k].op != O_NONE) runOp(ops[k], a, ms);
  lastGroup = r.group;
}

void update(eventm::Active& a, float dt, uint32_t ms) {
  if (!is(a.id)) return;
  const Recipe& r = R(a.id);
  if (r.ops[0].op != O_SPECIAL) return;
  switch (r.ops[0].a) {
    case SP_FESTIVAL:
      if (util::rng.chance(dt * 6)) fx::spawn(fx::PT_SPARKLE, a.x + rnd(-20, 20), a.y + rnd(-10, 6), 0, -8, 1400, util::rng.chance(0.5f) ? 0xFFD24B : 0xFF8CC8);
      break;
    case SP_TRAP_RESCUE: {
      creature::Creature& c = creature::at(a.seed % creature::CAP);
      if (c.active && (c.flags & creature::F_TRAPPED) && util::rng.chance(dt * 2)) fx::spawn(fx::PT_PETAL, c.x + rnd(-4, 4), c.y - 4, rnd(-10, 10), -10, 500, 0xC8B48C);
      break;
    }
    case SP_TREASURE:
      if (util::rng.chance(dt * 4)) fx::spawn(fx::PT_SPARKLE, a.x + rnd(-8, 8), a.y + rnd(-6, 6), 0, -10, 1200, 0xFFD24B);
      break;
    default: break;
  }
  (void)ms;
}

void finish(eventm::Active& a, uint32_t ms) {
  if (!is(a.id)) return;
  const Recipe& r = R(a.id);
  if (r.ops[0].op != O_SPECIAL) return;
  switch (r.ops[0].a) {
    case SP_TRAP_RESCUE: {  // 同伴把被困的小生物救出來
      creature::Creature& c = creature::at(a.seed % creature::CAP);
      if (c.active && (c.flags & creature::F_TRAPPED)) { c.flags &= ~creature::F_TRAPPED; c.state = creature::ST_IDLE; c.until = ms + 2000; }
      int t = structure::find(structure::T_TRAP);
      if (t >= 0) { structure::at(t).flags |= structure::F_TRIGGERED; structure::at(t).decay = fminf(0.84f, structure::at(t).decay + 0.2f); }
      evo::setFriend(creature::C_CRITTER, creature::C_CRITTER);
      journal::add(journal::J_X3_FREED);
      break;
    }
    case SP_ANIMAL_SEED: {  // 小動物身上的種子掉在新的地方
      int s = plant::randomSlotOf(plant::P_FLOWER, plant::S_GROW);
      if (s >= 0) plant::disperseSeeds(s, 1, true);
      break;
    }
    default: break;
  }
}

uint16_t journalMsg(uint8_t id, uint16_t normal) {
  if (!is(id)) return normal;
  const Recipe& r = R(id);
  return (lastVariant && r.altMsg != journal::J_NONE) ? r.altMsg : normal;
}

float weightFactor(uint8_t id) {
  if (!is(id)) return 1.0f;
  const Recipe& r = R(id);
  float f = 1.0f;
  if (r.group == lastGroup) f *= 0.3f;  // 相似事件避免連續發生
  // 同一地點已有事件在進行 → 降低 (同一區域事件限制)
  for (int i = 0; i < eventm::ACTIVE_CAP; i++) {
    const eventm::Active& o = eventm::active(i);
    if (o.on && is(o.id) && R(o.id).ops[0].place == r.ops[0].place && r.ops[0].place != PL_NONE) f *= 0.3f;
  }
  return f;
}

}  // namespace recipes
