// 人造建築與物件：建立、天氣腐朽、植物入侵、崩塌、融入大地 (自然回收)
// 腐朽以「森林時間」計算，雨水加速木材腐朽但也促進苔蘚/蘑菇；石頭祭壇會成為長久的遺跡。
#pragma once
#include <stdint.h>

namespace structure {

enum Type : uint8_t { T_CABIN, T_CAMPFIRE, T_TENT, T_SIGN, T_CRATE, T_FENCE, T_TRAP, T_BRIDGE, T_ALTAR, T_STALL, T_ITEM, T_COUNT };
// 階段：0 全新、1 受天氣影響、2 植物入侵、3 崩塌、4 融入大地
enum Stage : uint8_t { ST_NEW, ST_WEATHERED, ST_OVERGROWN, ST_COLLAPSED, ST_MERGING };
constexpr uint16_t F_INUSE = 1, F_LIT = 2, F_NEST = 4, F_SAID_WET = 8, F_SAID_MOSS = 16, F_SAID_MUSH = 32, F_SAID_VINE = 64,
                   F_WIND_HIT = 128, F_TRIGGERED = 256, F_SAID_SAPLING = 512;

struct Structure {
  uint8_t type;      // T_COUNT = 空位
  uint8_t site;
  uint8_t stage;
  uint8_t variant;
  uint16_t flags;
  uint32_t built;    // 建立時間 (epoch)
  float decay;       // 0..1 腐朽程度 (>=1 → 完全回收)
  float wet;         // 0..1 潮濕
  float moss, mush, vine;  // 0..1 植物入侵程度
};

struct Site { short x, y; uint16_t allowMask; };
constexpr int SITE_N = 6;
constexpr int CAP = 6;          // 同時存在的物件上限 (避免畫面充滿人造物)
extern const Site SITES[SITE_N];

void begin();
void tick(float dtSimSec);                 // 腐朽/回收 (森林時間)
void update(float dt, uint32_t ms);        // 動畫 (營火、煙、滴水)
int create(Type t, int site, uint32_t ms); // 回傳索引；-1 = 沒位置
int freeSite(Type t);                      // 找可用的位置，-1 = 沒有
int find(Type t);                          // 找第一個該類型的物件
int count();
Structure& at(int i);
void setUse(int i, bool inUse);
void setLit(int i, bool lit);
void remove(int i);
void glowAltar(uint32_t ms);
const char* name(uint8_t t);
void draw(int yMin, int yMax, uint32_t ms);  // 世界座標 y 範圍 (依 y 排序)

// 存檔
struct Blob { Structure s[CAP]; };
void exportBlob(Blob& b);
void importBlob(const Blob& b);

}  // namespace structure
