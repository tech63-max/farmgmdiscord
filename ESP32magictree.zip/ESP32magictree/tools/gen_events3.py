"""第三階段：100 個資料驅動事件 (事件配方)
一份清單同步產生：EventManager 的事件編號/定義/名稱、Journal 訊息、src/EventRecipeTable.h
用法：python tools/gen_events3.py .   (可重複執行：會先移除上次產生的內容)
"""
import re
import sys

root = sys.argv[1]
D, R, I, V, M = 'CAT_DAILY', 'CAT_RARE', 'CAT_INTERACT', 'CAT_ENV', 'CAT_MYSTERY'


def E(id, cat, w, cd, dur, ph, se, wx, needs, grp, var, text, alt, ops, altops=(), fol=(), moon='any'):
    return dict(id=id, cat=cat, w=w, cd=cd, dur=dur, ph=ph, se=se, wx=wx, moon=moon, needs=needs, grp=grp, var=var,
                text=text, alt=alt, ops=list(ops), altops=list(altops), fol=list(fol))


EV = [
    # ===== A. 生物日常與互動 (15) =====
    E('X_PLAY_CHASE', I, 4, 3, 30, 'day', '', 'calm', ['CRITTER'], 'chase', 'night', '兩隻小生物在草地上追逐嬉戲', '兩隻小生物在月光下追逐',
      ['SPECIAL SP_PLAYCHASE']),
    E('X_FRUIT_HOME', D, 5, 2, 50, 'day|dusk', '', 'dry', ['ACORNS', 'SQUIRREL'], 'food', 'none', '小生物找到果實，搬回巢穴', '',
      ['VISIT C_SQUIRREL 30 FOOD', 'WORLD WF_ACORNS -10', 'MEM MO_FOOD C_SQUIRREL']),
    E('X_SHARE_FOOD', I, 3, 8, 40, 'day|dusk', '', 'any', ['CACHE', 'CRITTER'], 'food', 'none', '兩隻小生物分享了食物', '',
      ['VISIT C_CRITTER 20 HOME', 'VISIT C_SQUIRREL 20 HOME', 'MEM MO_FRIEND C_CRITTER']),
    E('X_TIDY_NEST', D, 3, 8, 30, 'day|dusk|dawn', '', 'any', ['BURROW_OCC'], 'home', 'none', '小生物幫同伴整理巢穴', '',
      ['EMERGE C_CRITTER 0 BURROW', 'UNDER UO_TIDY', 'FX FXK_DIRT 8 BURROW']),
    E('X_SQUABBLE', I, 2, 10, 30, 'day', '', 'any', ['ACORNS', 'CRITTER'], 'food', 'none', '為了一顆果實起了小衝突', '',
      ['SPECIAL SP_FOODFIGHT']),
    E('X_STARTLED', D, 3, 4, 20, 'any', '', 'any', ['CREATURES2'], 'scare', 'none', '小生物被突然冒出來的同伴嚇了一跳', '',
      ['HIDE 0 30 GROUND', 'FX FXK_DIRT 6 GROUND']),
    E('X_TREE_NAP', D, 4, 3, 60, 'day|dusk', '', 'any', ['CRITTER'], 'rest', 'wet', '小生物在古樹下睡午覺', '小生物在樹下一邊躲雨一邊打盹',
      ['VISIT C_CRITTER 40 TREE']),
    E('X_RAIN_BURROW', D, 4, 3, 30, 'any', '', 'wet', ['BURROW'], 'hide', 'none', '下雨了，小生物躲進洞穴', '',
      ['SPECIAL SP_RAIN_BURROW']),
    E('X_SPLASH', D, 3, 4, 40, 'day', 'sp|su', 'warm', ['CRITTER'], 'water', 'none', '小生物在池塘邊玩水', '',
      ['VISIT C_CRITTER 25 POND', 'FX FXK_SPLASH 10 POND']),
    E('X_NEW_PLANT', D, 3, 4, 30, 'day|dawn', '', 'any', ['SPROUT'], 'curious', 'none', '小生物發現新冒出的嫩芽，好奇地觀察', '',
      ['VISIT C_SPRITE 20 SPROUT', 'FX FXK_GREEN 6 SPROUT']),
    E('X_HELP_FORAGE', I, 3, 6, 40, 'day', '', 'dry', ['CRITTER'], 'food', 'none', '小生物互相幫忙找食物', '',
      ['VISIT C_CRITTER 25 GROUND', 'VISIT C_SQUIRREL 25 GROUND', 'MEM MO_FRIEND C_SQUIRREL']),
    E('X_NIGHT_GATHER', D, 3, 8, 50, 'night', '', 'calm', [], 'gather', 'none', '夜裡，小生物們聚在古樹下', '',
      ['VISIT C_SHROOM 30 TREE', 'VISIT C_CRITTER 30 TREE', 'FIREFLY 0 4 TREE']),
    E('X_MOVE_HOUSE', I, 2, 24, 30, 'dawn|dusk|night', '', 'any', ['BURROW_OCC'], 'home', 'none', '小生物搬到新的家', '',
      ['UNDER UO_MOVE', 'MEM MO_HOME C_CRITTER', 'FX FXK_DIRT 8 BURROW']),
    E('X_CARE_YOUNG', I, 2, 24, 50, 'day', 'sp|su', 'calm', ['CRITTER'], 'family', 'none', '小獸細心照顧著幼崽', '',
      ['SPECIAL SP_FAMILY']),
    E('X_FIND_ITEM', D, 3, 8, 30, 'day|dusk', '', 'any', ['ITEM'], 'curious', 'none', '小生物發現其他生物留下的物品', '',
      ['VISIT C_CRITTER 20 ITEM', 'FX FXK_SPARKLE 6 ITEM']),
    # ===== B. 冒險家、獵人與商人 (15) =====
    E('X_ADV_EXPLORE', I, 2, 12, 20, 'any', '', 'any', ['VISITOR_OK'], 'visitor', 'hunter', '冒險家走進森林探索', '冒險家走進森林，小動物們記得獵人，早早躲了起來',
      ['STORY S_TASK TK_EXPLORE'], ['STORY S_TASK TK_EXPLORE', 'HIDE 0 120 GROUND']),
    E('X_ADV_RUIN', I, 2, 24, 20, 'day|dusk', '', 'any', ['VISITOR_OK', 'RUIN_ANY'], 'visitor', 'none', '冒險家循著線索前往古代遺跡', '',
      ['STORY S_DIG 0']),
    E('X_ADV_CAMP', I, 1.5, 48, 20, 'afternoon|dusk', '', 'dry', ['VISITOR_OK'], 'visitor', 'camp', '冒險家搭建臨時營地', '冒險家回到以前紮營過的地方',
      ['STORY S_CAMP 0']),
    E('X_ADV_CABIN', I, 1, 168, 20, 'day', '', 'dry', ['VISITOR_OK', 'NO_CABIN'], 'visitor', 'none', '冒險家決定在空地蓋一間木屋', '',
      ['STORY S_CABIN 0']),
    E('X_ADV_CHOP', I, 1, 72, 20, 'day', '', 'dry', ['VISITOR_OK', 'SAPLING_MATURE'], 'visitor', 'none', '冒險家砍下一棵小樹當木材', '',
      ['STORY S_TASK TK_CHOP']),
    E('X_ADV_MUSHROOM', I, 2, 24, 20, 'day|dawn', '', 'any', ['VISITOR_OK', 'MUSH'], 'visitor', 'none', '冒險家彎腰採集蘑菇', '',
      ['STORY S_TASK TK_MUSHROOM']),
    E('X_ADV_RARE_PLANT', I, 1.5, 48, 20, 'day', '', 'any', ['VISITOR_OK', 'RARE_PLANT'], 'visitor', 'none', '冒險家發現了一株稀有植物', '',
      ['STORY S_TASK TK_RAREPLANT']),
    E('X_HUNT_TRAP', I, 1, 48, 20, 'dawn|morning|afternoon', '', 'dry', ['VISITOR_OK', 'CRITTER'], 'visitor', 'none', '獵人在森林裡設下陷阱', '',
      ['STORY S_HUNT 0']),
    E('X_TRAP_AVOID', I, 3, 6, 30, 'any', '', 'any', ['TRAP'], 'trap', 'none', '小生物發現陷阱，小心地繞了過去', '',
      ['SPECIAL SP_TRAP_AVOID']),
    E('X_TRAP_RESCUE', I, 2, 24, 40, 'any', '', 'any', ['TRAP'], 'trap', 'none', '小生物被陷阱困住，同伴趕來救援', '',
      ['SPECIAL SP_TRAP_RESCUE']),
    E('X_HUNT_TRACK', I, 1, 36, 20, 'dawn|morning|afternoon', '', 'any', ['VISITOR_OK', 'CRITTER'], 'visitor', 'none', '獵人蹲下來，沿著足跡追蹤', '',
      ['STORY S_TASK TK_TRACK']),
    E('X_HUNT_HIDE', I, 3, 6, 20, 'any', '', 'any', ['HUNTER_NEAR'], 'hide', 'none', '生物察覺到獵人，紛紛躲了起來', '',
      ['HIDE 0 120 GROUND', 'MEM MO_FEAR 40']),
    E('X_MERCHANT_ARRIVE', I, 1, 36, 20, 'day', '', 'dry', ['VISITOR_OK'], 'visitor', 'wet', '商人推著貨物走進森林', '商人披著雨布、推著貨物走進森林',
      ['STORY S_MERCHANT 0']),
    E('X_MERCHANT_TRADE', I, 3, 12, 40, 'day', '', 'any', ['MERCHANT'], 'trade', 'none', '商人和森林生物交換了物品', '',
      ['SPECIAL SP_MERCH_TRADE']),
    E('X_MERCHANT_DROP', I, 3, 48, 20, 'any', '', 'any', ['MERCHANT_GONE'], 'trade', 'none', '商人離開時遺落了一些物品', '',
      ['STRUCT T_CRATE SO_CREATE', 'FX FXK_SPARKLE 6 ITEM']),
    # ===== C. 建築、文明與遺跡 (12) =====
    E('X_VL_BUILD', I, 3, 24, 40, 'day|dusk', '', 'calm', ['VILLAGE'], 'village', 'none', '森林生物開始建造小型住所', '',
      ['VILLAGE VO_BUILD', 'VISIT C_SPRITE 30 VILLAGE', 'FX FXK_SPARKLE 8 VILLAGE']),
    E('X_VL_GROW', I, 2, 48, 30, 'day', '', 'calm', ['VILLAGE_SETTLE'], 'village', 'none', '小型聚落一點一點地擴張', '',
      ['VILLAGE VO_EXPAND', 'VILLAGE VO_LANTERN', 'FX FXK_SPARKLE 8 VILLAGE']),
    E('X_BUILD_BRIDGE', I, 1.5, 96, 30, 'day', '', 'dry', ['BRIDGE_FREE', 'SPRITES_OR_VILLAGE'], 'build', 'none', '生物們合力在池塘邊搭起小木橋', '',
      ['STRUCT T_BRIDGE SO_CREATE', 'VISIT C_SPRITE 30 POND', 'FX FXK_SPARKLE 8 POND']),
    E('X_BUILD_TOWER', I, 1.5, 96, 30, 'day', '', 'calm', ['VILLAGE_SETTLE'], 'build', 'none', '小精靈蓋了一座森林瞭望台', '',
      ['VILLAGE VO_TOWER', 'FX FXK_SPARKLE 10 VILLAGE']),
    E('X_BUILD_STORAGE', I, 1.5, 96, 30, 'day', '', 'calm', ['VILLAGE_SETTLE'], 'build', 'none', '小精靈蓋了一間儲藏食物的小倉庫', '',
      ['VILLAGE VO_STORAGE', 'FX FXK_SPARKLE 8 VILLAGE']),
    E('X_REPAIR', I, 3, 24, 40, 'day', '', 'dry', ['DAMAGED'], 'build', 'none', '生物合力修理受損的建築', '',
      ['VILLAGE VO_REPAIR', 'STRUCT 0 SO_REPAIR', 'FX FXK_SPARKLE 8 VILLAGE']),
    E('X_STORM_DAMAGE', V, 2, 72, 20, 'any', '', 'heavy', ['BUILDINGS'], 'damage', 'none', '暴雨損壞了森林裡的建築', '',
      ['VILLAGE VO_DAMAGE', 'STRUCT 0 SO_DAMAGE', 'FX FXK_SPLASH 10 STRUCT']),
    E('X_LIGHTNING_BUILD', V, 1, 120, 10, 'any', '', 'storm', ['STRUCT'], 'damage', 'none', '閃電擊中了一座建築', '',
      ['STRUCT 0 SO_STRIKE', 'HIST H_LIGHTNING', 'FX FXK_GLOW 10 STRUCT']),
    E('X_VINE_RUIN', V, 2, 48, 20, 'day', 'sp|su', 'any', ['STRUCT_OLD'], 'reclaim', 'none', '藤蔓爬滿了廢棄建築', '',
      ['STRUCT 0 SO_VINE', 'FX FXK_GREEN 8 STRUCT']),
    E('X_ROOTS_RUIN', V, 2, 72, 20, 'any', '', 'any', ['RUIN_EXC'], 'reclaim', 'none', '樹根慢慢穿透了古老的遺跡', '',
      ['RUIN RO_ROOTS', 'FX FXK_GREEN 6 RUIN']),
    E('X_RUIN_NEST', I, 2, 72, 30, 'dusk|night', '', 'any', ['RUIN_OR_WRECK', 'BURROW_ROOM'], 'home', 'none', '廢墟成了生物的新巢穴', '',
      ['UNDER UO_DIG_RUIN', 'VISIT C_CRITTER 30 RUIN', 'MEM MO_HOME C_CRITTER']),
    E('X_SWALLOWED', V, 2, 72, 20, 'any', '', 'any', ['STRUCT_MERGING'], 'reclaim', 'none', '森林完全吞沒了一座廢棄建築', '',
      ['STRUCT 0 SO_FINISH', 'TERRAIN TF_CLEAR -20 STRUCT', 'FX FXK_GREEN 10 STRUCT']),
    # ===== D. 植物與生態變化 (12) =====
    E('X_RARE_BLOOM', R, 1.5, 72, 40, 'day', 'sp|su', 'dry', ['FLOWER_ANY'], 'plant', 'night', '一朵稀有的花突然綻放', '月光下，一朵稀有的花悄悄綻放',
      ['PLANT P_FLOWER PO_RAREBLOOM', 'FX FXK_GOLD 10 FLOWER']),
    E('X_MUSH_CLUSTER', V, 3, 24, 30, 'any', 'su|au', 'humid', [], 'plant', 'none', '一大片蘑菇群落冒了出來', '',
      ['PLANT P_MUSHROOM PO_SPROUT3', 'TERRAIN TF_MUSH 15 MUSH']),
    E('X_TREE_FRUIT', D, 3, 48, 30, 'day', 'su|au', 'any', [], 'food', 'none', '古樹結滿了果實', '',
      ['WORLD WF_ACORNS 40', 'FX FXK_ACORN 6 CANOPY']),
    E('X_DROUGHT_WITHER', V, 3, 24, 20, 'day', '', 'drought', ['FLOWER_ANY'], 'plant', 'none', '乾旱讓植物枯萎了', '',
      ['PLANT P_FLOWER PO_WITHER', 'TERRAIN TF_DEAD 10 FLOWER']),
    E('X_RAIN_SPURT', D, 4, 12, 30, 'any', '', 'after_rain', [], 'plant', 'none', '雨後植物快速生長', '',
      ['PLANT 0 PO_BOOST', 'FX FXK_GREEN 12 GROUND']),
    E('X_SEED_DRIFT', D, 3, 12, 30, 'day', '', 'windy', ['FLOWER_ANY'], 'plant', 'none', '種子乘著風飄向遠方', '',
      ['PLANT P_FLOWER PO_DISPERSE', 'FX FXK_SEED 10 FLOWER']),
    E('X_ANIMAL_SEED', I, 3, 12, 40, 'day', '', 'dry', ['FLOWER_ANY', 'CRITTER'], 'plant', 'none', '小動物把沾在身上的種子帶到新的地方', '',
      ['SPECIAL SP_ANIMAL_SEED']),
    E('X_MUTATION', R, 1, 96, 30, 'any', '', 'any', ['MAGIC_OR_RARE'], 'plant', 'none', '一株植物發生了奇特的變異', '',
      ['PLANT 0 PO_MUTATE', 'FX FXK_MAGIC 10 FLOWER']),
    E('X_MUSH_FOREST', V, 2, 72, 30, 'any', '', 'humid', ['DAMP_ZONE'], 'terrain', 'none', '這一帶的蘑菇越來越多，漸漸成了蘑菇森林', '',
      ['TERRAIN TF_MUSH 25 MUSH', 'PLANT P_MUSHROOM PO_SPROUT3']),
    E('X_LOG_HABITAT', D, 3, 24, 50, 'any', '', 'humid', ['LOG2'], 'habitat', 'none', '枯木成了許多生物的新棲地', '',
      ['VISIT C_SNAIL 40 LOG', 'VISIT C_SHROOM 40 LOG', 'PLANT P_MUSHROOM PO_LOGSPROUT']),
    E('X_INSECT_SWARM', D, 3, 12, 40, 'day', 'sp|su', 'warm', ['FLOWERS2'], 'insect', 'none', '花朵吸引了大批昆蟲', '',
      ['FX FXK_INSECT 12 FLOWER', 'SPAWN C_BEE 2 FLOWER', 'SPAWN C_BUTTERFLY 1 FLOWER']),
    E('X_PLANT_GONE', V, 2, 48, 20, 'any', '', 'stress', ['PLANT_ANY'], 'plant', 'none', '環境改變，一株植物消失了', '',
      ['PLANT 0 PO_REMOVE', 'TERRAIN TF_DEAD 10 GROUND']),
    # ===== E. 天氣與自然災害 (10) =====
    E('X_GALE_FRUIT', V, 3, 12, 20, 'any', '', 'windy', [], 'wind', 'none', '強風吹落了樹葉與果實', '',
      ['FX FXK_LEAVES 20 CANOPY', 'WORLD WF_ACORNS 15', 'FX FXK_ACORN 4 CANOPY']),
    E('X_LOCAL_FLOOD', V, 3, 24, 20, 'any', '', 'heavy', [], 'water', 'none', '暴雨在低窪處積起了水', '',
      ['WORLD WF_PUDDLE 5', 'TERRAIN TF_WET 15 POND', 'MEM MO_DANGER 0']),
    E('X_TREE_STRIKE', V, 1, 96, 8, 'any', '', 'storm', [], 'strike', 'none', '閃電擊中了森林裡的一棵樹', '',
      ['SPECIAL SP_TREE_STRIKE']),
    E('X_WATER_SHRINK', V, 3, 48, 20, 'day', '', 'drought', [], 'water', 'none', '乾旱讓水源越來越少', '',
      ['WORLD WF_POND -1', 'WORLD WF_DROUGHT 1', 'TERRAIN TF_DEAD 10 POND']),
    E('X_THICK_FOG', V, 2, 24, 90, 'dawn|night', '', 'humid', [], 'fog', 'none', '濃霧靜靜籠罩了整座森林', '',
      ['WORLD WF_FOG 9']),
    E('X_SNOW_COVER', V, 3, 48, 20, 'any', 'wi', 'cold', [], 'snow', 'none', '冬天的雪覆蓋了大地', '',
      ['SPECIAL SP_SNOW']),
    E('X_STORM_WRECK', V, 2, 96, 20, 'any', '', 'storm', ['BUILDINGS'], 'damage', 'none', '暴風雨摧毀了部分小型建築', '',
      ['STRUCT 0 SO_WRECK', 'VILLAGE VO_DAMAGE', 'FX FXK_LEAVES 16 STRUCT']),
    E('X_DOUBLE_RAINBOW', R, 1, 96, 90, 'day', '', 'after_rain', [], 'rainbow', 'none', '雨後的天空出現了雙彩虹', '',
      ['SPECIAL SP_DOUBLE_RAINBOW']),
    E('X_SPRING_POOL', V, 2, 72, 20, 'any', '', 'any', ['UNDER_WATER'], 'water', 'none', '地下水湧出，形成一個小水池', '',
      ['UNDER UO_SPRING', 'WORLD WF_PUDDLE 3', 'TERRAIN TF_WET 20 BURROW']),
    E('X_MUDSLIDE', V, 1, 168, 10, 'any', '', 'heavy', [], 'slide', 'none', '小規模土石崩落，露出了古老的石塊', '',
      ['WORLD WF_RUBBLE 8', 'RUIN RO_ERODE', 'MEM MO_DANGER 0']),
    # ===== F. 地下世界與洞穴 (8) =====
    E('X_TUNNEL', D, 3, 24, 30, 'dawn|dusk|night', '', 'any', ['BURROW', 'BURROW_ROOM'], 'under', 'none', '生物挖出了一條地下通道', '',
      ['UNDER UO_TUNNEL', 'FX FXK_DIRT 10 BURROW']),
    E('X_HIDDEN_CAVE', V, 2, 72, 20, 'any', '', 'any', ['HIDDEN_OR_ROOM'], 'under', 'none', '大家發現了一個隱藏的洞穴', '',
      ['UNDER UO_REVEAL', 'VISIT C_SPRITE 20 BURROW']),
    E('X_CAVE_GLOW', M, 2, 48, 40, 'night', '', 'any', ['BURROW'], 'under', 'none', '洞穴裡長出了會發光的蘑菇', '',
      ['UNDER UO_GLOWCAVE', 'FX FXK_GLOW 6 BURROW']),
    E('X_UNDER_SPRING', V, 2, 48, 20, 'any', '', 'any', ['UNDER_WATER'], 'water', 'none', '發現了地下水源，周圍的植物更茂盛了', '',
      ['TERRAIN TF_WET 10 BURROW', 'PLANT P_REED PO_BOOST', 'PLANT P_MOSS PO_BOOST']),
    E('X_CAVE_CREATURE', R, 1, 96, 30, 'night', '', 'any', ['BURROW'], 'rarecreature', 'none', '洞穴深處出現了一隻稀有生物', '',
      ['SPECIAL SP_CAVE_CREATURE']),
    E('X_ARTIFACT', R, 1, 120, 20, 'any', '', 'any', ['BURROW', 'RUIN_SLOT'], 'ruin', 'none', '地底挖出了一件古代遺物', '',
      ['RUIN RO_ERODE', 'FX FXK_GOLD 10 BURROW']),
    E('X_MYCEL_SPREAD', V, 3, 24, 30, 'night', '', 'humid', ['MYCEL'], 'under', 'none', '地下菌絲網絡又擴張了一些', '',
      ['UNDER UO_MYCEL', 'PLANT P_MUSHROOM PO_BOOST']),
    E('X_CAVE_COLLAPSE', V, 1, 96, 20, 'any', '', 'heavy', ['BURROW_OCC'], 'under', 'none', '洞穴坍塌了，生物從另一個出口逃出', '',
      ['UNDER UO_COLLAPSE', 'MEM MO_DANGER 0']),
    # ===== G. 魔法與神祕事件 (12) =====
    E('X_METEOR_CRASH', R, 0.6, 168, 4, 'night', '', 'clear', [], 'meteor', 'none', '一顆流星墜落在森林裡', '',
      ['SPECIAL SP_METEOR_CRASH']),
    E('X_METEOR_SHARDS', M, 3, 24, 40, 'night', '', 'any', ['METEOR'], 'magic', 'none', '流星碎片散發著魔法光芒', '',
      ['FX FXK_MAGIC 12 METEOR', 'WORLD WF_MAGIC 3', 'TERRAIN TF_GLOW 15 METEOR']),
    E('X_TREE_STIR', M, 1.5, 48, 20, 'night|dusk', '', 'calm', [], 'tree', 'none', '古樹輕輕動了一下，又睡著了', '',
      ['FX FXK_LEAVES 12 CANOPY', 'TRIGGER N_TREE_GLOW 1']),
    E('X_SPIRIT_HEAL', M, 2, 48, 30, 'any', '', 'any', ['WITHER'], 'magic', 'none', '森林精靈治癒了枯萎的植物', '',
      ['SPECIAL SP_HEAL']),
    E('X_LIGHT_ORB', M, 2, 24, 40, 'night', '', 'any', [], 'orb', 'none', '一顆神祕的光球在森林裡飄移', '',
      ['SPECIAL SP_LIGHT_ORB']),
    E('X_RUNE_RING', M, 1.5, 48, 25, 'night', '', 'any', [], 'rune', 'ruin', '夜裡地面浮現一圈發光符文', '遺跡周圍浮現一圈發光符文',
      ['TRIGGER M_RUNES 1'], ['RUIN RO_GLOW', 'FX FXK_MAGIC 12 RUIN']),
    E('X_PORTAL_FLICKER', M, 1, 72, 20, 'night', '', 'any', ['MAGIC_OR_FULL'], 'portal', 'none', '一道傳送門短暫閃現又消失', '',
      ['TRIGGER M_PORTAL 1']),
    E('X_MAGIC_CREATURE', M, 2, 24, 40, 'any', '', 'any', ['MAGIC_OR_RARE', 'CREATURES2'], 'magic', 'none', '一隻生物受到魔法影響，身上發出光芒', '',
      ['SPECIAL SP_MAGIC_CREATURE']),
    E('X_MOON_GLOW', M, 2, 24, 60, 'night', '', 'clear', [], 'moon', 'none', '月光照耀下，植物們發出微光', '',
      ['TERRAIN TF_GLOW 5 GROUND'], moon='full|fq'),
    E('X_MYSTIC_ARRIVE', I, 1, 48, 20, 'dusk|night', '', 'any', ['VISITOR_OK'], 'visitor', 'fullmoon', '神祕旅人走進森林', '滿月之下，神祕旅人走進森林',
      ['STORY S_MYSTIC 0']),
    E('X_ALTAR_WAKE', M, 1.5, 72, 40, 'night', '', 'any', ['ALTAR'], 'magic', 'none', '古代祭壇被重新啟動了', '',
      ['SPECIAL SP_ALTAR_WAKE']),
    E('X_MAGIC_RAIN', M, 1.5, 48, 25, 'any', '', 'dry', [], 'magic', 'none', '森林下起了一陣短暫的魔法雨', '',
      ['SPECIAL SP_MAGIC_RAIN']),
    # ===== H. 季節與遷徙 (8) =====
    E('X_PRE_HIBERNATE', D, 3, 48, 40, 'day|dusk', 'au', 'cool', ['BURROW'], 'season', 'none', '生物開始為冬眠做準備', '',
      ['VISIT C_CRITTER 30 BURROW', 'MEM MO_HOME C_CRITTER']),
    E('X_STORE_FOOD', D, 3, 24, 40, 'day', 'au', 'any', ['SQUIRREL'], 'food', 'none', '生物忙著囤積過冬的食物', '',
      ['WORLD WF_CACHE 20', 'VISIT C_SQUIRREL 30 HOME']),
    E('X_FLOCK', D, 2, 48, 25, 'day', 'sp|au', 'calm', [], 'season', 'none', '一群候鳥從森林上空飛過', '',
      ['SPECIAL SP_FLOCK']),
    E('X_WAKE_UP', D, 3, 72, 30, 'day', 'sp', 'mild', ['BURROW'], 'season', 'none', '冬眠的生物醒了過來', '',
      ['EMERGE C_CRITTER 0 BURROW', 'EMERGE C_MOLE 0 BURROW', 'FX FXK_DIRT 8 BURROW']),
    E('X_SPRING_SPROUT', D, 3, 48, 30, 'day', 'sp', 'any', [], 'season', 'none', '春天到了，新芽大量冒出', '',
      ['PLANT P_FLOWER PO_SPROUT3', 'FX FXK_GREEN 12 GROUND']),
    E('X_AUTUMN_LEAVES', D, 4, 24, 30, 'day', 'au', 'any', [], 'season', 'none', '秋天到了，樹開始落葉', '',
      ['FX FXK_AUTUMN 30 CANOPY']),
    E('X_FOOD_MIGRATE', V, 1.5, 120, 20, 'day', '', 'any', ['LOWFOOD'], 'migrate', 'none', '食物不足，生物們集體遷徙了', '',
      ['SPECIAL SP_MASS_MIGRATE']),
    E('X_NEW_COMPANION', I, 2, 72, 30, 'day', '', 'calm', ['MIGRATED'], 'migrate', 'none', '遷徙歸來的生物帶來了新同伴', '',
      ['SPAWN C_BIRD 1 EDGE', 'SPAWN C_SQUIRREL 1 EDGE', 'MEM MO_FRIEND C_BIRD']),
    # ===== I. 稀有與隱藏事件 (8) =====
    E('X_ANCIENT_TURTLE', R, 0.25, 720, 120, 'day|dusk', '', 'calm', [], 'legend', 'none', '一隻遠古巨龜緩緩走過森林', '',
      ['SPECIAL SP_TURTLE']),
    E('X_TREE_SPIRIT', R, 0.4, 336, 50, 'night', '', 'calm', [], 'legend', 'none', '神祕的樹精在古樹旁現身', '',
      ['SPECIAL SP_TREE_SPIRIT']),
    E('X_MOON_FOX', R, 1.5, 240, 50, 'night', '', 'clear', [], 'legend', 'none', '月圓之夜，一隻稀有的月光狐出現了', '',
      ['SPECIAL SP_MOON_FOX'], moon='full'),
    E('X_FESTIVAL', R, 0.5, 240, 60, 'dusk|night', 'sp|su|au', 'calm', ['FESTIVAL'], 'legend', 'none', '森林生物舉辦了一場小型慶典', '',
      ['SPECIAL SP_FESTIVAL']),
    E('X_TREASURE', R, 0.4, 480, 30, 'any', '', 'any', ['RUIN_EXC'], 'legend', 'none', '發現了古代文明留下的寶藏', '',
      ['SPECIAL SP_TREASURE']),
    E('X_GRAND_GATHER', R, 0.3, 480, 60, 'day|dusk', 'sp|su', 'calm', [], 'legend', 'none', '森林裡出現了罕見的生物大集會', '',
      ['SPECIAL SP_GATHERING']),
    E('X_RARE_NEST', R, 0.3, 720, 20, 'night', '', 'calm', [], 'legend', 'none', '一隻稀有生物在古樹下築了巢', '',
      ['SPECIAL SP_RARE_NEST']),
    E('X_ENCHANT_DAYS', R, 0.15, 1440, 30, 'night', '', 'clear', [], 'legend', 'none', '森林出現了持續數天的奇妙魔法現象', '',
      ['SPECIAL SP_ENCHANT']),
]
assert len(EV) == 100, len(EV)
EXTRA_MSGS = [
    ('J_T_WETLAND', '長期潮濕，這一帶漸漸變成濕地'), ('J_T_MUSHFOREST', '這一帶長滿蘑菇，成了蘑菇森林'),
    ('J_T_REGROW', '空地上重新長出了植物'), ('J_T_DEADWOOD', '長期乾旱，這一帶成了枯木區'),
    ('J_T_GLOWZONE', '魔法長期影響，這一帶的植物開始發光'), ('J_T_CLEARING', '樹被砍下，這裡多了一片空地'),
    ('J_X3_FREED', '同伴把困住的小生物救了出來'), ('J_X3_TRADE_GOODS', '小生物用果實換到了商人的小玩意'),
    ('J_X3_ENCHANT_END', '持續數天的魔法現象漸漸消失了'),
]

PH = {'any': '0', 'day': 'PM_DAY', 'night': 'PM_NIGHT', 'dawn': 'PM_DAWN', 'dusk': 'PM_DUSK', 'morning': 'PM_MORNING', 'afternoon': 'PM_AFTERNOON'}
SE = {'sp': 'SE_SP', 'su': 'SE_SU', 'au': 'SE_AU', 'wi': 'SE_WI'}
MOON = {'any': '0', 'full': '(1 << eco::MOON_FULL)', 'fq': '(1 << eco::MOON_FIRST_Q)', 'new': '(1 << eco::MOON_NEW)', 'lq': '(1 << eco::MOON_LAST_Q)'}


def mask(spec, table):
    if not spec or spec == 'any':
        return '0'
    return ' | '.join(table[s] for s in spec.split('|'))


EVENT_REFS = {'N_TREE_GLOW', 'M_RUNES', 'M_PORTAL', 'R_RAINBOW', 'R_ANCIENT', 'V_POLLEN', 'E_MOSS_SPREAD'}


def qual(t):
    # 讓配方表的名稱不必用 using namespace (避免各模組同名函式衝突)
    for pre, ns in (('C_', 'creature::'), ('T_', 'structure::'), ('S_', 'visitor::'), ('TK_', 'visitor::'), ('P_', 'plant::'),
                    ('H_', 'history::'), ('TF_', 'evo::')):
        if t.startswith(pre):
            return ns + t
    if t in EVENT_REFS:
        return 'eventm::' + t
    return t


def op(s):
    if not s:
        return '{O_NONE, 0, 0, PL_NONE}'
    p = s.split()
    kind = p[0]
    a = p[1] if len(p) > 1 else '0'
    b = p[2] if len(p) > 2 else '0'
    pl = 'PL_' + p[3] if len(p) > 3 else 'PL_NONE'
    if kind in ('HIDE', 'FIREFLY'):  # HIDE 0 半徑/2 地點
        pl = 'PL_' + p[3]
    return '{O_%s, %s, %s, %s}' % (kind, qual(a), qual(b), pl)


def ops3(lst):
    lst = list(lst) + [''] * (3 - len(lst))
    assert len(lst) == 3, lst
    return '{' + ', '.join(op(x) for x in lst) + '}'


groups = sorted({e['grp'] for e in EV})
needs = sorted({n for e in EV for n in e['needs']})
VAR = {'none': 'VA_NONE', 'night': 'VA_NIGHT', 'wet': 'VA_WET', 'hunter': 'VA_HUNTER', 'camp': 'VA_CAMP', 'ruin': 'VA_RUIN', 'fullmoon': 'VA_FULLMOON'}
WX = sorted({e['wx'] for e in EV})

# ---- EventRecipeTable.h ----
L = ['// 由 tools/gen_events3.py 產生，請勿手動修改', '#pragma once', '']
L.append('enum RecipeGroup : uint8_t { ' + ', '.join('G_' + g.upper() for g in groups) + ', G_COUNT };')
L.append('enum Need : uint8_t { ' + ', '.join('N_' + n for n in needs) + ', N_COUNT };')
L.append('enum Weather : uint8_t { ' + ', '.join('WX_' + w.upper() for w in WX) + ' };')
L.append('constexpr uint8_t FIRST_RECIPE = eventm::%s;' % EV[0]['id'])
L.append('constexpr int RECIPE_N = %d;' % len(EV))
L.append('const Recipe RECIPES[RECIPE_N] = {')
for e in EV:
    nd = ' | '.join('NB(N_%s)' % n for n in e['needs']) or '0'
    alt = 'journal::J_%s_ALT' % e['id'] if e['alt'] else 'journal::J_NONE'
    L.append('    // %s %s' % (e['id'], e['text']))
    L.append('    {%s, %s, WX_%s, %s, %s, G_%s, %s, %s, %s, %s},' % (
        mask(e['ph'], PH), mask(e['se'], SE), e['wx'].upper(), mask(e['moon'], MOON), nd, e['grp'].upper(),
        VAR[e['var']], alt, ops3(e['ops']), ops3(e['altops'])))
L.append('};')
open(root + '/src/EventRecipeTable.h', 'w', encoding='utf-8').write('\n'.join(L) + '\n')

# ---- EventManager.h：事件編號 ----
p = root + '/src/EventManager.h'
s = open(p, encoding='utf-8').read()
s = re.sub(r'\n  // 第三階段 \(事件配方\)\n.*?(?=\n  EV_COUNT)', '', s, flags=re.S)
ids = [e['id'] for e in EV]
block = '\n  // 第三階段 (事件配方)\n  ' + ',\n  '.join(', '.join(ids[i:i + 5]) for i in range(0, len(ids), 5)) + ','
s = s.replace('\n  EV_COUNT', block + '\n  EV_COUNT', 1)
open(p, 'w', encoding='utf-8').write(s)

# ---- EventManager.cpp：DEFS 與 NAMES ----
p = root + '/src/EventManager.cpp'
s = open(p, encoding='utf-8').read()
s = re.sub(r'    // ---- 第三階段 \(配方\) ----\n.*?(?=\n};)', '', s, flags=re.S)
s = re.sub(r'\n    // 第三階段名稱\n[^\n]*', '', s)
rows = []
for e in EV:
    f = [x.split() for x in e['fol']] + [['NO', '0', '0']] * (2 - len(e['fol']))
    fs = ', '.join('{%s, %s, %s}' % tuple(x) for x in f)
    rows.append('    {%s, journal::J_%s, %sf, %d, %d, -1, {%s}},' % (e['cat'], e['id'], repr(float(e['w'])), int(e['cd'] * 3600), e['dur'], fs))
# 插在 DEFS 結尾
d0 = s.index('const Def DEFS[] = {')
d1 = s.index('\n};', d0)
s = s[:d1] + '\n    // ---- 第三階段 (配方) ----\n' + '\n'.join(rows) + s[d1:]
n0 = s.index('const char* const NAMES[] = {')
n1 = s.index('\n};', n0)
s = s[:n1] + '\n    // 第三階段名稱\n    ' + ', '.join('"%s"' % i.lower() for i in ids) + ',' + s[n1:]
open(p, 'w', encoding='utf-8').write(s)

# ---- Journal ----
h = root + '/src/Journal.h'
s = open(h, encoding='utf-8').read()
s = re.sub(r'\n  // 第三階段\n[^\n]*\n[^\n]*', '', s)
jn = ['J_' + e['id'] for e in EV] + ['J_%s_ALT' % e['id'] for e in EV if e['alt']] + [m[0] for m in EXTRA_MSGS]
s = s.replace('\n  J_COUNT', '\n  // 第三階段\n  ' + ', '.join(jn) + ',\n  // (end)\n  J_COUNT', 1)
s = s.replace('\n  // (end)\n  // (end)', '\n  // (end)')
open(h, 'w', encoding='utf-8').write(s)
c = root + '/src/Journal.cpp'
s = open(c, encoding='utf-8').read()
s = re.sub(r'\n    // 第三階段\n[^\n]*', '', s)
t0 = s.index('const char* const TEXT[] = {')
t1 = s.index('\n};', t0)
jt = [e['text'] for e in EV] + [e['alt'] for e in EV if e['alt']] + [m[1] for m in EXTRA_MSGS]
s = s[:t1] + '\n    // 第三階段\n    ' + ', '.join('"%s"' % x for x in jt) + ',' + s[t1:]
open(c, 'w', encoding='utf-8').write(s)
print('recipes', len(EV), 'journal +', len(jn), 'groups', len(groups), 'needs', len(needs))
print('needs:', ' '.join(needs))
print('weather:', ' '.join(WX))
