"""序列埠監看/送指令 (開 port 前設 dtr/rts=False，避免板子重置 —— PINOUT 坑 #4)
用法: python tools/serial_mon.py COM6 秒數 [指令1] [指令2] ...
     指令以 "@秒數:" 開頭可延遲送出，例如 "@5:status"
     送 "shot" 會把畫面存成 shots/shot_N.png (放大 2 倍)
"""
import os
import sys
import time

import serial

port, dur = sys.argv[1], float(sys.argv[2])
cmds = []
for c in sys.argv[3:]:
    at = 0.5
    if c.startswith("@") and ":" in c:
        at, c = float(c[1:c.index(":")]), c[c.index(":") + 1:]
    cmds.append((at, c))

out = sys.stdout.buffer
s = serial.Serial()
s.port, s.baudrate, s.timeout = port, 115200, 0.1
s.dtr = False
s.rts = False
s.open()
t0 = time.time()
sent = set()
buf = b""
shot_n = 0


def save_png(raw, w, h, idx):
    from PIL import Image
    img = Image.new("RGB", (w, h))
    px = img.load()
    for i in range(w * h):
        v = raw[i * 2] | (raw[i * 2 + 1] << 8)  # little-endian uint16
        r, g, b = (v >> 11) & 31, (v >> 5) & 63, v & 31
        px[i % w, i // w] = (r * 255 // 31, g * 255 // 63, b * 255 // 31)
    os.makedirs("shots", exist_ok=True)
    name = f"shots/shot_{idx}.png"
    k = max(1, 480 // w)  # 一律放大到約 480 像素寬，像素保持銳利
    img.resize((w * k, h * k), Image.NEAREST).save(name)
    return name


while time.time() - t0 < dur:
    el = time.time() - t0
    for i, (at, c) in enumerate(cmds):
        if i not in sent and el >= at:
            if c == "!reset":  # 透過 RTS 重置板子 (看開機訊息用)
                s.rts = True
                time.sleep(0.2)
                s.rts = False
            else:
                s.write((c + "\n").encode())
            sent.add(i)
    buf += s.read(65536)
    while True:
        k = buf.find(b"SHOT_BEGIN")
        if k < 0:
            break
        nl = buf.find(b"\n", k)
        if nl < 0:
            break
        w, h = map(int, buf[k:nl].split()[1:3])
        need = nl + 1 + w * h * 2
        if len(buf) < need:
            break
        out.write(buf[:k])
        name = save_png(buf[nl + 1:need], w, h, shot_n)
        shot_n += 1
        out.write(f"[saved {name}]\n".encode())
        end = buf.find(b"SHOT_END", need)
        buf = buf[end + 8:] if end >= 0 else buf[need:]
    if b"SHOT_BEGIN" not in buf and buf:
        out.write(buf)
        out.flush()
        buf = b""
s.close()
