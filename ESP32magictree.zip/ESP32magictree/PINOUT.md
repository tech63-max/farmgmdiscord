# Waveshare ESP32-S3-LCD-1.54 腳位與開發備忘

給其他 ESP32 專案直接沿用的板子參考。內容取自 MemeBall 專案 (`src/config/BoardConfig.h` 等) 中**實機驗證過**的設定；
腳位原始來源是官方 repo `waveshareteam/ESP32-S3-Touch-LCD-1.54`
(`ESP-IDF-5.5.1/01_factory` 的 `bsp_display.h` / `bsp_power_manager.c` / `components/esp_bsp/bsp_sdcard.h`，以及 Arduino 範例 `07_sd_card_test`)。

## 板子規格

| 項目 | 內容 |
|---|---|
| MCU | ESP32-S3 (雙核 240 MHz) |
| Flash / PSRAM | 16 MB / 8 MB **OPI** PSRAM |
| 螢幕 | 1.54" ST7789，240x240，IPS，SPI (本板為**無觸控版**) |
| 儲存 | microSD，SDMMC 4-bit |
| 按鍵 | BOOT、PWR、PLUS (由左到右) |
| 其他 | 電池電源鎖定、喇叭功放 (ES8311 codec)、麥克風 (ES7210)；**沒有 RTC** |
| USB | 原生 USB (USB-CDC 序列埠) |

## 腳位表

| 功能 | GPIO | 說明 |
|---|---|---|
| LCD_SCK | 38 | SPI SCLK |
| LCD_MOSI | 39 | SPI MOSI (沒有 MISO) |
| LCD_CS | 21 | |
| LCD_DC | 45 | ⚠ strapping pin |
| LCD_RST | 40 | |
| LCD_BL | 46 | 背光，PWM (LEDC)；⚠ strapping pin |
| BTN_BOOT | 0 | 按下 = LOW，用 `INPUT_PULLUP`；⚠ strapping pin (開機時按住進下載模式) |
| BTN_PWR | 5 | 按下 = LOW，`INPUT_PULLUP` |
| BTN_PLUS | 4 | 按下 = LOW，`INPUT_PULLUP` |
| POWER_LATCH | 2 | 電池供電時開機後**必須立刻拉 HIGH** 才會維持供電；拉 LOW = 關機 (USB 供電時無效) |
| AMP_CTRL | 7 | 喇叭功放致能，HIGH = 開。不用聲音時開機拉 LOW |
| SD_CLK | 16 | SDMMC |
| SD_CMD | 15 | SDMMC |
| SD_D0 | 17 | SDMMC |
| SD_D1 | 18 | SDMMC |
| SD_D2 | 13 | SDMMC |
| SD_D3 | 14 | SDMMC |

### 未在本專案驗證的部分

ES8311 (喇叭 codec) / ES7210 (麥克風) 的 I2C 與 I2S 腳位、電池電壓 ADC 等本專案沒有使用，**沒有在此列出**以免抄錯；
需要時請查官方 repo 的 `bsp_*.h`。

### ESP32-S3 本身不能亂用的腳位 (晶片通則)

| GPIO | 原因 |
|---|---|
| 26–32 | 內部 SPI Flash |
| 33–37 | OPI PSRAM 使用 (本板是 OPI，35/36/37 也被占用) |
| 19 / 20 | 原生 USB D- / D+ |
| 43 / 44 | UART0 TX / RX |
| 0, 3, 45, 46 | Strapping pins，開機瞬間的電位會影響啟動模式，外接電路要小心 |

## Arduino 編譯設定

```
arduino-cli compile --fqbn "esp32:esp32:esp32s3:CDCOnBoot=cdc,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB" --upload -p COMx .
```

- 測試過的版本：Arduino-ESP32 core 3.3.12、GFX Library for Arduino 1.6.9。
- `PSRAM=opi` 一定要選，選錯 (QSPI / disabled) PSRAM 會抓不到。
- `CDCOnBoot=cdc` 才能用 USB 線上的 `Serial`。
- `app3M_fat9M_16MB`：3 MB App + 9 MB FAT。App 很大 (中文字型、Wi-Fi/TLS) 時才需要，一般專案可改其他 16MB 分割表。

## 初始化範例程式碼

### 開機第一件事：電源鎖定 + 關功放

```cpp
pinMode(2, OUTPUT);  digitalWrite(2, HIGH);  // POWER_LATCH：電池供電必須最先做
pinMode(7, OUTPUT);  digitalWrite(7, LOW);   // AMP_CTRL：不用聲音就關掉
// 關機：digitalWrite(2, LOW);  (插 USB 時不會真的斷電，記得處理這種情況)
```

### LCD (Arduino_GFX)

```cpp
#include <Arduino_GFX_Library.h>
Arduino_ESP32SPI bus(45 /*DC*/, 21 /*CS*/, 38 /*SCK*/, 39 /*MOSI*/, GFX_NOT_DEFINED /*MISO*/);
Arduino_ST7789 panel(&bus, 40 /*RST*/, 0 /*rotation*/, true /*IPS*/, 240, 240);

void setupLcd() {
  ledcAttach(46, 5000, 10);   // 背光 PWM 5 kHz、10 bit (core 3.x API)
  ledcWrite(46, 0);           // 初始化期間先關背光，避免看到雜訊
  panel.begin(40000000);      // SPI 40 MHz
  ledcWrite(46, 1023 * 80 / 100);  // 亮度 80%
}
```

### microSD (SD_MMC 4-bit)

```cpp
#include <SD_MMC.h>
bool mountSd() {
  if (!SD_MMC.setPins(16 /*CLK*/, 15 /*CMD*/, 17 /*D0*/, 18 /*D1*/, 13 /*D2*/, 14 /*D3*/)) return false;
  // mountpoint, mode1bit=false (4-bit), format_if_mount_failed=false, 20 MHz, 最多開 5 個檔
  if (!SD_MMC.begin("/sdcard", false, false, SDMMC_FREQ_DEFAULT, 5)) return false;
  if (SD_MMC.cardType() == CARD_NONE) { SD_MMC.end(); return false; }
  return true;
}
```

### 按鍵

```cpp
const int8_t BTNS[] = {0 /*BOOT*/, 5 /*PWR*/, 4 /*PLUS*/};
for (int8_t p : BTNS) pinMode(p, INPUT_PULLUP);
bool down = digitalRead(p) == LOW;
```

MemeBall 用的參數：去抖動 25 ms、長按 700 ms，放開時才送短按 (已送過長按就不送)，全部用 `millis()` 非阻塞輪詢。

## 踩過的坑 (實機驗證)

1. **SD 讀寫要經過內部 RAM、對齊的緩衝區。** FATFS 寫整個磁區時會把呼叫端指標直接丟給 DMA：
   從 Flash 上的 `const` 字串寫入，檔案內容全是 0；PSRAM 也有 cache 對齊風險。
   做法：準備 `alignas(16) uint8_t buf[2048];` (內部 RAM)，分段 `memcpy` 進去再 `write`。
2. **Arduino_GFX `draw16bitRGBBitmap` 要傳非 const 的 `uint16_t*`。** 傳 `const uint16_t*` 會選到 PROGMEM 版本的
   overload，畫面一直是黑的。
3. **`Serial.setTxTimeoutMs(0);`** (放在 `Serial.begin` 後)。USB 插著但電腦沒開序列埠時，HWCDC 每次寫入預設會卡
   最多 20×100 ms，整個畫面會延遲。也盡量不要在畫面繪製途中印 log。
4. **開序列埠會重開機。** 用 pyserial 時要在 `open()` 前設 `dtr=False; rts=False`，否則一開 port 板子就重置；
   要刻意重置時用 `rts=True → False`。
5. **USB-CDC 接收緩衝很小 (~256 B)。** 從電腦大量傳資料給板子要切成 ≤128 bytes 並等 ACK。
6. **SD 卡不要自動格式化** (`format_if_mount_failed=false`)，SDMMC 用 20 MHz 最穩。
7. **FAT 的 `rename` 不會覆蓋既有檔案。** 安全替換：寫 `.tmp` → 檢查大小 → 舊檔改名 `.bak` → `.tmp` 改正式名；開機時檢查殘留的 `.tmp`/`.bak` 做復原。
8. **`millis()` 比較用有號差值** `(int32_t)(now - t) >= 0`，避免約 49 天溢位出錯。
9. **沒有 RTC**：需要時間就連 Wi-Fi 後跑 NTP (`configTzTime("CST-8", "pool.ntp.org")`)。
10. **大塊記憶體放 PSRAM**：`heap_caps_malloc(size, MALLOC_CAP_SPIRAM)`；但要給 DMA / SD 用的緩衝放內部 RAM
    (`MALLOC_CAP_INTERNAL | MALLOC_CAP_DMA`)。
11. **JPEG**：ESP32-S3 ROM 內建 TJpgDec (`#include "rom/tjpgd.h"`，舊版 `jd_prepare/jd_decomp` API) 不用另外裝函式庫，
    但只支援 baseline JPEG，progressive 會解碼失敗。
12. **JSON**：core 內建 cJSON (`#include <cJSON.h>`)，可用 `cJSON_InitHooks` 把配置導到 PSRAM。
