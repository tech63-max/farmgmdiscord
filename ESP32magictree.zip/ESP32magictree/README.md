# Magic Forest Terrarium 魔法森林生態瓶

Waveshare ESP32-S3-LCD-1.54 (240x240 ST7789) 上的全螢幕像素魔法森林。森林會依照**台中的真實天氣與時間**自主生活，玩家只是觀察者。所有角色都是原創設計，程式不使用任何聲音（開機就把功放關掉）。

## 編譯與燒錄

```
arduino-cli compile --fqbn "esp32:esp32:esp32s3:CDCOnBoot=cdc,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB" .
arduino-cli upload  --fqbn "esp32:esp32:esp32s3:CDCOnBoot=cdc,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB" -p COM6 .
```

測試過的版本：Arduino-ESP32 3.3.12、GFX Library for Arduino 1.6.9。腳位見 `PINOUT.md`。

`src/Secrets.h` (已加入 .gitignore) 放 Wi-Fi 預設值與所在地座標。第一次開機時，若 NVS 裡還沒有 Wi-Fi 設定，會把這裡的值寫進 NVS；之後一律以 NVS 為準。範本見 `src/Secrets.example.h`。

## 按鍵

| 操作 | 效果 |
|---|---|
| PLUS 短按 | 自然祝福：魔法細雨、滋潤植物、吸引昆蟲 (冷卻 90 秒) |
| PLUS 雙擊 | 森林微風：吹動樹葉、飄散花粉與種子，可能引來特殊生物 (冷卻 60 秒) |
| PLUS 長按 | 魔法脈動：森林發光、喚醒沉睡生物，可能觸發隱藏事件 (冷卻 4 分鐘) |
| BOOT 短按 | 顯示 6 秒的時間、天氣、日出日落、季節 |
| PWR 短按 | 觀察日誌 (再按一次翻頁) |
| PWR 長按 2 秒 | 存檔後關機 (只有電池供電時有效) |
| **BOOT + PLUS 同時長按 1.5 秒** | 開/關 Wi-Fi 設定熱點 (沿用 ESP32S3myg 的設計) |
| **BOOT + PWR 同時長按 1.5 秒** | 顯示/隱藏 UI (右上角時鐘、事件提示、冷卻光點)，設定會記住。主動按出的資訊卡、日誌、Wi-Fi 面板不受影響 |

所有玩家互動之間還有 15 秒的共同冷卻。冷卻中再按，右下角會亮起一顆微弱光點。

### Wi-Fi 設定熱點
熱點名稱是 `Forest-XXXX`，8 位數密碼每次隨機產生，只顯示在螢幕上。手機連上後開啟 `http://192.168.4.1` 就能設定。設定表單只提供給連上熱點的裝置；從一般區網連進來只能看到唯讀狀態頁 (`http://forest.local/`)。頁面不會回傳密碼，所有輸出都會做 HTML 跳脫。

## 架構

| 模組 | 職責 |
|---|---|
| `ForestRenderer` | 以 120x120 低解析度、像素風格繪製森林，送畫面時放大 2 倍 (生物與植物在螢幕上是 2 倍大)；文字 UI 在送畫面時以 240 原生解析度疊上去。背景拆成「材質層」(只有換季、出現枯木、積雪時才重算) 和「打光層」(光線改變時快速套用) |
| `WeatherManager` | Open-Meteo 天氣，每 40 分鐘在獨立的 FreeRTOS task 更新一次；過期 3 小時後改用依季節的本地模擬天氣 |
| `TimeManager` / `SeasonManager` | NTP 校時、日出日落、日夜時段、月相、四季平滑過渡 |
| `Ecosystem` | 把天氣、時間、魔法整合成濕度、土壤、昆蟲、花蜜等環境值 |
| `PlantManager` | 22 個植物格位、8 種植物的生命週期 (種子到休眠)、種子散播、枯木演替 |
| `CreatureManager` | 8 種自然生物，加上 3 種只在事件中出現的生物；各有活動時段、速度、天氣偏好、休息與遷徙 |
| `EventManager` / `EventMemory` | 31 種事件，分 5 類；具備條件判斷、動態權重、冷卻、連鎖、事件記憶、稀有保底、安靜節奏 |
| `VisitorManager` | 外來訪客 (冒險家、獵人、旅行商人、神祕旅人)。每次來訪是一個有因果的故事腳本，同一時間最多一位，間隔至少 2~6 小時 (森林時間) 且真實時間至少 5 分鐘。冒險家多在白天、神祕旅人只在黃昏/夜晚出現，雨天機率降低 |
| `StructureManager` | 11 種人造物 (木屋、營火、帳篷、路標、木箱、圍欄、陷阱、棧橋、石頭祭壇、攤位、遺落物品)，最多同時 6 個，放在 6 個固定位置。會經歷 5 個階段：全新、受天氣影響、植物入侵 (苔蘚/蘑菇/藤蔓)、崩塌、融入大地。雨水會加速木材腐朽，石頭祭壇最後會成為永久的遺跡 |
| `Underground` | 地下生態：濕度、地下水、菌絲、樹根，以及最多 3 個洞穴。洞穴會經歷：新挖 → 有住戶 → 淹水 → 廢棄 → 被蘑菇佔據 → 被植物遮住 → 消失。地下水與菌絲會加速地表植物生長 |
| `Ruins` | 考古：4 個固定遺跡點，發現順序是石碑 → 石門 → 寶箱 → 石柱/石雕/地下入口/石橋。大雨沖刷會露出一角，再由冒險家挖掘、研究、留記號。遺跡永久保留，會慢慢被苔蘚和樹根包圍；石門出現符文後，神祕旅人與神秘事件都會變多 |
| `Families` | 鳥巢：產卵 → 孵化 → 親鳥餵食 → 練飛 → 離巢，巢可以給下一代沿用。青蛙：卵 → 蝌蚪 → 小青蛙。小獸會帶幼崽散步，幼崽約 10 天後長大 |
| `Village` | 小精靈聚落 (實驗性)：聚集 → 搬材料 → 蓋小屋 → 定居 → 擴張 (最多 3 間) → 被災害損壞 → 遷離 → 被植物覆蓋。必須小精靈長期在附近活動、環境穩定、3 天內沒有災害才會形成 |
| `ForestHistory` | 森林歷史：保留最近 24 筆重要事件、各類事件的累計次數，以及 6 個區域的長期地貌 (茂盛度、潮濕度、曾發生過的事)。歷史會影響植物 (舊木屋/雷擊處長發光菌)、鳥類 (舊巢吸引下一代) 和訪客 (重返遺跡) |
| `Ecosystem` 世界狀態 | 橡果與松鼠存糧、池塘水位、乾旱、霜、積水、雷擊焦痕、落石、隕石發光石、月相 (新月/上弦/滿月/下弦) |
| `PlayerInteraction` | 按鍵手勢與冷卻 |
| `Journal` / `SdStorage` | 觀察日誌 (NVS 保留最近 40 筆；有插 SD 卡時另外存到 `/forest/journal.txt`) |
| `SaveManager` | 每 15 分鐘把生態狀態以帶 CRC 檢查的 blob 存進 NVS；重開機後恢復，關機期間的生長最多補算 3 天 |
| `net/*`、`assets/Font12` | 從 ESP32S3myg 沿用：Wi-Fi 管理、設定網頁、Cubic11 繁中字型 (OFL 授權，見 `licenses/`) |

美術素材是程式內嵌的小型像素圖與程序化繪製，總共只有幾 KB，所以不需要從 SD 卡載入。

## 序列埠測試指令 (115200)

`python tools/serial_mon.py COM6 <秒數> [指令...]` 會在開 port 前把 DTR/RTS 設成 False，避免板子被重置。

`status`、`prof` (各繪製階段耗時)、`shot` (截圖存到 `shots/`)、`ev <名稱|list>`、`weather <clear|cloud|over|fog|drizzle|rain|storm|snow|live>`、`speed <倍率>` (縮時)、`skip <分鐘>`、`bless`、`breeze`、`pulse`、`info`、`log`、`journal`、`save`、`reset` (重置森林)、`wifi [ssid pass]`、`ap`、`story <cabin|camp|lost|glow|chase|study|hunt|merchant|mystic>` (立刻開始一個訪客故事)、`build <cabin|campfire|tent|sign|crate|fence|trap|bridge|altar|stall|item> [位置]`、`decay <小時>` (讓建築經過 N 小時的腐朽並列出狀態)、`world` (列出地下/遺跡/家庭/聚落/災害狀態)、`history`、`erode` (露出遺跡)、`set <puddle|drought|frost|rain|acorns|burn|rubble|nest|neststage|frog|village> <值>`、`nvs` (NVS 使用量)。事件名稱可用 `ev list` 查詢，例如 `ev d_flood`、`ev n_fallen_star`

### 存檔
- `eco`：第一版的生態存檔，格式從未改變，舊存檔可以直接讀取。
- `human`：訪客與建築。
- `world`：第二階段的地下、遺跡、歷史、家庭、聚落、災害、擴充的事件記憶，以及新物種的資料。

三者都帶 CRC 檢查。`human` 與 `world` 只有內容改變時才會寫入 NVS。
