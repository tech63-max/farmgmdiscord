# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

ESP32-S3 (Waveshare ESP32-S3-LCD-1.54, 240x240 ST7789) 上的像素風魔法森林生態瓶：依真實天氣/時間自主運作，玩家只觀察。Arduino 專案，入口是 `ESP32magictree.ino`，模組都在 `src/`。

## 編譯、燒錄、驗證

```
arduino-cli compile --fqbn "esp32:esp32:esp32s3:CDCOnBoot=cdc,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB" --build-path build .
arduino-cli upload  --fqbn "esp32:esp32:esp32s3:CDCOnBoot=cdc,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB" --input-dir build -p COM6 .
```

- 板子通常在 COM6 (`arduino-cli board list` 確認)。`PSRAM=opi` 必選。測試過：Arduino-ESP32 3.3.12、GFX Library for Arduino 1.6.9。
- 沒有單元測試。驗證靠實機序列埠指令：`python tools/serial_mon.py COM6 <秒數> ["@秒數:"指令 ...]`（開 port 前把 DTR/RTS 設 False，避免重置板子）。
  - `shot`：截圖到 `shots/shot_N.png`（每次執行從 0 編號，會覆蓋舊檔）。開機後約 10 秒再截。
  - `status`、`ev <名稱|list>`（強制觸發事件）、`story <名稱>`、`build <類型> [位置]`、`decay <小時>`、`world`、`evo`、`history`、`audit on|off|reset`（生物位置診斷）、`speed <倍率>`、`skip <分鐘>`、`weather <類型>`、`reset`（清空森林存檔）。完整清單見 `README.md`、`ARCHITECTURE.md` §7。
- `src/Secrets.h` 不進版控（範本 `src/Secrets.example.h`）。

## 架構重點

完整說明在 `ARCHITECTURE.md`（較新、以它為準；`README.md` 架構表與 `EVENTS.md` 的天數/冷卻是舊描述）。

- **分層**：環境 (Time/Season/Weather → `Ecosystem`) → 生態 (`PlantManager`、`CreatureManager`、`Families`、`Underground`) → 事件 (`EventManager` + `EventRecipes`) → 文明 (`VisitorManager`、`StructureManager`、`Village`、`Ruins`) → 長期 (`Evolution`、`ForestHistory`、`Journal`) → 呈現 (`ForestRenderer`、`Gfx`、`Sprites`、`Particles`) → 保存 (`SaveManager`)。
- **主迴圈節奏**：每幀 50 ms 更新生物/訪客/事件並繪圖；每秒 `eventm::tick`；每 5 秒族群；每 10 秒植物；`worldTick(dtSec)` 推進長期模擬（建築、地下、遺跡、歷史），關機期間會補算。
- **時間**：`update(dt, ms)` 用真實毫秒（`millis()`，比較用 `util::reached`）；`tick(dtH)` 和冷卻用森林時間 `timem::now()`（epoch 秒，可被 `speed` 加速）。
- **座標**：`src/Scene.h` 是所有模組共用的場景幾何（古樹、河流 `RIVER[]`/`inPond()`、石頭、枯木、行走高度）。世界座標 = 240 原生像素；畫布座標 = 世界 >> 1（120 格）。背景景物（瀑布、小溪、樹拱、岩壁）只畫在 `ForestRenderer.cpp` 的 bake 函式裡，`Scene.h` 不知道它們——新增固定位置時要自己避開。
- **事件**：189 個，`EvId` 是 `uint8_t`。第三階段 100 個 (`X_*`) 由 `tools/gen_events3.py` 產生（`EventManager` 的編號/定義/名稱、`Journal` 訊息、`EventRecipeTable.h`），改它們要改產生器再重跑，不要手改產生的區段。
- **固定容量**：所有容器固定大小、執行期不動態配置（生物 `CAP=24`、同時事件 8 個、粒子池等）。大緩衝放 PSRAM。

## 存檔相容性（改資料結構前必看）

- NVS 三個 blob：`eco`（第一版，格式不可變）、`human`（建築與訪客）、`world2`（其餘），都有 CRC。
- `EvId` 只能往後追加，事件記憶以編號存檔。
- 植物格位、建築地點、遺跡地點以**索引**存檔，座標可以自由改，但不能刪除或重排項目。要拿掉一個位置就停用它：植物用 `Z_OFF`，遺跡用 `SITE_OFF[]`，並在 tick 時清掉舊存檔留下的物件。

## 專案約定（使用者要求）

- 長時間的壽命、里程碑間隔、冷卻都要落在 30 分鐘～3 小時：用 `util::shortH(小時)` / `util::shortS(秒)`（`src/Util.h`）包住原始設計值，不要直接寫成多天。
- 生物頭上不畫驚嘆號（`drawEmote` 只畫睡覺的 z）。
- 不產生 `PT_INSECT` 小蟲粒子（`fx::spawn` 開頭已擋掉）。
- 角色與美術都要原創；不使用聲音（開機就關功放）。
- 回覆使用繁體中文。
