-- 0048 品評會：給沒有 Python 環境的測試資料庫手動套用（內容與 migrations/versions/0048_fair.py 的 upgrade 相同）。
-- 只能用在 alembic_version = '0047' 的資料庫；正式環境請在 Python 專案執行 alembic upgrade head。
BEGIN;
ALTER TABLE game_transactions DROP CONSTRAINT ck_game_transactions_event_type_valid;
ALTER TABLE game_transactions ADD CONSTRAINT ck_game_transactions_event_type_valid CHECK (event_type IN (
 'create_farm','buy_seed','plant','harvest','sell','upgrade','buy_item','use_item','water','clear','steal','stolen','bind_group',
 'steal_blocked','defended','defense_place','build','buy_animal','feed_animal','collect_animal','craft_start','craft_collect',
 'quest_reward','competition_reward','admin_adjust','ranking_reward','transfer_group','gamble','explore','build_machine','exchange','make_seed',
 'fishing_buy','fish_sell','release_animal','boss_donate','boss_reward','rename_farm','checkin_reward','achievement_reward',
 'ruins_donate','ruins_guardian','rumor_treasure','seed_lab','seed_share','aid_gift','aid_water',
 'reputation_donate','auction_bid','auction_refund','auction_win',
 'fair_entry','fair_reward'));
CREATE TABLE fair_entries (
 id BIGSERIAL PRIMARY KEY,
 group_id BIGINT NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
 week_start DATE NOT NULL,
 player_id BIGINT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 farm_id BIGINT NOT NULL REFERENCES farms(id) ON DELETE CASCADE,
 category VARCHAR(10) NOT NULL, item_code VARCHAR(50) NOT NULL, item_name VARCHAR(64) NOT NULL,
 quality VARCHAR(20) NOT NULL DEFAULT 'normal', mutation VARCHAR(20) NOT NULL DEFAULT 'none',
 base_value INTEGER NOT NULL, judge_score INTEGER NOT NULL, votes INTEGER NOT NULL DEFAULT 0, fee INTEGER NOT NULL,
 rank INTEGER, reward INTEGER NOT NULL DEFAULT 0, status VARCHAR(10) NOT NULL DEFAULT 'active',
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(), settled_at TIMESTAMPTZ,
 CONSTRAINT uq_fair_entries_group_week_player UNIQUE (group_id, week_start, player_id),
 CONSTRAINT ck_fair_entries_category_valid CHECK (category IN ('crop', 'goods', 'lab')),
 CONSTRAINT ck_fair_entries_status_valid CHECK (status IN ('active', 'settled', 'refunded')),
 CONSTRAINT ck_fair_entries_values_non_negative CHECK (base_value >= 0 AND judge_score >= 0 AND votes >= 0 AND fee >= 0 AND reward >= 0),
 CONSTRAINT ck_fair_entries_rank_positive CHECK (rank IS NULL OR rank >= 1));
CREATE INDEX ix_fair_entries_group_week ON fair_entries (group_id, week_start);
CREATE INDEX ix_fair_entries_status_week ON fair_entries (status, week_start);
CREATE TABLE fair_votes (
 id BIGSERIAL PRIMARY KEY,
 entry_id BIGINT NOT NULL REFERENCES fair_entries(id) ON DELETE CASCADE,
 group_id BIGINT NOT NULL REFERENCES groups(id) ON DELETE CASCADE,
 week_start DATE NOT NULL,
 voter_player_id BIGINT NOT NULL REFERENCES players(id) ON DELETE CASCADE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 CONSTRAINT uq_fair_votes_entry_voter UNIQUE (entry_id, voter_player_id));
CREATE INDEX ix_fair_votes_voter_week ON fair_votes (voter_player_id, group_id, week_start);
UPDATE alembic_version SET version_num = '0048';
COMMIT;
