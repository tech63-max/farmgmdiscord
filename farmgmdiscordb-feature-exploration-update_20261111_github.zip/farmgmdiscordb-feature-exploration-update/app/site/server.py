"""介紹網站（公開）：Bot 功能介紹、邀請連結與彙總統計。預設 Port 24444。

- 只提供彙總數字（玩家數、農場數、伺服器數、今日操作數等），不輸出任何玩家名稱、ID 或個別資料。
- /api/guide 提供操作手冊用的遊戲設定（作物、動物、道具、品質與突變、山洞冒險與機器、釣魚、啟用中的活動與
  排名獎勵規則），
  數值即時讀自資料庫與 balance，管理員在後台調整後網站會跟著更新；同樣不含玩家資料。
- 查詢都在唯讀交易中執行並快取（統計 STATS_CACHE_SECONDS、手冊 GUIDE_CACHE_SECONDS 秒），訪客再多也不會增加資料庫負擔。
- 沒有任何寫入端點；頁面為靜態檔，前端只用 textContent 填入資料。
"""

import logging
import threading
import time
from datetime import UTC, datetime
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, select, text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session, sessionmaker

from app.db.models import (
    Farm,
    FarmPlot,
    GameTransaction,
    Group,
    Player,
    RankingRewardRule,
    WorldBossEvent,
    WorldBossSchedule,
)
from app.game import achievements, balance, checkin, exploration, fishing, news, pets, ruins, seasons, special_shop
from app.game import events as event_rules
from app.game import ranking as ranking_rules
from app.game import world_boss as wb
from app.repositories import animals as animals_repo
from app.repositories import catalog as catalog_repo
from app.repositories import crops as crops_repo
from app.repositories import events as events_repo
from app.repositories import feature_settings as feature_settings_repo
from app.repositories import fishing as fishing_repo
from app.repositories import genetics as genetics_repo
from app.services.world_boss_service import event_view

logger = logging.getLogger(__name__)
STATIC_DIR = Path(__file__).parent / "static"
STATS_CACHE_SECONDS = 30
GUIDE_CACHE_SECONDS = 60
# 邀請 Bot 需要的權限：檢視頻道、傳送訊息、嵌入連結、附加檔案、讀取訊息紀錄、連接語音、說話
INVITE_PERMISSIONS = 1024 + 2048 + 16384 + 32768 + 65536 + 1048576 + 2097152

SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Content-Security-Policy": (
        "default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; "
        "font-src https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; "
        "frame-ancestors 'none'; base-uri 'none'; form-action 'none'"
    ),
}


def invite_url(application_id: int | None) -> str | None:
    if not application_id:
        return None
    return (
        f"https://discord.com/oauth2/authorize?client_id={application_id}"
        f"&scope=bot+applications.commands&permissions={INVITE_PERMISSIONS}"
    )


class StatsCache:
    def __init__(self, factory: sessionmaker[Session] | None, ttl: float = STATS_CACHE_SECONDS) -> None:
        self.factory = factory
        self.ttl = ttl
        self._value: dict | None = None
        self._at = 0.0
        self._lock = threading.Lock()

    def get(self) -> dict | None:
        with self._lock:
            if self._value is not None and time.monotonic() - self._at < self.ttl:
                return self._value
            if self.factory is None:
                return None
            with self.factory() as session:
                session.execute(text("SET TRANSACTION READ ONLY"))
                since = session.scalar(text("SELECT date_trunc('day', now() AT TIME ZONE 'Asia/Taipei') "
                                            "AT TIME ZONE 'Asia/Taipei'"))
                self._value = {
                    "players": session.scalar(select(func.count()).select_from(Player)) or 0,
                    "farms": session.scalar(select(func.count()).select_from(Farm)) or 0,
                    "servers": session.scalar(
                        select(func.count()).select_from(Group).where(Group.discord_guild_id.is_not(None))
                    ) or 0,
                    "growing": session.scalar(
                        select(func.count()).select_from(FarmPlot).where(FarmPlot.crop_type_id.is_not(None))
                    ) or 0,
                    "actions_today": session.scalar(
                        select(func.count()).select_from(GameTransaction).where(GameTransaction.created_at >= since)
                    ) or 0,
                    "last_activity": session.scalar(select(func.max(GameTransaction.created_at))),
                }
            self._at = time.monotonic()
            return self._value


def _pct(bp: int) -> float:
    """萬分比 → 百分比（最多兩位小數）。"""
    return round(bp / 100, 2)


def _duration(seconds: int) -> str:
    hours, minutes = divmod(seconds // 60, 60)
    parts = [f"{hours} 小時" if hours else "", f"{minutes} 分鐘" if minutes else ""]
    return " ".join(p for p in parts if p) or f"{seconds} 秒"


def build_exploration(names: dict[str, str]) -> dict:
    """山洞冒險的規則（區域、機率、機器、培育配方、等級解鎖），全部來自 game/exploration.py。"""
    def name(code: str) -> str:
        if code in exploration.MATERIALS:
            return exploration.MATERIALS[code][0]
        if code.startswith("seed_"):
            return f"{names.get(code[5:], code[5:])}種子"
        return names.get(code, code)

    def items(area: exploration.Area, kind: str) -> list[dict]:
        # 同一物品可能在不同等級各列一筆（提高機率），手冊只列最早可取得的等級
        first: dict[str, int] = {}
        for d in area.pools.get(kind, ()):
            first[d.item] = min(first.get(d.item, d.min_level), d.min_level)
        return [{"name": name(code), "min_level": lv} for code, lv in first.items()]

    def type_pct(key: str) -> list[dict]:
        bp = exploration.REWARD_TYPE_BP[key]
        return [{"name": exploration.REWARD_TYPE_LABELS[t], "chance_pct": _pct(bp[t])}
                for t in exploration.REWARD_TYPES]

    return {
        "max_level": balance.INITIAL_LEVEL + (balance.MAX_PLOTS - balance.INITIAL_PLOTS) // balance.UPGRADE_PLOTS_ADDED,
        "fake_coin_value": exploration.FAKE_COIN_VALUE,
        "material_bag_capacity": exploration.MATERIAL_BAG_CAPACITY,
        "reward_types": {"normal": type_pct("normal"), "advanced": type_pct("advanced")},
        "areas": [
            {"emoji": a.emoji, "name": a.name, "description": a.description, "unlock_level": a.unlock_level,
             "duration_seconds": a.duration_seconds, "rolls": a.rolls, "advanced_level": a.advanced_level,
             "needs_ruins": a.needs_ruins,
             "common": items(a, "common"), "rare": items(a, "rare"), "seeds": items(a, "seed"),
             "events": [{"name": e.name, "min_level": e.min_level} for e in a.events]}
            for a in (exploration.AREAS[c] for c in exploration.AREA_ORDER)
        ],
        "materials": [
            {"name": n, "rarity": rarity, "usage": usage} for n, rarity, usage in exploration.MATERIALS.values()
        ],
        "machines": [
            {"emoji": m.emoji, "name": m.name, "unlock_level": m.unlock_level, "description": m.description,
             "materials": [{"name": name(code), "quantity": qty} for code, qty in m.materials.items()]}
            for m in (exploration.MACHINES[c] for c in exploration.MACHINE_ORDER)
        ],
        "seed_maker_ratio": exploration.SEED_MAKER_RATIO,
        "incubator": [
            {"name": n, "inputs": [{"name": name(code), "quantity": qty} for code, qty in inputs.items()],
             "output": name(output), "output_quantity": qty_out, "seconds": seconds}
            for n, inputs, output, qty_out, seconds, _aliases in exploration.INCUBATOR_RECIPES.values()
        ],
        "incubator_max": exploration.INCUBATOR_MAX_QUANTITY,
        "level_unlocks": [{"level": lv, "text": t} for lv, t in exploration.LEVEL_UNLOCKS],
    }


def build_fishing(session: Session) -> dict:
    """釣魚手冊：稀有度機率與售價、基礎成功率、時間設定、啟用中的釣具與魚種（只有規則與目錄，沒有玩家資料）。"""
    version, s = fishing_repo.current_settings(session)
    fish_types = fishing_repo.list_fish_types(session, active_only=True)
    gear_names = {g.code: f"{g.emoji} {g.name}" for g in fishing_repo.list_gear(session)}
    return {
        "settings_version": version,
        "base_success_pct": s["base_success_pct"],
        "bite_wait": [s["bite_wait_min_seconds"], s["bite_wait_max_seconds"]],
        "reaction_seconds": s["reaction_seconds"],
        "action_timeout_seconds": s["action_timeout_seconds"],
        "basket_capacity": s["basket_capacity"],
        "rarities": [
            {"code": r, "name": fishing.RARITY_NAMES[r], "emoji": fishing.RARITY_EMOJI[r],
             "chance_pct": _pct(s["rarity_bp"][r]), "price": fishing.price_span(fish_types, r),
             "stamina": s["difficulty"][r]["stamina"], "surge_pct": s["difficulty"][r]["surge_pct"],
             "pulls": list(fishing.PULLS[r]),
             "strong_pct": s["difficulty"][r]["strong_pct"], "chain_pct": s["difficulty"][r]["chain_pct"]}
            for r in fishing.RARITIES
        ],
        "gear": [
            {"kind": g.kind, "kind_name": fishing.GEAR_KIND_NAMES[g.kind], "name": g.name, "emoji": g.emoji,
             "price": g.price, "required_level": g.required_level, "description": g.description,
             "effects_text": fishing.gear_effects_text(g.kind, g.effects)}
            for g in fishing_repo.list_gear(session, active_only=True)
        ],
        "fish": [
            {"name": f.name, "emoji": f.emoji, "rarity": f.rarity, "rarity_name": fishing.RARITY_NAMES[f.rarity],
             "rarity_emoji": fishing.RARITY_EMOJI[f.rarity], "price": [f.min_price, f.max_price],
             "weight": [fishing.weight_text(f.min_weight_g), fishing.weight_text(f.max_weight_g)],
             "description": f.description,
             "limit_text": seasons.describe(f.seasons, f.hour_start, f.hour_end),
             "baits": [gear_names.get(b, b) for b in (f.required_baits or [])]}
            for f in fish_types
        ],
    }


def _boss_source(session: Session, now: datetime) -> tuple[dict, dict, int, dict | None, dict]:
    """手冊數值的來源：未結束的全服活動（進行中優先，其次最早開始的）→ 第一個啟用的全服排程 → 程式預設值。
    只看全服（group_id NULL）：伺服器自己的活動不公開。回傳 (settings, rewards, 持續分鐘, 本場狀態, 來源)。"""
    E = WorldBossEvent
    events = list(session.scalars(select(E).where(E.group_id.is_(None), E.status != "ended")
                                  .order_by(E.starts_at, E.id)))
    views = [event_view(session, ev, now) for ev in events]
    views = [v for v in views if v["state"] not in ("ended", "defeated")] or views
    if views:
        v = next((x for x in views if x["state"] == "active"), views[0])
        minutes = int((v["ends_at"] - v["starts_at"]).total_seconds() // 60)
        current = {
            "name": v["name"], "state": v["state"], "state_label": v["state_label"],
            "hp": v["hp"], "max_hp": v["max_hp"], "hp_pct": v["hp_pct"],
            "starts_at": v["starts_at"].isoformat(), "ends_at": v["ends_at"].isoformat(),
            "participants": v["participants"],
            "supplies": [{"name": s["name"], "emoji": s["emoji"], "progress": s["progress"], "target": s["target"]}
                         for s in v["supplies"]],
        }
        return v["settings"], v["rewards"], minutes, current, {"kind": "event", "name": v["name"]}
    sc = session.scalar(select(WorldBossSchedule).where(WorldBossSchedule.enabled.is_(True),
                                                        WorldBossSchedule.group_id.is_(None))
                        .order_by(WorldBossSchedule.id).limit(1))
    if sc is not None:
        return sc.settings, sc.rewards, sc.duration_minutes, None, {"kind": "schedule", "name": sc.name}
    return (wb.DEFAULT_SETTINGS, wb.DEFAULT_REWARDS, wb.DEFAULT_DURATION_HOURS * 60, None,
            {"kind": "default", "name": None})


def build_progress() -> dict:
    """每日簽到、成就與圖鑑的規則（只有固定設定，沒有玩家資料）。"""
    cats = {key: (emoji, name) for key, emoji, name in achievements.CATEGORIES}
    return {
        "checkin": [{"day": i, "reward": checkin.reward_text(r)} for i, r in enumerate(checkin.rewards(), 1)],
        "achievements": [
            {"category": f"{cats[a.category][0]} {cats[a.category][1]}", "name": f"{a.emoji} {a.name}",
             "description": a.description, "reward": achievements.reward_text(a), "title": a.title}
            for a in achievements.active()
        ],
        "codex": ["作物（含珍稀變種）", "動物產品", "加工品", "山洞素材", "魚類"],
    }


def build_pets(crops) -> dict:
    """寵物規則；cat_odds：每種啟用中的作物在貓咪 Lv0～最高級時，每格實際多收多少（與遊戲相同算法）。"""
    levels = range(0, pets.max_level() + 1)
    return {
        "cat_odds": [
            {"name": c.name, "quantity": c.harvest_quantity,
             "levels": [pets.odds_text(c.harvest_quantity, pets.bonus_pct(lv)) for lv in levels]}
            for c in crops
        ],
        "buy_price": pets.buy_price(), "upgrade_prices": list(pets.upgrade_prices()),
        "base_pct": pets.base_pct(), "pct_per_level": pets.pct_per_level(), "max_level": pets.max_level(),
        "max_pct": pets.bonus_pct(pets.max_level()),
        "pets": [{"name": f"{p.emoji} {p.name}", "role": p.role, "effect": p.effect.format(pct="X")}
                 for p in pets.PETS.values()],
    }


def build_special_shop(session: Session, now: datetime) -> dict:
    """商店「特賣與升級」：溫室價格、本週特賣（所有玩家相同）與稱號商店（沒有玩家資料）。"""
    start = special_shop.week_start(now)
    crops = [special_shop.CropRef(c.code, c.name, c.seed_price, c.shop_buyable)
             for c in crops_repo.list_all(session, active_only=True)]
    return {
        "greenhouse": {"per_level": special_shop.greenhouse_pct_per_level(),
                       "prices": list(special_shop.greenhouse_prices())},
        "weekly": {
            "week_start": start.isoformat(), "ends_at": special_shop.week_ends_at(start).isoformat(),
            "offers": [{"name": f"{o.crop_name}種子", "price": o.price, "original_price": o.original_price,
                        "limit": o.limit, "rare": o.rare} for o in special_shop.weekly_offers(start, crops)],
        },
        "titles": [{"title": t, "price": p} for t, p in special_shop.title_shop()],
    }


def build_world_boss(session: Session, names: dict[str, str], now: datetime) -> dict:
    """世界 Boss 手冊：補給類型與效果、捐獻類別、積分規則、限制、獎勵、本場全服活動狀態，以及啟用中的固定出現排程
    （名稱、全服或伺服器、出現時間與獎勵；不含伺服器名稱或任何玩家資料）。
    數值取自目前的全服活動或排程（與 Discord「📖 活動說明」一致），都沒有時才用程式預設值。"""
    s, r, minutes, current, source = _boss_source(session, now)

    def part(p: dict) -> str:
        bits = [f"{p['gold']:,} 金幣"] if p["gold"] else []
        bits += [f"{names.get(code, code)} ×{qty}" for code, qty in p["items"].items()]
        return "、".join(bits) or "無"

    def rewards(x: dict) -> dict:
        return {
            "min_points": wb.min_points(x),
            "victory": part(x["victory"]), "participation": part(x["participation"]),
            "bonus_points": x["bonus_points"], "bonus": part(x["bonus"]),
            "rank": [part(y) for y in x["rank"]], "title": x["title"], "title_top": x["title_top"],
        }

    schedules = [
        {"name": sc.name, "scope": "全服" if sc.group_id is None else "指定伺服器",
         "interval_days": sc.interval_days, "time": f"{sc.spawn_hour:02d}:{sc.spawn_minute:02d}",
         "duration_minutes": sc.duration_minutes, "max_hp": sc.max_hp, "rewards": rewards(sc.rewards)}
        for sc in session.scalars(select(WorldBossSchedule).where(WorldBossSchedule.enabled.is_(True))
                                  .order_by(WorldBossSchedule.id))
    ]

    eff = s["effects"]
    effect_text = {
        "food": f"沒有糧食時出勤率 {eff['base_uptime_pct']}%，補滿時 100%",
        "medical": f"補滿時救回 {eff['medical_recovery_pct']}% 的缺勤時間",
        "combat": f"補滿時傷害 +{eff['combat_attack_pct']}%",
        "equipment": f"補滿時傷害 +{eff['equipment_attack_pct']}%",
    }
    return {
        "source": source,
        "current": current,
        "supplies": [
            {"code": code, "emoji": e, "name": n, "effect": f, "description": d, "effect_text": effect_text[code],
             "target": s["supply_targets"][code]}
            for code, (e, n, f, d) in wb.SUPPLY_INFO.items()
        ],
        "categories": [{"emoji": e, "name": n} for e, n in wb.CATEGORY_INFO.values()],
        "items": [
            {"name": names.get(code, code), "supply": wb.SUPPLY_INFO[v["supply"]][1], "points": v["points"]}
            for code, v in s["items"].items() if v["points"] > 0
        ],
        "gold_per_point": s["gold_per_point"],
        "base_damage_per_hour": s["base_damage_per_hour"],
        "instant_damage_per_point": s["instant_damage_per_point"],
        "ratio_cap_pct": eff["ratio_cap_pct"],
        "limits": s["limits"],
        "duration_hours": wb.DEFAULT_DURATION_HOURS,  # 管理員手動建立活動的預設時長
        "duration_minutes": minutes,  # 本場（或排程）的持續時間
        "rewards": rewards(r),
        "schedules": schedules,
    }


def build_ruins(names: dict[str, str]) -> dict:
    """古代遺跡（群組修復）、遺跡守護者與額外探索的規則（固定數值，沒有任何群組資料）。"""
    area = exploration.AREAS["ruins"]
    return {
        "stages": [
            {"name": st.name, "description": st.description,
             "materials": [{"name": names.get(c, exploration.material_name(c)), "quantity": q}
                           for c, q in st.materials.items()]}
            for st in ruins.STAGES
        ],
        "title": ruins.TITLE,
        "unlock_level": area.unlock_level,
        "cooldown_seconds": area.duration_seconds,
        "rolls": area.rolls,
        "extra_rolls": list(exploration.RUINS_EXTRA_ROLLS),
        "guardian": {
            "name": ruins.GUARDIAN_NAME, "hp_base": ruins.GUARDIAN_HP_BASE,
            "hp_per_member": ruins.GUARDIAN_HP_PER_MEMBER,
            "hp_max": ruins.GUARDIAN_HP_MAX, "damage": dict(ruins.GUARDIAN_DAMAGE),
            "expedition_damage": ruins.EXPEDITION_DAMAGE, "bonus_rolls": ruins.DEFEAT_BONUS_ROLLS,
        },
    }


def build_news() -> dict:
    """總覽的農場日報與傳聞挖寶規則。"""
    return {
        "max_headlines": news.MAX_HEADLINES,
        "rumor_chance_pct": round(news.RUMOR_CHANCE * 100),
        "rumor_true_pct": round(news.RUMOR_TRUE_CHANCE * 100),
        "dig_chance_pct": round(news.DIG_CHANCE * 100),
        "treasure_gold": list(news.TREASURE_GOLD),
    }


def build_seasons(now: datetime) -> dict:
    return {
        "now_text": seasons.now_text(now),
        "current": seasons.SEASON_NAMES[seasons.season_of(now)],
        "months": {"春": "3–5 月", "夏": "6–8 月", "秋": "9–11 月", "冬": "12–2 月"},
    }


def build_guide(session: Session, now: datetime) -> dict:
    """操作手冊需要的遊戲設定。只輸出規則與數值，不含任何玩家、農場或群組資料。"""
    feature_settings_repo.refresh(session)  # 管理網站調整過的簽到、寵物、特賣與成就數值
    crops = [c for c in crops_repo.list_all(session) if c.active]
    animals = [a for a in animals_repo.list_all(session) if a.active]
    version, g = genetics_repo.current(session)
    names = {c.code: c.name for c in crops_repo.list_all(session)}
    names.update({code: v[0] for code, v in balance.GOODS.items()})
    mutation_effects = {
        "giant": f"收成數量 ×{g['giant_multiplier']}",
        "golden": f"售價 ×{g['golden_price_pct'] / 100:g}",
        "fast": (f"生長時間減少 {_duration(g['fast_reduction_seconds'])}"
                 f"（最短 {_duration(balance.MIN_GROW_SECONDS)}，仍需澆水）"),
        "variant": f"長成獨立的稀有作物，售價 ×{g['variant_price_pct'] / 100:g}",
    }
    return {
        "genetics_version": version,
        "start": {
            "gold": balance.INITIAL_GOLD,
            "plots": balance.INITIAL_PLOTS,
            "warehouse": balance.INITIAL_WAREHOUSE_CAPACITY,
            "rename_cost": balance.RENAME_FARM_COST,
            "upgrade_prices": list(balance.UPGRADE_PRICES),
            "upgrade_plots": balance.UPGRADE_PLOTS_ADDED,
            "max_plots": balance.MAX_PLOTS,
            "wither_minutes": balance.WITHER_SECONDS // 60,
            "steal_max": balance.STEAL_MAX_PER_ACTION,
            "steal_plots_per_day": balance.STEAL_PLOTS_PER_VICTIM_PER_DAY,
            "steal_thieves_per_day": balance.STEAL_THIEVES_PER_VICTIM_PER_DAY,
            "transfer_cooldown_days": balance.GROUP_TRANSFER_COOLDOWN_SECONDS // 86400,
            "max_block_pct": round(balance.DEFENSE_MAX_BLOCK_CHANCE * 100),
            "patrol_days": balance.PATROL_DAYS,
            "barn_slots": balance.BARN_SLOTS,
            "craft_max": balance.CRAFT_MAX_QUANTITY,
            "warehouse_step": balance.WAREHOUSE_EXPANSION_STEP,
            "warehouse_prices": list(balance.WAREHOUSE_EXPANSION_PRICES),
            "warehouse_max": balance.WAREHOUSE_MAX_CAPACITY,
        },
        "crops": [
            {"name": c.name, "seed_price": c.seed_price, "grow_seconds": c.grow_seconds,
             "harvest_quantity": c.harvest_quantity, "sell_price": c.sell_price, "variant_name": c.variant_name,
             "shop_buyable": c.shop_buyable, "season_text": seasons.describe(c.seasons, c.hour_start, c.hour_end),
             "in_season": seasons.available(c.seasons, c.hour_start, c.hour_end, now)}
            for c in crops
        ],
        "exploration": build_exploration(names),
        "ruins": build_ruins(catalog_repo.item_names(session)),
        "news": build_news(),
        "seasons": build_seasons(now),
        "fishing": build_fishing(session),
        "world_boss": build_world_boss(session, catalog_repo.item_names(session), now),
        "progress": build_progress(),
        "special_shop": build_special_shop(session, now),
        "pets": build_pets(crops),
        "qualities": [
            {"name": label, "chance_pct": _pct(g["quality_bp"][code]), "price_mul": g["quality_price_pct"][code] / 100}
            for code, label in balance.QUALITIES.items()
        ],
        "level_bonus_pct": _pct(g["level_bonus_bp"]),
        "level_bonus_max_pct": _pct(g["level_bonus_max_bp"]),
        "mutations": [
            {"name": balance.MUTATIONS[code], "chance_pct": _pct(g["mutation_bp"][code]), "effect": effect}
            for code, effect in mutation_effects.items()
        ],
        "items": [
            {"name": name, "price": price, "kind": kind, "description": desc}
            for name, price, kind, desc, _aliases in balance.ITEMS.values()
        ],
        "defenses": [
            {"name": name, "price": price, "max": max_count, "chance_pct": round(chance * 100), "range": cells}
            for name, price, max_count, chance, cells, _aliases in (balance.DEFENSES[c] for c in balance.DEFENSE_ORDER)
        ],
        "buildings": [
            {"name": name, "price": price, "max": max_count}
            for name, price, max_count, _aliases in balance.BUILDINGS.values()
        ],
        "animals": [
            {"name": a.name, "price": a.price, "feed_cost": a.feed_cost, "cycle_seconds": a.cycle_seconds,
             "product_name": a.product_name, "product_quantity": a.product_quantity, "product_price": a.product_price}
            for a in animals
        ],
        "recipes": [
            {"name": name, "building": balance.BUILDINGS[building][0], "building_price": balance.BUILDINGS[building][1],
             "inputs": [{"name": names.get(code, code), "quantity": qty} for code, qty in inputs.items()],
             "output_quantity": out_qty, "seconds": seconds, "sell_price": balance.GOODS[output][1]}
            for name, building, inputs, output, out_qty, seconds, _aliases in balance.RECIPES.values()
        ],
        "gamble": {
            "min": balance.GAMBLE_MIN, "max": balance.GAMBLE_MAX, "big_from": balance.GAMBLE_BIG_FROM,
            "hilo_multiplier": balance.GAMBLE_HILO_MULTIPLIER, "exact_multiplier": balance.GAMBLE_EXACT_MULTIPLIER,
            "qualities": [balance.QUALITIES[q] for q in balance.GAMBLE_QUALITIES],
            "mutations": [balance.MUTATIONS[m] for m in balance.GAMBLE_MUTATIONS],
        },
        # 只列啟用中的活動（名稱、效果與時段本來就會在 Discord 面板公開顯示）
        "events": [
            {"name": e.name, "description": e.description, "effects_text": event_rules.effects_text(e),
             "schedule_text": event_rules.schedule_text(e), "active_now": event_rules.is_active(e, now)}
            for e in sorted(events_repo.list_all(session), key=lambda e: e.id)
            if e.enabled
        ],
        # 只列啟用中的排名獎勵規則（規則本身會在 Discord「🎁 排名獎勵」公開顯示，不含任何得獎紀錄）
        "rankings": {
            "settle_grace_seconds": balance.RANKING_SETTLE_GRACE_SECONDS,
            "rules": [
                {"name": r.name, "scope": r.scope, "metric": ranking_rules.METRICS[r.metric],
                 "period": ranking_rules.PERIODS[r.period],
                 "rewards": [ranking_rules.reward_text(x) for x in r.rewards]}
                for r in session.scalars(
                    select(RankingRewardRule).where(RankingRewardRule.enabled.is_(True)).order_by(RankingRewardRule.id)
                )
            ],
        },
    }


class GuideCache:
    def __init__(self, factory: sessionmaker[Session] | None, ttl: float = GUIDE_CACHE_SECONDS) -> None:
        self.factory = factory
        self.ttl = ttl
        self._value: dict | None = None
        self._at = 0.0
        self._lock = threading.Lock()

    def get(self) -> dict | None:
        with self._lock:
            if self._value is not None and time.monotonic() - self._at < self.ttl:
                return self._value
            if self.factory is None:
                return None
            with self.factory() as session:
                session.execute(text("SET TRANSACTION READ ONLY"))
                self._value = build_guide(session, datetime.now(UTC))
            self._at = time.monotonic()
            return self._value


def create_site_app(
    session_factory: sessionmaker[Session] | None = None,
    *,
    site_name: str = "油祥農場",
    application_id: int | None = None,
    support_url: str | None = None,
    music_enabled: bool = True,
    music_application_id: int | None = None,
    music_prefix_commands: bool = False,
    music_prefix: str = "!",
    music_playlist_limit: int = 20,
    music_idle_timeout: int = 300,
    music_volume: float = 0.1,
) -> FastAPI:
    app = FastAPI(title=site_name, docs_url=None, redoc_url=None, openapi_url=None)
    stats = StatsCache(session_factory)
    guide = GuideCache(session_factory)

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        response = await call_next(request)
        for key, value in SECURITY_HEADERS.items():
            response.headers.setdefault(key, value)
        # 網站更新後訪客立即看到新版：瀏覽器可快取，但每次先向伺服器確認（ETag）
        response.headers.setdefault("Cache-Control", "no-cache")
        return response

    @app.get("/api/info")
    async def info() -> dict:
        return {
            "name": site_name,
            "invite_url": invite_url(application_id),
            # 音樂改用獨立 Bot 時，另外提供音樂 Bot 的邀請連結
            "music_invite_url": invite_url(music_application_id),
            "support_url": support_url,
            "music_enabled": music_enabled,
            # 音樂說明用的設定值（不含任何 Token 或機密）
            "music": {
                "prefix_commands": music_prefix_commands,
                "prefix": music_prefix,
                "playlist_limit": music_playlist_limit,
                "idle_minutes": round(music_idle_timeout / 60, 1),
                "default_volume_pct": round(music_volume * 100),
            },
        }

    @app.get("/api/guide")
    async def get_guide():
        try:
            value = await run_in_threadpool(guide.get)
        except SQLAlchemyError as exc:
            logger.warning("介紹網站手冊資料查詢失敗：%s", type(exc).__name__)
            return JSONResponse(status_code=503, content={"detail": "遊戲設定暫時無法取得"})
        if value is None:
            return JSONResponse(status_code=503, content={"detail": "遊戲設定暫時無法取得"})
        return {**value, "cached_seconds": GUIDE_CACHE_SECONDS}

    @app.get("/api/stats")
    async def get_stats():
        try:
            value = await run_in_threadpool(stats.get)
        except SQLAlchemyError as exc:
            logger.warning("介紹網站統計查詢失敗：%s", type(exc).__name__)
            return JSONResponse(status_code=503, content={"detail": "統計資料暫時無法取得"})
        if value is None:
            return JSONResponse(status_code=503, content={"detail": "統計資料暫時無法取得"})
        return {**value, "cached_seconds": STATS_CACHE_SECONDS}

    app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

    @app.get("/favicon.ico", include_in_schema=False)
    async def favicon() -> FileResponse:
        return FileResponse(STATIC_DIR / "favicon.svg", media_type="image/svg+xml")

    @app.get("/", include_in_schema=False)
    async def index() -> FileResponse:
        return FileResponse(STATIC_DIR / "index.html")

    return app
