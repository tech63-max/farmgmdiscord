#include "DisplayManager.h"

#include "../assets/Font12.h"
#include "../config/BoardConfig.h"
#include "LargeAlloc.h"

namespace {
// UTF-8 文字緩衝區：最寬 240px、最高 2 倍字 (26px)
constexpr int16_t TEXT_MAX_SCALE = 2;
constexpr size_t TEXT_BUF_PX = DisplayManager::WIDTH * FONT12_HEIGHT * TEXT_MAX_SCALE;
uint16_t *textBuf = nullptr;

// 解出下一個 UTF-8 字元；遇到不合法序列回傳 '?'
uint32_t nextCodepoint(const char *&p) {
  const uint8_t c = (uint8_t)*p++;
  if (c < 0x80) return c;
  int extra = 0;
  uint32_t cp = 0;
  if ((c & 0xE0) == 0xC0) { extra = 1; cp = c & 0x1F; }
  else if ((c & 0xF0) == 0xE0) { extra = 2; cp = c & 0x0F; }
  else if ((c & 0xF8) == 0xF0) { extra = 3; cp = c & 0x07; }
  else return '?';
  while (extra-- > 0) {
    const uint8_t n = (uint8_t)*p;
    if ((n & 0xC0) != 0x80) return '?';
    cp = (cp << 6) | (n & 0x3F);
    p++;
  }
  return cp;
}

constexpr int GLYPH_MISSING = -1;     // 沒收錄的字 → 畫方框 (例如 emoji)
constexpr int GLYPH_ZERO_WIDTH = -2;  // 不佔位置的控制字元 → 略過

int findGlyph(uint32_t cp) {
  if ((cp >= 0xFE00 && cp <= 0xFE0F) || cp == 0x200B || cp == 0x200C || cp == 0x200D ||
      cp == 0xFEFF || (cp >= 0x1F3FB && cp <= 0x1F3FF) || cp < 0x20)
    return GLYPH_ZERO_WIDTH;
  if (cp > 0xFFFF) return GLYPH_MISSING;
  int lo = 0, hi = FONT12_COUNT - 1;
  while (lo <= hi) {
    const int mid = (lo + hi) / 2;
    if (FONT12_CODES[mid] == cp) return mid;
    if (FONT12_CODES[mid] < cp) lo = mid + 1;
    else hi = mid - 1;
  }
  return GLYPH_MISSING;
}

constexpr uint8_t MISSING_W = 8;
uint8_t glyphWidth(int g) {
  if (g == GLYPH_ZERO_WIDTH) return 0;
  return g >= 0 ? FONT12_WIDTHS[g] : MISSING_W;
}

// 找出從 s 開始、寬度 maxW 內能放到哪裡 (換行用)；回傳下一行開頭
const char *wrapCut(const char *s, int16_t maxW, uint8_t scale) {
  int16_t w = 0;
  const char *p = s;
  const char *cut = s;
  while (*p && *p != '\n') {
    const char *q = p;
    const int16_t gw = glyphWidth(findGlyph(nextCodepoint(q))) * scale;
    if (w + gw > maxW) break;
    w += gw;
    p = q;
    cut = p;
  }
  if (cut == s && *p && *p != '\n') {  // 一個字都放不下：至少放一個，避免無窮迴圈
    nextCodepoint(p);
    cut = p;
  }
  return cut;
}

// 靜態物件，不使用 new
Arduino_ESP32SPI bus(Pins::LCD_DC, Pins::LCD_CS, Pins::LCD_SCK, Pins::LCD_MOSI, GFX_NOT_DEFINED);
Arduino_ST7789 panel(&bus, Pins::LCD_RST, 0 /*rotation*/, true /*IPS*/, 240, 240);

constexpr uint32_t BL_FREQ = 5000;
constexpr uint8_t BL_RES_BITS = 10;
}  // namespace

// ---------------- PixelCanvas ----------------
bool PixelCanvas::begin() {
  if (buf_ == nullptr) buf_ = allocLarge<uint16_t>((size_t)W * H);
  return buf_ != nullptr;
}

void PixelCanvas::fill(uint16_t color) {
  if (buf_ == nullptr) return;
  for (int32_t i = 0; i < (int32_t)W * H; i++) buf_[i] = color;
}

void PixelCanvas::pset(int16_t x, int16_t y, uint16_t color) {
  if (buf_ == nullptr || x < 0 || y < 0 || x >= LW || y >= LH) return;
  uint16_t *p = buf_ + (y * SCALE) * W + x * SCALE;
  p[0] = p[1] = color;
  p[W] = p[W + 1] = color;
}

void PixelCanvas::fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color) {
  if (buf_ == nullptr) return;
  int16_t x0 = max<int16_t>(x, 0), y0 = max<int16_t>(y, 0);
  int16_t x1 = min<int16_t>(x + w, LW), y1 = min<int16_t>(y + h, LH);
  if (x1 <= x0 || y1 <= y0) return;
  for (int16_t yy = y0; yy < y1; yy++) {
    uint16_t *row = buf_ + (yy * SCALE) * W;
    for (int16_t xx = x0 * SCALE; xx < x1 * SCALE; xx++) row[xx] = color;
    memcpy(row + W + x0 * SCALE, row + x0 * SCALE, (size_t)(x1 - x0) * SCALE * sizeof(uint16_t));
  }
}

void PixelCanvas::line(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t color) {
  int16_t dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1;
  int16_t dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1;
  int16_t err = dx + dy;
  for (int guard = 0; guard < 512; guard++) {
    pset(x0, y0, color);
    if (x0 == x1 && y0 == y1) break;
    const int16_t e2 = 2 * err;
    if (e2 >= dy) { err += dy; x0 += sx; }
    if (e2 <= dx) { err += dx; y0 += sy; }
  }
}

void PixelCanvas::fillCircle(int16_t cx, int16_t cy, int16_t r, uint16_t color) {
  fillEllipse(cx, cy, r, r, color);
}

void PixelCanvas::circle(int16_t cx, int16_t cy, int16_t r, uint16_t color) {
  int16_t x = r, y = 0, err = 1 - r;
  while (x >= y) {
    pset(cx + x, cy + y, color); pset(cx - x, cy + y, color);
    pset(cx + x, cy - y, color); pset(cx - x, cy - y, color);
    pset(cx + y, cy + x, color); pset(cx - y, cy + x, color);
    pset(cx + y, cy - x, color); pset(cx - y, cy - x, color);
    y++;
    if (err < 0) err += 2 * y + 1;
    else { x--; err += 2 * (y - x) + 1; }
  }
}

void PixelCanvas::fillEllipse(int16_t cx, int16_t cy, int16_t rx, int16_t ry, uint16_t color) {
  if (rx <= 0 || ry <= 0) return;
  const int32_t rx2 = (int32_t)rx * rx, ry2 = (int32_t)ry * ry;
  for (int16_t dy = -ry; dy <= ry; dy++) {
    // x^2/rx^2 + y^2/ry^2 <= 1  →  |x| <= rx * sqrt(1 - y^2/ry^2)
    const int32_t lim = rx2 * (ry2 - (int32_t)dy * dy);
    int16_t half = 0;
    while ((int32_t)(half + 1) * (half + 1) * ry2 <= lim) half++;
    hline(cx - half, cy + dy, half * 2 + 1, color);
  }
}

void PixelCanvas::glyph(const char *const rows[], uint8_t nRows, int16_t x, int16_t y,
                        uint16_t color) {
  for (uint8_t r = 0; r < nRows; r++)
    for (uint8_t c = 0; rows[r][c]; c++)
      if (rows[r][c] == '#') pset(x + c, y + r, color);
}

// ---------------- DisplayManager ----------------
bool DisplayManager::begin() {
  if (textBuf == nullptr) textBuf = allocLarge<uint16_t>(TEXT_BUF_PX);
  if (textBuf == nullptr) return false;
  ledcAttach(Pins::LCD_BL, BL_FREQ, BL_RES_BITS);
  setBrightness(0);  // 初始化期間先關背光，避免看到雜訊畫面
  if (!panel.begin(LCD_SPI_HZ)) return false;
  panel.setTextWrap(false);
  return true;
}

void DisplayManager::setBrightness(uint8_t percent) {
  if (percent > 100) percent = 100;
  if (percent == brightness_) return;
  brightness_ = percent;
  ledcWrite(Pins::LCD_BL, (uint32_t)percent * ((1u << BL_RES_BITS) - 1) / 100);
}

Arduino_GFX &DisplayManager::gfx() { return panel; }

void DisplayManager::clear(uint16_t color) { panel.fillScreen(color); }

void DisplayManager::fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color) {
  if (w > 0 && h > 0) panel.fillRect(x, y, w, h, color);
}

void DisplayManager::pushRgb(int16_t x, int16_t y, uint16_t *px, int16_t w, int16_t h) {
  if (px != nullptr && w > 0 && h > 0) panel.draw16bitRGBBitmap(x, y, px, w, h);
}

int16_t DisplayManager::utf8Width(const char *s, uint8_t scale) {
  int16_t w = 0;
  while (*s) w += glyphWidth(findGlyph(nextCodepoint(s)));
  return w * scale;
}

void DisplayManager::utf8(int16_t x, int16_t y, const char *s, uint8_t scale, uint16_t fg,
                          uint16_t bg) {
  if (scale < 1) scale = 1;
  if (scale > TEXT_MAX_SCALE) scale = TEXT_MAX_SCALE;
  if (x < 0) x = 0;
  int16_t w = utf8Width(s, scale);
  if (x + w > WIDTH) w = WIDTH - x;
  if (w <= 0) return;
  const int16_t h = FONT12_HEIGHT * scale;
  for (int32_t i = 0; i < w * h; i++) textBuf[i] = bg;

  int16_t penX = 0;
  while (*s) {
    const int g = findGlyph(nextCodepoint(s));
    if (g == GLYPH_ZERO_WIDTH) continue;
    const uint8_t gw = glyphWidth(g);
    for (uint8_t gy = 0; gy < FONT12_HEIGHT; gy++) {
      uint16_t bits;
      if (g >= 0) {
        bits = FONT12_ROWS[(uint32_t)g * FONT12_HEIGHT + gy];
      } else {  // 方框
        bits = (gy == 1 || gy == FONT12_HEIGHT - 2) ? 0x7E00 : (gy > 1 && gy < FONT12_HEIGHT - 2 ? 0x4200 : 0);
      }
      for (uint8_t gx = 0; gx < gw && bits; gx++, bits <<= 1) {
        if (!(bits & 0x8000)) continue;
        const int16_t px = penX + gx * scale;
        for (uint8_t sy = 0; sy < scale; sy++)
          for (uint8_t sx = 0; sx < scale; sx++) {
            const int16_t xx = px + sx;
            if (xx < w) textBuf[(gy * scale + sy) * w + xx] = fg;
          }
      }
    }
    penX += gw * scale;
    if (penX >= w) break;
  }
  panel.draw16bitRGBBitmap(x, y, textBuf, w, h);
}

uint8_t DisplayManager::utf8LineCount(const char *s, int16_t maxW, uint8_t scale) {
  uint8_t n = 0;
  while (*s && n < 250) {
    s = wrapCut(s, maxW, scale);
    if (*s == '\n') s++;
    n++;
  }
  return n;
}

uint8_t DisplayManager::utf8Wrap(int16_t x, int16_t y, int16_t maxW, const char *s,
                                 uint8_t scale, uint8_t maxLines, uint16_t fg, uint16_t bg) {
  const int16_t lineH = FONT12_HEIGHT * scale + 1;
  const int16_t ellipsisW = utf8Width("…", scale);
  char line[200];
  uint8_t used = 0;
  while (*s && used < maxLines) {
    const bool last = used == maxLines - 1;
    const char *cut = wrapCut(s, maxW, scale);
    size_t n = (size_t)(cut - s);
    const bool more = *cut != '\0' && !(*cut == '\n' && cut[1] == '\0');
    if (last && more) {  // 最後一行還有剩：截到「放得下 …」的位置
      int16_t ww = 0;
      const char *r = s;
      const char *fit = s;
      while (r < cut) {
        const char *q = r;
        ww += glyphWidth(findGlyph(nextCodepoint(q))) * scale;
        if (ww + ellipsisW > maxW) break;
        r = q;
        fit = r;
      }
      n = (size_t)(fit - s);
    }
    if (n > sizeof(line) - 4) n = sizeof(line) - 4;
    memcpy(line, s, n);
    line[n] = '\0';
    if (last && more) strcat(line, "…");
    const int16_t lw = utf8Width(line, scale);
    if (lw > 0) utf8(x, y + used * lineH, line, scale, fg, bg);
    if (lw < maxW) panel.fillRect(x + lw, y + used * lineH, maxW - lw, lineH, bg);
    used++;
    s = cut;
    if (*s == '\n') s++;
  }
  return used;
}

void DisplayManager::utf8Box(int16_t x, int16_t y, int16_t w, int16_t h, const char *s, uint8_t scale,
                             uint8_t maxLines, uint16_t fg, uint16_t bg) {
  panel.fillRect(x, y, w, h, bg);
  const int16_t lineH = FONT12_HEIGHT * scale + 1;
  uint8_t total = utf8LineCount(s, w, scale);
  if (total > maxLines) total = maxLines;
  if (total == 0) return;
  int16_t ly = y + (h - (total * lineH - 1)) / 2;
  if (ly < y) ly = y;
  char line[200];
  for (uint8_t i = 0; i < total && *s; i++, ly += lineH) {
    const char *cut = wrapCut(s, w, scale);
    size_t n = (size_t)(cut - s);
    const bool last = i == total - 1;
    const bool more = *cut != '\0' && !(*cut == '\n' && cut[1] == '\0');
    if (n > sizeof(line) - 4) n = sizeof(line) - 4;
    memcpy(line, s, n);
    line[n] = '\0';
    if (last && more) {  // 放不下：最後一行截短加「…」
      const int16_t ellW = utf8Width("…", scale);
      while (n > 0 && utf8Width(line, scale) + ellW > w) {
        do { n--; } while (n > 0 && ((uint8_t)line[n] & 0xC0) == 0x80);
        line[n] = '\0';
      }
      strcat(line, "…");
    }
    const int16_t lw = utf8Width(line, scale);
    if (lw > 0) utf8(x + (w - lw) / 2, ly, line, scale, fg, bg);
    s = cut;
    if (*s == '\n') s++;
  }
}

void DisplayManager::utf8Centered(int16_t y, const char *s, uint8_t scale, uint16_t fg,
                                  uint16_t bg, int16_t clearW) {
  int16_t w = utf8Width(s, scale);
  if (w > WIDTH) w = WIDTH;
  const int16_t x = (WIDTH - w) / 2;
  const int16_t clearX = (WIDTH - clearW) / 2;
  const int16_t h = FONT12_HEIGHT * scale;
  if (x > clearX) {
    panel.fillRect(clearX, y, x - clearX, h, bg);
    panel.fillRect(x + w, y, clearX + clearW - (x + w), h, bg);
  }
  utf8(x, y, s, scale, fg, bg);
}

void DisplayManager::utf8Right(int16_t xRight, int16_t y, const char *s, uint8_t scale,
                               uint16_t fg, uint16_t bg) {
  utf8(xRight - utf8Width(s, scale), y, s, scale, fg, bg);
}

void DisplayManager::pushCanvas(PixelCanvas &c, int16_t x, int16_t y) {
  if (c.data() == nullptr) return;
  panel.draw16bitRGBBitmap(x, y, c.data(), PixelCanvas::W, PixelCanvas::H);
}
