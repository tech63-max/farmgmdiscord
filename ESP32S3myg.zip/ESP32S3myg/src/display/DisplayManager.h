#pragma once
#include <Arduino_GFX_Library.h>

// 動畫區的離屏畫布：以「邏輯像素」作畫，輸出時每個邏輯像素放大成 SCALE x SCALE。
// 緩衝區在 PSRAM，只在畫面有變化時整塊推送，避免閃爍。
class PixelCanvas {
 public:
  static constexpr int16_t LW = 120;  // 邏輯寬
  static constexpr int16_t LH = 84;   // 邏輯高
  static constexpr int16_t SCALE = 2;
  static constexpr int16_t W = LW * SCALE;  // 240
  static constexpr int16_t H = LH * SCALE;  // 168

  bool begin();  // 配置緩衝區 (開機呼叫一次)
  void fill(uint16_t color);
  void pset(int16_t x, int16_t y, uint16_t color);
  void fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);
  void hline(int16_t x, int16_t y, int16_t w, uint16_t color) { fillRect(x, y, w, 1, color); }
  void vline(int16_t x, int16_t y, int16_t h, uint16_t color) { fillRect(x, y, 1, h, color); }
  void line(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t color);
  void fillCircle(int16_t cx, int16_t cy, int16_t r, uint16_t color);
  void circle(int16_t cx, int16_t cy, int16_t r, uint16_t color);
  void fillEllipse(int16_t cx, int16_t cy, int16_t rx, int16_t ry, uint16_t color);
  // 由 5 列字串組成的小圖示 ('#' = 上色)，用來畫問號、Z 等符號
  void glyph(const char *const rows[], uint8_t nRows, int16_t x, int16_t y, uint16_t color);
  uint16_t *data() { return buf_; }

 private:
  uint16_t *buf_ = nullptr;
};

class DisplayManager {
 public:
  static constexpr int16_t WIDTH = 240;
  static constexpr int16_t HEIGHT = 240;

  bool begin();
  void setBrightness(uint8_t percent);
  uint8_t brightness() const { return brightness_; }
  Arduino_GFX &gfx();

  void clear(uint16_t color);
  void fillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color);
  // 推送一塊 RGB565 影像 (JPEG 解碼結果用)
  // 注意：一定要用非 const 指標，才會走和畫布相同的 RAM 版 draw16bitRGBBitmap
  // (const 版是給 PROGMEM 圖用的逐點寫入路徑)
  void pushRgb(int16_t x, int16_t y, uint16_t *px, int16_t w, int16_t h);

  // UTF-8 文字 (中英文，12px 像素字型 Font12)。scale 1 = 13px 高，2 = 26px 高。
  // 會先畫進緩衝區再一次推送，背景色會覆蓋整個文字區塊
  void utf8(int16_t x, int16_t y, const char *s, uint8_t scale, uint16_t fg, uint16_t bg);
  void utf8Centered(int16_t y, const char *s, uint8_t scale, uint16_t fg, uint16_t bg,
                    int16_t clearW = WIDTH);
  void utf8Right(int16_t xRight, int16_t y, const char *s, uint8_t scale, uint16_t fg,
                 uint16_t bg);
  static int16_t utf8Width(const char *s, uint8_t scale);
  // 自動換行，超過 maxLines 時最後一行結尾加「…」；每行右側多餘處填背景色。回傳用了幾行
  uint8_t utf8Wrap(int16_t x, int16_t y, int16_t maxW, const char *s, uint8_t scale,
                   uint8_t maxLines, uint16_t fg, uint16_t bg);
  // 以 maxW 換行後需要幾行 (不畫)
  static uint8_t utf8LineCount(const char *s, int16_t maxW, uint8_t scale);
  // 在方框內換行並置中 (每行水平置中、整塊垂直置中)，會先把方框填成背景色；超過 maxLines 時結尾加「…」
  void utf8Box(int16_t x, int16_t y, int16_t w, int16_t h, const char *s, uint8_t scale, uint8_t maxLines,
               uint16_t fg, uint16_t bg);

  void pushCanvas(PixelCanvas &c, int16_t x, int16_t y);

 private:
  uint8_t brightness_ = 0xFF;
};
