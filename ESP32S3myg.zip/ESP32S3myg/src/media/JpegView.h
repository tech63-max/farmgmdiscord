#pragma once
#include <stdint.h>

#include "../display/DisplayManager.h"
#include "../storage/SdStorage.h"

enum class JpegResult : uint8_t { Ok, OpenFail, NotJpeg, TooBig, DecodeFail, NoMemory };

// 用 ESP32-S3 ROM 內建的 TJpgDec 解碼 SD 卡上的 JPEG：
// - 串流讀檔，不把整張圖載入 RAM (只用約 4 KB 工作區 + 一條 240x16 像素的列緩衝)
// - 自動選 1/1、1/2、1/4、1/8 縮小倍率，讓圖片塞進指定方框並置中，其餘填底色
// - 只看檔頭 magic bytes 判斷格式，不信任副檔名
class JpegView {
 public:
  static constexpr uint32_t MAX_FILE_BYTES = 2u * 1024 * 1024;  // 單張上限 2 MB
  static constexpr uint16_t MAX_DIM = 4096;                     // 原圖最大邊長

  static JpegResult draw(SdStorage &sd, DisplayManager &d, const char *path, int16_t boxX,
                         int16_t boxY, int16_t boxW, int16_t boxH, uint16_t bg);
  static const char *resultName(JpegResult r);
};
