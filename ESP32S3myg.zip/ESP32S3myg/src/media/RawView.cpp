#include "RawView.h"

#include <Arduino.h>
#include <esp_heap_caps.h>

namespace RawView {

void header(uint8_t *out, uint16_t w, uint16_t h, size_t capLen) {
  out[0] = 'M'; out[1] = '5'; out[2] = '6'; out[3] = '5';
  out[4] = w & 0xFF; out[5] = w >> 8;
  out[6] = h & 0xFF; out[7] = h >> 8;
  out[8] = capLen & 0xFF; out[9] = (capLen >> 8) & 0xFF;
  out[10] = out[11] = 0;
}

bool draw(SdStorage &sd, DisplayManager &d, const char *path, int16_t boxX, int16_t boxY,
          int16_t boxW, int16_t boxH, uint16_t bg, char *caption, size_t capCap) {
  if (caption && capCap) caption[0] = '\0';
  if (!sd.mounted() || !SdStorage::safePath(path) || boxW <= 0 || boxH <= 0 || boxW > MAX_W) return false;
  File f = sd.fs().open(path, FILE_READ);
  if (!f || f.isDirectory()) return false;
  uint8_t h[HEADER];
  bool ok = f.read(h, HEADER) == HEADER && memcmp(h, "M565", 4) == 0;
  const uint16_t w = h[4] | (h[5] << 8), ht = h[6] | (h[7] << 8);
  const size_t capLen = h[8] | (h[9] << 8);
  ok = ok && w > 0 && ht > 0 && w <= MAX_W && ht <= MAX_H && capLen <= MAX_CAPTION &&
       f.size() == fileSize(w, ht, capLen);  // 大小不符 = 檔案不完整
  if (!ok) {
    f.close();
    return false;
  }
  static uint8_t cap[MAX_CAPTION + 1];
  if (f.read(cap, capLen) != capLen) {
    f.close();
    return false;
  }
  cap[capLen] = 0;
  if (caption && capCap) strlcpy(caption, (const char *)cap, capCap);

  // 整張讀進 PSRAM (最大 240x180x2 = 86 KB)；經內部 RAM 小緩衝 (DMA 安全)
  const size_t bytes = (size_t)w * ht * 2;
  uint16_t *src = (uint16_t *)heap_caps_malloc(bytes, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!src) {
    f.close();
    return false;
  }
  alignas(16) static uint16_t rows[MAX_W * 16];
  size_t got = 0;
  while (got < bytes) {
    const size_t n = min(sizeof(rows), bytes - got);
    if (f.read((uint8_t *)rows, n) != n) break;
    memcpy((uint8_t *)src + got, rows, n);
    got += n;
  }
  f.close();
  if (got != bytes) {
    free(src);
    sd.markError();
    return false;
  }

  // 「填滿」方框：等比例放大到蓋滿方框，超出的部分置中裁掉 (已是方框大小時就是原圖)
  // 放大倍率 = max(boxW / w, boxH / h)，用 16.16 定點數算來源座標 (最近鄰)
  uint32_t dispW, dispH;
  if ((uint32_t)boxW * ht >= (uint32_t)boxH * w) {  // 方框比較寬 → 寬度對齊
    dispW = boxW;
    dispH = ((uint32_t)ht * boxW + w - 1) / w;
  } else {  // 方框比較高 → 高度對齊
    dispH = boxH;
    dispW = ((uint32_t)w * boxH + ht - 1) / ht;
  }
  if (dispW < (uint32_t)boxW) dispW = boxW;
  if (dispH < (uint32_t)boxH) dispH = boxH;
  const uint32_t ox = (dispW - boxW) / 2, oy = (dispH - boxH) / 2;
  const uint32_t stepX = ((uint32_t)w << 16) / dispW, stepY = ((uint32_t)ht << 16) / dispH;

  for (int16_t y0 = 0; y0 < boxH; y0 += 16) {
    const int16_t n = min<int16_t>(16, boxH - y0);
    for (int16_t r = 0; r < n; r++) {
      uint32_t sy = ((uint32_t)(y0 + r + oy) * stepY) >> 16;
      if (sy >= ht) sy = ht - 1;
      const uint16_t *srow = src + sy * w;
      uint16_t *drow = rows + r * boxW;
      uint32_t fx = ox * stepX;
      for (int16_t x = 0; x < boxW; x++, fx += stepX) {
        uint32_t sx = fx >> 16;
        if (sx >= w) sx = w - 1;
        drow[x] = srow[sx];
      }
    }
    d.pushRgb(boxX, boxY + y0, rows, boxW, n);
  }
  (void)bg;
  free(src);
  return true;
}
}  // namespace RawView
