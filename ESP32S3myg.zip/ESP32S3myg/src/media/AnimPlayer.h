#pragma once
#include <stdint.h>

#include "../display/DisplayManager.h"
#include "../storage/SdStorage.h"

// 逐格動畫：一個資料夾內放 000.jpg、001.jpg …，可選 anim.json {"fps": 8}
// 每次 update() 最多解碼一格，直接從 SD 讀取，不整段載入記憶體。
// (GIF 不直接播放：之後的下載流程會先轉成這種逐格 JPEG 格式)
class AnimPlayer {
 public:
  static constexpr uint16_t MAX_FRAMES = 300;

  // 回傳 false = 第 0 格讀不到 (不是有效的動畫資料夾)
  bool open(SdStorage &sd, DisplayManager &d, const char *dir, int16_t x, int16_t y, int16_t w,
            int16_t h, uint16_t bg, uint32_t now);
  void update(uint32_t now);
  void stop() { active_ = false; }
  bool active() const { return active_; }
  bool failed() const { return failed_; }

 private:
  bool drawFrame(uint16_t idx);

  SdStorage *sd_ = nullptr;
  DisplayManager *disp_ = nullptr;
  char dir_[SdStorage::MAX_PATH] = {0};
  int16_t x_ = 0, y_ = 0, w_ = 0, h_ = 0;
  uint16_t bg_ = 0;
  uint16_t frame_ = 0;
  uint16_t frameCount_ = 0;  // 0 = 尚未得知
  uint16_t frameMs_ = 125;
  uint32_t next_ = 0;
  bool active_ = false;
  bool failed_ = false;
};
