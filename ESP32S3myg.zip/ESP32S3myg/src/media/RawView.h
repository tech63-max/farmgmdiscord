#pragma once
#include <stddef.h>
#include <stdint.h>

#include "../display/DisplayManager.h"
#include "../storage/SdStorage.h"

// 裝置自己的圖檔格式 (.565)：下載時已縮成螢幕大小，播放時不用解碼，直接逐列從 SD 推到螢幕。
//   [0..3]  "M565"
//   [4..5]  寬 (uint16 LE)，[6..7] 高
//   [8..9]  說明文字長度 capLen (UTF-8，最多 300 bytes)，[10..11] 保留 0
//   [12..]  說明文字，接著 w*h 個 RGB565 (LE)
namespace RawView {
constexpr uint16_t MAX_W = 240, MAX_H = 180;  // 新下載的圖存 240x180 (4:3)；舊的 240x135 顯示時放大裁切
constexpr size_t MAX_CAPTION = 300;
constexpr size_t HEADER = 12;

inline size_t fileSize(uint16_t w, uint16_t h, size_t capLen) { return HEADER + capLen + (size_t)w * h * 2; }

// 等比例放大蓋滿方框、置中裁切 (最近鄰)。成功回傳 true；caption 有給就把說明文字複製進去
bool draw(SdStorage &sd, DisplayManager &d, const char *path, int16_t boxX, int16_t boxY,
          int16_t boxW, int16_t boxH, uint16_t bg, char *caption, size_t capCap);
// 組出檔頭 (out 至少 HEADER bytes)
void header(uint8_t *out, uint16_t w, uint16_t h, size_t capLen);
}  // namespace RawView
