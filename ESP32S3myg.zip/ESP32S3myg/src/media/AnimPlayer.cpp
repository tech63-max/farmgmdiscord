#include "AnimPlayer.h"

#include <Arduino.h>
#include <cJSON.h>

#include "JpegView.h"

bool AnimPlayer::open(SdStorage &sd, DisplayManager &d, const char *dir, int16_t x, int16_t y,
                      int16_t w, int16_t h, uint16_t bg, uint32_t now) {
  active_ = false;
  failed_ = false;
  if (!SdStorage::safePath(dir) || strlen(dir) + 10 >= sizeof(dir_)) return false;
  sd_ = &sd;
  disp_ = &d;
  strlcpy(dir_, dir, sizeof(dir_));
  x_ = x; y_ = y; w_ = w; h_ = h; bg_ = bg;
  frame_ = 0;
  frameCount_ = 0;
  frameMs_ = 125;

  char path[SdStorage::MAX_PATH + 16];
  snprintf(path, sizeof(path), "%s/anim.json", dir_);
  size_t len = 0;
  char *json = sd.readAll(path, 2048, &len);
  if (json != nullptr) {
    cJSON *root = cJSON_Parse(json);
    const cJSON *fps = cJSON_GetObjectItemCaseSensitive(root, "fps");
    if (cJSON_IsNumber(fps) && fps->valueint >= 1 && fps->valueint <= 15)
      frameMs_ = (uint16_t)(1000 / fps->valueint);
    cJSON_Delete(root);
    free(json);
  }
  if (!drawFrame(0)) {
    failed_ = true;
    return false;
  }
  active_ = true;
  next_ = now + frameMs_;
  return true;
}

bool AnimPlayer::drawFrame(uint16_t idx) {
  char path[SdStorage::MAX_PATH + 16];
  snprintf(path, sizeof(path), "%s/%03u.jpg", dir_, idx);
  return JpegView::draw(*sd_, *disp_, path, x_, y_, w_, h_, bg_) == JpegResult::Ok;
}

void AnimPlayer::update(uint32_t now) {
  if (!active_ || (int32_t)(now - next_) < 0) return;
  next_ = now + frameMs_;
  uint16_t nextIdx = frame_ + 1;
  bool atEnd = nextIdx >= MAX_FRAMES || (frameCount_ != 0 && nextIdx >= frameCount_);
  if (!atEnd && frameCount_ == 0) {  // 還不知道總格數：檢查下一格是否存在
    char path[SdStorage::MAX_PATH + 16];
    snprintf(path, sizeof(path), "%s/%03u.jpg", dir_, nextIdx);
    if (!sd_->exists(path)) {
      frameCount_ = nextIdx;
      atEnd = true;
      Serial.printf("[Anim] %s: %u frames, %u ms/frame\n", dir_, frameCount_, frameMs_);
    }
  }
  if (atEnd) {
    if (frame_ == 0) return;  // 只有一格：靜止顯示
    nextIdx = 0;              // 播到底 → 從頭循環
  }
  if (!drawFrame(nextIdx)) {  // 檔案在但讀不出來：卡被拔掉或檔案損壞
    active_ = false;
    failed_ = true;
    sd_->markError();
    return;
  }
  frame_ = nextIdx;
}
