#include "JpegView.h"

#include <Arduino.h>
#include <esp_heap_caps.h>
#include <rom/tjpgd.h>

namespace {
constexpr size_t WORK_BYTES = 4096;  // TJpgDec 工作區 (此 ROM 版本至少需要約 3100 bytes)
constexpr int16_t STRIP_H = 16;      // 一個 MCU 列最高 16 px

struct Session {
  File *file;
  DisplayManager *disp;
  uint16_t *strip;     // 一整個 MCU 列 (寬 = 縮放後圖寬，最多 240)
  int16_t outX, outY;  // 圖片左上角在螢幕上的位置
  int16_t imgW;        // 縮放後寬
  int16_t stripTop;    // 目前列緩衝對應的圖片 y
  int16_t stripRows;   // 目前列緩衝的高度
};

UINT inFunc(JDEC *jd, BYTE *buf, UINT len) {
  Session *s = (Session *)jd->device;
  if (buf == nullptr) {  // 略過 len bytes
    const size_t pos = s->file->position();
    return s->file->seek(pos + len) ? len : 0;
  }
  return (UINT)s->file->read(buf, len);
}

void flushStrip(Session *s) {
  if (s->stripRows <= 0) return;
  s->disp->pushRgb(s->outX, s->outY + s->stripTop, s->strip, s->imgW, s->stripRows);
  s->stripRows = 0;
}

UINT outFunc(JDEC *jd, void *bitmap, JRECT *rect) {
  Session *s = (Session *)jd->device;
  const BYTE *rgb = (const BYTE *)bitmap;  // ROM 版輸出 RGB888
  const int16_t w = rect->right - rect->left + 1;
  const int16_t h = rect->bottom - rect->top + 1;
  if (rect->top != s->stripTop) {  // 換到下一個 MCU 列：先送出上一列
    flushStrip(s);
    s->stripTop = rect->top;
  }
  if (h > STRIP_H) return 0;
  for (int16_t y = 0; y < h; y++) {
    uint16_t *dst = s->strip + y * s->imgW + rect->left;
    for (int16_t x = 0; x < w; x++, rgb += 3) {
      if (rect->left + x >= s->imgW) continue;
      dst[x] = (uint16_t)(((rgb[0] & 0xF8) << 8) | ((rgb[1] & 0xFC) << 3) | (rgb[2] >> 3));
    }
  }
  if (h > s->stripRows) s->stripRows = h;
  if (rect->right + 1 >= s->imgW) flushStrip(s);  // 這一列的最後一塊
  return 1;
}
}  // namespace

const char *JpegView::resultName(JpegResult r) {
  switch (r) {
    case JpegResult::Ok: return "ok";
    case JpegResult::OpenFail: return "open failed";
    case JpegResult::NotJpeg: return "not a JPEG";
    case JpegResult::TooBig: return "too big";
    case JpegResult::DecodeFail: return "decode failed";
    case JpegResult::NoMemory: return "no memory";
  }
  return "?";
}

JpegResult JpegView::draw(SdStorage &sd, DisplayManager &d, const char *path, int16_t boxX,
                          int16_t boxY, int16_t boxW, int16_t boxH, uint16_t bg) {
  if (!sd.mounted() || !SdStorage::safePath(path)) return JpegResult::OpenFail;
  File f = sd.fs().open(path, FILE_READ);
  if (!f || f.isDirectory()) return JpegResult::OpenFail;  // 是否算 SD 錯誤由呼叫端判斷
  if (f.size() < 4 || f.size() > MAX_FILE_BYTES) {
    f.close();
    return JpegResult::TooBig;
  }
  uint8_t magic[3] = {0};
  if (f.read(magic, 3) != 3 || magic[0] != 0xFF || magic[1] != 0xD8 || magic[2] != 0xFF) {
    f.close();
    return JpegResult::NotJpeg;
  }
  f.seek(0);

  alignas(4) static uint8_t work[WORK_BYTES];  // 內部 RAM，ROM 解碼器存取較快
  uint16_t *strip = (uint16_t *)heap_caps_malloc((size_t)DisplayManager::WIDTH * STRIP_H * 2,
                                                 MALLOC_CAP_8BIT);
  if (strip == nullptr) {
    f.close();
    return JpegResult::NoMemory;
  }

  Session s{&f, &d, strip, 0, 0, 0, -1, 0};
  JDEC jd;
  JpegResult res = JpegResult::Ok;
  if (jd_prepare(&jd, inFunc, work, WORK_BYTES, &s) != JDR_OK) {
    res = JpegResult::DecodeFail;  // 也包含 progressive JPEG (TJpgDec 不支援)
  } else if (jd.width > MAX_DIM || jd.height > MAX_DIM) {
    res = JpegResult::TooBig;
  } else {
    uint8_t scale = 0;
    while (scale <= 3 && ((int32_t)(jd.width >> scale) > boxW || (int32_t)(jd.height >> scale) > boxH))
      scale++;
    if (scale > 3) {
      res = JpegResult::TooBig;
    } else {
      const int16_t iw = (int16_t)((jd.width + (1u << scale) - 1) >> scale);
      const int16_t ih = (int16_t)((jd.height + (1u << scale) - 1) >> scale);
      s.imgW = min<int16_t>(iw, boxW);
      s.outX = boxX + (boxW - s.imgW) / 2;
      s.outY = boxY + (boxH - min<int16_t>(ih, boxH)) / 2;
      // 先填四周留白
      d.fillRect(boxX, boxY, boxW, s.outY - boxY, bg);
      d.fillRect(boxX, s.outY + ih, boxW, boxY + boxH - (s.outY + ih), bg);
      d.fillRect(boxX, s.outY, s.outX - boxX, ih, bg);
      d.fillRect(s.outX + s.imgW, s.outY, boxX + boxW - (s.outX + s.imgW), ih, bg);
      const JRESULT jr = jd_decomp(&jd, outFunc, scale);
      flushStrip(&s);
      if (jr != JDR_OK) res = JpegResult::DecodeFail;
    }
  }
  free(strip);
  f.close();
  if (res == JpegResult::DecodeFail) Serial.printf("[JPEG] decode failed: %s\n", path);
  return res;
}
