#include "WebPanel.h"

#include <DNSServer.h>
#include <ESPmDNS.h>
#include <WebServer.h>
#include <WiFi.h>
#include <stdarg.h>

namespace {
WebServer server(80);
DNSServer dns;
bool captive = false;
WebPanel::SaveWifi saveCb;
WebPanel::Status statusCb;

char chunk[768];
void sendf(const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(chunk, sizeof(chunk), fmt, ap);
  va_end(ap);
  server.sendContent(chunk);
}

// HTML 跳脫 (防 XSS)
void escapeHtml(const char *in, char *out, size_t cap) {
  size_t o = 0;
  for (; *in && o + 7 < cap; in++) {
    const char *rep = nullptr;
    switch (*in) {
      case '&': rep = "&amp;"; break;
      case '<': rep = "&lt;"; break;
      case '>': rep = "&gt;"; break;
      case '"': rep = "&quot;"; break;
      case '\'': rep = "&#39;"; break;
      default: break;
    }
    if (rep) {
      while (*rep) out[o++] = *rep++;
    } else {
      out[o++] = *in;
    }
  }
  out[o] = '\0';
}

void securityHeaders() {
  server.sendHeader("Cache-Control", "no-store");
  server.sendHeader("X-Content-Type-Options", "nosniff");
  server.sendHeader("X-Frame-Options", "DENY");
  server.sendHeader("Referrer-Policy", "no-referrer");
  server.sendHeader("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; form-action 'self'");
}

// 請求是不是從板子的設定熱點進來的 (只有這種才允許改 Wi-Fi)
bool fromSetupAp() {
  if (!captive) return false;
  const IPAddress ap = WiFi.softAPIP();
  const IPAddress remote = server.client().remoteIP();
  return remote[0] == ap[0] && remote[1] == ap[1] && remote[2] == ap[2];
}

const char PAGE_HEAD[] =
    "<!doctype html><html lang=zh-Hant><meta charset=utf-8>"
    "<meta name=viewport content='width=device-width,initial-scale=1'><meta name=theme-color content=#1d2740>"
    "<style>"
    ":root{--bg:#1d2740;--card:#27334f;--line:#34416a;--in:#1a2238;--txt:#f7f1e3;--dim:#8c98ba;--acc:#8ce6d2;--gold:#ffd678;--red:#ff9aa8}"
    "*{box-sizing:border-box}"
    "body{font-family:-apple-system,'PingFang TC','Noto Sans TC',sans-serif;background:var(--bg);color:var(--txt);"
    "margin:0 auto;padding:18px 14px 40px;max-width:540px;line-height:1.45}"
    "h1{font-size:22px;margin:2px 0 4px}h1 span{color:var(--acc)}"
    ".sub{color:var(--dim);font-size:13px;margin:0 0 14px}"
    ".card{background:var(--card);border-radius:18px;padding:4px 16px 8px;margin:0 0 14px}"
    ".card h2{font-size:15px;color:var(--gold);margin:12px 0 2px}"
    ".row{display:flex;flex-direction:column;gap:6px;padding:11px 0;border-top:1px solid var(--line)}"
    ".card h2+.row{border-top:0}pre{white-space:pre-wrap;margin:0;font:inherit}"
    "input,select{font:inherit;font-size:16px;padding:8px 10px;border-radius:10px;border:1px solid var(--line);"
    "background:var(--in);color:var(--txt);width:100%}"
    "button{font:inherit;font-size:16px;font-weight:bold;border:0;border-radius:12px;padding:12px 16px;"
    "background:var(--acc);color:#1d2740;width:100%}small{color:var(--dim);font-size:13px}a{color:var(--gold)}"
    "</style>";

void beginPage(int code) {
  securityHeaders();
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(code, "text/html; charset=utf-8", "");
  server.sendContent(PAGE_HEAD);
}

void redirectToSetup() {
  server.sendHeader("Location", String("http://") + WiFi.softAPIP().toString() + "/wifi");
  server.send(302, "text/plain", "");
}

const char *const PROBE_PATHS[] = {"/hotspot-detect.html", "/library/test/success.html",
                                   "/generate_204", "/gen_204", "/connecttest.txt",
                                   "/ncsi.txt", "/redirect", "/fwlink", "/canonical.html"};

void handleRoot() {
  if (fromSetupAp() && !WiFi.isConnected()) return redirectToSetup();
  static char status[600];
  static char esc[1200];
  status[0] = '\0';
  if (statusCb) statusCb(status, sizeof(status));
  escapeHtml(status, esc, sizeof(esc));
  beginPage(200);
  server.sendContent("<title>MemeBall</title><h1>🔮 <span>梗圖發射器</span></h1>"
                     "<p class=sub>素材更新請在裝置上按鍵操作（檢查更新 → 確認後立即下載）</p>"
                     "<div class=card><h2>狀態</h2><div class=row><pre>");
  server.sendContent(esc);
  server.sendContent("</pre></div></div>");
  if (fromSetupAp()) server.sendContent("<p><a href='/wifi'>📶 Wi-Fi 設定</a></p>");
  else server.sendContent("<p><small>要更改 Wi-Fi：在裝置上長按右鍵 → 「Wi-Fi 連線」開啟設定熱點，用手機連上後設定。</small></p>");
  server.sendContent("</html>");
  server.sendContent("");
}

void handleWifiPage() {
  if (!fromSetupAp()) {
    server.send(403, "text/plain; charset=utf-8", "Wi-Fi settings are only available on the setup hotspot.");
    return;
  }
  if (server.hasArg("rescan")) WiFi.scanNetworks(true);
  beginPage(200);
  server.sendContent("<title>MemeBall Wi-Fi</title><h1>📶 <span>Wi-Fi 設定</span></h1>"
                     "<p class=sub>讓梗圖發射器連上你的網路（只支援 2.4GHz）</p>"
                     "<form method=post action=/wifi><div class=card><h2>選擇網路</h2>");
  const int n = WiFi.scanComplete();
  if (n > 0) {
    server.sendContent("<label class=row><span>附近的 Wi-Fi</span><select name=pick><option value=''>（自己輸入 ↓）</option>");
    char esc[200];
    for (int i = 0; i < n && i < 20; i++) {
      const String ssid = WiFi.SSID(i);
      if (ssid.length() == 0 || ssid.length() > 32) continue;
      escapeHtml(ssid.c_str(), esc, sizeof(esc));
      sendf("<option value=\"%s\">%s（%d dBm）</option>", esc, esc, (int)WiFi.RSSI(i));
    }
    server.sendContent("</select></label>");
  } else {
    if (n == WIFI_SCAN_FAILED) WiFi.scanNetworks(true);
    server.sendContent("<div class=row><small>正在掃描附近的 Wi-Fi…</small><a href='/wifi'>重新整理</a></div>");
  }
  server.sendContent(
      "<label class=row><span>或自己輸入名稱</span><input type=text name=ssid maxlength=32 autocomplete=off></label>"
      "<label class=row><span>密碼 <small>開放網路請留空</small></span>"
      "<input type=password name=pass maxlength=63 autocomplete=off></label>"
      "<div class=row><button type=submit>連線</button></div></div></form>"
      "<p><a href='/wifi?rescan=1'>🔄 重新掃描</a></p></html>");
  server.sendContent("");
}

void handleWifiSave() {
  if (!fromSetupAp()) {
    server.send(403, "text/plain; charset=utf-8", "Forbidden");
    return;
  }
  String ssid = server.arg("pick");
  if (ssid.length() == 0) ssid = server.arg("ssid");
  const String pass = server.arg("pass");
  char esc[200];
  if (ssid.length() == 0 || ssid.length() > 32 || pass.length() > 63 ||
      (pass.length() > 0 && pass.length() < 8)) {
    beginPage(400);
    server.sendContent("<title>MemeBall</title><div class=card><h2>⚠️ 沒有儲存</h2>"
                       "<div class=row>名稱需 1~32 字元，密碼需 8~63 字元（開放網路請留空）</div>"
                       "<div class=row><a href='/wifi'>← 返回</a></div></div></html>");
    server.sendContent("");
    return;
  }
  escapeHtml(ssid.c_str(), esc, sizeof(esc));
  beginPage(200);
  sendf("<title>MemeBall</title><div class=card><h2>⏳ 正在連線到「%s」…</h2>"
        "<div class=row>請看裝置螢幕上的 Wi-Fi 狀態。連上後這個設定熱點約 20 秒後關閉。</div></div></html>", esc);
  server.sendContent("");
  if (saveCb) saveCb(ssid.c_str(), pass.c_str());
}
}  // namespace

void WebPanel::begin(SaveWifi onSave, Status status) {
  if (started_) return;
  saveCb = onSave;
  statusCb = status;
  server.on("/", HTTP_GET, handleRoot);
  server.on("/wifi", HTTP_GET, handleWifiPage);
  server.on("/wifi", HTTP_POST, handleWifiSave);
  for (const char *p : PROBE_PATHS) {
    server.on(p, []() {
      if (captive) redirectToSetup();
      else server.send(404, "text/plain", "Not found");
    });
  }
  server.onNotFound([]() {
    if (captive) redirectToSetup();
    else server.send(404, "text/plain", "Not found");
  });
  server.begin();
  if (MDNS.begin("memeball")) MDNS.addService("http", "tcp", 80);
  started_ = true;
  Serial.println("[Web] started (http://memeball.local/)");
}

void WebPanel::setCaptive(bool on) {
  if (on == captive) return;
  captive = on;
  if (on) {
    dns.setErrorReplyCode(DNSReplyCode::NoError);
    dns.start(53, "*", WiFi.softAPIP());
    WiFi.scanNetworks(true);
  } else {
    dns.stop();
  }
}

void WebPanel::update() {
  if (!started_) return;
  if (captive) dns.processNextRequest();
  server.handleClient();
}
