#pragma once
#include <stddef.h>
#include <stdint.h>

// HTTPS GET 到 PSRAM 緩衝。用 ESP-IDF 內建 CA 憑證包驗證伺服器 (不接受未驗證的連線)。
// 只允許 https://；回應超過 maxBytes 直接放棄 (限制單一素材大小)。
namespace Http {
struct Result {
  int status = 0;       // HTTP 狀態碼 (0 = 連線 / TLS 失敗)
  uint8_t *data = nullptr;  // PSRAM，呼叫端 free()；結尾多補一個 '\0'
  size_t len = 0;
  bool tooBig = false;
  bool cancelled = false;
};

Result get(const char *url, size_t maxBytes, volatile bool *cancel = nullptr);
// 把 UTF-8 路徑做百分比編碼 (保留 '/')，給 URL 使用
bool encodePath(const char *in, char *out, size_t cap);
}  // namespace Http
