#include "Http.h"

#include <Arduino.h>
#include <esp_crt_bundle.h>
#include <esp_heap_caps.h>
#include <esp_http_client.h>

namespace Http {

Result get(const char *url, size_t maxBytes, volatile bool *cancel) {
  Result r;
  if (url == nullptr || strncmp(url, "https://", 8) != 0) return r;

  esp_http_client_config_t cfg = {};
  cfg.url = url;
  cfg.crt_bundle_attach = esp_crt_bundle_attach;  // 驗證伺服器憑證
  cfg.timeout_ms = 15000;
  cfg.user_agent = "MemeBall-ESP32/0.3";
  cfg.buffer_size = 4096;
  cfg.max_redirection_count = 3;
  esp_http_client_handle_t client = esp_http_client_init(&cfg);
  if (!client) return r;

  if (esp_http_client_open(client, 0) == ESP_OK) {
    const int64_t clen = esp_http_client_fetch_headers(client);
    r.status = esp_http_client_get_status_code(client);
    if (r.status == 200) {
      if (clen > 0 && (uint64_t)clen > maxBytes) {
        r.tooBig = true;
      } else {
        size_t cap = clen > 0 ? (size_t)clen : 256 * 1024;
        r.data = (uint8_t *)heap_caps_malloc(cap + 1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
        // 先收到內部 RAM 小緩衝再複製到 PSRAM (避免 DMA / cache 對齊問題)
        static uint8_t net[2048];
        while (r.data != nullptr) {
          if (cancel && *cancel) {
            r.cancelled = true;
            break;
          }
          const int n = esp_http_client_read(client, (char *)net, sizeof(net));
          if (n <= 0) break;
          if (r.len + n > maxBytes) {
            r.tooBig = true;
            break;
          }
          if (r.len + n > cap) {  // 沒有 Content-Length：逐步擴大
            size_t ncap = cap * 2;
            if (ncap > maxBytes) ncap = maxBytes;
            uint8_t *p = (uint8_t *)heap_caps_realloc(r.data, ncap + 1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
            if (!p) break;
            r.data = p;
            cap = ncap;
          }
          memcpy(r.data + r.len, net, n);
          r.len += n;
        }
        // 長度不符 (中途斷線) 視為失敗
        if (r.data && clen > 0 && (int64_t)r.len != clen) r.status = -1;
        if (r.data) r.data[r.len] = 0;
      }
    }
  }
  esp_http_client_close(client);
  esp_http_client_cleanup(client);
  if (r.status != 200 || r.tooBig || r.cancelled) {
    free(r.data);
    r.data = nullptr;
    r.len = 0;
  }
  return r;
}

bool encodePath(const char *in, char *out, size_t cap) {
  static const char HEX_DIGITS[] = "0123456789ABCDEF";
  size_t o = 0;
  for (const uint8_t *p = (const uint8_t *)in; *p; p++) {
    const uint8_t c = *p;
    const bool keep = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
                      c == '-' || c == '_' || c == '.' || c == '~' || c == '/';
    if (keep) {
      if (o + 1 >= cap) return false;
      out[o++] = (char)c;
    } else {
      if (o + 3 >= cap) return false;
      out[o++] = '%';
      out[o++] = HEX_DIGITS[c >> 4];
      out[o++] = HEX_DIGITS[c & 15];
    }
  }
  out[o] = '\0';
  return true;
}
}  // namespace Http
