#pragma once
#include <stdint.h>

#include "../display/DisplayManager.h"
#include "Mood.h"

// 程式繪製的像素風寵物 (不需要圖檔)：
// 主畫面閒晃 (眨眼 / 左右看 / 偶爾跳)、各分類的反應動畫、召喚水晶球動畫。
// 每次呼叫畫完整的一格到 PixelCanvas (120x84 邏輯像素)。
class PetRenderer {
 public:
  void reset(uint32_t now);  // 動畫時間歸零 (換畫面時呼叫)
  void drawIdle(PixelCanvas &c, uint32_t now);
  void drawReaction(PixelCanvas &c, Mood mood, uint32_t now);
  void drawSummon(PixelCanvas &c, uint32_t now);  // 約 2.6 秒一輪，之後持續發光

 private:
  enum class Eyes : uint8_t { Open, Closed, Happy, Sad, Wide, Dizzy };
  enum class Mouth : uint8_t { Smile, Open, Flat, Wavy };

  void room(PixelCanvas &c, uint16_t wall, uint16_t floor);
  void shadow(PixelCanvas &c, int16_t cx, int16_t lift);
  void body(PixelCanvas &c, int16_t cx, int16_t cy, Eyes eyes, Mouth mouth, int8_t look,
            bool squash = false);
  void eye(PixelCanvas &c, int16_t ex, int16_t ey, Eyes eyes, bool left);
  void crystalBall(PixelCanvas &c, int16_t cx, int16_t cy, uint32_t t);

  uint32_t t0_ = 0;
  // 閒晃狀態
  uint32_t nextBlink_ = 0, blinkUntil_ = 0;
  uint32_t nextLook_ = 0, lookUntil_ = 0;
  uint32_t nextHop_ = 0, hopStart_ = 0;
  int8_t look_ = 0;
};
