#include "PetRenderer.h"

#include <Arduino.h>
#include <esp_random.h>
#include <math.h>

#include "../display/Theme.h"

namespace {
constexpr int16_t FLOOR_Y = 70;  // 地板上緣 (邏輯座標)
constexpr int16_t BODY_RX = 13, BODY_RY = 11;
constexpr int16_t PET_CY = FLOOR_Y - BODY_RY - 2;

constexpr uint16_t BODY = rgb565(255, 208, 150);
constexpr uint16_t OUTLINE = rgb565(96, 62, 54);
constexpr uint16_t BLUSH = rgb565(255, 140, 150);
constexpr uint16_t EYE = rgb565(44, 30, 44);
constexpr uint16_t WHITE = rgb565(255, 255, 255);
constexpr uint16_t MOUTH = rgb565(200, 70, 80);
constexpr uint16_t SHADOW = rgb565(24, 30, 48);
constexpr uint16_t WALL = rgb565(46, 60, 94);
constexpr uint16_t FLOOR = rgb565(78, 70, 104);
constexpr uint16_t FLOOR_LINE = rgb565(110, 100, 140);
constexpr uint16_t GREY = rgb565(150, 156, 170);
constexpr uint16_t DARK_GREY = rgb565(70, 74, 86);
constexpr uint16_t BLUE = rgb565(110, 180, 255);
constexpr uint16_t GOLD = rgb565(255, 210, 90);
constexpr uint16_t PURPLE = rgb565(120, 50, 140);
constexpr uint16_t BROWN = rgb565(140, 90, 50);
constexpr uint16_t BROWN_LT = rgb565(190, 130, 80);
constexpr uint16_t CYAN = rgb565(140, 240, 255);
constexpr uint16_t PINK = rgb565(255, 150, 220);

const char *const QMARK[] = {".###.", "#...#", "...#.", "..#..", ".....", "..#.."};
const char *const ZZ[] = {"###", "..#", ".#.", "#..", "###"};
const char *const NOTE[] = {"..##", "..#.", "..#.", "###.", "###."};
const char *const LETTER_H[] = {"#.#", "#.#", "###", "#.#", "#.#"};
const char *const LETTER_A[] = {".#.", "#.#", "###", "#.#", "#.#"};
const char *const STAR[] = {".#.", "###", ".#."};

uint32_t rnd(uint32_t lo, uint32_t hi) { return lo + esp_random() % (hi - lo + 1); }

// 三角波：0 → 1 → 0，週期 period
float tri(uint32_t t, uint32_t period) {
  const float p = (float)(t % period) / period;
  return p < 0.5f ? p * 2 : 2 - p * 2;
}

void ear(PixelCanvas &c, int16_t tipX, int16_t tipY) {
  for (int16_t r = 0; r < 4; r++) {
    c.hline(tipX - r, tipY + r, 1 + 2 * r, OUTLINE);
    if (r > 0) c.hline(tipX - r + 1, tipY + r, 2 * r - 1, BODY);
  }
}
}  // namespace

void PetRenderer::reset(uint32_t now) {
  t0_ = now;
  nextBlink_ = now + rnd(1500, 4000);
  nextLook_ = now + rnd(3000, 6000);
  nextHop_ = now + rnd(6000, 12000);
  blinkUntil_ = lookUntil_ = hopStart_ = 0;
  look_ = 0;
}

void PetRenderer::room(PixelCanvas &c, uint16_t wall, uint16_t floor) {
  c.fill(wall);
  c.fillRect(0, FLOOR_Y, PixelCanvas::LW, PixelCanvas::LH - FLOOR_Y, floor);
  c.hline(0, FLOOR_Y, PixelCanvas::LW, FLOOR_LINE);
}

void PetRenderer::shadow(PixelCanvas &c, int16_t cx, int16_t lift) {
  const int16_t rx = max<int16_t>(4, 11 - lift / 2);
  c.fillEllipse(cx, FLOOR_Y + 2, rx, 2, SHADOW);
}

void PetRenderer::eye(PixelCanvas &c, int16_t ex, int16_t ey, Eyes eyes, bool left) {
  switch (eyes) {
    case Eyes::Open:
      c.fillRect(ex, ey - 1, 2, 3, EYE);
      c.pset(ex, ey - 1, WHITE);
      break;
    case Eyes::Closed:
      c.hline(ex - 1, ey + 1, 3, EYE);
      break;
    case Eyes::Happy:  // ^
      c.pset(ex - 1, ey + 1, EYE);
      c.pset(ex, ey, EYE);
      c.pset(ex + 1, ey + 1, EYE);
      break;
    case Eyes::Sad:  // 下垂
      c.pset(ex - 1, left ? ey : ey + 1, EYE);
      c.pset(ex, ey + 1, EYE);
      c.pset(ex + 1, left ? ey + 1 : ey, EYE);
      break;
    case Eyes::Wide:
      c.fillRect(ex - 1, ey - 2, 3, 4, EYE);
      c.pset(ex - 1, ey - 2, WHITE);
      break;
    case Eyes::Dizzy:  // x
      c.pset(ex - 1, ey - 1, EYE); c.pset(ex + 1, ey - 1, EYE);
      c.pset(ex, ey, EYE);
      c.pset(ex - 1, ey + 1, EYE); c.pset(ex + 1, ey + 1, EYE);
      break;
  }
}

void PetRenderer::body(PixelCanvas &c, int16_t cx, int16_t cy, Eyes eyes, Mouth mouth,
                       int8_t look, bool squash) {
  const int16_t rx = squash ? 16 : BODY_RX;
  const int16_t ry = squash ? 7 : BODY_RY;
  if (squash) cy += BODY_RY - ry;  // 底部貼齊地板
  ear(c, cx - 7, cy - ry - 3);
  ear(c, cx + 7, cy - ry - 3);
  if (!squash) {  // 腳
    c.fillEllipse(cx - 6, cy + ry, 3, 2, OUTLINE);
    c.fillEllipse(cx + 6, cy + ry, 3, 2, OUTLINE);
  }
  c.fillEllipse(cx, cy, rx + 1, ry + 1, OUTLINE);
  c.fillEllipse(cx, cy, rx, ry, BODY);
  const int16_t ey = cy - (squash ? 1 : 2);
  eye(c, cx - 5 + look, ey, eyes, true);
  eye(c, cx + 4 + look, ey, eyes, false);
  c.hline(cx - 10, cy + 2, 3, BLUSH);
  c.hline(cx + 8, cy + 2, 3, BLUSH);
  const int16_t mx = cx + look / 2, my = cy + 3;
  switch (mouth) {
    case Mouth::Smile:
      c.pset(mx - 1, my, EYE); c.pset(mx, my + 1, EYE); c.pset(mx + 1, my, EYE);
      break;
    case Mouth::Open:
      c.fillRect(mx - 1, my, 3, 2, MOUTH);
      break;
    case Mouth::Flat:
      c.hline(mx - 1, my + 1, 3, EYE);
      break;
    case Mouth::Wavy:
      for (int16_t i = -2; i <= 2; i++) c.pset(mx + i, my + ((i & 1) ? 0 : 1), EYE);
      break;
  }
}

// ------------------------------------------------------------
void PetRenderer::drawIdle(PixelCanvas &c, uint32_t now) {
  if ((int32_t)(now - nextBlink_) >= 0) {
    blinkUntil_ = now + 130;
    nextBlink_ = now + rnd(2500, 6000);
  }
  if ((int32_t)(now - nextLook_) >= 0) {
    static const int8_t LOOKS[] = {-2, 2, -2, 2, 0};
    look_ = LOOKS[esp_random() % 5];
    lookUntil_ = now + rnd(1200, 2200);
    nextLook_ = now + rnd(4000, 9000);
  }
  if (lookUntil_ && (int32_t)(now - lookUntil_) >= 0) {
    look_ = 0;
    lookUntil_ = 0;
  }
  if ((int32_t)(now - nextHop_) >= 0) {
    hopStart_ = now;
    nextHop_ = now + rnd(7000, 15000);
  }
  int16_t lift = 0;
  if (hopStart_ && now - hopStart_ < 500) lift = (int16_t)(sinf(PI * (now - hopStart_) / 500.0f) * 7);
  const bool blink = (int32_t)(now - blinkUntil_) < 0;

  room(c, WALL, FLOOR);
  shadow(c, 60, lift);
  body(c, 60, PET_CY - lift, blink ? Eyes::Closed : Eyes::Open, lift ? Mouth::Open : Mouth::Smile, look_);
}

void PetRenderer::drawReaction(PixelCanvas &c, Mood mood, uint32_t now) {
  const uint32_t t = now - t0_;
  int16_t cx = 60, cy = PET_CY, lift = 0;
  switch (mood) {
    case Mood::Mic: {  // 拿麥克風、開心跳躍 (音符只是畫面，不出聲)
      room(c, WALL, FLOOR);
      lift = (int16_t)(fabsf(sinf(PI * (t % 700) / 700.0f)) * 6);
      cy -= lift;
      for (int i = 0; i < 2; i++) {
        const uint32_t p = (t / 45 + i * 17) % 34;
        c.glyph(NOTE, 5, 26 + i * 52 + (int16_t)(sinf(p * 0.4f) * 2), 40 - (int16_t)p, i ? PINK : CYAN);
      }
      shadow(c, cx, lift);
      body(c, cx, cy, Eyes::Happy, Mouth::Open, 0);
      c.line(cx + 11, cy + 5, cx + 15, cy - 1, DARK_GREY);  // 麥克風桿
      c.fillCircle(cx + 16, cy - 3, 3, GREY);
      c.pset(cx + 15, cy - 4, WHITE);
      break;
    }
    case Mood::Broke: {  // 空錢包、冒汗、蛾飛出來
      room(c, rgb565(52, 52, 72), FLOOR);
      if ((t / 900) % 3 == 0) cx += ((t / 70) % 2) ? 1 : -1;  // 偶爾發抖
      shadow(c, cx, 0);
      body(c, cx, cy, (t / 1200) % 2 ? Eyes::Dizzy : Eyes::Wide, Mouth::Wavy, 0);
      const int16_t dy = (int16_t)((t / 60) % 12);  // 汗滴
      c.pset(cx + 13, cy - 9 + dy / 3, BLUE);
      c.fillRect(cx + 12, cy - 8 + dy / 3, 3, 2, BLUE);
      c.fillRect(cx - 7, cy + 5, 14, 7, OUTLINE);  // 打開的錢包
      c.fillRect(cx - 6, cy + 6, 12, 5, BROWN);
      c.fillRect(cx - 5, cy + 6, 10, 2, rgb565(40, 26, 20));  // 空空的內袋
      c.fillRect(cx - 7, cy + 2, 14, 3, BROWN_LT);           // 翻開的蓋子
      for (int i = 0; i < 2; i++) {                            // 飛走的蛾
        const uint32_t p = (t / 40 + i * 20) % 40;
        const int16_t mx = cx - 4 + i * 8 + (int16_t)(sinf(p * 0.5f + i) * 4);
        const int16_t my = cy + 3 - (int16_t)p;
        c.pset(mx - 1, my, WHITE); c.pset(mx + 1, my, WHITE); c.pset(mx, my + 1, GREY);
      }
      break;
    }
    case Mood::Confused: {  // 左右走動、頭上問號
      room(c, WALL, FLOOR);
      const uint32_t period = 3200;
      cx = 34 + (int16_t)(tri(t, period) * 52);
      const int8_t look = (t % period) < period / 2 ? 2 : -2;
      lift = ((t / 160) % 2) ? 1 : 0;
      shadow(c, cx, lift);
      body(c, cx, cy - lift, Eyes::Open, Mouth::Flat, look);
      if ((t / 400) % 4 != 3) c.glyph(QMARK, 6, cx - 2, cy - BODY_RY - 12, GOLD);
      break;
    }
    case Mood::Rain: {  // 沉默、下雨、情緒低落 (無聲)
      room(c, rgb565(40, 46, 64), rgb565(58, 58, 80));
      const int16_t bob = (int16_t)((t / 900) % 2);
      shadow(c, cx, 0);
      body(c, cx, cy + bob, Eyes::Sad, Mouth::Flat, 0);
      if ((t / 1500) % 2) c.pset(cx - 6, cy + 1 + (int16_t)((t / 200) % 4), BLUE);  // 淚
      for (int i = 0; i < 9; i++) {  // 雨滴
        const int16_t x = cx - 18 + i * 4 + (i % 2);
        const int16_t y = 22 + (int16_t)((t / 22 + i * 13) % 46);
        if (y < FLOOR_Y - 2) c.vline(x, y, 3, BLUE);
      }
      c.fillCircle(cx - 9, 15, 6, GREY);  // 烏雲
      c.fillCircle(cx, 12, 8, GREY);
      c.fillCircle(cx + 9, 15, 6, GREY);
      c.fillRect(cx - 15, 15, 30, 6, GREY);
      c.hline(cx - 14, 21, 28, DARK_GREY);
      break;
    }
    case Mood::Lazy: {  // 趴睡 ↔ 假裝認真 (節能模式)
      room(c, WALL, FLOOR);
      shadow(c, cx, 0);
      if ((t / 3500) % 2 == 0) {
        body(c, cx, cy, Eyes::Closed, Mouth::Flat, 0, true);
        for (int k = 0; k < 3; k++) {
          const int16_t rise = (int16_t)((t / 180 + k * 4) % 12);
          c.glyph(ZZ, 5, cx + 14 + k * 5, cy - 6 - k * 5 - rise / 2, rgb565(200, 210, 240));
        }
      } else {
        body(c, cx, cy, Eyes::Open, Mouth::Flat, (t / 600) % 2 ? 1 : -1);
        c.fillRect(cx - 9, cy + 3, 18, 8, DARK_GREY);  // 筆電螢幕 (背面)
        c.fillRect(cx - 8, cy + 4, 16, 6, rgb565(60, 90, 120));
        c.hline(cx - 6, cy + 6, 4 + (int16_t)((t / 150) % 8), CYAN);
        c.fillRect(cx - 11, cy + 11, 22, 2, GREY);  // 鍵盤
      }
      break;
    }
    case Mood::Mask: {  // 假面舞會、閃光
      room(c, rgb565(54, 26, 46), rgb565(70, 40, 60));
      cx += (int16_t)(sinf(t / 400.0f) * 2);
      shadow(c, cx, 0);
      body(c, cx, cy, Eyes::Open, Mouth::Smile, 0);
      c.fillRect(cx - 10, cy - 5, 20, 5, PURPLE);  // 半臉面具
      c.hline(cx - 10, cy - 6, 20, GOLD);
      c.hline(cx - 9, cy, 18, GOLD);
      c.fillRect(cx - 6, cy - 4, 3, 3, BODY);  // 眼洞
      c.fillRect(cx + 3, cy - 4, 3, 3, BODY);
      c.fillRect(cx - 5, cy - 3, 2, 2, EYE);
      c.fillRect(cx + 4, cy - 3, 2, 2, EYE);
      static const int8_t SP[][2] = {{-26, -14}, {24, -18}, {-18, 6}, {28, 2}};
      for (int i = 0; i < 4; i++)
        if ((t / 220 + i) % 4 == 0) c.glyph(STAR, 3, cx + SP[i][0], cy + SP[i][1], GOLD);
      break;
    }
    case Mood::Laugh:
    default: {  // 笑到發抖、噴淚
      room(c, WALL, FLOOR);
      cx += ((t / 60) % 2) ? 1 : -1;
      lift = (int16_t)((t / 240) % 2) * 2;
      shadow(c, cx, lift);
      body(c, cx, cy - lift, Eyes::Happy, Mouth::Open, 0);
      const int16_t td = (int16_t)((t / 70) % 5);
      c.pset(cx - 11 - td / 2, cy - 2 + td, BLUE);
      c.pset(cx + 11 + td / 2, cy - 2 + td, BLUE);
      if ((t / 300) % 2) {
        c.glyph(LETTER_H, 5, cx + 14, cy - 18, GOLD);
        c.glyph(LETTER_A, 5, cx + 18, cy - 18, GOLD);
      }
      break;
    }
  }
}

// ------------------------------------------------------------
void PetRenderer::crystalBall(PixelCanvas &c, int16_t cx, int16_t cy, uint32_t t) {
  const bool pulse = (t / 150) % 2;
  if (t > 600) {  // 外圈光暈
    c.circle(cx, cy, 19, pulse ? PINK : CYAN);
    c.circle(cx, cy, 20, pulse ? CYAN : PURPLE);
    if (t > 1600) c.circle(cx, cy, 22 + (int16_t)((t / 80) % 3), pulse ? GOLD : PINK);
  }
  // 底座
  for (int16_t r = 0; r < 5; r++) c.hline(cx - 6 - r, cy + 15 + r, 13 + 2 * r, r == 0 ? BROWN_LT : BROWN);
  // 球體
  c.fillCircle(cx, cy, 16, rgb565(60, 30, 110));
  c.fillCircle(cx, cy, 13, rgb565(84, 50, 150));
  // 旋轉的雙螺旋
  const float spin = t * 0.008f;
  for (int i = 0; i < 34; i++) {
    const float a = spin + i * 0.33f;
    const float r = i * 0.38f;
    c.pset(cx + (int16_t)(cosf(a) * r), cy + (int16_t)(sinf(a) * r * 0.85f), (i & 1) ? CYAN : PINK);
    c.pset(cx + (int16_t)(cosf(a + PI) * r), cy + (int16_t)(sinf(a + PI) * r * 0.85f), (i & 1) ? PINK : WHITE);
  }
  c.fillRect(cx - 9, cy - 10, 3, 2, WHITE);  // 反光
  c.pset(cx - 10, cy - 7, WHITE);
  if (t > 600) {  // 冒泡
    for (int i = 0; i < 6; i++) {
      const float p = (float)((t + i * 333) % 2000) / 2000.0f;
      const int16_t bx = cx + (int16_t)(sinf(p * 12.6f + i) * 5) + (i - 3) * 3;
      const int16_t by = cy - 17 - (int16_t)(p * 34);
      if (i % 2) c.circle(bx, by, 2, CYAN);
      else c.pset(bx, by, WHITE);
    }
  }
}

void PetRenderer::drawSummon(PixelCanvas &c, uint32_t now) {
  const uint32_t t = now - t0_;
  room(c, rgb565(30, 22, 52), rgb565(52, 40, 80));
  static const int8_t STARS[][2] = {{8, 6}, {22, 18}, {40, 4}, {58, 12}, {104, 8}, {114, 26},
                                    {12, 34}, {70, 3}, {96, 40}, {30, 48}, {86, 20}, {50, 30}};
  for (int i = 0; i < 12; i++)
    if ((t / 180 + i * 3) % 7 != 0) c.pset(STARS[i][0], STARS[i][1], (i % 3) ? rgb565(200, 170, 90) : WHITE);

  // 水晶球從地板升起 → 漂浮
  const int16_t ballX = 82;
  int16_t ballY;
  if (t < 600) ballY = 96 - (int16_t)(52 * t / 600);
  else ballY = 44 + (int16_t)(sinf(t / 300.0f) * 1.5f);
  crystalBall(c, ballX, ballY, t);

  // 寵物：看向水晶球，興奮地小跳
  const int16_t lift = t > 600 ? (int16_t)(fabsf(sinf(PI * (t % 400) / 400.0f)) * 3) : 0;
  shadow(c, 36, lift);
  body(c, 36, PET_CY - lift, Eyes::Wide, t > 1500 ? Mouth::Open : Mouth::Smile, 2);
}
