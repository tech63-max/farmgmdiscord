#pragma once
#include <stdint.h>

// 寵物反應 (對應梗分類的 mood 欄位)
enum class Mood : uint8_t {
  Idle,      // 主畫面閒晃
  Mic,       // MyGO 經典梗：拿麥克風、開心跳躍
  Broke,     // 祥子梗：空錢包、財務危機
  Confused,  // 迷子梗：左右走動、頭上問號
  Rain,      // 春日影梗：沉默、下雨、低落
  Lazy,      // 上班摸魚：趴睡 / 假裝認真
  Mask,      // Ave Mujica：假面、閃光
  Laugh,     // 一般搞笑：笑到發抖
  Random,    // 每次隨機選一種
};

constexpr uint8_t MOOD_REACTION_FIRST = (uint8_t)Mood::Mic;
constexpr uint8_t MOOD_REACTION_LAST = (uint8_t)Mood::Laugh;
