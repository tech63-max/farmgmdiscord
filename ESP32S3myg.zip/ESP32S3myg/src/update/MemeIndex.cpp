#include "MemeIndex.h"

#include <Arduino.h>
#include <cJSON.h>
#include <esp_heap_caps.h>

namespace {
constexpr size_t MAX_INDEX_BYTES = 8 * 1024 * 1024;
const char *const STATE_NAMES[] = {"pending", "approved", "rejected", "duplicate"};

char *psDup(const char *s) {
  if (!s) return nullptr;
  const size_t n = strlen(s);
  char *p = (char *)heap_caps_malloc(n + 1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (p) memcpy(p, s, n + 1);
  return p;
}

// 授權字串種類很少：共用同一份，避免每筆都複製
const char *internLicense(const char *s) {
  static char *pool[8] = {nullptr};
  if (!s) return "unknown";
  for (char *p : pool)
    if (p && strcmp(p, s) == 0) return p;
  for (char *&p : pool)
    if (!p) return p = psDup(s);
  return "unknown";
}

// 可以一直往後接的 PSRAM 字串
struct Buf {
  char *p = nullptr;
  size_t len = 0, cap = 0;
  bool ok = true;
  void reserve(size_t n) {
    if (!ok || len + n + 1 <= cap) return;
    size_t nc = cap ? cap * 2 : 64 * 1024;
    while (nc < len + n + 1) nc *= 2;
    char *q = (char *)heap_caps_realloc(p, nc, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!q) { ok = false; return; }
    p = q;
    cap = nc;
  }
  void raw(const char *s) {
    const size_t n = strlen(s);
    reserve(n);
    if (!ok) return;
    memcpy(p + len, s, n + 1);
    len += n;
  }
  void str(const char *s) {  // JSON 字串 (含跳脫)
    raw("\"");
    for (const char *c = s ? s : ""; *c; c++) {
      char tmp[8];
      if (*c == '"' || *c == '\\') { tmp[0] = '\\'; tmp[1] = *c; tmp[2] = 0; }
      else if ((uint8_t)*c < 0x20) snprintf(tmp, sizeof(tmp), "\\u%04x", (uint8_t)*c);
      else { tmp[0] = *c; tmp[1] = 0; }
      raw(tmp);
    }
    raw("\"");
  }
  void kv(const char *k, const char *v, bool comma = true) {
    str(k); raw(":"); str(v); if (comma) raw(",");
  }
  void kn(const char *k, uint32_t v, bool comma = true) {
    char n[16];
    snprintf(n, sizeof(n), "%lu", (unsigned long)v);
    str(k); raw(":"); raw(n); if (comma) raw(",");
  }
};

void copyField(char *dst, size_t cap, const cJSON *o, const char *k) {
  const cJSON *v = cJSON_GetObjectItemCaseSensitive(o, k);
  strlcpy(dst, cJSON_IsString(v) ? v->valuestring : "", cap);
}
uint32_t numField(const cJSON *o, const char *k) {
  const cJSON *v = cJSON_GetObjectItemCaseSensitive(o, k);
  return cJSON_IsNumber(v) && v->valuedouble >= 0 ? (uint32_t)v->valuedouble : 0;
}
}  // namespace

void MemeIndex::idHex(uint64_t id, char out[17]) {
  snprintf(out, 17, "%08lx%08lx", (unsigned long)(id >> 32), (unsigned long)(id & 0xFFFFFFFF));
}

void MemeIndex::clear() {
  for (uint32_t i = 0; i < count_; i++) free(entries_[i].url);
  count_ = 0;
}

bool MemeIndex::load(SdStorage &sd) {
  if (!entries_) {
    entries_ = (IndexEntry *)heap_caps_calloc(MAX_ENTRIES, sizeof(IndexEntry), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!entries_) return false;
  }
  clear();
  loaded_ = false;
  updated_[0] = '\0';
  sd.recover(PATH);
  if (!sd.exists(PATH)) {
    loaded_ = true;
    return true;
  }
  size_t len = 0;
  char *raw = sd.readAll(PATH, MAX_INDEX_BYTES, &len);
  if (!raw) return false;
  cJSON *root = cJSON_Parse(raw);
  free(raw);
  const cJSON *items = cJSON_GetObjectItemCaseSensitive(root, "items");
  if (!cJSON_IsArray(items)) {
    cJSON_Delete(root);
    Serial.println("[Index] invalid meme_index.json (left untouched)");
    return false;
  }
  copyField(updated_, sizeof(updated_), root, "updated");
  version_ = numField(root, "version");
  const cJSON *it;
  cJSON_ArrayForEach(it, items) {
    char idhex[20];
    copyField(idhex, sizeof(idhex), it, "id");
    if (strlen(idhex) != 16) continue;
    IndexEntry *e = add();
    if (!e) break;
    e->id = strtoull(idhex, nullptr, 16);
    copyField(e->src, sizeof(e->src), it, "src");
    copyField(e->cat, sizeof(e->cat), it, "cat");
    char st[16];
    copyField(st, sizeof(st), it, "state");
    e->state = IndexEntry::Rejected;
    for (uint8_t s = 0; s < 4; s++)
      if (strcmp(st, STATE_NAMES[s]) == 0) e->state = (IndexEntry::State)s;
    copyField(e->sha, sizeof(e->sha), it, "sha");
    copyField(e->file, sizeof(e->file), it, "file");
    if (e->file[0] && !SdStorage::safePath(e->file)) e->file[0] = '\0';
    copyField(e->at, sizeof(e->at), it, "at");
    e->bytes = numField(it, "bytes");
    e->srcBytes = numField(it, "srcBytes");
    const cJSON *u = cJSON_GetObjectItemCaseSensitive(it, "url");
    e->url = psDup(cJSON_IsString(u) ? u->valuestring : "");
    const cJSON *l = cJSON_GetObjectItemCaseSensitive(it, "lic");
    e->lic = internLicense(cJSON_IsString(l) ? l->valuestring : nullptr);
  }
  cJSON_Delete(root);
  loaded_ = true;
  Serial.printf("[Index] %lu entries\n", (unsigned long)count_);
  return true;
}

bool MemeIndex::save(SdStorage &sd) {
  if (!loaded_) return false;
  Buf b;
  b.raw("{");
  b.kn("version", version_);
  b.kv("updated", updated_);
  b.raw("\"items\":[\n");
  for (uint32_t i = 0; i < count_; i++) {
    const IndexEntry &e = entries_[i];
    char idhex[17];
    idHex(e.id, idhex);
    b.raw("{");
    b.kv("id", idhex);
    b.kv("src", e.src);
    b.kv("cat", e.cat);
    b.kv("state", STATE_NAMES[e.state]);
    b.kv("file", e.file);
    b.kv("sha", e.sha);
    b.kn("bytes", e.bytes);
    b.kn("srcBytes", e.srcBytes);
    b.kv("url", e.url ? e.url : "");
    b.kv("lic", e.lic ? e.lic : "");
    b.kv("at", e.at, false);
    b.raw(i + 1 < count_ ? "},\n" : "}\n");
  }
  b.raw("]}\n");
  bool ok = b.ok && sd.writeAtomic(PATH, (const uint8_t *)b.p, b.len);
  free(b.p);
  if (ok) {  // 素材版本檔
    char v[96];
    snprintf(v, sizeof(v), "{\"version\":%lu,\"updated\":\"%s\",\"items\":%lu}\n", (unsigned long)version_,
             updated_, (unsigned long)count_);
    sd.writeAtomic(VERSION_PATH, (const uint8_t *)v, strlen(v));
  }
  return ok;
}

const IndexEntry *MemeIndex::find(uint64_t id) const {
  for (uint32_t i = 0; i < count_; i++)
    if (entries_[i].id == id) return &entries_[i];
  return nullptr;
}

bool MemeIndex::hasSha(const char *sha) const {
  for (uint32_t i = 0; i < count_; i++)
    if (entries_[i].sha[0] && strcmp(entries_[i].sha, sha) == 0) return true;
  return false;
}

IndexEntry *MemeIndex::add() {
  if (!entries_ || count_ >= MAX_ENTRIES) return nullptr;
  IndexEntry *e = &entries_[count_++];
  memset(e, 0, sizeof(*e));
  return e;
}

uint32_t MemeIndex::countState(IndexEntry::State s, const char *cat) const {
  uint32_t n = 0;
  for (uint32_t i = 0; i < count_; i++)
    if (entries_[i].state == s && (!cat || strcmp(entries_[i].cat, cat) == 0)) n++;
  return n;
}

void MemeIndex::setUpdated(const char *t) { strlcpy(updated_, t ? t : "", sizeof(updated_)); }

// 供 Updater 設定授權字串
const char *memeIndexInternLicense(const char *s) { return internLicense(s); }
