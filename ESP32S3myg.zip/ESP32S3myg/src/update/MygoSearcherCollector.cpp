#include "MygoSearcherCollector.h"

#include <Arduino.h>
#include <cJSON.h>
#include <esp_heap_caps.h>

#include "../net/Http.h"

namespace {
constexpr const char *LIST_URL =
    "https://8t8c0l3nfh.execute-api.ap-east-2.amazonaws.com/production/list-s3-objects-by-json";
constexpr const char *IMG_BASE = "https://s3.ap-east-2.amazonaws.com/mygo-ave-mujica.ronald890119.com/";
constexpr size_t MAX_LIST_BYTES = 2 * 1024 * 1024;
}  // namespace

const char *MygoSearcherCollector::classify(const char *folder, const char *caption) {
  if (strncmp(folder, "Ave Mujica", 10) == 0) return "avemujica";
  if (strncmp(folder, "MyGO", 4) != 0) return "";  // 不認得的資料夾 → 未分類
  if (strstr(caption, "春日影")) return "haruhikage";
  if (strstr(caption, "祥")) return "saki";  // 祥子 / 小祥
  if (strstr(caption, "迷")) return "maigo";
  return "classic";
}

bool MygoSearcherCollector::list(ItemSink &sink) {
  release();
  Http::Result r = Http::get(LIST_URL, MAX_LIST_BYTES);
  if (!r.data) {
    Serial.printf("[mygo] list http %d\n", r.status);
    return false;
  }
  root_ = cJSON_Parse((const char *)r.data);
  const size_t rawLen = r.len;
  free(r.data);
  if (!root_) return false;
  const cJSON *body = cJSON_GetObjectItemCaseSensitive(root_, "body");
  if (!cJSON_IsObject(body)) return false;
  // 字幕 = 檔名去掉資料夾與副檔名；一次配置足夠的空間存全部
  captions_ = (char *)heap_caps_malloc(rawLen + 1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!captions_) return false;
  size_t used = 0;
  static const char *const ARRAYS[] = {"mygo_keys", "ave_mujica_keys"};
  for (const char *name : ARRAYS) {
    const cJSON *arr = cJSON_GetObjectItemCaseSensitive(body, name);
    const cJSON *k;
    cJSON_ArrayForEach(k, arr) {
      if (!cJSON_IsString(k)) continue;
      const char *key = k->valuestring;
      const size_t klen = strlen(key);
      if (klen < 5 || klen > 200 || strcasecmp(key + klen - 4, ".png") != 0) continue;
      if (strstr(key, "..")) continue;
      const char *slash = strrchr(key, '/');
      const char *base = slash ? slash + 1 : key;
      const size_t clen = strlen(base) - 4;
      if (clen == 0 || used + clen + 1 > rawLen) continue;
      char *cap = captions_ + used;
      memcpy(cap, base, clen);
      cap[clen] = '\0';
      used += clen + 1;
      if (!sink.add(key, cap, classify(key, cap))) return true;
    }
  }
  return true;
}

bool MygoSearcherCollector::url(const RemoteItem &item, char *out, size_t cap) const {
  const size_t base = strlen(IMG_BASE);
  if (cap <= base) return false;
  memcpy(out, IMG_BASE, base);
  return Http::encodePath(item.key, out + base, cap - base);
}

void MygoSearcherCollector::release() {
  if (root_) cJSON_Delete(root_);
  root_ = nullptr;
  free(captions_);
  captions_ = nullptr;
}
