#pragma once
#include <stddef.h>
#include <stdint.h>

// 遠端素材的一筆資料 (字串指向 Collector 自己保管的記憶體，release() 前都有效)
struct RemoteItem {
  const char *key;      // 來源內的識別 (例如 S3 物件路徑)
  const char *caption;  // 標題 / 字幕 (UTF-8)
  char cat[16];         // 分類 id (對應 messages.json)；"" = 無法判斷 → 未分類
  uint64_t id;          // 全域唯一 id (來源名稱 + key 的雜湊)
  uint8_t src;          // 第幾個 Collector
};

class ItemSink {
 public:
  virtual bool add(const char *key, const char *caption, const char *cat) = 0;  // false = 滿了
  virtual ~ItemSink() = default;
};

// 一個素材來源。每個來源獨立實作，新增 / 移除來源只要改 Updater 的 COLLECTORS 清單。
// list() / url() 只在更新背景工作裡呼叫。
class Collector {
 public:
  virtual const char *id() const = 0;       // 寫進索引的來源名稱 (英數)
  virtual const char *license() const = 0;  // 授權說明 (寫進索引，核准畫面會顯示)
  virtual bool needsReview() const = 0;     // 授權不明 → 下載到待確認區，裝置上逐張核准
  virtual bool list(ItemSink &sink) = 0;    // 查詢清單 (不下載圖片)；false = 來源無法使用
  virtual bool url(const RemoteItem &item, char *out, size_t cap) const = 0;
  virtual uint32_t typicalBytes() const = 0;  // 預估單張下載大小 (沒有 Content-Length 時用)
  virtual void release() = 0;                 // 釋放 list() 的記憶體
  virtual ~Collector() = default;
};
