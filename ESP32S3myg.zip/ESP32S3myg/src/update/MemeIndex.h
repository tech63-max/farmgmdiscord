#pragma once
#include <stddef.h>
#include <stdint.h>

#include "../storage/SdStorage.h"

// SD:/index/meme_index.json：每一筆下載過 (或拒絕過) 的素材
//   {"version":1,"updated":"...","items":[{"id","src","cat","state","file","sha","bytes","srcBytes","url","lic","at"}]}
// state：pending (待核准) / approved / rejected (刪掉，不再下載) / duplicate (內容重複)
// 寫入一律用 SdStorage::writeAtomic (先寫 .tmp 再替換)
struct IndexEntry {
  enum State : uint8_t { Pending, Approved, Rejected, Duplicate };
  uint64_t id;
  char src[16];
  char cat[16];
  State state;
  char sha[65];
  uint32_t bytes;     // SD 上的大小
  uint32_t srcBytes;  // 下載大小
  char file[64];
  char at[20];
  char *url;          // PSRAM
  const char *lic;    // 指向 Collector 的常數字串，或 PSRAM
};

class MemeIndex {
 public:
  static constexpr const char *PATH = "/index/meme_index.json";
  static constexpr const char *VERSION_PATH = "/index/update_version.json";
  static constexpr uint32_t MAX_ENTRIES = 12000;

  bool load(SdStorage &sd);  // 檔案不存在 = 空索引 (回傳 true)；格式錯誤回傳 false 且不覆蓋
  bool save(SdStorage &sd);
  bool loaded() const { return loaded_; }
  uint32_t count() const { return count_; }
  IndexEntry &at(uint32_t i) { return entries_[i]; }
  const IndexEntry *find(uint64_t id) const;
  bool hasSha(const char *sha) const;
  IndexEntry *add();  // 新增一筆 (已清空)；滿了回傳 nullptr
  uint32_t countState(IndexEntry::State s, const char *cat = nullptr) const;
  const char *updated() const { return updated_; }
  void setUpdated(const char *t);
  uint32_t version() const { return version_; }
  void bumpVersion() { version_++; }

  static void idHex(uint64_t id, char out[17]);

 private:
  void clear();

  IndexEntry *entries_ = nullptr;
  uint32_t count_ = 0;
  bool loaded_ = false;
  char updated_[24] = "";
  uint32_t version_ = 0;
};
