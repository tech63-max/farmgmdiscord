#include "Updater.h"

#include <Arduino.h>
#include <WiFi.h>
#include <esp_heap_caps.h>
#include <esp_random.h>
#include <mbedtls/sha256.h>
#include <new>
#include <stdarg.h>
#include <time.h>

#include "../media/RawView.h"
#include "../net/Http.h"
#include "../third_party/PNGdec/PNGdec.h"
#include "MygoSearcherCollector.h"

const char *memeIndexInternLicense(const char *s);

namespace {
// ---- 素材來源清單：新增來源就在這裡加一個 Collector ----
MygoSearcherCollector mygoSearcher;
Collector *const COLLECTORS[] = {&mygoSearcher};
constexpr uint8_t COLLECTOR_COUNT = sizeof(COLLECTORS) / sizeof(COLLECTORS[0]);

constexpr const char *CACHE_DIR = "/system/download_cache";
constexpr const char *LOG_PATH = "/system/update_log.txt";
constexpr const char *PENDING_DIR = "/meme/_pending";
constexpr const char *UNSORTED = "unsorted";
constexpr uint32_t ITEM_GAP_MS = 300;  // 每張之間休息 (對來源客氣一點)
constexpr uint8_t MAX_CONSECUTIVE_FAIL = 5;
constexpr uint32_t FAIL_BACKOFF_MS = 5000;  // 失敗後多等一下再試下一張
constexpr uint32_t INDEX_SAVE_EVERY = 10;   // 每幾張存一次索引

uint64_t fnv64(const char *a, const char *b) {
  uint64_t h = 1469598103934665603ull;
  for (const char *s : {a, ":", b})
    for (; *s; s++) {
      h ^= (uint8_t)*s;
      h *= 1099511628211ull;
    }
  return h;
}

void nowString(char *out, size_t cap) {
  const time_t t = time(nullptr);
  if (t < 1700000000) {  // 還沒對時
    snprintf(out, cap, "未對時");
    return;
  }
  struct tm tmv;
  localtime_r(&t, &tmv);
  strftime(out, cap, "%Y-%m-%d %H:%M", &tmv);
}

// 在 UTF-8 字元邊界截斷
void utf8Copy(char *dst, size_t cap, const char *src) {
  size_t n = strlen(src);
  if (n >= cap) {
    n = cap - 1;
    while (n > 0 && ((uint8_t)src[n] & 0xC0) == 0x80) n--;
  }
  memcpy(dst, src, n);
  dst[n] = '\0';
}

// ---- PNG 解碼 + 縮圖 (逐列，不需要整張原圖的像素緩衝) ----
struct Scaler {
  PNG *png;
  uint16_t srcW, srcH, dstW, dstH;
  uint16_t cropX, cropY, cropW, cropH;  // 原圖中要保留的區域 (置中裁成 4:3)
  uint16_t *out;      // dstW*dstH (PSRAM)
  uint32_t acc[RawView::MAX_W][4];
  int curDy;
  uint16_t line[1920];

  void flush() {
    if (curDy < 0) return;
    for (uint16_t x = 0; x < dstW; x++) {
      uint32_t *a = acc[x];
      const uint32_t n = a[3] ? a[3] : 1;
      const uint32_t r = a[0] / n, g = a[1] / n, b = a[2] / n;
      out[curDy * dstW + x] = (uint16_t)((r << 11) | (g << 5) | b);
      a[0] = a[1] = a[2] = a[3] = 0;
    }
  }
};
Scaler *scaler = nullptr;
PNG *png = nullptr;

int pngLine(PNGDRAW *p) {
  Scaler &s = *(Scaler *)p->pUser;
  s.png->getLineAsRGB565(p, s.line, PNG_RGB565_LITTLE_ENDIAN, 0x00000000);
  if (p->y < s.cropY || p->y >= s.cropY + s.cropH) return 1;  // 裁掉的上下區域
  const int dy = (int)((uint32_t)(p->y - s.cropY) * s.dstH / s.cropH);
  if (dy != s.curDy) {
    s.flush();
    s.curDy = dy;
  }
  const uint16_t xEnd = min<int>(s.cropX + s.cropW, p->iWidth);
  for (uint16_t x = s.cropX; x < xEnd; x++) {
    const uint16_t c = s.line[x];
    uint32_t *a = s.acc[(uint32_t)(x - s.cropX) * s.dstW / s.cropW];
    a[0] += c >> 11;
    a[1] += (c >> 5) & 0x3F;
    a[2] += c & 0x1F;
    a[3]++;
  }
  return 1;
}

bool decodePng(uint8_t *data, size_t len, uint16_t *&out, uint16_t &w, uint16_t &h) {
  out = nullptr;
  if (!png) {
    void *mem = heap_caps_malloc(sizeof(PNG), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    void *smem = heap_caps_malloc(sizeof(Scaler), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!mem || !smem) {
      free(mem);
      free(smem);
      return false;
    }
    png = new (mem) PNG();
    scaler = (Scaler *)smem;
  }
  if (png->openRAM(data, (int)len, pngLine) != PNG_SUCCESS) return false;
  const int sw = png->getWidth(), sh = png->getHeight();
  if (sw <= 0 || sh <= 0 || sw > 1920 || sh > 4096) {
    png->close();
    return false;
  }
  // 置中裁成 4:3 (240x180) 再縮小：比 16:9 整張縮小在螢幕上大很多，左右各裁約 12%
  uint32_t cw, ch;
  if ((uint32_t)sw * RawView::MAX_H > (uint32_t)sh * RawView::MAX_W) {  // 比 4:3 寬 → 裁左右
    ch = sh;
    cw = (uint32_t)sh * RawView::MAX_W / RawView::MAX_H;
  } else {  // 比 4:3 高 → 裁上下
    cw = sw;
    ch = (uint32_t)sw * RawView::MAX_H / RawView::MAX_W;
  }
  // 原圖比 240x180 小就不放大 (縮圖濾波只能縮小)
  uint32_t dw = min<uint32_t>(RawView::MAX_W, cw);
  uint32_t dh = dw * RawView::MAX_H / RawView::MAX_W;
  if (dh > ch) {
    dh = ch;
    dw = dh * RawView::MAX_W / RawView::MAX_H;
  }
  if (dw == 0 || dh == 0 || cw == 0 || ch == 0) {
    png->close();
    return false;
  }
  Scaler &s = *scaler;
  memset(s.acc, 0, sizeof(s.acc));
  s.png = png;
  s.srcW = sw; s.srcH = sh; s.dstW = dw; s.dstH = dh;
  s.cropW = cw; s.cropH = ch;
  s.cropX = (sw - cw) / 2; s.cropY = (sh - ch) / 2;
  s.curDy = -1;
  s.out = (uint16_t *)heap_caps_malloc(dw * dh * 2, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!s.out) {
    png->close();
    return false;
  }
  const int rc = png->decode(&s, 0);
  png->close();
  if (rc != PNG_SUCCESS) {
    free(s.out);
    return false;
  }
  s.flush();
  out = s.out;
  w = dw;
  h = dh;
  return true;
}

void sha256Hex(const uint8_t *d, size_t n, char out[65]) {
  uint8_t h[32];
  mbedtls_sha256(d, n, h, 0);
  for (int i = 0; i < 32; i++) snprintf(out + i * 2, 3, "%02x", h[i]);
}
}  // namespace

// ============================================================
class UpdaterSink : public ItemSink {
 public:
  UpdaterSink(Updater &u, uint8_t src) : u_(u), src_(src) {}
  bool add(const char *key, const char *caption, const char *cat) override {
    if (u_.itemCount_ >= Updater::MAX_REMOTE) return false;
    RemoteItem &it = u_.items_[u_.itemCount_++];
    it.key = key;
    it.caption = caption;
    strlcpy(it.cat, cat && *cat ? cat : UNSORTED, sizeof(it.cat));
    it.src = src_;
    it.id = fnv64(COLLECTORS[src_]->id(), key);
    return true;
  }

 private:
  Updater &u_;
  uint8_t src_;
};

const char *Updater::collectorLicense(const char *srcId) {
  for (Collector *c : COLLECTORS)
    if (strcmp(c->id(), srcId) == 0) return c->license();
  return "unknown";
}

void Updater::begin(SdStorage &sd, MemeIndex &index) {
  sd_ = &sd;
  index_ = &index;
  lock_ = xSemaphoreCreateMutex();
  queue_ = xQueueCreate(2, sizeof(Cmd));
  items_ = (RemoteItem *)heap_caps_calloc(MAX_REMOTE, sizeof(RemoteItem), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  newIdx_ = (uint32_t *)heap_caps_calloc(MAX_REMOTE, sizeof(uint32_t), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  // 工作堆疊放內部 RAM (TLS 需要)；優先權低於主迴圈，跑在核心 0
  xTaskCreatePinnedToCore(taskMain, "updater", 16384, this, 1, &task_, 0);
}

bool Updater::requestCheck() {
  if (busy() || !queue_) return false;
  cancel_ = false;
  setPhase(Phase::Checking, "連線中…");
  const Cmd c = Cmd::Check;
  return xQueueSend(queue_, &c, 0) == pdTRUE;
}

uint32_t Updater::remaining(const char *cat) const {
  if (!checked_) return 0;
  if (!cat || !*cat) return newCount_ - newStart_;
  uint32_t n = 0;
  for (uint32_t k = newStart_; k < newCount_; k++)
    if (strcmp(items_[newIdx_[k]].cat, cat) == 0) n++;
  return n;
}

bool Updater::requestDownload(const char *cat, uint32_t count) {
  if (busy() || !queue_ || !checked_ || newStart_ >= newCount_) return false;
  if (count == 0) count = BATCH;
  if (count > MAX_COUNT) count = MAX_COUNT;
  if (remaining(cat) == 0) return false;
  strlcpy(dlCat_, cat ? cat : "", sizeof(dlCat_));
  dlCount_ = count;
  cancel_ = false;
  setPhase(Phase::Downloading, "準備下載…");
  const Cmd c = Cmd::Download;
  return xQueueSend(queue_, &c, 0) == pdTRUE;
}

Updater::Status Updater::status() {
  Status s;
  if (xSemaphoreTake(lock_, pdMS_TO_TICKS(20)) == pdTRUE) {
    s = st_;
    xSemaphoreGive(lock_);
  }
  s.phase = phase_;
  return s;
}

void Updater::setPhase(Phase p, const char *msg) {
  xSemaphoreTake(lock_, portMAX_DELAY);
  st_.phase = p;
  if (msg) strlcpy(st_.msg, msg, sizeof(st_.msg));
  xSemaphoreGive(lock_);
  phase_ = p;
}

void Updater::log(const char *fmt, ...) {
  char line[200];
  char t[24];
  nowString(t, sizeof(t));
  const int n = snprintf(line, sizeof(line), "[%s] ", t);
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(line + n, sizeof(line) - n - 2, fmt, ap);
  va_end(ap);
  strlcat(line, "\n", sizeof(line));
  Serial.print("[Update] ");
  Serial.print(line + n);
  if (!sd_->mounted()) return;
  File f = sd_->fs().open(LOG_PATH, FILE_APPEND);
  if (!f) return;
  if (f.size() > 256 * 1024) {  // 太大就從頭開始 (保留上一份)
    f.close();
    sd_->fs().remove("/system/update_log.old.txt");
    sd_->fs().rename(LOG_PATH, "/system/update_log.old.txt");
    f = sd_->fs().open(LOG_PATH, FILE_APPEND);
    if (!f) return;
  }
  f.write((const uint8_t *)line, strlen(line));  // < 1 磁區，從內部 RAM 寫
  f.close();
}

void Updater::cleanCache() {
  File d = sd_->fs().open(CACHE_DIR);
  if (!d || !d.isDirectory()) return;
  char paths[8][SdStorage::MAX_PATH];
  for (;;) {  // 刪除迭代中不安全：每次收集幾個再刪
    uint8_t n = 0;
    bool isDir = false;
    while (n < 8) {
      String name = d.getNextFileName(&isDir);
      if (!name.length()) break;
      if (!isDir) strlcpy(paths[n++], name.c_str(), sizeof(paths[0]));
    }
    d.close();
    for (uint8_t i = 0; i < n; i++) sd_->fs().remove(paths[i]);
    if (n < 8) return;
    d = sd_->fs().open(CACHE_DIR);
    if (!d) return;
  }
}

void Updater::taskMain(void *arg) {
  Updater &u = *(Updater *)arg;
  Cmd c;
  for (;;) {
    if (xQueueReceive(u.queue_, &c, portMAX_DELAY) != pdTRUE) continue;
    if (c == Cmd::Check) u.runCheck();
    else u.runDownload();
  }
}

// ------------------------------------------------------------
void Updater::runCheck() {
  checked_ = false;
  if (WiFi.status() != WL_CONNECTED) return setPhase(Phase::Error, "沒有 Wi-Fi，無法更新");
  if (!sd_->mounted()) return setPhase(Phase::Error, "沒有 SD 卡，無法更新");
  if (!index_->loaded() && !index_->load(*sd_)) return setPhase(Phase::Error, "素材索引損壞，未進行更新");
  if (!items_ || !newIdx_) return setPhase(Phase::Error, "記憶體不足");

  itemCount_ = 0;
  bool anyOk = false;
  for (uint8_t i = 0; i < COLLECTOR_COUNT; i++) {
    setPhase(Phase::Checking, "查詢素材來源…");
    UpdaterSink sink(*this, i);
    const uint32_t before = itemCount_;
    if (COLLECTORS[i]->list(sink)) {
      anyOk = true;
      log("check %s: %lu items", COLLECTORS[i]->id(), (unsigned long)(itemCount_ - before));
    } else {
      log("check %s: source unavailable", COLLECTORS[i]->id());
    }
    if (cancel_) return setPhase(Phase::Idle, "已取消");
  }
  if (!anyOk) return setPhase(Phase::Error, "素材來源無法使用，請稍後再試");

  // 比對索引：已下載 / 拒絕過 / 重複的都不算新的
  setPhase(Phase::Checking, "比對 SD 卡索引…");
  newCount_ = newStart_ = 0;
  for (uint32_t i = 0; i < itemCount_; i++) {
    if (!index_->find(items_[i].id)) newIdx_[newCount_++] = i;
    if ((i & 255) == 0) vTaskDelay(1);
  }
  // 打亂順序，讓每批都混到不同分類
  for (uint32_t i = newCount_; i > 1; i--) {
    const uint32_t j = esp_random() % i;
    const uint32_t t = newIdx_[i - 1];
    newIdx_[i - 1] = newIdx_[j];
    newIdx_[j] = t;
  }
  xSemaphoreTake(lock_, portMAX_DELAY);
  recount();
  xSemaphoreGive(lock_);
  checked_ = true;
  setPhase(Phase::CheckDone, newCount_ ? "有新素材" : "已經是最新");
  log("check done: %lu new", (unsigned long)newCount_);
}

void Updater::recount() {
  st_.catN = 0;
  for (uint32_t k = newStart_; k < newCount_; k++) {
    const RemoteItem &it = items_[newIdx_[k]];
    uint8_t c = 0;
    while (c < st_.catN && strcmp(st_.cats[c].cat, it.cat) != 0) c++;
    if (c == st_.catN) {
      if (st_.catN >= sizeof(st_.cats) / sizeof(st_.cats[0])) continue;
      strlcpy(st_.cats[c].cat, it.cat, sizeof(st_.cats[c].cat));
      st_.cats[c].n = 0;
      st_.catN++;
    }
    st_.cats[c].n++;
  }
  st_.newTotal = newCount_ - newStart_;
  st_.batch = min<uint32_t>(st_.newTotal, BATCH);
  st_.estDownload = (uint64_t)st_.batch * COLLECTORS[0]->typicalBytes();
  st_.estStore = (uint64_t)st_.batch * RawView::fileSize(RawView::MAX_W, RawView::MAX_H, 120);
}

void Updater::runDownload() {
  xSemaphoreTake(lock_, portMAX_DELAY);
  st_.done = st_.ok = st_.failed = st_.skipped = 0;
  st_.bytes = 0;
  st_.total = min<uint32_t>(remaining(dlCat_), dlCount_);
  st_.finishedAt[0] = '\0';
  xSemaphoreGive(lock_);

  if (WiFi.status() != WL_CONNECTED) return setPhase(Phase::Error, "沒有 Wi-Fi，無法下載");
  if (!sd_->mounted()) return setPhase(Phase::Error, "沒有 SD 卡，無法下載");
  if (sd_->freeBytes() < SD_RESERVE + 16ull * 1024 * 1024) return setPhase(Phase::Error, "SD 卡空間不足，未下載");
  cleanCache();  // 上次中斷留下的暫存檔
  sd_->fs().mkdir(PENDING_DIR);

  const uint32_t total = st_.total;
  uint8_t consecutiveFail = 0;
  const char *stopReason = nullptr;
  uint32_t scan = newStart_;  // 在剩下的清單裡找符合分類的下一張
  for (uint32_t k = 0; k < total; k++) {
    if (cancel_) { stopReason = "已取消（已下載的素材保留）"; break; }
    if (WiFi.status() != WL_CONNECTED) { stopReason = "Wi-Fi 斷線（已下載的素材保留）"; break; }
    if (sd_->freeBytes() < SD_RESERVE) { stopReason = "SD 卡空間不足，停止下載"; break; }
    if (st_.bytes >= MAX_SESSION_BYTES) { stopReason = "達到單次下載容量上限"; break; }
    if (scan < newStart_) scan = newStart_;
    while (scan < newCount_ && dlCat_[0] && strcmp(items_[newIdx_[scan]].cat, dlCat_) != 0) scan++;
    if (scan >= newCount_) break;
    // 把這張換到已處理區的最後面，newStart_ 往後推 (其他分類的留著下次下載)
    const uint32_t tmpIdx = newIdx_[scan];
    newIdx_[scan] = newIdx_[newStart_];
    newIdx_[newStart_] = tmpIdx;
    scan++;
    const RemoteItem &it = items_[tmpIdx];
    xSemaphoreTake(lock_, portMAX_DELAY);
    strlcpy(st_.curCat, it.cat, sizeof(st_.curCat));
    utf8Copy(st_.curCaption, sizeof(st_.curCaption), it.caption);
    xSemaphoreGive(lock_);
    setPhase(Phase::Downloading, nullptr);

    const bool ok = downloadOne(it, *COLLECTORS[it.src]);
    newStart_++;
    consecutiveFail = ok ? 0 : consecutiveFail + 1;
    xSemaphoreTake(lock_, portMAX_DELAY);
    st_.done++;
    st_.newTotal = newCount_ - newStart_;
    st_.batch = min<uint32_t>(st_.newTotal, BATCH);
    xSemaphoreGive(lock_);
    if (st_.done % INDEX_SAVE_EVERY == 0) index_->save(*sd_);  // 定期存索引：斷電最多損失幾筆紀錄
    if (consecutiveFail >= MAX_CONSECUTIVE_FAIL) { stopReason = "連續下載失敗，停止（已下載的素材保留）"; break; }
    vTaskDelay(pdMS_TO_TICKS(ok ? ITEM_GAP_MS : FAIL_BACKOFF_MS));
  }
  xSemaphoreTake(lock_, portMAX_DELAY);
  recount();
  xSemaphoreGive(lock_);
  char t[24];
  nowString(t, sizeof(t));
  index_->setUpdated(t);
  index_->bumpVersion();
  const bool saved = index_->save(*sd_);
  cleanCache();
  xSemaphoreTake(lock_, portMAX_DELAY);
  strlcpy(st_.finishedAt, t, sizeof(st_.finishedAt));
  xSemaphoreGive(lock_);
  log("download done: ok=%lu failed=%lu skipped=%lu bytes=%llu%s", (unsigned long)st_.ok,
      (unsigned long)st_.failed, (unsigned long)st_.skipped, st_.bytes, saved ? "" : " (index save FAILED)");
  setPhase(Phase::DownloadDone, stopReason ? stopReason : (saved ? "更新完成" : "索引寫入失敗"));
}

bool Updater::downloadOne(const RemoteItem &it, Collector &col) {
  char url[512];
  if (!col.url(it, url, sizeof(url))) {
    st_.failed++;
    return false;
  }
  Http::Result r = Http::get(url, MAX_ITEM_BYTES, &cancel_);
  if (!r.data) {
    if (r.cancelled) return true;
    log("fail http=%d%s %s", r.status, r.tooBig ? " (too big)" : "", it.key);
    st_.failed++;
    return false;
  }
  st_.bytes += r.len;
  // 檢查格式：看 PNG 檔頭，不看副檔名
  static const uint8_t PNG_SIG[8] = {0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A};
  if (r.len < 8 || memcmp(r.data, PNG_SIG, 8) != 0) {
    log("fail not PNG %s", it.key);
    free(r.data);
    st_.failed++;
    return false;
  }
  char sha[65];
  sha256Hex(r.data, r.len, sha);
  IndexEntry *e = nullptr;
  if (index_->hasSha(sha)) {  // 內容重複：記下來，以後不再下載
    free(r.data);
    e = index_->add();
    if (e) {
      e->id = it.id;
      strlcpy(e->src, col.id(), sizeof(e->src));
      strlcpy(e->cat, it.cat, sizeof(e->cat));
      e->state = IndexEntry::Duplicate;
      strlcpy(e->sha, sha, sizeof(e->sha));
      e->lic = memeIndexInternLicense(col.license());
    }
    st_.skipped++;
    return true;
  }
  uint16_t *px = nullptr;
  uint16_t w = 0, h = 0;
  const bool decoded = decodePng(r.data, r.len, px, w, h);
  const uint32_t srcBytes = r.len;
  free(r.data);
  if (!decoded) {
    log("fail decode %s", it.key);
    st_.failed++;
    return false;
  }

  // 暫存檔 → 檢查大小 → 改名到待確認區
  char idhex[17];
  MemeIndex::idHex(it.id, idhex);
  char tmp[SdStorage::MAX_PATH], dir[SdStorage::MAX_PATH], dst[SdStorage::MAX_PATH];
  snprintf(tmp, sizeof(tmp), "%s/%s.tmp", CACHE_DIR, idhex);
  snprintf(dir, sizeof(dir), "%s/%s", col.needsReview() ? PENDING_DIR : "/meme", it.cat);
  snprintf(dst, sizeof(dst), "%s/%s.565", dir, idhex);
  char caption[RawView::MAX_CAPTION + 1];
  utf8Copy(caption, sizeof(caption), it.caption);
  const size_t capLen = strlen(caption);
  const size_t fileLen = RawView::fileSize(w, h, capLen);

  bool ok = SdStorage::safePath(tmp) && SdStorage::safePath(dst);
  if (ok) {
    File f = sd_->fs().open(tmp, FILE_WRITE);
    ok = (bool)f;
    if (ok) {
      alignas(16) static uint8_t wbuf[4096];  // 經內部 RAM 寫 SD (DMA 安全)
      RawView::header(wbuf, w, h, capLen);
      memcpy(wbuf + RawView::HEADER, caption, capLen);
      ok = f.write(wbuf, RawView::HEADER + capLen) == RawView::HEADER + capLen;
      const uint8_t *src = (const uint8_t *)px;
      size_t left = (size_t)w * h * 2;
      while (ok && left) {
        const size_t n = min(left, sizeof(wbuf));
        memcpy(wbuf, src, n);
        ok = f.write(wbuf, n) == n;
        src += n;
        left -= n;
      }
      f.close();
    }
    if (ok) {
      File chk = sd_->fs().open(tmp, FILE_READ);
      ok = chk && chk.size() == fileLen;
      if (chk) chk.close();
    }
    if (ok) {
      if (!sd_->fs().exists(dir)) sd_->fs().mkdir(dir);
      if (sd_->fs().exists(dst)) sd_->fs().remove(dst);
      ok = sd_->fs().rename(tmp, dst);
    }
    if (!ok) sd_->fs().remove(tmp);
  }
  free(px);
  if (!ok) {
    log("fail write %s", dst);
    st_.failed++;
    return false;
  }
  e = index_->add();
  if (e) {
    e->id = it.id;
    strlcpy(e->src, col.id(), sizeof(e->src));
    strlcpy(e->cat, it.cat, sizeof(e->cat));
    e->state = col.needsReview() ? IndexEntry::Pending : IndexEntry::Approved;
    strlcpy(e->sha, sha, sizeof(e->sha));
    strlcpy(e->file, dst, sizeof(e->file));
    e->bytes = fileLen;
    e->srcBytes = srcBytes;
    const size_t ul = strlen(url);
    e->url = (char *)heap_caps_malloc(ul + 1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (e->url) memcpy(e->url, url, ul + 1);
    e->lic = memeIndexInternLicense(col.license());
    nowString(e->at, sizeof(e->at));
  }
  st_.ok++;
  return true;
}
