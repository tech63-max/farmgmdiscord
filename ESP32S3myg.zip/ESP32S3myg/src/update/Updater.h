#pragma once
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>
#include <freertos/task.h>
#include <stdint.h>

#include "../storage/SdStorage.h"
#include "Collector.h"
#include "MemeIndex.h"

// 手動素材更新 (只有使用者按鍵才會動作，沒有任何排程或背景自動下載)
//   requestCheck()    ：連網查詢各來源清單 → 跟 SD 索引比對 → 各分類新增數量 + 預估容量 (不下載圖片)
//   requestDownload() ：使用者確認後才下載；可指定分類與張數 (預設 BATCH 張，最多 MAX_COUNT)
// 在獨立的 FreeRTOS 工作裡執行，主迴圈 (動畫 / 按鍵) 不會被卡住。
// ⚠️ 工作執行期間 (busy()) 由 Updater 獨占 SD 卡，App 不可讀寫 SD。
class Updater {
 public:
  static constexpr uint8_t BATCH = 20;                        // 預設下載張數
  static constexpr uint32_t MAX_ITEM_BYTES = 3u * 1024 * 1024;  // 單一素材下載上限
  static constexpr uint32_t MAX_COUNT = 1000;                  // 單次最多張數
  static constexpr uint64_t MAX_SESSION_BYTES = 2000ull << 20;  // 單次下載總量上限 (約 1000 張原圖)
  static constexpr uint64_t SD_RESERVE = 256ull << 20;          // SD 至少保留的空間
  static constexpr uint32_t MAX_REMOTE = 16000;

  enum class Phase : uint8_t { Idle, Checking, CheckDone, Downloading, DownloadDone, Error };
  struct CatCount {
    char cat[16];
    uint32_t n;
  };
  struct Status {
    Phase phase = Phase::Idle;
    char msg[96] = "";
    // 檢查結果
    CatCount cats[18];
    uint8_t catN = 0;
    uint32_t newTotal = 0;   // 還沒下載的新素材
    uint32_t batch = 0;      // 下一次「立即下載」會抓幾張
    uint64_t estDownload = 0, estStore = 0;
    // 下載進度 / 結果
    char curCat[16] = "";
    char curCaption[128] = "";
    uint32_t done = 0, total = 0, ok = 0, failed = 0, skipped = 0;
    uint64_t bytes = 0;      // 實際下載容量
    char finishedAt[24] = "";
  };

  void begin(SdStorage &sd, MemeIndex &index);
  bool requestCheck();
  // cat = 只下載這個分類 (nullptr / "" = 全部)；count = 張數 (1..MAX_COUNT)
  bool requestDownload(const char *cat = nullptr, uint32_t count = BATCH);
  uint32_t remaining(const char *cat) const;  // 檢查結果中還沒下載的張數
  void cancel() { cancel_ = true; }
  bool busy() const { return phase_ == Phase::Checking || phase_ == Phase::Downloading; }
  bool hasCheckResult() const { return checked_; }
  Status status();  // 複製一份目前狀態給畫面用

  static const char *collectorLicense(const char *srcId);

 private:
  enum class Cmd : uint8_t { Check, Download };
  static void taskMain(void *arg);
  void runCheck();
  void runDownload();
  bool downloadOne(const RemoteItem &item, Collector &col);
  void setPhase(Phase p, const char *msg = nullptr);
  void log(const char *fmt, ...);
  void cleanCache();
  void recount();  // 依剩下的新素材重算各分類數量 (需持有 lock_)

  SdStorage *sd_ = nullptr;
  MemeIndex *index_ = nullptr;
  TaskHandle_t task_ = nullptr;
  QueueHandle_t queue_ = nullptr;
  SemaphoreHandle_t lock_ = nullptr;
  volatile Phase phase_ = Phase::Idle;
  volatile bool cancel_ = false;
  bool checked_ = false;
  Status st_;

  RemoteItem *items_ = nullptr;  // PSRAM
  uint32_t itemCount_ = 0;
  uint32_t *newIdx_ = nullptr;   // 還沒下載的項目 (已打亂順序)
  uint32_t newCount_ = 0;
  uint32_t newStart_ = 0;        // [0, newStart_) 已處理過
  char dlCat_[16] = "";          // 這次下載只抓這個分類 ("" = 全部)
  uint32_t dlCount_ = BATCH;

  friend class UpdaterSink;
};
