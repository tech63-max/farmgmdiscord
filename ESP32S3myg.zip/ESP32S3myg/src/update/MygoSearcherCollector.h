#pragma once
#include "Collector.h"

struct cJSON;

// MyGO / Ave Mujica 動畫截圖 (https://mygo-ave-mujica.ronald890119.com/ 使用的公開清單 API 與 S3)
// 截圖著作權屬原權利人；mygo-searcher 的 MIT 授權只涵蓋程式碼 → needsReview = true
// 分類依據 metadata：資料夾 (MyGO / Ave Mujica) + 檔名 (= 字幕) 關鍵字，不做影像辨識
class MygoSearcherCollector : public Collector {
 public:
  const char *id() const override { return "mygo-searcher"; }
  const char *license() const override {
    return "Anime screenshot; copyright belongs to rights holders. Listed by mygo-searcher (MIT covers code only). Personal non-commercial use.";
  }
  bool needsReview() const override { return true; }
  bool list(ItemSink &sink) override;
  bool url(const RemoteItem &item, char *out, size_t cap) const override;
  uint32_t typicalBytes() const override { return 650 * 1024; }
  void release() override;

  static const char *classify(const char *folder, const char *caption);

 private:
  cJSON *root_ = nullptr;
  char *captions_ = nullptr;  // 所有字幕字串 (PSRAM)
};
