#pragma once
#include <stdint.h>

// Waveshare ESP32-S3-LCD-1.54 (無觸控版) 腳位
// 來源：官方 repo waveshareteam/ESP32-S3-Touch-LCD-1.54
//   LCD / 按鍵 / 電源：ESP-IDF-5.5.1/01_factory (bsp_display.h / bsp_power_manager.c / main.c)
//   SD 卡：ESP-IDF-5.5.1/01_factory/components/esp_bsp/bsp_sdcard.h 與 Arduino 範例 07_sd_card_test
namespace Pins {
constexpr int8_t LCD_DC = 45;
constexpr int8_t LCD_CS = 21;
constexpr int8_t LCD_SCK = 38;
constexpr int8_t LCD_MOSI = 39;
constexpr int8_t LCD_RST = 40;
constexpr int8_t LCD_BL = 46;     // 背光 (PWM)

constexpr int8_t BTN_BOOT = 0;    // BOOT 鍵，按下為 LOW
constexpr int8_t BTN_PLUS = 4;    // PLUS 鍵，按下為 LOW
constexpr int8_t BTN_PWR = 5;     // PWR 鍵，按下為 LOW

constexpr int8_t POWER_LATCH = 2; // 電池供電時須保持 HIGH，拉 LOW = 關機

// 喇叭功放致能。本專案完全無聲：開機拉 LOW 後永遠不再拉 HIGH，也不初始化 I2S / ES8311 / 麥克風
constexpr int8_t AMP_CTRL = 7;

// microSD (SDMMC 4-bit)
constexpr int8_t SD_CLK = 16;
constexpr int8_t SD_CMD = 15;
constexpr int8_t SD_D0 = 17;
constexpr int8_t SD_D1 = 18;
constexpr int8_t SD_D2 = 13;
constexpr int8_t SD_D3 = 14;
}  // namespace Pins

constexpr uint32_t LCD_SPI_HZ = 40000000;
