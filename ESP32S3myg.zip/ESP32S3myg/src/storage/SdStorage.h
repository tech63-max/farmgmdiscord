#pragma once
#include <FS.h>
#include <stddef.h>
#include <stdint.h>

// microSD (SDMMC 4-bit) 存取。
// - 掛載失敗絕不自動格式化 (避免洗掉使用者的卡)
// - 讀取失敗時標記 error，之後由 App 在安全時機 (回主畫面) 嘗試重新掛載
// - writeAtomic()：先寫 .tmp，確認大小正確後才替換正式檔；斷電後 recover() 可還原
class SdStorage {
 public:
  static constexpr size_t MAX_PATH = 96;

  bool begin();          // 開機掛載 + 建立資料夾
  bool remount();        // 卡被拔掉 / 讀取錯誤後重新掛載
  bool mounted() const { return mounted_; }
  void markError() { error_ = true; }
  bool hasError() const { return error_; }
  fs::FS &fs();

  uint64_t totalBytes() const;
  uint64_t usedBytes() const;
  uint64_t freeBytes() const;
  const char *cardTypeName() const;

  bool exists(const char *path);
  // 整個檔案讀進 PSRAM (結尾補 '\0')；超過 maxSize 或讀取失敗回傳 nullptr。用 free() 釋放
  char *readAll(const char *path, size_t maxSize, size_t *outLen);
  bool writeAtomic(const char *path, const uint8_t *data, size_t len);
  void recover(const char *path);  // 處理上次中斷留下的 .tmp / .bak

  // 只允許 /英數_-. 組成的絕對路徑，不得有 ".." 或以 '.' 開頭的路徑段 (防路徑穿越)
  static bool safePath(const char *path);

 private:
  bool mountOnly();
  void ensureDirs();

  bool mounted_ = false;
  bool error_ = false;
};
