#include "SdStorage.h"

#include <Arduino.h>
#include <SD_MMC.h>
#include <esp_heap_caps.h>

#include "../config/BoardConfig.h"

namespace {
// 建議的素材資料夾 (依序建立，父資料夾在前)
const char *const DIRS[] = {
    "/meme", "/meme/mygo", "/meme/mygo/classic", "/meme/mygo/saki", "/meme/mygo/maigo",
    "/meme/mygo/haruhikage", "/meme/mygo/ave_mujica", "/meme/funny", "/meme/work",
    "/meme/reaction", "/meme/_pending",
    "/animation", "/animation/happy", "/animation/angry", "/animation/confused",
    "/animation/sleepy", "/animation/funny",
    "/fortune", "/index", "/system", "/system/download_cache",
};

// SD 讀寫一律經過這塊內部 RAM 緩衝 (DMA 可用、對齊)：
// 實測 FATFS 寫入整個磁區時會直接拿呼叫端的指標做 DMA，來源在 Flash (const 字串) 時
// 寫進卡裡的內容全是 0；PSRAM 也有 cache 對齊風險。目前只在主迴圈使用 (非執行緒安全)。
alignas(16) uint8_t ioBuf[2048];

void suffixed(char *out, size_t n, const char *path, const char *suffix) {
  snprintf(out, n, "%s%s", path, suffix);
}
}  // namespace

fs::FS &SdStorage::fs() { return SD_MMC; }

bool SdStorage::mountOnly() {
  if (!SD_MMC.setPins(Pins::SD_CLK, Pins::SD_CMD, Pins::SD_D0, Pins::SD_D1, Pins::SD_D2,
                      Pins::SD_D3)) {
    Serial.println("[SD] setPins failed");
    return false;
  }
  // 4-bit、不自動格式化、20 MHz (與官方範例相同的保守頻率)、最多同時開 5 個檔
  if (!SD_MMC.begin("/sdcard", false, false, SDMMC_FREQ_DEFAULT, 5)) {
    Serial.println("[SD] mount failed (no card / not FAT32?)");
    return false;
  }
  if (SD_MMC.cardType() == CARD_NONE) {
    SD_MMC.end();
    Serial.println("[SD] no card");
    return false;
  }
  return true;
}

bool SdStorage::begin() {
  mounted_ = mountOnly();
  error_ = false;
  if (mounted_) {
    ensureDirs();
    Serial.printf("[SD] %s, total %llu MB, free %llu MB\n", cardTypeName(),
                  totalBytes() >> 20, freeBytes() >> 20);
  }
  return mounted_;
}

bool SdStorage::remount() {
  if (mounted_) SD_MMC.end();
  mounted_ = false;
  return begin();
}

void SdStorage::ensureDirs() {
  for (const char *d : DIRS)
    if (!SD_MMC.exists(d) && !SD_MMC.mkdir(d)) Serial.printf("[SD] mkdir %s failed\n", d);
}

uint64_t SdStorage::totalBytes() const { return mounted_ ? SD_MMC.totalBytes() : 0; }
uint64_t SdStorage::usedBytes() const { return mounted_ ? SD_MMC.usedBytes() : 0; }
uint64_t SdStorage::freeBytes() const {
  const uint64_t t = totalBytes(), u = usedBytes();
  return t > u ? t - u : 0;
}

const char *SdStorage::cardTypeName() const {
  if (!mounted_) return "none";
  switch (SD_MMC.cardType()) {
    case CARD_MMC: return "MMC";
    case CARD_SD: return "SDSC";
    case CARD_SDHC: return "SDHC/SDXC";
    default: return "unknown";
  }
}

bool SdStorage::exists(const char *path) {
  return mounted_ && safePath(path) && SD_MMC.exists(path);
}

char *SdStorage::readAll(const char *path, size_t maxSize, size_t *outLen) {
  if (outLen) *outLen = 0;
  if (!mounted_ || !safePath(path)) return nullptr;
  File f = SD_MMC.open(path, FILE_READ);
  if (!f || f.isDirectory()) return nullptr;
  const size_t len = f.size();
  if (len == 0 || len > maxSize) {
    f.close();
    return nullptr;
  }
  char *buf = (char *)heap_caps_malloc(len + 1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (buf == nullptr) buf = (char *)malloc(len + 1);
  if (buf == nullptr) {
    f.close();
    return nullptr;
  }
  size_t got = 0;
  while (got < len) {
    const size_t want = min(sizeof(ioBuf), len - got);
    const size_t n = f.read(ioBuf, want);
    if (n == 0) break;
    memcpy(buf + got, ioBuf, n);
    got += n;
  }
  f.close();
  if (got != len) {
    free(buf);
    error_ = true;
    return nullptr;
  }
  buf[len] = '\0';
  if (outLen) *outLen = len;
  return buf;
}

bool SdStorage::writeAtomic(const char *path, const uint8_t *data, size_t len) {
  if (!mounted_ || !safePath(path) || data == nullptr) return false;
  char tmp[MAX_PATH + 8], bak[MAX_PATH + 8];
  suffixed(tmp, sizeof(tmp), path, ".tmp");
  suffixed(bak, sizeof(bak), path, ".bak");

  if (freeBytes() < (uint64_t)len + 64 * 1024) {
    Serial.printf("[SD] not enough space for %s\n", path);
    return false;
  }
  File f = SD_MMC.open(tmp, FILE_WRITE);
  if (!f) return false;
  size_t wrote = 0;
  while (wrote < len) {
    const size_t n = min(sizeof(ioBuf), len - wrote);
    memcpy(ioBuf, data + wrote, n);
    if (f.write(ioBuf, n) != n) break;
    wrote += n;
  }
  f.flush();
  f.close();
  // 重新開啟確認大小 (寫入中斷 / 卡滿時不替換正式檔)
  File chk = SD_MMC.open(tmp, FILE_READ);
  const size_t onDisk = chk ? chk.size() : 0;
  if (chk) chk.close();
  if (wrote != len || onDisk != len) {
    SD_MMC.remove(tmp);
    error_ = true;
    return false;
  }
  // FAT 的 rename 不會覆蓋既有檔案：正式檔 → .bak，.tmp → 正式檔，最後刪 .bak
  if (SD_MMC.exists(bak)) SD_MMC.remove(bak);
  const bool hadOld = SD_MMC.exists(path);
  if (hadOld && !SD_MMC.rename(path, bak)) {
    SD_MMC.remove(tmp);
    return false;
  }
  if (!SD_MMC.rename(tmp, path)) {
    if (hadOld) SD_MMC.rename(bak, path);  // 還原舊檔
    SD_MMC.remove(tmp);
    return false;
  }
  if (hadOld) SD_MMC.remove(bak);
  return true;
}

void SdStorage::recover(const char *path) {
  if (!mounted_ || !safePath(path)) return;
  char tmp[MAX_PATH + 8], bak[MAX_PATH + 8];
  suffixed(tmp, sizeof(tmp), path, ".tmp");
  suffixed(bak, sizeof(bak), path, ".bak");
  if (!SD_MMC.exists(path) && SD_MMC.exists(bak)) {
    SD_MMC.rename(bak, path);  // 替換到一半斷電：舊檔還在 .bak
    Serial.printf("[SD] restored %s from .bak\n", path);
  } else if (SD_MMC.exists(bak)) {
    SD_MMC.remove(bak);  // 新檔已就位，只差刪 .bak
  }
  if (SD_MMC.exists(tmp)) SD_MMC.remove(tmp);  // 沒寫完的暫存檔
}

bool SdStorage::safePath(const char *path) {
  if (path == nullptr || path[0] != '/') return false;
  const size_t n = strnlen(path, MAX_PATH + 1);
  if (n < 2 || n > MAX_PATH) return false;
  bool segStart = true;
  for (size_t i = 0; i < n; i++) {
    const char c = path[i];
    if (c == '/') {
      if (i > 0 && path[i - 1] == '/') return false;  // 空路徑段
      segStart = true;
      continue;
    }
    const bool ok = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') ||
                    c == '_' || c == '-' || c == '.';
    if (!ok) return false;
    if (segStart && c == '.') return false;  // 擋下 ".." 及隱藏檔
    segStart = false;
  }
  return true;
}
