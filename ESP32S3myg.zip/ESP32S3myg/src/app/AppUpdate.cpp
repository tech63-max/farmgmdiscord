// 素材管理：Wi-Fi、檢查更新、立即下載、核准待確認素材、素材數量
#include <Arduino.h>
#include <WiFi.h>
#include <time.h>

#include "../display/Theme.h"
#include "../media/RawView.h"
#include "../net/WifiConfig.h"
#include "App.h"
#include "Layout.h"

namespace {
constexpr int16_t INFO_Y = 36;
constexpr int16_t MANAGE_ROWS_Y = 84;
constexpr int16_t MANAGE_PITCH = 20;
constexpr int16_t MANAGE_ROW_H = 18;
constexpr uint8_t MANAGE_COUNT = 7;
constexpr uint32_t REDRAW_MS = 400;
constexpr uint32_t WIFI_APPLY_DELAY_MS = 1500;  // 網頁送出後再套用 (先讓回應送到手機)
constexpr uint32_t DL_COUNTS[] = {20, 100, 500, 1000};  // 檢查結果畫面可選的下載張數

// 網頁改 Wi-Fi：延遲套用
char pendingSsid[33];
char pendingPass[64];
uint32_t pendingWifiAt = 0;

double mb(uint64_t b) { return b / 1048576.0; }
}  // namespace

// ============================================================
// Wi-Fi / 網頁
void App::beginNet(uint32_t now) {
  char ssid[33], pass[65];
  WifiConfig::load(ssid, sizeof(ssid), pass, sizeof(pass));
  wifi_.begin(ssid, pass, now);
  memset(pass, 0, sizeof(pass));
  web_.begin(
      [](const char *s, const char *p) {
        if (!WifiConfig::save(s, p)) return;
        strlcpy(pendingSsid, s, sizeof(pendingSsid));
        strlcpy(pendingPass, p, sizeof(pendingPass));
        pendingWifiAt = millis() + WIFI_APPLY_DELAY_MS;
      },
      [this](char *buf, size_t cap) { webStatus(buf, cap); });
}

void App::updateNet(uint32_t now) {
  if (pendingWifiAt && (int32_t)(now - pendingWifiAt) >= 0) {
    pendingWifiAt = 0;
    wifi_.setCredentials(pendingSsid, pendingPass, now);
    memset(pendingPass, 0, sizeof(pendingPass));
  }
  wifi_.update(now);
  web_.setCaptive(wifi_.apActive());
  web_.update();
  if (wifi_.justConnected()) {
    Serial.printf("[WiFi] connected, ip %s\n", WiFi.localIP().toString().c_str());
    if (!ntpStarted_) {  // 對時 (更新時間記錄用)
      configTzTime("CST-8", "pool.ntp.org", "time.google.com");
      ntpStarted_ = true;
    }
  }
  wifi_.apJustStarted();
}

void App::webStatus(char *buf, size_t cap) {
  snprintf(buf, cap,
           "Wi-Fi：%s\nSD 卡：%s，剩餘 %.1f GB\n已核准素材 %lu 張，待核准 %lu 張\n上次更新：%s\n文字梗 %u 則",
           wifi_.state() == WifiState::Connected ? WiFi.localIP().toString().c_str() : "未連線",
           sd_.mounted() ? "正常" : "未偵測到", sd_.freeBytes() / 1073741824.0,
           (unsigned long)index_.countState(IndexEntry::Approved), (unsigned long)index_.countState(IndexEntry::Pending),
           index_.updated()[0] ? index_.updated() : "尚未更新", library_.totalTexts());
}

const char *App::catName(const char *catId) const {
  for (uint8_t i = 0; i < library_.count(); i++)
    if (strcmp(library_.category(i).id, catId) == 0) return library_.category(i).name;
  return strcmp(catId, "unsorted") == 0 ? "未分類" : catId;
}

// ============================================================
// 素材管理主畫面
void App::drawManageWifiLine() {
  char line[96];
  uint16_t color = Theme::DIM;
  if (wifi_.apActive()) {
    snprintf(line, sizeof(line), "熱點 %s 密碼 %s", wifi_.apSsid(), wifi_.apPass());
    color = Theme::TIME;
  } else if (wifi_.state() == WifiState::Connected) {
    snprintf(line, sizeof(line), "Wi-Fi 已連線 %s", WiFi.localIP().toString().c_str());
    color = Theme::ACCENT;
  } else if (wifi_.state() == WifiState::NoCredentials) {
    snprintf(line, sizeof(line), "Wi-Fi 尚未設定");
    color = Theme::WARN;
  } else {
    snprintf(line, sizeof(line), "Wi-Fi 連線中…");
  }
  display_.fillRect(0, INFO_Y + 30, 240, 15, Theme::BG);
  display_.utf8(8, INFO_Y + 30, line, 1, color, Theme::BG);
  shownWifi_ = (int8_t)wifi_.state() + (wifi_.apActive() ? 10 : 0);
}

void App::drawManage() {
  drawHeader("素材管理", nullptr);
  char line[96];
  snprintf(line, sizeof(line), "SD 剩 %.1f GB｜已核准 %lu 張", sd_.freeBytes() / 1073741824.0,
           (unsigned long)index_.countState(IndexEntry::Approved));
  display_.fillRect(0, INFO_Y, 240, 30, Theme::BG);
  display_.utf8(8, INFO_Y, sd_.mounted() ? line : "SD 卡：未偵測到", 1, sd_.mounted() ? Theme::TEXT : Theme::WARN,
                Theme::BG);
  snprintf(line, sizeof(line), "待核准 %lu｜更新 %s", (unsigned long)index_.countState(IndexEntry::Pending),
           index_.updated()[0] ? index_.updated() : "尚未更新");
  display_.utf8(8, INFO_Y + 15, line, 1, Theme::TEXT, Theme::BG);
  drawManageWifiLine();

  const Updater::Status st = updater_.status();
  char items[MANAGE_COUNT][40];
  snprintf(items[0], 40, wifi_.state() == WifiState::Connected ? "Wi-Fi 連線（已連線）" : "Wi-Fi 連線");
  snprintf(items[1], 40, "檢查更新");
  if (updater_.hasCheckResult()) snprintf(items[2], 40, "立即下載（%lu 張）", (unsigned long)st.batch);
  else snprintf(items[2], 40, "立即下載（請先檢查）");
  const unsigned long pending = (unsigned long)index_.countState(IndexEntry::Pending);
  snprintf(items[3], 40, "逐張核准（%lu 張）", pending);
  if (confirmApproveAll_) snprintf(items[4], 40, "再按一次左鍵：全部核准 %lu 張", pending);
  else snprintf(items[4], 40, "全部核准（%lu 張）", pending);
  snprintf(items[5], 40, "查看素材數量");
  snprintf(items[6], 40, "返回主畫面");
  for (uint8_t i = 0; i < MANAGE_COUNT; i++) {
    const int16_t y = MANAGE_ROWS_Y + i * MANAGE_PITCH;
    const bool sel = i == manageItem_;
    const uint16_t bg = sel ? Theme::CARD_SEL : Theme::CARD;
    display_.fillRect(0, y, 240, MANAGE_PITCH, Theme::BG);
    display_.gfx().fillRoundRect(4, y, 232, MANAGE_ROW_H, 4, bg);
    if (sel) display_.gfx().drawRoundRect(4, y, 232, MANAGE_ROW_H, 4, Theme::ACCENT);
    const uint16_t fg = (i == 4 && confirmApproveAll_) ? Theme::TIME : (sel ? Theme::TEXT : Theme::DIM_TEXT);
    display_.utf8(12, y + 3, items[i], 1, fg, bg);
  }
  drawKeyHints("選擇", "上", "下");
}

// ============================================================
// 檢查更新 / 下載畫面
void App::drawCheck(const Updater::Status &s) {
  drawHeader("檢查更新", nullptr);
  display_.fillRect(0, HEADER_H, 240, KEYBAR_Y - HEADER_H, Theme::BG);
  char line[96];
  if (s.phase == Updater::Phase::Checking) {
    static const char *const DOTS[] = {"", "．", "．．", "．．．"};
    snprintf(line, sizeof(line), "%s%s", s.msg, DOTS[(millis() / 400) % 4]);
    display_.utf8Centered(100, line, 1, Theme::ACCENT, Theme::BG);
    display_.utf8Centered(122, "只查詢清單，不會下載圖片", 1, Theme::DIM, Theme::BG);
    drawKeyHints("取消", nullptr, nullptr);
    return;
  }
  if (s.phase != Updater::Phase::CheckDone) {
    display_.utf8Centered(100, s.msg[0] ? s.msg : "檢查失敗", 1, Theme::WARN, Theme::BG);
    drawKeyHints("返回", nullptr, nullptr);
    return;
  }
  if (s.newTotal == 0) {
    display_.utf8Centered(100, "已經是最新，沒有新素材", 1, Theme::ACCENT, Theme::BG);
    drawKeyHints("返回", nullptr, nullptr);
    return;
  }
  int16_t y = 40;
  for (uint8_t i = 0; i < s.catN && i < 6; i++, y += 17) {
    snprintf(line, sizeof(line), "%s：新增 %lu 張", catName(s.cats[i].cat), (unsigned long)s.cats[i].n);
    display_.utf8(8, y, line, 1, Theme::TEXT, Theme::BG);
  }
  if (dlCat_ > s.catN) dlCat_ = 0;
  const char *cat = dlCat_ ? s.cats[dlCat_ - 1].cat : "";
  const uint32_t avail = dlCat_ ? s.cats[dlCat_ - 1].n : s.newTotal;
  const uint32_t n = min<uint32_t>(avail, DL_COUNTS[dlCountIdx_]);
  y = 148;
  snprintf(line, sizeof(line), "下載：%s × %lu 張", dlCat_ ? catName(cat) : "全部分類", (unsigned long)n);
  display_.utf8(8, y, line, 1, Theme::TIME, Theme::BG);
  snprintf(line, sizeof(line), "預估下載 %.0f MB，佔用 SD 約 %.1f MB", mb((uint64_t)n * 770 * 1024),
           mb((uint64_t)n * RawView::fileSize(RawView::MAX_W, RawView::MAX_H, 120)));
  display_.utf8(8, y + 17, line, 1, Theme::TEXT, Theme::BG);
  snprintf(line, sizeof(line), "約需 %lu 分鐘；中鍵換分類，長按右鍵換張數", (unsigned long)((n * 9 + 59) / 60));
  display_.utf8Wrap(8, y + 34, 228, line, 1, 2, Theme::DIM, Theme::BG);
  drawKeyHints("返回", "換分類", "下載");
}

void App::drawDownload(const Updater::Status &s) {
  char line[160];
  if (s.phase == Updater::Phase::Downloading) {
    drawHeader("下載中", nullptr);
    display_.fillRect(0, HEADER_H, 240, KEYBAR_Y - HEADER_H, Theme::BG);
    snprintf(line, sizeof(line), "分類：%s", s.curCat[0] ? catName(s.curCat) : "準備中");
    display_.utf8(8, 42, line, 1, Theme::TEXT, Theme::BG);
    snprintf(line, sizeof(line), "檔案：%s", s.curCaption);
    display_.utf8Wrap(8, 60, 224, line, 1, 1, Theme::DIM_TEXT, Theme::BG);
    const uint32_t pct = s.total ? s.done * 100 / s.total : 0;
    display_.gfx().drawRoundRect(10, 84, 220, 14, 4, Theme::ACCENT_DK);
    display_.gfx().fillRoundRect(12, 86, (int16_t)(216 * pct / 100), 10, 3, Theme::ACCENT);
    snprintf(line, sizeof(line), "%lu%%  已完成 %lu / %lu", (unsigned long)pct, (unsigned long)s.done,
             (unsigned long)s.total);
    display_.utf8Centered(104, line, 1, Theme::TIME, Theme::BG);
    snprintf(line, sizeof(line), "失敗 %lu  略過 %lu  已下載 %.1f MB", (unsigned long)s.failed,
             (unsigned long)s.skipped, mb(s.bytes));
    display_.utf8Centered(124, line, 1, s.failed ? Theme::WARN : Theme::DIM, Theme::BG);
    display_.utf8Centered(150, "下載中仍可隨時取消，已下載的會保留", 1, Theme::DIM, Theme::BG);
    drawKeyHints("取消", nullptr, nullptr);
    return;
  }
  drawHeader("更新結果", nullptr);
  display_.fillRect(0, HEADER_H, 240, KEYBAR_Y - HEADER_H, Theme::BG);
  const bool err = s.phase == Updater::Phase::Error;
  display_.utf8(8, 42, s.msg, 1, err ? Theme::WARN : Theme::ACCENT, Theme::BG);
  if (!err) {
    snprintf(line, sizeof(line), "成功下載 %lu 張", (unsigned long)s.ok);
    display_.utf8(8, 64, line, 1, Theme::TEXT, Theme::BG);
    snprintf(line, sizeof(line), "下載失敗 %lu 張", (unsigned long)s.failed);
    display_.utf8(8, 82, line, 1, s.failed ? Theme::WARN : Theme::TEXT, Theme::BG);
    snprintf(line, sizeof(line), "略過 %lu 張（內容重複）", (unsigned long)s.skipped);
    display_.utf8(8, 100, line, 1, Theme::TEXT, Theme::BG);
    snprintf(line, sizeof(line), "實際下載 %.1f MB", mb(s.bytes));
    display_.utf8(8, 118, line, 1, Theme::TEXT, Theme::BG);
    snprintf(line, sizeof(line), "完成時間 %s", s.finishedAt);
    display_.utf8(8, 136, line, 1, Theme::TEXT, Theme::BG);
    if (s.ok) display_.utf8(8, 162, "新素材要先「核准」才會被抽到", 1, Theme::TIME, Theme::BG);
  }
  drawKeyHints("返回", nullptr, (!err && index_.countState(IndexEntry::Pending)) ? "去核准" : nullptr);
}

void App::updateUpdateScreens(uint32_t now) {
  if (screen_ == Screen::Manage || screen_ == Screen::WifiSetup) {
    const int8_t w = (int8_t)wifi_.state() + (wifi_.apActive() ? 10 : 0);
    if (w != shownWifi_) {  // Wi-Fi 狀態或熱點開關變了
      if (screen_ == Screen::Manage) drawManage();
      else {
        drawWifiSetup();
        shownWifi_ = w;
      }
    }
    return;
  }
  if (screen_ != Screen::Check && screen_ != Screen::Download) return;
  const Updater::Status s = updater_.status();
  const bool changed = s.phase != shownPhase_ || s.done != shownDone_;
  const bool live = s.phase == Updater::Phase::Checking || s.phase == Updater::Phase::Downloading;
  if (!changed && !(live && now - lastUpdateDraw_ >= REDRAW_MS)) return;
  lastUpdateDraw_ = now;
  shownPhase_ = s.phase;
  shownDone_ = s.done;
  if (screen_ == Screen::Check) drawCheck(s);
  else drawDownload(s);
}

// ============================================================
// 核准待確認素材
bool App::nextPending(int32_t from, int dir) {
  const int32_t n = (int32_t)index_.count();
  for (int32_t k = 1; k <= n; k++) {
    const int32_t i = ((from + dir * k) % n + n) % n;
    if (index_.at(i).state == IndexEntry::Pending) {
      reviewPos_ = i;
      return true;
    }
  }
  reviewPos_ = -1;
  return false;
}

void App::drawReview() {
  if (reviewPos_ < 0 || reviewPos_ >= (int32_t)index_.count() ||
      index_.at(reviewPos_).state != IndexEntry::Pending) {
    nextPending(reviewPos_ < 0 ? -1 : reviewPos_, 1);
  }
  display_.clear(Theme::BG);
  if (reviewPos_ < 0) {
    drawHeader("核准素材", nullptr);
    display_.utf8Centered(100, "沒有待核准的素材", 1, Theme::ACCENT, Theme::BG);
    drawKeyHints("返回", nullptr, nullptr);
    return;
  }
  IndexEntry &e = index_.at(reviewPos_);
  char cap[RawView::MAX_CAPTION + 1];
  const bool ok = RawView::draw(sd_, display_, e.file, 0, 0, 240, PHOTO_H, Theme::BG, cap, sizeof(cap));
  if (!ok) display_.utf8Centered(70, "（檔案讀取失敗，可以刪除）", 1, Theme::WARN, Theme::BG);
  display_.fillRect(0, PHOTO_H, 240, KEYBAR_Y - PHOTO_H, Theme::BG);
  display_.utf8Wrap(6, PHOTO_CAPTION_Y - 1, 228, ok ? cap : e.file, 1, 1, Theme::TEXT, Theme::BG);
  char line[96];
  snprintf(line, sizeof(line), "待核准 %lu 張｜%s｜來源 %s（授權未明）",
           (unsigned long)index_.countState(IndexEntry::Pending), catName(e.cat), e.src);
  display_.utf8Wrap(6, PHOTO_CAPTION_Y + 14, 228, line, 1, 2, Theme::DIM, Theme::BG);
  drawKeyHints("返回", "刪除", "核准");
}

// 核准 = 從待確認區移到分類資料夾；刪除 = 刪檔並記為 rejected (之後不再下載)。不存索引
bool App::applyReview(IndexEntry &e, bool approve) {
  bool ok = true;
  picker_.invalidate();
  if (approve) {
    const char *dir = "/meme/funny";  // 未分類 → 一般搞笑
    for (uint8_t i = 0; i < library_.count(); i++) {
      const MemeCategory &c = library_.category(i);
      if (strcmp(c.id, e.cat) == 0 && c.dirCount > 0) dir = c.dirs[0];
    }
    const char *base = strrchr(e.file, '/');
    char dst[SdStorage::MAX_PATH];
    snprintf(dst, sizeof(dst), "%s%s", dir, base ? base : "/x.565");
    if (!sd_.fs().exists(dir)) sd_.fs().mkdir(dir);
    if (sd_.fs().exists(dst)) sd_.fs().remove(dst);
    ok = SdStorage::safePath(dst) && sd_.fs().rename(e.file, dst);
    if (ok) {
      strlcpy(e.file, dst, sizeof(e.file));
      e.state = IndexEntry::Approved;
    }
  } else {
    sd_.fs().remove(e.file);  // 刪除並記為拒絕，之後不會再下載
    e.file[0] = '\0';
    e.state = IndexEntry::Rejected;
  }
  return ok;
}

void App::approveCurrent(bool approve) {
  if (reviewPos_ < 0 || sdLocked()) return;
  IndexEntry &e = index_.at(reviewPos_);
  const bool ok = applyReview(e, approve);
  if (!ok || !index_.save(sd_)) {
    display_.utf8Centered(100, "寫入 SD 卡失敗", 2, Theme::WARN, Theme::BG);
    Serial.println("[Review] save failed");
    return;
  }
  Serial.printf("[Review] %s %s\n", approve ? "approved" : "rejected", e.file);
  nextPending(reviewPos_, 1);
  drawReview();
}

void App::approveAll() {
  if (sdLocked()) return;
  const uint32_t total = index_.countState(IndexEntry::Pending);
  if (total == 0) return;
  uint32_t done = 0, failed = 0;
  char line[64];
  for (uint32_t i = 0; i < index_.count(); i++) {
    IndexEntry &e = index_.at(i);
    if (e.state != IndexEntry::Pending) continue;
    if (applyReview(e, true)) done++;
    else failed++;
    if ((done + failed) % 5 == 0 || done + failed == total) {  // 進度
      snprintf(line, sizeof(line), "核准中 %lu / %lu", (unsigned long)(done + failed), (unsigned long)total);
      display_.utf8Centered(INFO_Y + 30, line, 1, Theme::TIME, Theme::BG, 240);
    }
  }
  const bool saved = index_.save(sd_);
  Serial.printf("[Review] approve all: %lu ok, %lu failed%s\n", (unsigned long)done, (unsigned long)failed,
                saved ? "" : ", index save FAILED");
  drawManage();
  snprintf(line, sizeof(line), saved ? "已核准 %lu 張%s" : "索引寫入失敗", (unsigned long)done,
           failed ? "（部分失敗）" : "");
  display_.utf8Centered(INFO_Y + 30, line, 1, saved && !failed ? Theme::ACCENT : Theme::WARN, Theme::BG, 240);
}

// ============================================================
void App::drawCounts() {
  drawHeader("素材數量", nullptr);
  char line[96];
  int16_t y = 38;
  for (uint8_t i = 0; i < library_.count() && i < 9; i++, y += 19) {
    const MemeCategory &c = library_.category(i);
    display_.utf8(8, y, c.name, 1, Theme::TEXT, Theme::BG);
    snprintf(line, sizeof(line), "%lu 張｜待 %lu", (unsigned long)index_.countState(IndexEntry::Approved, c.id),
             (unsigned long)index_.countState(IndexEntry::Pending, c.id));
    display_.utf8Right(232, y, line, 1, Theme::DIM, Theme::BG);
  }
  snprintf(line, sizeof(line), "文字梗 %u 則（下載的圖另計）", library_.totalTexts());
  display_.utf8(8, 208, line, 1, Theme::DIM, Theme::BG);
  drawKeyHints("返回", nullptr, nullptr);
}

// ============================================================
void App::updateButton(const ButtonEvent &e, uint32_t now) {
  switch (screen_) {
    case Screen::Manage:
      if (e.type == Press::Long) {
        confirmApproveAll_ = false;
        enter(Screen::Home, now);
      } else if (e.btn == Btn::Pwr) {
        confirmApproveAll_ = false;
        manageItem_ = (manageItem_ + MANAGE_COUNT - 1) % MANAGE_COUNT;
        drawManage();
      } else if (e.btn == Btn::Plus) {
        confirmApproveAll_ = false;
        manageItem_ = (manageItem_ + 1) % MANAGE_COUNT;
        drawManage();
      } else {
        if (manageItem_ != 4) confirmApproveAll_ = false;
        switch (manageItem_) {
          case 0:
            enter(Screen::WifiSetup, now);
            break;
          case 1:
            updater_.requestCheck();
            enter(Screen::Check, now);
            break;
          case 2:
            if (updater_.hasCheckResult() && updater_.requestDownload()) enter(Screen::Download, now);
            else display_.utf8Centered(INFO_Y + 30, "請先「檢查更新」並確認有新素材", 1, Theme::WARN, Theme::BG, 240);
            break;
          case 3:
            reviewPos_ = -1;
            enter(Screen::Review, now);
            break;
          case 4:  // 全部核准：第一次按只顯示確認，第二次才執行
            if (index_.countState(IndexEntry::Pending) == 0) break;
            if (!confirmApproveAll_) {
              confirmApproveAll_ = true;
              drawManage();
            } else {
              confirmApproveAll_ = false;
              approveAll();
            }
            break;
          case 5:
            enter(Screen::Counts, now);
            break;
          default:
            enter(Screen::Home, now);
            break;
        }
      }
      break;
    case Screen::Check:
      if (e.btn == Btn::Boot) {
        if (updater_.busy()) updater_.cancel();
        else enter(Screen::Manage, now);
      } else if (!updater_.busy() && updater_.status().phase == Updater::Phase::CheckDone) {
        const Updater::Status s = updater_.status();
        if (e.btn == Btn::Pwr && e.type == Press::Short) {  // 換分類：全部 → 各分類
          dlCat_ = (dlCat_ + 1) % (s.catN + 1);
          drawCheck(s);
        } else if (e.btn == Btn::Plus && e.type == Press::Long) {  // 換張數
          dlCountIdx_ = (dlCountIdx_ + 1) % (sizeof(DL_COUNTS) / sizeof(DL_COUNTS[0]));
          drawCheck(s);
        } else if (e.btn == Btn::Plus && e.type == Press::Short) {
          const char *cat = (dlCat_ && dlCat_ <= s.catN) ? s.cats[dlCat_ - 1].cat : "";
          if (updater_.requestDownload(cat, DL_COUNTS[dlCountIdx_])) enter(Screen::Download, now);  // 使用者確認後才下載
        }
      }
      break;
    case Screen::Download:
      if (e.btn == Btn::Boot) {
        if (updater_.busy()) updater_.cancel();
        else enter(Screen::Manage, now);
      } else if (e.btn == Btn::Plus && !updater_.busy()) {
        reviewPos_ = -1;
        enter(Screen::Review, now);
      }
      break;
    case Screen::Review:
      if (e.btn == Btn::Boot || e.type == Press::Long) enter(Screen::Manage, now);
      else if (reviewPos_ >= 0 && e.btn == Btn::Pwr) approveCurrent(false);
      else if (reviewPos_ >= 0 && e.btn == Btn::Plus) approveCurrent(true);
      break;
    case Screen::Counts:
      enter(Screen::Manage, now);
      break;
    case Screen::WifiSetup:
      if (e.btn == Btn::Boot || e.type == Press::Long) {
        // 離開時關熱點；剛設定完正在連線的話，WifiManager 會在連上 20 秒後自己關
        if (wifi_.state() != WifiState::Connecting) wifi_.stopAp();
        enter(Screen::Manage, now);
      }
      break;
    default:
      break;
  }
}

void App::drawWifiSetup() {
  drawHeader("Wi-Fi 連線", nullptr);
  display_.fillRect(0, HEADER_H, 240, KEYBAR_Y - HEADER_H, Theme::BG);
  char line[96];
  if (wifi_.state() == WifiState::Connected) {
    snprintf(line, sizeof(line), "目前：已連線 %s", WiFi.localIP().toString().c_str());
    display_.utf8(8, 40, line, 1, Theme::ACCENT, Theme::BG);
  } else if (wifi_.state() == WifiState::NoCredentials) {
    display_.utf8(8, 40, "目前：尚未設定 Wi-Fi", 1, Theme::WARN, Theme::BG);
  } else {
    display_.utf8(8, 40, "目前：連線中…", 1, Theme::DIM, Theme::BG);
  }
  if (!wifi_.apActive()) {
    display_.utf8(8, 70, "設定熱點已關閉", 1, Theme::DIM, Theme::BG);
    drawKeyHints("返回", nullptr, nullptr);
    return;
  }
  display_.utf8(8, 62, "1. 手機連這個 Wi-Fi：", 1, Theme::TEXT, Theme::BG);
  display_.utf8(16, 78, wifi_.apSsid(), 2, Theme::TIME, Theme::BG);
  snprintf(line, sizeof(line), "密碼 %s", wifi_.apPass());
  display_.utf8(16, 106, line, 2, Theme::TIME, Theme::BG);
  display_.utf8(8, 138, "2. 會自動跳出設定頁", 1, Theme::TEXT, Theme::BG);
  snprintf(line, sizeof(line), "   沒跳出來就開 http://%s", WiFi.softAPIP().toString().c_str());
  display_.utf8(8, 154, line, 1, Theme::DIM, Theme::BG);
  display_.utf8(8, 172, "3. 選你的 Wi-Fi、輸入密碼", 1, Theme::TEXT, Theme::BG);
  display_.utf8(8, 196, "連上後熱點約 20 秒自動關閉", 1, Theme::DIM, Theme::BG);
  drawKeyHints("返回", nullptr, nullptr);
}
