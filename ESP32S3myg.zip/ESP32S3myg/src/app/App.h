#pragma once
#include <stddef.h>
#include <stdint.h>

#include "../display/DisplayManager.h"
#include "../input/ButtonManager.h"
#include "../media/AnimPlayer.h"
#include "../meme/MemeLibrary.h"
#include "../net/WebPanel.h"
#include "../net/WifiManager.h"
#include "../pet/PetRenderer.h"
#include "../storage/SdStorage.h"
#include "../update/MemeIndex.h"
#include "../update/Updater.h"

// 唯一的調度者：持有所有模組、畫面狀態機，全部非阻塞，由 loop() 以 millis() 驅動。
// 實體按鍵由左到右：BOOT (左鍵)、PWR (中鍵)、PLUS (右鍵)。完全無聲。
class App {
 public:
  void begin();
  void loop();

 private:
  enum class Screen : uint8_t {
    Home, Menu, Summon, Result, Info, PowerOff,
    Manage, Check, Download, Review, Counts, WifiSetup  // 素材管理 (AppUpdate.cpp)
  };

  void enter(Screen s, uint32_t now);
  void handleButton(const ButtonEvent &e, uint32_t now);
  void startDraw(uint8_t cat, uint32_t now);
  void showResult(uint32_t now);
  void updateIdleDim(uint32_t now);
  void maybeRecoverSd(uint32_t now);

  // 畫面
  void drawHeader(const char *title, const char *right);
  void drawKeyHints(const char *left, const char *mid, const char *right);
  void drawStatusLine(const char *s, uint16_t color);
  void drawCaption(const char *text, bool small = false);  // small = 有圖時的小字幕
  void showCaptionWithNote(const char *note);  // 結果文字 + 失敗提示
  void drawMenu();
  void drawInfo();

  // ---- AppUpdate.cpp：Wi-Fi、素材管理、檢查更新、下載、核准 ----
  void beginNet(uint32_t now);
  void updateNet(uint32_t now);
  void updateUpdateScreens(uint32_t now);
  void updateButton(const ButtonEvent &e, uint32_t now);  // 素材管理相關畫面的按鍵
  bool sdLocked() const { return updater_.busy(); }       // 更新工作執行中：App 不碰 SD
  void drawManage();
  void drawManageWifiLine();
  void drawCheck(const Updater::Status &s);
  void drawDownload(const Updater::Status &s);
  void drawReview();
  void drawCounts();
  void drawWifiSetup();
  bool nextPending(int32_t from, int dir);  // 找下一筆待核准 (reviewPos_)
  void approveCurrent(bool approve);
  bool applyReview(IndexEntry &e, bool approve);
  void approveAll();
  const char *catName(const char *catId) const;
  void webStatus(char *buf, size_t cap);

  // 序列埠指令 (115200)
  void pollSerial(uint32_t now);
  void runCommand(char *cmd, uint32_t now);

  DisplayManager display_;
  PixelCanvas canvas_;
  ButtonManager buttons_;
  SdStorage sd_;
  MemeLibrary library_;
  RecentStore recent_;
  MemePicker picker_;
  PetRenderer pet_;
  AnimPlayer anim_;
  WifiManager wifi_;
  WebPanel web_;
  MemeIndex index_;
  Updater updater_;

  Screen screen_ = Screen::Home;
  uint32_t screenSince_ = 0;
  uint32_t lastInput_ = 0;
  uint32_t lastFrame_ = 0;
  uint32_t lastRemount_ = 0;
  bool dimmed_ = false;

  uint8_t menuItem_ = 0;
  uint8_t menuTop_ = 0;
  uint8_t lastCat_ = 0;    // 右鍵 / 選單抽的分類
  bool drawAll_ = false;    // 上一次是不是「全部抽」(結果畫面的「再抽」沿用)
  MemePick result_;
  bool resultAnimated_ = false;  // Result 畫面是否要持續重畫寵物
  bool resultPhoto_ = false;     // Result 畫面上方是圖片 / 動畫 (字幕用小字)
  char resultCaption_[301];  // .565 圖內嵌的字幕

  // 素材管理
  uint8_t manageItem_ = 0;
  int8_t shownWifi_ = -1;
  uint32_t lastUpdateDraw_ = 0;
  uint32_t shownDone_ = 0xFFFFFFFF;
  Updater::Phase shownPhase_ = Updater::Phase::Idle;
  int32_t reviewPos_ = -1;
  bool confirmApproveAll_ = false;
  uint32_t timeImageMs_ = 0, timeCaptionMs_ = 0;  // 上一次結果畫面：畫圖 / 畫字各花多久
  uint8_t dlCat_ = 0;       // 檢查結果畫面：0 = 全部分類，k = 第 k 個有新素材的分類
  uint8_t dlCountIdx_ = 0;  // 下載張數選項  // 「全部核准」已按第一次，等確認
  bool ntpStarted_ = false;

  char serialBuf_[128];
  uint8_t serialLen_ = 0;
};
