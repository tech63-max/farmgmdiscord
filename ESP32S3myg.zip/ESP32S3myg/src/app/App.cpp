#include "App.h"

#include <Arduino.h>
#include <WiFi.h>
#include <esp_heap_caps.h>

#include "../assets/Font12.h"
#include "../config/BoardConfig.h"
#include "../display/Theme.h"
#include "../media/JpegView.h"
#include "../media/RawView.h"
#include "../net/WifiConfig.h"
#include "Layout.h"

namespace {
constexpr const char *FW_VERSION = "0.3 (階段三)";

constexpr uint8_t BRIGHTNESS = 80;
constexpr uint8_t DIM_BRIGHTNESS = 12;
constexpr uint32_t DIM_AFTER_MS = 90 * 1000;      // 無操作 90 秒調暗
constexpr uint32_t FRAME_MS = 70;                 // 動畫約 14 fps
constexpr uint32_t SUMMON_MIN_MS = 1500;          // 水晶球至少轉這麼久
constexpr uint32_t RESULT_TIMEOUT_MS = 25 * 1000; // 結果畫面無操作自動回主畫面
constexpr uint32_t REMOUNT_INTERVAL_MS = 15 * 1000;
constexpr uint32_t PICK_BUDGET_MS = 6;            // 每圈掃描 SD 的時間上限
}  // namespace

void App::begin() {
  // 電池供電時要先鎖住電源；喇叭功放永遠關閉 (完全無聲)
  pinMode(Pins::POWER_LATCH, OUTPUT);
  digitalWrite(Pins::POWER_LATCH, HIGH);
  pinMode(Pins::AMP_CTRL, OUTPUT);
  digitalWrite(Pins::AMP_CTRL, LOW);

  Serial.begin(115200);
  // USB 插著但電腦沒在讀時，預設每次寫入最多會等 20 x 100 ms (畫面會卡住)；改成不等待、直接丟掉
  Serial.setTxTimeoutMs(0);
  const uint32_t now = millis();
  buttons_.begin(now);
  if (!display_.begin()) Serial.println("[MemeBall] LCD init failed");
  if (!canvas_.begin()) Serial.println("[MemeBall] canvas alloc failed");
  display_.clear(Theme::BG);
  display_.utf8Centered(100, "梗圖發射器", 2, Theme::TIME, Theme::BG);
  display_.utf8Centered(134, "讀取 SD 卡…", 1, Theme::DIM, Theme::BG);
  display_.setBrightness(BRIGHTNESS);

  sd_.begin();
  library_.begin(sd_);
  recent_.begin();
  if (sd_.mounted() && !index_.load(sd_)) Serial.println("[Index] load failed");
  updater_.begin(sd_, index_);
  beginNet(now);
  Serial.printf("[MemeBall] %u categories, %u texts (%s)\n", library_.count(), library_.totalTexts(),
                library_.fromSd() ? "SD" : "built-in");
  Serial.println("[MemeBall] type 'help' for serial commands");
  lastInput_ = now;
  enter(Screen::Home, now);
}

void App::loop() {
  const uint32_t now = millis();
  buttons_.update(now);
  ButtonEvent e;
  while (buttons_.poll(e)) {
    lastInput_ = now;
    if (dimmed_) {  // 調暗時第一下只負責點亮
      dimmed_ = false;
      display_.setBrightness(BRIGHTNESS);
      continue;
    }
    handleButton(e, now);
  }
  pollSerial(now);
  updateIdleDim(now);
  updateNet(now);

  const bool frameDue = now - lastFrame_ >= FRAME_MS;
  switch (screen_) {
    case Screen::Home:
      if (frameDue) {
        lastFrame_ = now;
        pet_.drawIdle(canvas_, now);
        display_.pushCanvas(canvas_, 0, CANVAS_Y);
      }
      break;
    case Screen::Summon:
      picker_.step(PICK_BUDGET_MS);
      if (frameDue) {
        lastFrame_ = now;
        pet_.drawSummon(canvas_, now);
        display_.pushCanvas(canvas_, 0, CANVAS_Y);
      }
      if (!picker_.busy() && now - screenSince_ >= SUMMON_MIN_MS) {
        result_ = picker_.result();
        enter(Screen::Result, now);
      }
      break;
    case Screen::Result:
      if (anim_.active()) {
        anim_.update(now);
        if (anim_.failed()) {  // 播放中讀不到 SD：改成寵物反應，不卡住
          resultAnimated_ = true;
          resultPhoto_ = false;
          display_.fillRect(0, MEDIA_H, 240, KEYBAR_Y - MEDIA_H, Theme::BG);
          showCaptionWithNote("（動畫讀取失敗）");
        }
      } else if (resultAnimated_ && frameDue) {
        lastFrame_ = now;
        pet_.drawReaction(canvas_, result_.mood, now);
        display_.pushCanvas(canvas_, 0, 0);
      }
      if (now - lastInput_ >= RESULT_TIMEOUT_MS) enter(Screen::Home, now);
      break;
    case Screen::PowerOff:
      // 用 USB 供電時拉低電源鎖定不會斷電，2 秒後回主畫面
      if (now - screenSince_ > 2000) {
        digitalWrite(Pins::POWER_LATCH, HIGH);
        enter(Screen::Home, now);
      }
      break;
    default:
      updateUpdateScreens(now);
      break;
  }
}

// ============================================================
void App::enter(Screen s, uint32_t now) {
  if (screen_ == Screen::Summon && s != Screen::Summon) picker_.cancel();
  if (s != Screen::Result) anim_.stop();
  screen_ = s;
  screenSince_ = now;
  lastFrame_ = 0;
  pet_.reset(now);
  switch (s) {
    case Screen::Home: {
      maybeRecoverSd(now);
      display_.clear(Theme::BG);
      drawHeader("梗圖發射器", sd_.mounted() ? "SD OK" : "無 SD");
      char line[64];
      snprintf(line, sizeof(line), "右鍵抽：%s", library_.category(lastCat_).name);
      drawStatusLine(line, Theme::DIM);
      drawKeyHints("分類", "全部抽", "抽！");
      break;
    }
    case Screen::Menu:
      display_.clear(Theme::BG);
      drawMenu();
      break;
    case Screen::Summon: {
      display_.clear(Theme::BG);
      drawHeader(drawAll_ ? "全部梗圖" : library_.category(lastCat_).name, nullptr);
      drawStatusLine("水晶球占卜中…", Theme::ACCENT);
      drawKeyHints("取消", nullptr, nullptr);
      break;
    }
    case Screen::Result:
      showResult(now);
      break;
    case Screen::Info:
      display_.clear(Theme::BG);
      drawInfo();
      break;
    case Screen::PowerOff:
      display_.clear(Theme::BG);
      display_.utf8Centered(100, "掰掰～", 2, Theme::TIME, Theme::BG);
      digitalWrite(Pins::POWER_LATCH, LOW);  // 電池供電時在此斷電
      break;
    case Screen::Manage:
      display_.clear(Theme::BG);
      drawManage();
      break;
    case Screen::Check:
    case Screen::Download:
      display_.clear(Theme::BG);
      shownDone_ = 0xFFFFFFFF;
      shownPhase_ = Updater::Phase::Idle;
      lastUpdateDraw_ = 0;
      updateUpdateScreens(now);
      break;
    case Screen::Review:
      display_.clear(Theme::BG);
      drawReview();
      break;
    case Screen::Counts:
      display_.clear(Theme::BG);
      drawCounts();
      break;
    case Screen::WifiSetup:
      wifi_.startAp(now);  // 使用者按了「Wi-Fi 連線」才開熱點
      display_.clear(Theme::BG);
      drawWifiSetup();
      break;
  }
}

void App::handleButton(const ButtonEvent &e, uint32_t now) {
  switch (screen_) {
    case Screen::Home:
      if (e.btn == Btn::Pwr && e.type == Press::Long) enter(Screen::PowerOff, now);
      else if (e.btn == Btn::Boot && e.type == Press::Long) enter(Screen::Info, now);
      else if (e.btn == Btn::Plus && e.type == Press::Long) {
        manageItem_ = 0;
        enter(Screen::Manage, now);
      }
      else if (e.type != Press::Short) break;
      else if (e.btn == Btn::Boot) {
        menuItem_ = lastCat_;
        enter(Screen::Menu, now);
      } else if (e.btn == Btn::Pwr) startDraw(MemePicker::ALL, now);  // 中鍵：從全部梗圖抽一張
      else startDraw(lastCat_, now);
      break;
    case Screen::Menu: {
      if (e.type == Press::Long) {
        enter(Screen::Home, now);
        break;
      }
      const uint8_t n = library_.count();
      if (e.btn == Btn::Pwr) {
        menuItem_ = (menuItem_ + n - 1) % n;
        drawMenu();
      } else if (e.btn == Btn::Plus) {
        menuItem_ = (menuItem_ + 1) % n;
        drawMenu();
      } else {
        startDraw(menuItem_, now);
      }
      break;
    }
    case Screen::Summon:
      if (e.btn == Btn::Boot) enter(Screen::Home, now);
      break;
    case Screen::Result:
      if (e.type == Press::Long) enter(Screen::Home, now);
      else if (e.btn == Btn::Boot) enter(Screen::Home, now);
      else if (e.btn == Btn::Pwr) {
        menuItem_ = lastCat_;
        enter(Screen::Menu, now);
      } else startDraw(drawAll_ ? MemePicker::ALL : lastCat_, now);  // 再抽一次 (沿用上次的模式)
      break;
    case Screen::Info:
      if (e.btn == Btn::Pwr && e.type == Press::Short && !sdLocked()) {
        display_.utf8Centered(STATUS_Y, "重新掛載 SD 卡…", 1, Theme::ACCENT, Theme::BG);
        sd_.remount();
        library_.begin(sd_);
        picker_.invalidate();
        lastRemount_ = now;
        if (lastCat_ >= library_.count()) lastCat_ = 0;
        drawInfo();
      } else if (e.btn == Btn::Boot || e.type == Press::Long) {
        enter(Screen::Home, now);
      }
      break;
    case Screen::PowerOff:
      break;
    default:
      updateButton(e, now);
      break;
  }
}

void App::startDraw(uint8_t cat, uint32_t now) {
  if (library_.count() == 0 || sdLocked()) return;
  drawAll_ = cat == MemePicker::ALL;
  if (!drawAll_) lastCat_ = cat < library_.count() ? cat : 0;
  picker_.start(sd_, library_, drawAll_ ? MemePicker::ALL : lastCat_, recent_);
  enter(Screen::Summon, now);
}

void App::showResult(uint32_t now) {
  const uint32_t tStart = millis();
  display_.clear(Theme::BG);
  resultAnimated_ = false;
  resultPhoto_ = false;
  const char *note = nullptr;
  const char *mediaResult = "";  // log 等畫完再印 (序列埠寫入可能卡住)
  if (result_.kind == MemePick::None) {
    result_.text = "這個分類還沒有內容，請在 SD 卡加入梗圖或文字。";
    result_.mood = Mood::Confused;
  } else if (result_.key != 0) {  // 序列埠測試 (jpg / anim) 不記錄
    recent_.push(result_.key);
  }
  const char *ext = strrchr(result_.path, '.');
  if (result_.kind == MemePick::Image && ext && strcasecmp(ext, ".565") == 0) {
    // 下載的截圖：已縮好的 RGB565，字幕內嵌在檔案裡
    const bool shown = RawView::draw(sd_, display_, result_.path, 0, 0, 240, PHOTO_H, Theme::BG, resultCaption_,
                                     sizeof(resultCaption_));
    mediaResult = shown ? "ok" : "unreadable";
    if (shown) {
      resultPhoto_ = true;
      if (resultCaption_[0]) result_.text = resultCaption_;
    } else {
      note = "（圖片無法顯示）";
      resultAnimated_ = true;
    }
  } else if (result_.kind == MemePick::Image) {
    const JpegResult r = JpegView::draw(sd_, display_, result_.path, 0, 0, 240, PHOTO_H, Theme::BG);
    mediaResult = JpegView::resultName(r);
    resultPhoto_ = r == JpegResult::Ok;
    if (r != JpegResult::Ok) {
      if (r == JpegResult::OpenFail) sd_.markError();
      note = "（圖片無法顯示）";
      resultAnimated_ = true;
    }
  } else if (result_.kind == MemePick::Anim) {
    mediaResult = "ok";
    resultPhoto_ = true;
    if (!anim_.open(sd_, display_, result_.path, 0, 0, 240, PHOTO_H, Theme::BG, now)) {
      resultPhoto_ = false;
      mediaResult = "no playable frames (need 000.jpg)";
      note = "（動畫無法播放）";
      resultAnimated_ = true;
    }
  } else {
    resultAnimated_ = true;
  }
  if (resultAnimated_) {
    pet_.drawReaction(canvas_, result_.mood, now);
    display_.pushCanvas(canvas_, 0, 0);
  }
  const uint32_t tCaption = millis();
  showCaptionWithNote(note);
  drawKeyHints("返回", "分類", "再抽");
  timeImageMs_ = tCaption - tStart;
  timeCaptionMs_ = millis() - tCaption;
  Serial.printf("[Draw] %s kind=%u key=%08lx %s %s | scan %lu ms, image %lu ms, caption %lu ms\n",
                library_.category(result_.cat).id, result_.kind, (unsigned long)result_.key,
                result_.kind == MemePick::Text ? "" : result_.path, mediaResult,
                (unsigned long)picker_.lastScanMs(), (unsigned long)timeImageMs_, (unsigned long)timeCaptionMs_);
}

void App::showCaptionWithNote(const char *note) {
  char buf[480];
  snprintf(buf, sizeof(buf), "%s%s", result_.text ? result_.text : "", note ? note : "");
  drawCaption(buf, resultPhoto_);
}

void App::updateIdleDim(uint32_t now) {
  if (!dimmed_ && screen_ != Screen::PowerOff && now - lastInput_ >= DIM_AFTER_MS) {
    dimmed_ = true;
    display_.setBrightness(DIM_BRIGHTNESS);
  }
}

void App::maybeRecoverSd(uint32_t now) {
  // 只在曾經發生讀取錯誤時自動重試 (避免沒插卡時每次回主畫面都卡一下)
  if (!sd_.hasError() || sdLocked() || now - lastRemount_ < REMOUNT_INTERVAL_MS) return;
  lastRemount_ = now;
  Serial.println("[SD] read error earlier, remounting");
  sd_.remount();
  library_.begin(sd_);
  picker_.invalidate();
  if (lastCat_ >= library_.count()) lastCat_ = 0;
}

// ============================================================
// 畫面元件
void App::drawHeader(const char *title, const char *right) {
  display_.fillRect(0, 0, 240, HEADER_H, Theme::HEADER);
  display_.fillRect(0, HEADER_H - 2, 240, 2, Theme::ACCENT_DK);
  display_.utf8(8, 3, title, 2, Theme::TIME, Theme::HEADER);
  if (right) display_.utf8Right(234, 10, right, 1, Theme::DIM_TEXT, Theme::HEADER);
}

void App::drawKeyHints(const char *left, const char *mid, const char *right) {
  display_.fillRect(0, KEYBAR_Y, 240, 240 - KEYBAR_Y, Theme::HEADER);
  const char *labels[3] = {left, mid, right};
  for (int i = 0; i < 3; i++) {
    if (!labels[i]) continue;
    const int16_t w = DisplayManager::utf8Width(labels[i], 1);
    display_.utf8(40 + 80 * i - w / 2, KEYBAR_Y + 2, labels[i], 1, Theme::ACCENT, Theme::HEADER);
  }
}

void App::drawStatusLine(const char *s, uint16_t color) {
  display_.utf8Centered(STATUS_Y, s, 1, color, Theme::BG);
}

void App::drawCaption(const char *text, bool small) {
  constexpr int16_t X = 6, W = 228;
  if (small) {  // 有圖：字幕在圖下方的框內置中；一行放得下用 2 倍字，否則 1 倍字最多 3 行
    constexpr int16_t BOX_H = KEYBAR_Y - PHOTO_H;  // 44 px
    const uint8_t scale = DisplayManager::utf8LineCount(text, W, 2) <= 1 ? 2 : 1;
    display_.utf8Box(0, PHOTO_H, 240, BOX_H, text, scale, scale == 2 ? 1 : 3, Theme::TEXT, Theme::BG);
    return;
  }
  display_.fillRect(0, CAPTION_Y, 240, CAPTION_H, Theme::BG);
  // 短句用 2 倍字 (最多 2 行)，長句用 1 倍字 (最多 3 行)
  if (DisplayManager::utf8LineCount(text, W, 2) <= 2) {
    display_.utf8Wrap(X, CAPTION_Y + 1, W, text, 2, 2, Theme::TEXT, Theme::BG);
  } else {
    display_.utf8Wrap(X, CAPTION_Y + 4, W, text, 1, 3, Theme::TEXT, Theme::BG);
  }
}

void App::drawMenu() {
  drawHeader("選擇梗分類", nullptr);
  const uint8_t n = library_.count();
  if (menuItem_ >= n) menuItem_ = 0;
  if (menuItem_ < menuTop_) menuTop_ = menuItem_;
  if (menuItem_ >= menuTop_ + MENU_ROWS) menuTop_ = menuItem_ - MENU_ROWS + 1;
  for (uint8_t row = 0; row < MENU_ROWS; row++) {
    const int16_t y = ROWS_Y + row * ROW_PITCH;
    const uint8_t i = menuTop_ + row;
    if (i >= n) {
      display_.fillRect(0, y, 240, ROW_PITCH, Theme::BG);
      continue;
    }
    const bool sel = i == menuItem_;
    const uint16_t bg = sel ? Theme::CARD_SEL : Theme::CARD;
    display_.fillRect(0, y, 240, ROW_PITCH, Theme::BG);
    display_.gfx().fillRoundRect(4, y, 232, ROW_H, 5, bg);
    if (sel) display_.gfx().drawRoundRect(4, y, 232, ROW_H, 5, Theme::ACCENT);
    const MemeCategory &c = library_.category(i);
    char label[80];
    snprintf(label, sizeof(label), "%u %s", i + 1, c.name);
    display_.utf8(12, y + 8, label, 1, sel ? Theme::TEXT : Theme::DIM_TEXT, bg);
    char cnt[16];
    snprintf(cnt, sizeof(cnt), "%u 則", c.textCount);
    display_.utf8Right(228, y + 8, cnt, 1, Theme::DIM, bg);
  }
  drawKeyHints("選擇", "上", "下");
}

void App::drawInfo() {
  drawHeader("資訊", FW_VERSION);
  char line[96];
  int16_t y = 42;
  auto put = [&](const char *s, uint16_t color) {
    display_.fillRect(0, y, 240, 16, Theme::BG);
    display_.utf8(8, y, s, 1, color, Theme::BG);
    y += 18;
  };
  if (sd_.mounted()) {
    snprintf(line, sizeof(line), "SD 卡：%s", sd_.cardTypeName());
    put(line, Theme::TEXT);
    snprintf(line, sizeof(line), "容量 %.1f GB，剩餘 %.1f GB", sd_.totalBytes() / 1073741824.0,
             sd_.freeBytes() / 1073741824.0);
    put(line, Theme::TEXT);
  } else {
    put("SD 卡：未偵測到", Theme::WARN);
    put("請插入 FAT32 格式的卡", Theme::DIM);
  }
  put(library_.fromSd() ? "梗資料：SD 卡 messages.json" : "梗資料：內建資料", Theme::TEXT);
  snprintf(line, sizeof(line), "分類 %u 個，文字梗 %u 則", library_.count(), library_.totalTexts());
  put(line, Theme::TEXT);
  snprintf(line, sizeof(line), "RAM 剩 %u KB，PSRAM 剩 %u KB",
           (unsigned)(heap_caps_get_free_size(MALLOC_CAP_INTERNAL) / 1024),
           (unsigned)(heap_caps_get_free_size(MALLOC_CAP_SPIRAM) / 1024));
  put(line, Theme::DIM);
  put("完全無聲：不使用喇叭", Theme::DIM);
  put("主畫面長按左鍵 = 資訊", Theme::DIM);
  put("主畫面長按中鍵 = 關機", Theme::DIM);
  put("主畫面長按右鍵 = 素材管理 / Wi-Fi", Theme::DIM);
  display_.fillRect(0, STATUS_Y, 240, 14, Theme::BG);
  drawKeyHints("返回", "重掛 SD", nullptr);
}

// ============================================================
// 序列埠指令
void App::pollSerial(uint32_t now) {
  while (Serial.available()) {
    const char c = (char)Serial.read();
    if (c == '\r') continue;
    if (c == '\n') {
      serialBuf_[serialLen_] = '\0';
      if (serialLen_) runCommand(serialBuf_, now);
      serialLen_ = 0;
    } else if (serialLen_ < sizeof(serialBuf_) - 1) {
      serialBuf_[serialLen_++] = c;
    }
  }
}

void App::runCommand(char *cmd, uint32_t now) {
  char *arg = strchr(cmd, ' ');
  if (arg) *arg++ = '\0';
  const bool sdCmd = strcmp(cmd, "sd") == 0 || strcmp(cmd, "ls") == 0 || strcmp(cmd, "jpg") == 0 ||
                     strcmp(cmd, "anim") == 0 || strcmp(cmd, "draw") == 0 || strcmp(cmd, "rm") == 0;
  if (sdCmd && sdLocked()) {
    Serial.println("busy: update in progress");
    return;
  }
  if (strcmp(cmd, "help") == 0) {
    Serial.println("status | sd | sd remount | ls <dir> | jpg <file> | anim <dir> | draw <1..n|all> | recent clear");
    Serial.println("wifi [scan] | wifi <ssid> <pass> | update check|download|cancel|status | approve all | rm <path>");
  } else if (strcmp(cmd, "wifi") == 0 && arg && strcmp(arg, "scan") == 0) {
    WiFi.disconnect();  // 連線重試中無法掃描；掃完由 WifiManager 自動重連
    delay(200);
    const int n = WiFi.scanNetworks();  // 阻塞約 2 秒 (除錯用)
    for (int i = 0; i < n && i < 20; i++)
      Serial.printf("  %-32s ch%-2d %d dBm\n", WiFi.SSID(i).c_str(), (int)WiFi.channel(i), (int)WiFi.RSSI(i));
    Serial.printf("scan: %d networks, WiFi.status()=%d\n", n, (int)WiFi.status());
    WiFi.scanDelete();
  } else if (strcmp(cmd, "wifi") == 0) {
    if (arg) {  // wifi <ssid> <pass>：存進 NVS，不回顯密碼
      char *pass = strrchr(arg, ' ');
      if (pass) *pass++ = '\0';
      const char *p = pass ? pass : "";
      if (WifiConfig::save(arg, p)) {
        wifi_.setCredentials(arg, p, now);
        Serial.printf("wifi saved, connecting to '%s'\n", arg);
      } else {
        Serial.println("wifi: ssid 1-32, password empty or 8-63");
      }
    }
    Serial.printf("wifi state %u, ip %s, ap %s\n", (unsigned)wifi_.state(), WiFi.localIP().toString().c_str(),
                  wifi_.apActive() ? wifi_.apSsid() : "off");
  } else if (strcmp(cmd, "approve") == 0 && arg && strcmp(arg, "all") == 0) {
    if (sdLocked()) {
      Serial.println("busy: update in progress");
      return;
    }
    manageItem_ = 4;
    enter(Screen::Manage, now);
    approveAll();  // 與素材管理的「全部核准」相同
  } else if (strcmp(cmd, "update") == 0 && arg) {
    if (strcmp(arg, "check") == 0) Serial.println(updater_.requestCheck() ? "check started" : "busy");
    else if (strncmp(arg, "download", 8) == 0) {  // update download [分類] [張數]
      char cat[16] = "";
      unsigned long count = Updater::BATCH;
      sscanf(arg + 8, "%15s %lu", cat, &count);
      if (strcmp(cat, "all") == 0) cat[0] = '\0';
      if (cat[0] >= '0' && cat[0] <= '9') {  // 只給張數
        count = strtoul(cat, nullptr, 10);
        cat[0] = '\0';
      }
      Serial.println(updater_.requestDownload(cat, count) ? "download started" : "not ready (run check first / no items)");
    }
    else if (strcmp(arg, "cancel") == 0) updater_.cancel();
    const Updater::Status st = updater_.status();
    Serial.printf("phase %u msg '%s' new %lu batch %lu est %llu KB | done %lu/%lu ok %lu fail %lu skip %lu bytes %llu at %s\n",
                  (unsigned)st.phase, st.msg, (unsigned long)st.newTotal, (unsigned long)st.batch, st.estDownload >> 10,
                  (unsigned long)st.done, (unsigned long)st.total, (unsigned long)st.ok, (unsigned long)st.failed,
                  (unsigned long)st.skipped, st.bytes, st.finishedAt);
    for (uint8_t i = 0; i < st.catN; i++) Serial.printf("  %s: %lu\n", st.cats[i].cat, (unsigned long)st.cats[i].n);
  } else if (strcmp(cmd, "rm") == 0 && arg) {
    // 只允許刪 /meme/ 與 /animation/ 底下的檔案，或只含檔案的資料夾
    if (!SdStorage::safePath(arg) || (strncmp(arg, "/meme/", 6) != 0 && strncmp(arg, "/animation/", 11) != 0)) {
      Serial.println("rm: only files under /meme/ or /animation/");
      return;
    }
    File f = sd_.fs().open(arg);
    if (!f) {
      Serial.println("rm: not found");
      return;
    }
    if (f.isDirectory()) {
      static char files[32][SdStorage::MAX_PATH];
      uint8_t n = 0;
      bool isDir = false, hasSub = false;
      for (;;) {
        String name = f.getNextFileName(&isDir);
        if (!name.length()) break;
        if (isDir) hasSub = true;
        else if (n < 32) strlcpy(files[n++], name.c_str(), sizeof(files[0]));
      }
      f.close();
      if (hasSub) {
        Serial.println("rm: directory has subdirectories, refused");
        return;
      }
      for (uint8_t i = 0; i < n; i++) sd_.fs().remove(files[i]);
      Serial.printf("rm %s: %u files, rmdir %s\n", arg, n, sd_.fs().rmdir(arg) ? "ok" : "failed");
      picker_.invalidate();
    } else {
      f.close();
      Serial.printf("rm %s: %s\n", arg, sd_.fs().remove(arg) ? "ok" : "failed");
      picker_.invalidate();
    }
  } else if (strcmp(cmd, "status") == 0) {
    Serial.printf("last result: image %lu ms, caption %lu ms\n", (unsigned long)timeImageMs_,
                  (unsigned long)timeCaptionMs_);
    Serial.printf("heap %u (min %u), psram %u, screen %u, sd %s err=%d, lib %s %u cats\n",
                  (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL),
                  (unsigned)heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL),
                  (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM), (unsigned)screen_,
                  sd_.mounted() ? sd_.cardTypeName() : "none", sd_.hasError(),
                  library_.fromSd() ? "SD" : "built-in", library_.count());
  } else if (strcmp(cmd, "sd") == 0) {
    if (arg && strcmp(arg, "remount") == 0) {
      // 重新載入梗資料前先回主畫面 (抽籤 / 結果畫面還指著舊資料)
      if (screen_ != Screen::Home && screen_ != Screen::Info) enter(Screen::Home, now);
      sd_.remount();
      library_.begin(sd_);
      picker_.invalidate();
      if (lastCat_ >= library_.count()) lastCat_ = 0;
    }
    Serial.printf("sd %s total %llu MB free %llu MB\n", sd_.cardTypeName(), sd_.totalBytes() >> 20,
                  sd_.freeBytes() >> 20);
  } else if (strcmp(cmd, "ls") == 0) {
    const char *dir = arg ? arg : "/";
    if (!sd_.mounted() || (strcmp(dir, "/") != 0 && !SdStorage::safePath(dir))) {
      Serial.println("ls: no SD or bad path");
      return;
    }
    File d = sd_.fs().open(dir);
    if (!d || !d.isDirectory()) {
      Serial.println("ls: not a directory");
      return;
    }
    bool isDir = false;
    for (int i = 0; i < 100; i++) {
      String name = d.getNextFileName(&isDir);
      if (!name.length()) break;
      if (isDir) {
        Serial.printf("  %s/\n", name.c_str());
      } else {
        File f = sd_.fs().open(name.c_str());
        Serial.printf("  %s  %u bytes\n", name.c_str(), f ? (unsigned)f.size() : 0u);
        if (f) f.close();
      }
    }
    d.close();
  } else if ((strcmp(cmd, "jpg") == 0 || strcmp(cmd, "anim") == 0) && arg) {
    if (!SdStorage::safePath(arg)) {
      Serial.println("bad path");
      return;
    }
    result_ = MemePick();
    result_.kind = cmd[0] == 'j' ? MemePick::Image : MemePick::Anim;
    strlcpy(result_.path, arg, sizeof(result_.path));
    result_.text = cmd[0] == 'j' ? "JPEG 顯示測試" : "動畫播放測試";
    result_.mood = Mood::Laugh;
    lastInput_ = now;
    enter(Screen::Result, now);
  } else if (strcmp(cmd, "draw") == 0 && arg) {
    const int n = atoi(arg);
    if (strcmp(arg, "all") == 0) {
      lastInput_ = now;
      startDraw(MemePicker::ALL, now);
    } else if (n >= 1 && n <= library_.count()) {
      lastInput_ = now;
      startDraw((uint8_t)(n - 1), now);
    } else {
      Serial.println("draw: bad category");
    }
  } else if (strcmp(cmd, "recent") == 0 && arg && strcmp(arg, "clear") == 0) {
    recent_.clear();
    Serial.println("recent cleared");
  } else {
    Serial.println("unknown command, try 'help'");
  }
}
