#pragma once
#include <stdint.h>

// 畫面版面常數 (240x240)，App.cpp 與 AppUpdate.cpp 共用
namespace Layout {
constexpr int16_t HEADER_H = 32;
constexpr int16_t CANVAS_Y = 36;    // 主畫面 / 召喚畫面的動畫區
constexpr int16_t STATUS_Y = 207;   // 動畫區下方一行小字
constexpr int16_t KEYBAR_Y = 224;   // 最下方按鍵提示
constexpr int16_t MEDIA_H = 168;    // 結果畫面上方的寵物動畫區 (文字梗)
constexpr int16_t PHOTO_H = 180;    // 結果畫面上方的圖片 / 動畫區 (240x180，4:3)
constexpr int16_t PHOTO_CAPTION_Y = 183;  // 有圖時的小字幕 (1 倍字，最多 3 行)
constexpr int16_t CAPTION_Y = 171;  // 結果畫面文字區
constexpr int16_t CAPTION_H = KEYBAR_Y - CAPTION_Y;
constexpr int16_t ROWS_Y = 38;
constexpr int16_t ROW_PITCH = 31;
constexpr int16_t ROW_H = 28;
constexpr uint8_t MENU_ROWS = 6;
}  // namespace Layout
using namespace Layout;
