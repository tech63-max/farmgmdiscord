#include "MemeLibrary.h"

#include <Arduino.h>
#include <Preferences.h>
#include <cJSON.h>
#include <esp_heap_caps.h>
#include <esp_random.h>

#include "DefaultMemes.h"

namespace {
constexpr uint8_t MAX_TEXTS = sizeof(MemeCategory::texts) / sizeof(MemeCategory::texts[0]);
constexpr size_t MAX_TEXT_BYTES = 400;
constexpr size_t MAX_NAME_BYTES = 64;

void *psramMalloc(size_t n) {
  void *p = heap_caps_malloc(n, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  return p ? p : malloc(n);
}

bool validId(const char *s) {
  if (s == nullptr || !*s) return false;
  size_t n = 0;
  for (; s[n]; n++) {
    const char c = s[n];
    if (!((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '_' || c == '-'))
      return false;
    if (n >= 15) return false;
  }
  return true;
}

bool validMediaDir(const char *s) {
  return SdStorage::safePath(s) && (strncmp(s, "/meme/", 6) == 0 || strncmp(s, "/animation/", 11) == 0);
}

Mood parseMood(const char *s) {
  static const struct { const char *name; Mood mood; } MAP[] = {
      {"mic", Mood::Mic}, {"broke", Mood::Broke}, {"confused", Mood::Confused}, {"rain", Mood::Rain},
      {"lazy", Mood::Lazy}, {"mask", Mood::Mask}, {"laugh", Mood::Laugh}, {"random", Mood::Random},
  };
  if (s != nullptr)
    for (const auto &m : MAP)
      if (strcmp(s, m.name) == 0) return m.mood;
  return Mood::Laugh;
}

const char *str(const cJSON *obj, const char *key) {
  const cJSON *v = cJSON_GetObjectItemCaseSensitive(obj, key);
  return cJSON_IsString(v) ? v->valuestring : nullptr;
}

bool hasImageExt(const char *path) {
  const char *dot = strrchr(path, '.');
  return dot && (strcasecmp(dot, ".jpg") == 0 || strcasecmp(dot, ".jpeg") == 0 || strcasecmp(dot, ".565") == 0);
}

Mood resolveMood(Mood m) {
  if (m != Mood::Random) return m;
  return (Mood)(MOOD_REACTION_FIRST + esp_random() % (MOOD_REACTION_LAST - MOOD_REACTION_FIRST + 1));
}
}  // namespace

uint32_t fnv1a(const char *s, uint32_t h) {
  while (*s) {
    h ^= (uint8_t)*s++;
    h *= 16777619u;
  }
  return h;
}

// ============================================================
// MemeLibrary
void MemeLibrary::begin(SdStorage &sd) {
  static bool hooked = false;
  if (!hooked) {  // cJSON 節點放 PSRAM，內部 RAM 留給 Wi-Fi / TLS
    cJSON_Hooks hooks = {psramMalloc, free};
    cJSON_InitHooks(&hooks);
    hooked = true;
  }
  if (root_) cJSON_Delete(root_);
  root_ = nullptr;
  free(raw_);
  raw_ = nullptr;
  fromSd_ = false;

  if (sd.mounted()) {
    sd.recover(PATH);
    if (!sd.exists(PATH)) {
      // 第一次使用：把內建資料寫到 SD 卡，之後可以直接改這個檔案擴充
      const bool ok = sd.writeAtomic(PATH, (const uint8_t *)DEFAULT_MEMES_JSON, strlen(DEFAULT_MEMES_JSON));
      Serial.printf("[Meme] write default %s: %s\n", PATH, ok ? "ok" : "failed");
    }
    size_t len = 0;
    raw_ = sd.readAll(PATH, MAX_JSON_BYTES, &len);
    if (raw_ == nullptr) Serial.printf("[Meme] read %s failed\n", PATH);
    if (raw_ != nullptr && load(raw_)) {
      fromSd_ = true;
      free(raw_);  // cJSON 已複製所有字串
      raw_ = nullptr;
      Serial.printf("[Meme] loaded %s: %u categories\n", PATH, count_);
      return;
    }
    free(raw_);
    raw_ = nullptr;
    // 檔案壞掉：改名保留 (messages.bad.json) 再寫回內建資料，不需要電腦也能恢復
    if (sd.exists(PATH)) {
      if (sd.exists(BAD_PATH)) sd.fs().remove(BAD_PATH);
      const bool moved = sd.fs().rename(PATH, BAD_PATH);
      Serial.printf("[Meme] %s invalid, moved to %s: %s\n", PATH, BAD_PATH, moved ? "ok" : "failed");
      if (moved && sd.writeAtomic(PATH, (const uint8_t *)DEFAULT_MEMES_JSON, strlen(DEFAULT_MEMES_JSON))) {
        raw_ = sd.readAll(PATH, MAX_JSON_BYTES, &len);
        if (raw_ != nullptr && load(raw_)) {
          fromSd_ = true;
          free(raw_);
          raw_ = nullptr;
          return;
        }
        free(raw_);
        raw_ = nullptr;
      }
    }
    Serial.printf("[Meme] using built-in data\n");
  }
  if (!load(DEFAULT_MEMES_JSON)) Serial.println("[Meme] built-in data invalid!");
}

bool MemeLibrary::load(const char *json) {
  count_ = 0;
  if (root_) cJSON_Delete(root_);
  root_ = cJSON_Parse(json);
  if (root_ == nullptr) {
    const char *err = cJSON_GetErrorPtr();
    Serial.printf("[Meme] JSON syntax error near byte %d, starts with %02X %02X %02X %02X\n",
                  err ? (int)(err - json) : -1, (uint8_t)json[0], (uint8_t)json[1],
                  (uint8_t)json[2], (uint8_t)json[3]);
    return false;
  }
  const cJSON *arr = cJSON_GetObjectItemCaseSensitive(root_, "categories");
  if (!cJSON_IsArray(arr)) {
    cJSON_Delete(root_);
    root_ = nullptr;
    return false;
  }
  const cJSON *c;
  cJSON_ArrayForEach(c, arr) {
    if (count_ >= MAX_CATEGORIES) break;
    const char *id = str(c, "id");
    const char *name = str(c, "name");
    if (!validId(id) || name == nullptr || !*name || strlen(name) > MAX_NAME_BYTES) {
      Serial.println("[Meme] skip category: bad id/name");
      continue;
    }
    MemeCategory &cat = cats_[count_];
    memset(&cat, 0, sizeof(cat));
    cat.id = id;
    cat.name = name;
    cat.mood = parseMood(str(c, "mood"));

    const cJSON *dirs = cJSON_GetObjectItemCaseSensitive(c, "dirs");
    const cJSON *d;
    cJSON_ArrayForEach(d, dirs) {
      if (cat.dirCount >= 4) break;
      if (cJSON_IsString(d) && validMediaDir(d->valuestring)) cat.dirs[cat.dirCount++] = d->valuestring;
      else Serial.printf("[Meme] %s: ignore unsafe dir\n", id);
    }

    const cJSON *texts = cJSON_GetObjectItemCaseSensitive(c, "texts");
    const cJSON *t;
    cJSON_ArrayForEach(t, texts) {
      if (cat.textCount >= MAX_TEXTS) break;
      const char *tid = str(t, "id");
      const char *text = str(t, "text");
      if (!validId(tid) || text == nullptr || !*text || strlen(text) > MAX_TEXT_BYTES) continue;
      cat.textIds[cat.textCount] = tid;
      cat.texts[cat.textCount] = text;
      cat.textCount++;
    }
    if (cat.textCount == 0 && cat.dirCount == 0) continue;  // 空分類
    count_++;
  }
  if (count_ == 0) {
    cJSON_Delete(root_);
    root_ = nullptr;
    return false;
  }
  return true;
}

uint16_t MemeLibrary::totalTexts() const {
  uint16_t n = 0;
  for (uint8_t i = 0; i < count_; i++) n += cats_[i].textCount;
  return n;
}

// ============================================================
// RecentStore
namespace {
constexpr const char *NVS_NS = "memeball";
constexpr const char *NVS_RECENT = "recent";
struct RecentBlob {
  uint8_t version;
  uint8_t pos;
  uint8_t count;
  uint32_t keys[RecentStore::SIZE];
};
}  // namespace

void RecentStore::begin() {
  Preferences p;
  if (!p.begin(NVS_NS, true)) return;
  RecentBlob b;
  if (p.getBytesLength(NVS_RECENT) == sizeof(b) && p.getBytes(NVS_RECENT, &b, sizeof(b)) == sizeof(b) &&
      b.version == 1 && b.pos < SIZE && b.count <= SIZE) {
    memcpy(keys_, b.keys, sizeof(keys_));
    pos_ = b.pos;
    count_ = b.count;
  }
  p.end();
}

bool RecentStore::contains(uint32_t key) const {
  for (uint8_t i = 0; i < count_; i++)
    if (keys_[(pos_ + SIZE - 1 - i) % SIZE] == key) return true;
  return false;
}

void RecentStore::push(uint32_t key) {
  keys_[pos_] = key;
  pos_ = (pos_ + 1) % SIZE;
  if (count_ < SIZE) count_++;
  save();
}

void RecentStore::clear() {
  count_ = pos_ = 0;
  save();
}

void RecentStore::save() {
  Preferences p;
  if (!p.begin(NVS_NS, false)) return;
  RecentBlob b{1, pos_, count_, {0}};
  memcpy(b.keys, keys_, sizeof(keys_));
  p.putBytes(NVS_RECENT, &b, sizeof(b));
  p.end();
}

// ============================================================
// MemePicker
void MemePicker::start(SdStorage &sd, const MemeLibrary &lib, uint8_t cat, const RecentStore &recent) {
  cancel();
  sd_ = &sd;
  lib_ = &lib;
  recent_ = &recent;
  all_ = cat == ALL;
  catCount_ = 0;
  if (all_) {
    for (uint8_t i = 0; i < lib.count(); i++) cats_[catCount_++] = i;
  } else if (cat < lib.count()) {
    cats_[catCount_++] = cat;
  }
  for (Pool &p : pools_) p = Pool();
  pick_ = MemePick();
  catPos_ = 0;
  dirIdx_ = 0;
  busy_ = true;
  startedAt_ = millis();
  for (DirCache &c : cache_) c.building = false;  // 上次沒掃完的不算
  // 文字梗直接全部丟進去 (不碰 SD)
  char key[48];
  for (uint8_t c = 0; c < catCount_; c++) {
    const MemeCategory &mc = lib.category(cats_[c]);
    for (uint8_t i = 0; i < mc.textCount; i++) {
      snprintf(key, sizeof(key), "t:%s:%s", mc.id, mc.textIds[i]);
      feed(MemePick::Text, mc.texts[i], fnv1a(key), cats_[c]);
    }
  }
}

void MemePicker::cancel() {
  if (dir_) dir_.close();
  busy_ = false;
  for (DirCache &c : cache_) c.building = false;  // 掃到一半的快取不可用
}

void MemePicker::invalidate() {
  for (DirCache &c : cache_) {
    c.valid = c.building = false;
    c.n = c.poolLen = 0;
  }
}

void MemePicker::cacheAdd(DirCache &c, const char *path, bool isAnim) {
  if (!c.building) return;
  const uint32_t len = strlen(path) + 2;  // 第 0 個字元記類型 ('A' / 'I')
  if (c.n + 1 > c.cap) {
    const uint32_t nc = c.cap ? c.cap * 2 : 256;
    uint32_t *p = (uint32_t *)heap_caps_realloc(c.off, nc * sizeof(uint32_t), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!p) { c.building = false; return; }
    c.off = p;
    c.cap = nc;
  }
  if (c.poolLen + len > c.poolCap) {
    uint32_t nc = c.poolCap ? c.poolCap * 2 : 16384;
    while (nc < c.poolLen + len) nc *= 2;
    char *p = (char *)heap_caps_realloc(c.pool, nc, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!p) { c.building = false; return; }
    c.pool = p;
    c.poolCap = nc;
  }
  c.off[c.n++] = c.poolLen;
  c.pool[c.poolLen] = isAnim ? 'A' : 'I';
  memcpy(c.pool + c.poolLen + 1, path, len - 1);
  c.poolLen += len;
}

void MemePicker::feed(MemePick::Kind kind, const char *pathOrText, uint32_t key, uint8_t cat) {
  // 單一分類：文字與圖片一起抽；全部模式：圖片 / 動畫另外一池，優先抽圖
  Pool &pool = pools_[(all_ && kind != MemePick::Text) ? 1 : 0];
  auto take = [&](MemePick &slot, uint32_t &n) {
    n++;
    if (esp_random() % n != 0) return;  // 水庫抽樣：每個候選被選中的機率相同
    slot.kind = kind;
    slot.key = key;
    slot.cat = cat;
    if (kind == MemePick::Text) {
      slot.text = pathOrText;
      slot.path[0] = '\0';
    } else {
      slot.text = nullptr;
      strlcpy(slot.path, pathOrText, sizeof(slot.path));
    }
  };
  take(pool.any, pool.anyN);
  if (key != recent_->last()) take(pool.notLast, pool.notLastN);
  if (!recent_->contains(key)) take(pool.fresh, pool.freshN);
}

bool MemePicker::step(uint32_t budgetMs) {
  if (!busy_) return true;
  const uint32_t t0 = millis();
  while (millis() - t0 < budgetMs) {
    if (!sd_->mounted() || catPos_ >= catCount_) {
      finish();
      return true;
    }
    const uint8_t cat = cats_[catPos_];
    const MemeCategory &mc = lib_->category(cat);
    DirCache &cache = cache_[cat];
    if (dirIdx_ == 0 && !dir_ && cache.valid) {  // 有快取：不碰 SD，直接從記憶體抽
      for (uint32_t i = 0; i < cache.n; i++) {
        const char *rec = cache.pool + cache.off[i];
        feed(rec[0] == 'A' ? MemePick::Anim : MemePick::Image, rec + 1, fnv1a(rec + 1), cat);
      }
      catPos_++;
      continue;
    }
    if (dirIdx_ == 0 && !dir_ && !cache.building) {  // 開始重建這個分類的快取
      cache.n = cache.poolLen = 0;
      cache.building = true;
    }
    if (dirIdx_ >= mc.dirCount) {  // 這個分類的資料夾都掃完了
      if (cache.building) {
        cache.building = false;
        cache.valid = true;
      }
      catPos_++;
      dirIdx_ = 0;
      continue;
    }
    if (!dir_) {
      dir_ = sd_->fs().open(mc.dirs[dirIdx_]);
      if (!dir_ || !dir_.isDirectory()) {
        if (dir_) dir_.close();
        dirIdx_++;
        continue;
      }
    }
    bool isDir = false;
    String name = dir_.getNextFileName(&isDir);
    if (name.length() == 0) {  // 這個資料夾掃完了
      dir_.close();
      dirIdx_++;
      continue;
    }
    // 不合規的檔名 (中文、空白、.隱藏檔、_pending 等) 一律略過
    const char *path = name.c_str();
    const char *base = strrchr(path, '/');
    base = base ? base + 1 : path;
    if (base[0] == '_' || !SdStorage::safePath(path) || name.length() >= SdStorage::MAX_PATH) continue;
    if (isDir) {
      feed(MemePick::Anim, path, fnv1a(path), cat);
      cacheAdd(cache, path, true);
    } else if (hasImageExt(path)) {
      feed(MemePick::Image, path, fnv1a(path), cat);
      cacheAdd(cache, path, false);
    }
  }
  return false;
}

void MemePicker::finish() {
  if (dir_) dir_.close();
  busy_ = false;
  scanMs_ = millis() - startedAt_;
  const Pool &p = (all_ && pools_[1].anyN) ? pools_[1] : pools_[0];
  if (p.freshN) pick_ = p.fresh;
  else if (p.notLastN) pick_ = p.notLast;
  else pick_ = p.any;
  if (pick_.kind == MemePick::None) return;
  const MemeCategory &mc = lib_->category(pick_.cat);
  pick_.mood = resolveMood(mc.mood);
  if (pick_.kind != MemePick::Text) {  // 圖片 / 動畫：隨機配一句同分類的文字
    pick_.text = mc.textCount ? mc.texts[esp_random() % mc.textCount] : mc.name;
  }
}
