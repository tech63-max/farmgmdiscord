#pragma once
#include <FS.h>
#include <stddef.h>
#include <stdint.h>

#include "../pet/Mood.h"
#include "../storage/SdStorage.h"

struct cJSON;

struct MemeCategory {
  const char *id;
  const char *name;
  Mood mood;
  const char *dirs[4];
  uint8_t dirCount;
  const char *textIds[64];
  const char *texts[64];
  uint8_t textCount;
};

// 梗資料庫：讀 SD:/fortune/messages.json，失敗時用內建資料
class MemeLibrary {
 public:
  static constexpr uint8_t MAX_CATEGORIES = 16;
  static constexpr const char *PATH = "/fortune/messages.json";
  static constexpr const char *BAD_PATH = "/fortune/messages.bad.json";
  static constexpr size_t MAX_JSON_BYTES = 256 * 1024;

  void begin(SdStorage &sd);
  uint8_t count() const { return count_; }
  const MemeCategory &category(uint8_t i) const { return cats_[i < count_ ? i : 0]; }
  bool fromSd() const { return fromSd_; }
  uint16_t totalTexts() const;

 private:
  bool load(const char *json);

  cJSON *root_ = nullptr;
  char *raw_ = nullptr;
  MemeCategory cats_[MAX_CATEGORIES];
  uint8_t count_ = 0;
  bool fromSd_ = false;
};

// 近期抽取紀錄 (NVS)：最近 48 次抽到的項目雜湊，用來避免重複
class RecentStore {
 public:
  static constexpr uint8_t SIZE = 48;
  void begin();
  bool contains(uint32_t key) const;
  uint32_t last() const { return count_ ? keys_[(pos_ + SIZE - 1) % SIZE] : 0; }
  void push(uint32_t key);
  void clear();

 private:
  void save();
  uint32_t keys_[SIZE] = {0};
  uint8_t pos_ = 0;
  uint8_t count_ = 0;
};

struct MemePick {
  enum Kind : uint8_t { None, Text, Image, Anim } kind = None;
  char path[SdStorage::MAX_PATH] = {0};  // Image: 檔案；Anim: 資料夾
  const char *text = nullptr;             // 搭配文字
  Mood mood = Mood::Idle;
  uint32_t key = 0;
  uint8_t cat = 0;  // 抽到的項目屬於哪個分類
};

// 抽籤：文字梗 + SD 資料夾內的圖片 / 動畫一起抽，避開近期抽過的。
// 掃描資料夾是分段進行 (step 每次只做幾毫秒)，水晶球動畫不會卡住。
// 每個分類第一次掃完就把檔案清單快取在 PSRAM，之後抽籤不碰 SD (上千張也很快)；
// SD 內容有變 (核准 / 刪除 / 下載 / 重新掛載) 時呼叫 invalidate()。
class MemePicker {
 public:
  static constexpr uint8_t ALL = 0xFF;  // 從全部分類一起抽

  void start(SdStorage &sd, const MemeLibrary &lib, uint8_t cat, const RecentStore &recent);
  bool step(uint32_t budgetMs);  // true = 抽完了
  bool busy() const { return busy_; }
  const MemePick &result() const { return pick_; }
  void cancel();
  void invalidate();  // 丟掉所有分類的檔案清單快取
  uint32_t lastScanMs() const { return scanMs_; }

 private:
  void feed(MemePick::Kind kind, const char *pathOrText, uint32_t key, uint8_t cat);
  void finish();
  struct DirCache {  // 一個分類的媒體檔清單 (路徑字串池 + 位移)
    char *pool = nullptr;
    uint32_t poolLen = 0, poolCap = 0;
    uint32_t *off = nullptr;
    uint32_t n = 0, cap = 0;
    bool valid = false;
    bool building = false;
  };
  void cacheAdd(DirCache &c, const char *path, bool isAnim);

  SdStorage *sd_ = nullptr;
  const MemeLibrary *lib_ = nullptr;
  const RecentStore *recent_ = nullptr;
  uint8_t cats_[MemeLibrary::MAX_CATEGORIES] = {0};  // 要掃的分類
  uint8_t catCount_ = 0;
  uint8_t catPos_ = 0;
  File dir_;
  uint8_t dirIdx_ = 0;
  bool busy_ = false;
  bool all_ = false;
  // 三個水庫抽樣：沒抽過的 / 不是上一次的 / 任何一個。pools_[0] = 文字 (單一分類時也含圖)，[1] = 全部模式的圖片 / 動畫
  struct Pool {
    MemePick fresh, notLast, any;
    uint32_t freshN = 0, notLastN = 0, anyN = 0;
  } pools_[2];
  MemePick pick_;
  DirCache cache_[MemeLibrary::MAX_CATEGORIES];
  uint32_t startedAt_ = 0, scanMs_ = 0;
};

uint32_t fnv1a(const char *s, uint32_t h = 2166136261u);
