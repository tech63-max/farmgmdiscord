// MyGO!!!!! 梗圖發射器 — 進入點
// 板子：Waveshare ESP32-S3-LCD-1.54 (ST7789 240x240, microSD SDMMC)
#include <Arduino.h>

#include "app/App.h"

namespace {
App app;  // 全部模組皆為靜態配置
}

void setup() { app.begin(); }

void loop() {
  app.loop();
  delay(4);  // 讓出 CPU；動畫皆以 millis() 計時
}
