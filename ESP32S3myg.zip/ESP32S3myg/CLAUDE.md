# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project

"MyGO!!!!! 梗圖發射器" (MemeBall): a standalone meme fortune-ball device for the **Waveshare ESP32-S3-LCD-1.54** (non-touch, ST7789 240x240 SPI, 8MB OPI PSRAM, 16MB flash, microSD on SDMMC 4-bit, no RTC). Arduino framework; `ESP32S3myg.ino` is an empty stub, all code is under `src/` (Arduino compiles it recursively). `README.md` is the user-facing doc (Traditional Chinese) — keep it in sync when buttons, SD layout, formats or serial commands change. Reply to the user in Traditional Chinese.

This is **not** the desk-pet project (`C:\Users\tech63\Desktop\ESP32S3`); `display/`, `input/ButtonManager`, `assets/Font12`, `LargeAlloc/Theme` and `net/WifiManager` were copied from it. Reuse pet modules only when actually needed.

## Build / flash / verify

```
arduino-cli compile --fqbn "esp32:esp32:esp32s3:CDCOnBoot=cdc,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB" --warnings default --upload -p COM6 .
```

- Toolchain: Arduino-ESP32 core **3.3.12**, GFX Library for Arduino **1.6.9**. PNGdec 1.1.6 is **vendored** in `src/third_party/PNGdec` (`PNG_MAX_BUFFERED_PIXELS` raised to 1920 px; `png.inl` renamed `png_inl.h` because Arduino does not copy `.inl`; PNGDisplay removed) — do not install the global PNGdec library. JPEG uses the ESP32-S3 **ROM TJpgDec** (`rom/tjpgd.h`, RGB888 output, old `jd_prepare/jd_decomp` API); JSON uses the core's bundled **cJSON**. App is ~74% of the 3MB partition (Font12 ≈ 0.9MB, Wi-Fi/TLS/PNG ≈ 0.9MB).
- No unit tests. Verification = zero-warning compile + drive the board over USB serial (115200, pyserial) and read logs. **Open the port with `dtr=False; rts=False` set before `open()`**, otherwise opening it resets the board (this once silently killed a running download); reset deliberately with `rts=True→False`. Serial commands (`help`): `status` (heap + last result image/caption ms), `sd [remount]`, `ls <dir>`, `jpg <file>` (JPEG or `.565`), `anim <dir>`, `draw <1..n|all>`, `recent clear`, `wifi [scan]`, `wifi <ssid> <pass>` (saved to NVS, not echoed), `update check|cancel|status`, `update download [cat|all] [count]`, `approve all`, `rm <path>` (only under `/meme/`, `/animation/`). Downloads take ~9 s per image.
- The screen cannot be observed — say so instead of claiming visual results.
- Flashing overwrites whatever firmware is on the board; confirm with the user first.
- `python tools/make_test_sd.py` generates original test assets into `sdcard_test/` (copy to the card root by hand; they were deleted from the user's card).
- When patching C++ from a bash heredoc, `\n` inside string literals becomes a real newline in this environment; write a Python patch script to a file (or use Edit) instead.

## Architecture

- `App` (`src/app/App.cpp`, update/Wi-Fi screens in `src/app/AppUpdate.cpp`, shared constants in `Layout.h`) is the only orchestrator: owns all modules, a `Screen` state machine (`enter()` redraws, `loop()` advances; `updateButton`/`updateUpdateScreens` handle the AppUpdate screens), and the serial console. Everything is non-blocking and `millis()`-driven; animated screens redraw the `PixelCanvas` every 70 ms.
- Buttons left→right are **BOOT (GPIO0), PWR (GPIO5), PLUS (GPIO4)**; `drawKeyHints(left, mid, right)` follows that order. Menus: BOOT = select, PWR = up, PLUS = down, long press = back. Home: BOOT = category menu (long = Info), PWR = draw from all categories (long = power off, GPIO2 latch LOW), PLUS = draw last category (long = 素材管理 menu, whose first item is "Wi-Fi 連線").
- Rendering: `PixelCanvas` is 120x84 logical px ×2 (240x168, PSRAM). `PetRenderer` draws everything procedurally (idle, 7 `Mood` reactions, crystal-ball summon) — no sprite assets. UTF-8 text goes through `DisplayManager::utf8*` (Cubic 11 pixel font, integer scale 1–2 only); any new UI string must use glyphs in `FONT12_CODES` (e.g. `✓` and U+3000 are missing).
- Result screen: a photo/animation fills `PHOTO_H`=240x180 and the caption goes in the 44 px box below via `utf8Box` (centered; 2x if it fits on one line, else 1x up to 3 lines). Text-only results show the 168 px pet reaction + large text.
- Draw flow: `startDraw()` → `MemePicker::start()` feeds all text items, then `step()` scans the category's SD dirs incrementally (≤6 ms per loop) during the ≥1.5 s summon. Each category's media list is cached in PSRAM after the first scan; call `picker_.invalidate()` whenever category folders change (approve/reject, `rm`, remount, library reload). Selection is reservoir sampling in three tiers (not in `RecentStore` → not the last pick → any); "all" mode (`MemePicker::ALL`) uses a separate media pool and falls back to texts only when there is no media. `RecentStore` is a 48-entry FNV-1a ring in NVS namespace `memeball`.
- Media in a category dir: `*.jpg/*.jpeg` (baseline JPEG), `*.565` (downloaded screenshots), or a subdirectory with `000.jpg…` (+ optional `anim.json {"fps":n}`) = animation. Names must pass `SdStorage::safePath` (ASCII `A-Za-z0-9_-.`, no `..`/dot segments); entries starting with `_` (e.g. `/meme/_pending`) are skipped. GIF playback/conversion is not implemented.
- `MemeLibrary` loads `/fortune/messages.json` (categories: `id`, `name`, `mood`, `dirs` restricted to `/meme/` or `/animation/`, `texts[{id,text}]`; limits 16 categories / 64 texts / 400 bytes). Missing → writes `DefaultMemes.h` JSON to SD; invalid → renames to `messages.bad.json` and rewrites the default; no SD → built-in JSON. The cJSON tree (PSRAM hooks) stays alive and categories point into it, so **don't reload the library while a pick/result is in use** — go to Home first.
- Update system (`src/update/`): `Updater` runs a FreeRTOS task (core 0, 16KB stack) fed by a queue. `requestCheck()` lists sources and diffs against `MemeIndex` (no image download); `requestDownload(cat, count)` fetches up to `count` (≤1000, default 20) shuffled new items, optionally one category (matching items are swapped into the consumed prefix `[0, newStart_)`). Per item: `Http::get` (esp_http_client + `esp_crt_bundle_attach`, into PSRAM) → PNG signature check → SHA-256 dedupe → PNGdec decode with streaming box filter, center-cropped to 4:3 → 240x180 → `/system/download_cache/<id>.tmp` → size check → rename to `/meme/_pending/<cat>/<id>.565`. `MemeIndex` (`/index/meme_index.json`, states pending/approved/rejected/duplicate) is saved every 10 items and on review actions via `writeAtomic`. Sources implement `Collector` and are registered in `COLLECTORS` in `Updater.cpp` (currently only `MygoSearcherCollector`: classification by source folder + subtitle keywords 春日影/祥/迷).
- `.565` = 12-byte header (`M565`, w, h, captionLen) + UTF-8 caption + RGB565 LE. New files are 240x180, older ones 240x135; `RawView::draw` cover-scales (nearest neighbour, center crop) into the box and returns the embedded caption, which replaces the random category text.
- While `updater_.busy()` the task owns the SD card: `App::sdLocked()` blocks draws, remounts and SD serial commands, and the Check/Download screens only allow cancel. The task uses its own static buffers (`Http` net buffer, `wbuf` in `downloadOne`); `SdStorage::ioBuf` is main-thread only.
- Wi-Fi: credentials live in NVS (`WifiConfig`). The setup hotspot is **never opened automatically** (user decision) — only `Screen::WifiSetup` starts it; leaving the screen stops it unless a connection is in progress. `WebPanel` serves the Wi-Fi form only to clients on the hotspot (`fromSetupAp()`); LAN clients get a read-only status page. NTP (`CST-8`) starts on first connect, for update timestamps.

## Constraints and gotchas

- **Completely silent** (user decision): never initialize I2S/ES8311/ES7210; `AMP_CTRL` (GPIO7) is set LOW at boot and must never go HIGH.
- **Never format the SD card** (`format_if_mount_failed=false`); the user's card holds other data. SDMMC runs at 20 MHz, pins from Waveshare's `bsp_sdcard.h` (CLK16 CMD15 D0 17 D1 18 D2 13 D3 14).
- **SD reads/writes must go through internal-RAM, aligned buffers** (chunked memcpy). Verified on hardware: FATFS hands full-sector buffers straight to DMA, and writing from a flash `const` string produced a file full of zeros; PSRAM targets have cache-alignment risk too.
- Replace files with `SdStorage::writeAtomic()` (`.tmp` → size check → old file to `.bak` → rename) and call `recover()` at boot; FAT `rename` won't overwrite.
- `DisplayManager::pushRgb` must take a **non-const** `uint16_t*`: a const pointer selects Arduino_GFX's PROGMEM `draw16bitRGBBitmap` overload, and images stayed black (confirmed fixed by switching).
- `Serial.setTxTimeoutMs(0)` in `App::begin` is required: with USB plugged in but no host reading, HWCDC writes otherwise block up to 20 x 100 ms each (visibly delayed captions). Keep `Serial` logging out of the middle of screen drawing (`showResult` prints one summary line afterwards).
- TJpgDec is baseline-only (progressive → `DecodeFail`); formats are checked by magic bytes, not extension. Large JPEGs are slow (960x672 ≈ 560 ms, blocking once).
- `JpegView` does not mark SD errors on open failure; callers decide. `App::maybeRecoverSd` remounts on Home entry only after an error, at most every 15 s.
- USB-CDC RX buffer is small (~256 B): bulk serial transfers to the board need ≤128-byte chunks with ACKs.
- Compare `millis()` timestamps with signed differences (`(int32_t)(now - t)`).
- User rules for updates: only on button press (separate "check" and "download"); verify HTTPS certs; no hard-coded API keys or Wi-Fi passwords; unclear-license material (mygo-searcher anime screenshots) goes to `/meme/_pending/` with source/license/URL and is approved on the device (per item, or "全部核准" with a two-press confirm); keep old assets when a download fails; no PC-side management tool.
