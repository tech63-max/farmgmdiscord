# MyGO!!!!! 梗圖發射器（ESP32-S3 MemeBall）

獨立的「梗占卜球」裝置：選一個梗分類 → 寵物召喚水晶球（旋轉、發光、冒泡）→ 抽出一則文字梗、梗圖或逐格動畫，寵物做出對應反應。**完全無聲**（不初始化喇叭、I2S、ES8311、麥克風；功放腳開機即拉 LOW）。

目前完成：**第一階段（SD 卡）＋第二階段（占卜球、文字梗、動畫）＋第三階段（Wi-Fi 手動檢查更新 / 下載 / 核准）**。

## 硬體

**Waveshare ESP32-S3-LCD-1.54**（無觸控版）

| 項目 | 規格 / 腳位 |
|---|---|
| MCU | ESP32-S3R8，8MB PSRAM，16MB Flash |
| 螢幕 | 1.54" IPS 240x240 ST7789，SPI：DC=45 CS=21 SCK=38 MOSI=39 RST=40 BL=46 |
| 按鍵 | BOOT=GPIO0（左）、PWR=GPIO5（中）、PLUS=GPIO4（右），按下為 LOW |
| microSD | SDMMC 4-bit：CLK=16 CMD=15 D0=17 D1=18 D2=13 D3=14，20 MHz |
| 電源 | GPIO2 = 電池供電鎖定（開機拉 HIGH，拉 LOW = 關機） |
| 喇叭功放 | GPIO7，永遠 LOW（不出聲） |
| RTC | 沒有（所以目前沒有時鐘 / 夜間模式，需等 Wi-Fi 對時） |

腳位來源：官方 repo `waveshareteam/ESP32-S3-Touch-LCD-1.54`（`ESP-IDF-5.5.1/01_factory/components/esp_bsp/bsp_sdcard.h`、Arduino 範例 `07_sd_card_test`）。

## 燒錄

- ESP32 開發板套件 **3.3.12**、函式庫 **GFX Library for Arduino 1.6.9**（不需要其他函式庫：JPEG 用 ESP32-S3 ROM 內建的 TJpgDec，JSON 用核心內建 cJSON，PNG 用內附的 PNGdec 1.1.6（`src/third_party/PNGdec`，Apache-2.0，已把行緩衝放大到 1920 px））
- 開發板 ESP32S3 Dev Module、USB CDC On Boot = Enabled、Flash 16MB、PSRAM = OPI、Partition = 16M Flash (3MB APP/9.9MB FATFS)

```bash
arduino-cli compile --fqbn "esp32:esp32:esp32s3:CDCOnBoot=cdc,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB" --warnings default --upload -p COM6 .
```

目前程式大小 2.32 MB / 3 MB（73%），其中約 0.9 MB 是中文像素字型 Font12（Cubic 11，OFL 授權，見 `licenses/`）。

## 操作

| 畫面 | 左鍵 (BOOT) | 中鍵 (PWR) | 右鍵 (PLUS) |
|---|---|---|---|
| 主畫面（寵物眨眼、左右看、偶爾跳） | 分類選單；**長按 = 資訊** | **從全部分類抽一張圖**；**長按 = 關機** | 用上次的分類抽；**長按 = 素材管理** |
| 分類選單 | 選擇並抽 | 上 | 下（任一鍵長按 = 返回） |
| 水晶球占卜中（約 1.5 秒） | 取消 | | |
| 結果 | 返回 | 換分類 | 再抽一次（沿用上次是「全部」還是單一分類） |
| 資訊 | 返回 | 重新掛載 SD 卡 | |

- 「全部抽」只抽 SD 卡上所有分類的圖片 / 逐格動畫（同樣避開近期抽過的）；SD 卡上完全沒有圖時，改從全部文字梗抽。搭配的文字與寵物反應取自該圖所屬的分類。
- 結果畫面 25 秒沒操作自動回主畫面；任何畫面 90 秒沒操作螢幕調暗，按任一鍵（第一下只負責點亮）恢復。
- 抽籤會避開最近 48 次抽過的內容（記錄在 NVS，重開機仍有效），全部抽過才會重複，且絕不連續抽到同一則。

### 分類與寵物反應

| 分類 | 素材資料夾 | 寵物反應 |
|---|---|---|
| MyGO 經典梗 | /meme/mygo/classic | 拿麥克風開心跳、飄音符 |
| 祥子梗 | /meme/mygo/saki | 空錢包、冒汗、蛾飛出來 |
| 迷子梗 | /meme/mygo/maigo | 左右走動、頭上問號 |
| 春日影梗 | /meme/mygo/haruhikage | 烏雲下雨、低落（無聲） |
| 上班摸魚梗 | /meme/work | 趴睡 ↔ 假裝打筆電 |
| Ave Mujica 梗 | /meme/mygo/ave_mujica | 假面、閃光 |
| 一般搞笑梗 | /meme/funny | 笑到發抖噴淚 |
| GIF 動態表情包 | /meme/reaction | 笑到發抖 |
| 寵物搞笑動畫 | /animation/happy、funny、confused、sleepy | 隨機 |

每個分類內建 15～16 則文字梗（共 142 則）。寵物與水晶球都是程式繪製的原創像素圖，不需要圖檔。

## SD 卡

- 需 FAT32（32GB 以下的 SDHC 出廠通常就是）。**掛載失敗不會自動格式化**，不會動到卡上其他資料。
- 開機時自動建立資料夾：`/meme/...`、`/animation/...`、`/fortune`、`/index`、`/system/download_cache`、`/meme/_pending`（第三階段給授權待確認的素材用，抽籤會略過底線開頭的資料夾）。
- 沒有 SD 卡也能用：改用內建文字梗。

### 梗資料 `/fortune/messages.json`

第一次開機會把內建資料寫到這裡，之後直接改這個檔案就能新增分類 / 文字梗（分類最多 16 個、每分類文字最多 64 則、每則最多 400 bytes、檔案最大 256 KB）。

```json
{"version":1,"categories":[
  {"id":"classic","name":"MyGO 經典梗","mood":"mic","dirs":["/meme/mygo/classic"],
   "texts":[{"id":"c01","text":"一輩子、一輩子、一輩子……"}]}
]}
```

- `mood`：mic / broke / confused / rain / lazy / mask / laugh / random
- `dirs` 只接受 `/meme/` 或 `/animation/` 底下、由英數 `_-.` 組成的路徑（防路徑穿越）
- 檔案格式錯誤時：改名保留為 `messages.bad.json`，並寫回內建資料（不需要電腦也能恢復）

### 圖片與動畫格式

| 類型 | 放法 | 限制 |
|---|---|---|
| 靜態圖 | 分類資料夾內的 `*.jpg` / `*.jpeg` | **baseline JPEG**（不支援 progressive）、≤ 2 MB、邊長 ≤ 4096；自動 1/1～1/8 縮小置中到 240x168 |
| 逐格動畫 | 分類資料夾內的子資料夾，放 `000.jpg`、`001.jpg`…（最多 300 格），可選 `anim.json` `{"fps": 8}`（1～15） | 每格建議剛好 240x168 |

- 檔名只能用英數 `_-.`，其他檔名會被略過。
- 用檔頭 magic bytes 判斷 JPEG，不信任副檔名。
- 圖片串流解碼，只用約 4 KB 工作區加一條 240x16 的列緩衝，不會把整張圖載入 RAM；動畫每格直接從 SD 讀。
- **GIF 不直接播放**：第三階段下載時會先轉成逐格 JPEG。
- SD 讀取失敗（拔卡、檔案損壞）時改顯示寵物反應和提示文字，不會卡住；回主畫面時自動嘗試重新掛載。

## 序列埠指令（115200）

`status`、`sd`、`sd remount`、`ls <dir>`、`jpg <file>`（顯示測試，也可顯示 .565）、`anim <dir>`（動畫測試）、`draw <1..n|all>`（模擬抽籤，all = 全部抽）、`recent clear`、`wifi`、`wifi scan`、`wifi <ssid> <pass>`（存進 NVS，不回顯密碼）、`update check|cancel|status`、`update download [分類|all] [張數]`、`approve all`、`rm <path>`（只能刪 /meme、/animation 底下）

> 用 pyserial 開序列埠前要先設 `dtr=False; rts=False` 再 `open()`，否則開埠會重開板子。

## 測試素材

`python tools/make_test_sd.py` 會在 `sdcard_test/` 產生原創測試圖（240x168、960x672、4 格動畫、一個假的 .jpg 壞檔），複製到 SD 卡根目錄即可驗證。這只是開發測試用，正式素材由第三階段的裝置端下載取得。

## 實測紀錄（2026-11-09，16GB SDHC 卡）

| 項目 | 結果 |
|---|---|
| SD 掛載 / 建立資料夾 | 正常（SDHC，15892 MB） |
| 寫入 messages.json / 重開機讀回 | 正常（修正後，見下方） |
| 壞 JSON 自動改名並恢復 | 正常 |
| JPEG 240x168 | 正常，72 ms |
| JPEG 960x672（1/4 縮小） | 正常，563 ms（大圖會讓畫面停頓約半秒，第三階段下載時應先縮圖） |
| 假 .jpg 壞檔 | 正確拒絕（not a JPEG） |
| 不存在的檔案 | 安全失敗 |
| 4 格動畫 6 fps | 正常 |
| 抽籤避免重複 | 16 個候選抽 17 次：前 16 次全不同、0 次連續重複；有抽到 SD 圖片與動畫 |
| 記憶體 | 內部 RAM 剩約 322 KB（最低 308 KB），PSRAM 剩約 8.2 MB |

**畫面效果（動畫、文字排版、按鍵）沒有被自動驗證**（看不到螢幕），需要實機目視確認。

已知問題（已改，**待實機目視確認**）：圖片解碼成功（像素值正確）但螢幕全黑——`DisplayManager::pushRgb` 原本傳 `const uint16_t*`，會選到 Arduino_GFX 給 PROGMEM 用的 const 版 `draw16bitRGBBitmap`；改成非 const，和畫布 / 文字走同一條已驗證的路徑。

已知問題（已修正）：FATFS 寫入整個磁區時會直接拿呼叫端指標做 DMA，來源是 Flash 常數字串時，寫進卡裡的內容全是 0。現在所有 SD 讀寫都經過內部 RAM 的對齊緩衝區（`SdStorage.cpp` 的 `ioBuf`）。第三階段的下載也必須走這條路徑。

## 程式架構

```
src/
├── main.cpp                 setup() / loop()
├── app/App.*                唯一的調度者：畫面狀態機、按鍵、序列埠指令
├── config/BoardConfig.h     腳位
├── display/                 ST7789、像素畫布 (120x84 邏輯像素 ×2)、UTF-8 文字
├── input/ButtonManager.*    三鍵防抖、短按 / 長按
├── storage/SdStorage.*      SD 掛載、safePath、writeAtomic (.tmp → 正式檔，.bak 斷電還原)
├── media/JpegView.*         ROM TJpgDec 串流解碼
├── media/AnimPlayer.*       逐格 JPEG 動畫，每次 update 最多解一格
├── meme/MemeLibrary.*       JSON 載入驗證、近期紀錄 (NVS)、分段掃描的水庫抽樣
├── meme/DefaultMemes.h      內建梗資料 (JSON)
├── pet/PetRenderer.*        程式繪製的寵物、7 種反應、水晶球
└── assets/Font12.*          中文像素字型 (由桌寵專案沿用)
```

全部非阻塞，以 `millis()` 驅動；抽籤時掃描 SD 資料夾每圈最多 6 ms，水晶球動畫不會卡住。

## 第三階段：手動素材更新

**只有按鍵才會動作，沒有任何排程或背景自動下載。** 主畫面長按右鍵進「素材管理」：

| 選項 | 動作 |
|---|---|
| 檢查更新 | 連網查詢各來源清單、跟 `/index/meme_index.json` 比對，顯示各分類新增數量與預估容量。**不下載圖片** |
| 立即下載 | 使用者確認後才下載。檢查結果畫面：中鍵換分類（全部 / 各分類）、長按右鍵換張數（20 / 100 / 500 / 1000），右鍵開始；顯示分類、檔名、進度、成功 / 失敗 / 略過；可隨時取消 |
| 逐張核准 | 看圖與字幕：右鍵核准（移到分類資料夾）、中鍵刪除（記為 rejected，不再下載） |
| 全部核准 | 一次核准所有待核准素材；需要按兩次左鍵確認 |
| 查看素材數量 | 各分類已核准 / 待核准張數 |
| Wi-Fi 連線（選單第一項） | 按了才開 `MemeBall-XXXX` 設定熱點，畫面顯示熱點名稱、密碼與步驟；手機連上後自動跳出設定頁。按返回關熱點；設定成功連上後約 20 秒自動關。**不會自動開熱點** |

- 來源：`MygoSearcherCollector`（mygo-searcher 網站使用的公開清單 API + S3，約 4200 張 MyGO、2800 張 Ave Mujica 截圖）。檔名就是字幕，抽到時直接顯示這句字幕。新增來源只要實作 `Collector` 並加進 `Updater.cpp` 的 `COLLECTORS`。
- 分類依 metadata：Ave Mujica 資料夾 → Ave Mujica 梗；MyGO 字幕含「春日影」→ 春日影、含「祥」→ 祥子、含「迷」→ 迷子，其餘 → MyGO 經典。不認得的來源資料夾 → 未分類（核准後放 /meme/funny）。
- 截圖授權不明（MIT 只涵蓋網站程式碼），所以先放 `/meme/_pending/<分類>/`，核准後才會被抽到；索引保留來源、授權說明、來源網址、SHA-256。
- 下載後在裝置上用 PNGdec 解碼、置中裁成 4:3（左右各裁約 12%）再縮成 240x180，存成 `.565`（RGB565 + 內嵌字幕），播放時不需解碼。舊的 240x135 檔顯示時會放大約 1.33 倍並置中裁切（最近鄰）。
- 結果畫面：有圖時圖片佔 240x180，字幕用 1 倍字（最多 3 行）；純文字梗維持寵物動畫 + 大字。
- 安全：HTTPS 用 ESP-IDF 內建 CA 憑證包驗證；只看 PNG 檔頭判斷格式；SHA-256 去重；單張 ≤ 3 MB、單次 ≤ 1000 張 / 2000 MB、SD 至少保留 256 MB；連續 5 張失敗就停止（失敗後等 5 秒）；暫存檔寫完並確認大小才改名；索引每 10 張存一次（writeAtomic）；錯誤記錄在 `/system/update_log.txt`。
- 下載期間由更新工作獨占 SD：只能看進度或取消；主迴圈動畫、按鍵照常。沒 Wi-Fi / 斷線 / 空間不足會停止並保留已下載的素材。
- 網頁 `http://memeball.local/`：一般網路只看得到唯讀狀態；Wi-Fi 設定表單只在連到板子熱點時提供。

### 第三階段實測（2026-11-09，SSID test）
- 檢查更新：7029 筆，7028 筆新（avemujica 2811、classic 4091、saki 69、maigo 42、haruhikage 15），約 20 秒。
- 下載：每張原圖約 770 KB、約 8～10 秒（下載 + 解碼 + 縮圖），轉存後每張約 64.8 KB；過程 0 失敗。
- 中途重開機（意外的斷電測試）：已下載的 15 張與索引一致，沒有暫存檔殘留。
- 全部核准：15 張全部移到分類資料夾，「全部抽」抽得到。
- 指定分類下載：`update download classic 100` → 100 張全部成功、72 MB、約 15 分鐘（約 9 秒 / 張）；全部核准 100 張 0 失敗。
- 抽籤速度：每個分類第一次抽會掃 SD（107 張的資料夾約 150 ms），之後用 PSRAM 快取約 40～75 ms；畫一張 .565 約 40 ms。
- **螢幕上的截圖畫面尚未由人目視確認。**
