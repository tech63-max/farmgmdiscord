"""產生 SD 卡測試素材 (只用來驗證第一、二階段的 JPEG / 逐格動畫播放，內容為程式繪製的原創圖)。

用法：python tools/make_test_sd.py  → 輸出到 sdcard_test/，把裡面的資料夾複製到 SD 卡根目錄。
正式素材之後由裝置透過 Wi-Fi 下載 (第三階段)，不需要電腦。
"""
import os
from PIL import Image, ImageDraw

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "sdcard_test")


def save(img, rel):
    path = os.path.join(OUT, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path, "JPEG", quality=85, progressive=False, optimize=False)  # TJpgDec 只支援 baseline
    print(path)


def card(w, h, bg, fg, label):
    img = Image.new("RGB", (w, h), bg)
    d = ImageDraw.Draw(img)
    for i in range(0, w + h, 24):
        d.line([(i, 0), (i - h, h)], fill=tuple(min(255, c + 18) for c in bg), width=6)
    d.ellipse([w // 2 - 40, h // 2 - 40, w // 2 + 40, h // 2 + 40], fill=fg, outline=(40, 30, 40), width=4)
    d.ellipse([w // 2 - 18, h // 2 - 12, w // 2 - 8, h // 2 + 2], fill=(40, 30, 40))
    d.ellipse([w // 2 + 8, h // 2 - 12, w // 2 + 18, h // 2 + 2], fill=(40, 30, 40))
    d.arc([w // 2 - 14, h // 2, w // 2 + 14, h // 2 + 20], 0, 180, fill=(40, 30, 40), width=3)
    d.text((8, 8), label, fill=(255, 255, 255))
    return img


# 靜態圖：一張剛好 240x168，一張 960x672 (測試 1/4 縮放)
save(card(240, 168, (60, 80, 140), (255, 208, 150), "TEST 240x168"), "meme/funny/test_small.jpg")
save(card(960, 672, (120, 60, 90), (255, 220, 120), "TEST 960x672 (scaled 1/4)"), "meme/mygo/classic/test_big.jpg")

# 逐格動畫：4 格，anim.json 設定 6 fps
for i in range(4):
    img = card(240, 168, (40, 100, 90), (255, 208, 150), f"ANIM frame {i}")
    d = ImageDraw.Draw(img)
    x = 30 + i * 50
    d.rectangle([x, 140, x + 30, 160], fill=(255, 255, 255))
    save(img, f"meme/reaction/test_bounce/{i:03d}.jpg")
with open(os.path.join(OUT, "meme/reaction/test_bounce/anim.json"), "w", encoding="utf-8") as f:
    f.write('{"fps": 6}\n')

# 壞檔：副檔名是 .jpg 但內容不是 JPEG，應被拒絕而不會當機
os.makedirs(os.path.join(OUT, "meme/work"), exist_ok=True)
with open(os.path.join(OUT, "meme/work/broken.jpg"), "wb") as f:
    f.write(b"not a jpeg at all")
print("done")
