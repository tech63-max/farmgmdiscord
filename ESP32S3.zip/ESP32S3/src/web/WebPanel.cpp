#include "WebPanel.h"

#include <DNSServer.h>
#include <ESPmDNS.h>
#include <WebServer.h>
#include <WiFi.h>
#include <stdarg.h>

#include "../app/App.h"
#include "../ui/Strings.h"

namespace {
WebServer server(80);
App *gApp = nullptr;

// 分段送出 HTML，用固定緩衝區，不在每次請求動態組大字串
char chunk[768];
void sendf(const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(chunk, sizeof(chunk), fmt, ap);
  va_end(ap);
  server.sendContent(chunk);
}

// HTML 跳脫 (防 XSS)
void escapeHtml(const char *in, char *out, size_t cap) {
  size_t o = 0;
  for (; *in && o + 7 < cap; in++) {
    const char *rep = nullptr;
    switch (*in) {
      case '&': rep = "&amp;"; break;
      case '<': rep = "&lt;"; break;
      case '>': rep = "&gt;"; break;
      case '"': rep = "&quot;"; break;
      case '\'': rep = "&#39;"; break;
      default: break;
    }
    if (rep) {
      while (*rep) out[o++] = *rep++;
    } else {
      out[o++] = *in;
    }
  }
  out[o] = '\0';
}

void securityHeaders() {
  server.sendHeader("Cache-Control", "no-store");
  server.sendHeader("X-Content-Type-Options", "nosniff");
  server.sendHeader("X-Frame-Options", "DENY");
  server.sendHeader("Referrer-Policy", "no-referrer");
}

// 只接受純數字並檢查範圍
bool parseNum(const char *name, long lo, long hi, long &out) {
  if (!server.hasArg(name)) return false;
  const String v = server.arg(name);
  if (v.length() == 0 || v.length() > 4) return false;
  for (size_t i = 0; i < v.length(); i++)
    if (v[i] < '0' || v[i] > '9') return false;
  out = v.toInt();
  return out >= lo && out <= hi;
}

void sendPageHead();  // 定義在下方 (PAGE_HEAD 之後)

void badRequest(const char *why) {
  securityHeaders();
  char esc[160];
  escapeHtml(why, esc, sizeof(esc));
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(400, "text/html; charset=utf-8", "");
  sendPageHead();
  sendf("<title>DeskPet</title><div class=card><h2>⚠️ 設定沒有儲存</h2><div class=row>%s</div>"
        "<div class=row><a href='/'>← 返回</a></div></div></html>", esc);
  server.sendContent("");
}

// ---- 共用樣式 (卡片、開關、底部固定的儲存鈕) ----
const char PAGE_HEAD[] =
    "<!doctype html><html lang=zh-Hant><meta charset=utf-8>"
    "<meta name=viewport content='width=device-width,initial-scale=1'><meta name=theme-color content=#1d2740>"
    "<style>"
    ":root{--bg:#1d2740;--card:#27334f;--line:#34416a;--in:#1a2238;--txt:#f7f1e3;--dim:#8c98ba;--acc:#8ce6d2;--gold:#ffd678;--red:#ff9aa8}"
    "*{box-sizing:border-box}"
    "body{font-family:-apple-system,'PingFang TC','Noto Sans TC',sans-serif;background:var(--bg);color:var(--txt);"
    "margin:0 auto;padding:18px 14px 96px;max-width:540px;line-height:1.45}"
    "h1{font-size:22px;margin:2px 0 4px}h1 span{color:var(--acc)}"
    ".sub{color:var(--dim);font-size:13px;margin:0 0 14px}"
    ".card{background:var(--card);border-radius:18px;padding:4px 16px 8px;margin:0 0 14px;box-shadow:0 3px 12px #0003}"
    ".card h2{font-size:15px;color:var(--gold);margin:12px 0 2px;letter-spacing:.5px}"
    ".row{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:11px 0;border-top:1px solid var(--line)}"
    ".card h2+.row,.card h2+form .row{border-top:0}"
    ".row>span{flex:1;min-width:0}.row small{display:block}"
    ".ctl{display:flex;align-items:center;gap:6px;flex:none;color:var(--dim)}"
    ".col{flex-direction:column;align-items:stretch}"
    "input,select{font:inherit;font-size:16px;padding:8px 10px;border-radius:10px;border:1px solid var(--line);"
    "background:var(--in);color:var(--txt)}"
    "select{max-width:190px}input[type=number]{width:72px;text-align:center}"
    "input[type=text],input[type=password]{width:100%}"
    ".sw{appearance:none;-webkit-appearance:none;width:48px;height:28px;border-radius:14px;background:#46527a;"
    "position:relative;flex:none;border:0;padding:0;margin:0;transition:.2s;cursor:pointer}"
    ".sw::after{content:'';position:absolute;top:3px;left:3px;width:22px;height:22px;border-radius:50%;"
    "background:#fff;transition:.2s;box-shadow:0 1px 3px #0005}"
    ".sw:checked{background:var(--acc)}.sw:checked::after{left:23px}"
    ".btn{display:block;text-align:center;text-decoration:none}"
    "button,.btn{font:inherit;font-size:16px;font-weight:bold;border:0;border-radius:12px;padding:12px 16px;"
    "background:var(--acc);color:#1d2740;cursor:pointer;width:100%}"
    ".b2{background:#34416a;color:var(--txt)}.bad{background:none;color:var(--red);border:1px solid #ff9aa866}"
    ".acts{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin:0 0 14px}.acts form{margin:0}"
    ".save{position:fixed;left:0;right:0;bottom:0;padding:12px 14px calc(12px + env(safe-area-inset-bottom));"
    "background:#1d2740e8;backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);border-top:1px solid var(--line)}"
    ".save button{display:block;max-width:512px;margin:0 auto}"
    ".kv{display:grid;grid-template-columns:auto 1fr;gap:6px 14px;padding:8px 0 10px}.kv b{color:var(--dim);font-weight:normal}"
    ".bar{display:inline-block;width:70px;height:10px;border-radius:5px;background:var(--in);vertical-align:middle;overflow:hidden;margin-right:6px}"
    ".bar i{display:block;height:100%;background:var(--acc)}"
    ".day{padding:10px 0;border-top:1px solid var(--line)}.day:first-of-type{border-top:0}.day b{color:var(--acc)}"
    ".day p{margin:4px 0 0}small{color:var(--dim);font-size:13px}a{color:var(--gold)}"
    ".note{color:var(--dim);font-size:12px;text-align:center;margin:18px 0}"
    "</style>";

void sendPageHead() { server.sendContent(PAGE_HEAD); }

void cardStart(const char *title) { sendf("<div class=card><h2>%s</h2>", title); }
void cardEnd() { server.sendContent("</div>"); }

// 開關列：標題 (+ 說明) 在左，開關在右
void toggleRow(const char *name, const char *label, bool on, const char *hint = nullptr) {
  sendf("<label class=row><span>%s%s%s%s</span><input type=checkbox class=sw name=%s value=1%s></label>", label,
        hint ? "<small>" : "", hint ? hint : "", hint ? "</small>" : "", name, on ? " checked" : "");
}

// 數字列：標題在左，輸入框 + 單位在右
void numRow(const char *name, const char *label, int lo, int hi, int step, int v, const char *unit,
            const char *hint = nullptr) {
  sendf("<label class=row><span>%s%s%s%s</span><span class=ctl><input type=number name=%s min=%d max=%d step=%d "
        "value=%d inputmode=numeric>%s</span></label>",
        label, hint ? "<small>" : "", hint ? hint : "", hint ? "</small>" : "", name, lo, hi, step, v, unit);
}

// 下拉選單列
void selectRow(const char *name, const char *label, const char *const *opts, uint8_t n, uint8_t cur) {
  sendf("<label class=row><span>%s</span><select name=%s>", label, name);
  for (uint8_t i = 0; i < n; i++) sendf("<option value=%u%s>%s</option>", i, i == cur ? " selected" : "", opts[i]);
  server.sendContent("</select></label>");
}

void hourRow(const char *name, const char *label, uint8_t cur) {
  sendf("<label class=row><span>%s</span><select name=%s>", label, name);
  for (uint8_t h = 0; h < 24; h++) sendf("<option value=%u%s>%02u:00</option>", h, h == cur ? " selected" : "", h);
  server.sendContent("</select></label>");
}

void actionButton(const char *action, const char *text, const char *cls, const char *confirmMsg = nullptr) {
  if (confirmMsg) {
    sendf("<form method=post action=%s onsubmit=\"return confirm('%s')\"><button class=%s>%s</button></form>",
          action, confirmMsg, cls, text);
  } else {
    sendf("<form method=post action=%s><button class=%s>%s</button></form>", action, cls, text);
  }
}

void sendDiary();

void handleRoot() {
  const Settings s = gApp->webSettings();
  const CostumeManager &cos = gApp->costumes();
  const BatteryMonitor &bat = gApp->battery();

  securityHeaders();
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200, "text/html; charset=utf-8", "");
  server.sendContent(PAGE_HEAD);
  server.sendContent("<title>DeskPet</title><h1>💧 <span>水伊布桌寵</span></h1>"
                     "<p class=sub>修改後按最下方「儲存設定」</p>");

  // ---- 狀態 ----
  char timeBuf[32];
  if (!gApp->timeString(timeBuf, sizeof(timeBuf))) strcpy(timeBuf, "尚未同步");
  static const char *const PHONE_STATE[] = {"關閉", "等待 iPhone 連線", "配對中", "已連線（讀取通知中）", "已連線"};
  const uint8_t ps = (uint8_t)gApp->phoneState();
  const WeatherInfo w = gApp->weather();
  cardStart("📋 狀態");
  sendf("<div class=kv><b>時間</b><span>%s</span><b>電池</b><span><span class=bar><i style='width:%u%%'></i></span>"
        "%u%%（%.2fV）%s</span><b>iPhone</b><span>%s</span><b>IP</b><span>%s</span>",
        timeBuf, bat.percent(), bat.percent(), bat.voltage(), bat.charging() ? " ⚡充電中" : "",
        PHONE_STATE[ps < 5 ? ps : 0], WiFi.localIP().toString().c_str());
  if (w.valid) {
    sendf("<b>天氣</b><span>%s %d~%d°C，降雨 %u%%</span>",
          Str::WEATHER_NAMES[(uint8_t)w.kind < 8 ? (uint8_t)w.kind : 0], w.minT, w.maxT, w.pop);
  }
  server.sendContent("</div>");
  cardEnd();

  // ---- 互動按鈕 (各自獨立的 form，不能放進設定表單裡) ----
  server.sendContent("<div class=acts>");
  actionButton("/pet", "🤚 摸摸頭", "b2");
  actionButton("/walk", "🌼 去散步", "b2");
  server.sendContent("</div>");

  server.sendContent("<form method=post action=/save>");

  // ---- 裝扮 ----
  cardStart("🎀 裝扮");
  sendf("<label class=row><span>目前裝扮</span><select name=costume>");
  for (uint8_t i = 0; i < cos.count(); i++)
    sendf("<option value=%u%s>%s</option>", i, i == s.costume ? " selected" : "", cos.get(i).name);
  server.sendContent("</select></label>");
  toggleRow("autoCos", "自動裝扮", s.autoCostume, "聖誕節聖誕帽、生日皇冠、睡覺睡眠帽");
  sendf("<label class=row><span>生日<small>0 = 不設定</small></span><span class=ctl>"
        "<input type=number name=bMonth min=0 max=12 value=%u inputmode=numeric>月"
        "<input type=number name=bDay min=0 max=31 value=%u inputmode=numeric>日</span></label>",
        s.birthMonth, s.birthDay);
  cardEnd();

  // ---- 睡眠與螢幕 ----
  static const char *const PS_OPTS[] = {"關", "自動（沒充電時）", "開"};
  cardStart("🌙 睡眠與螢幕");
  toggleRow("sleepOn", "夜間睡眠", s.sleepEnabled);
  hourRow("sleepS", "睡覺時間", s.sleepStart);
  hourRow("sleepE", "起床時間", s.sleepEnd);
  numRow("nap", "閒置小睡", 0, 60, 1, s.napMinutes, "分", "0 = 關閉");
  numRow("bright", "亮度", 10, 100, 10, s.brightness, "%");
  selectRow("pwrSave", "省電模式", PS_OPTS, 3, s.powerSave);
  cardEnd();

  // ---- 背景與互動 ----
  static const char *const BG_OPTS[] = {"自動（依時間）", "清晨", "白天", "黃昏", "夜晚"};
  static const char *const LV_OPTS[] = {"低", "中", "高"};
  cardStart("🌿 背景與互動");
  selectRow("bgMode", "背景", BG_OPTS, 5, s.bgMode);
  toggleRow("wxFx", "天氣特效", s.weatherFx, "雲、雨、雪、霧");
  toggleRow("tempMood", "溫度表情", s.tempMood, "≥32°C 扇子、≤15°C 圍巾");
  toggleRow("hourly", "整點小動作", s.hourlyFx);
  toggleRow("tilt", "傾斜互動", s.tiltOn, "歪一邊，寵物就看那一邊");
  selectRow("shake", "搖晃靈敏度", LV_OPTS, 3, s.shakeLevel);
  selectRow("patLv", "拍頭偵測（拍上方兩下）", Str::PAT_LEVELS, 4, s.patLevel);
  cardEnd();

  // ---- 聲音 ----
  cardStart("🔔 聲音");
  toggleRow("sound", "音效", s.soundOn, "預設關閉；睡覺時不會發出聲音");
  selectRow("vol", "音量", LV_OPTS, 3, s.soundVol);
  cardEnd();

  // ---- 鬧鐘 ----
  static const char *const DAY_OPTS[] = {"每天", "平日（週一～五）", "週末"};
  cardStart("⏰ 鬧鐘");
  toggleRow("alarmOn", "鬧鐘", s.alarmOn, "響鈴前 15 分鐘螢幕會慢慢變亮；鬧鐘一定有聲音");
  hourRow("alarmH", "幾點", s.alarmHour);
  numRow("alarmM", "幾分", 0, 59, 1, s.alarmMin, "分");
  selectRow("alarmD", "哪幾天", DAY_OPTS, 3, s.alarmDays);
  cardEnd();

  // ---- 番茄鐘 ----
  cardStart("🍅 番茄鐘");
  numRow("focus", "專注", 1, 90, 1, s.focusMin, "分");
  numRow("break", "休息", 1, 30, 1, s.breakMin, "分");
  cardEnd();

  // ---- iPhone 通知 ----
  cardStart("📱 iPhone 通知");
  toggleRow("notify", "顯示 iPhone 通知", s.notifyOn, "藍牙，iPhone 不用裝 App");
  toggleRow("notifyDtl", "顯示通知內容", s.notifyDetail, "關閉 = 只顯示 App 名稱");
  server.sendContent("<div class=row><small>配對：iPhone「設定 → 藍牙」點 DeskPet，輸入板子螢幕上的 6 位數配對碼，"
                     "並允許分享通知。</small></div>");
  cardEnd();

  // ---- 天氣 ----
  cardStart("☀️ 天氣（中央氣象署）");
  sendf("<label class=row><span>縣市</span><select name=county>");
  for (uint8_t i = 0; i < WeatherService::COUNTY_COUNT; i++)
    sendf("<option value=%u%s>%s</option>", i, i == s.county ? " selected" : "", WeatherService::countyName(i));
  server.sendContent("</select></label>");
  sendf("<label class='row col'><span>API 金鑰%s</span><input type=password name=cwaKey maxlength=64 "
        "autocomplete=off placeholder=\"%s\"></label>",
        w.valid || !s.cwaKey[0] ? "" : "<small>尚未取得資料</small>",
        s.cwaKey[0] ? "已設定（留空 = 不變更）" : "尚未設定");
  toggleRow("clearKey", "清除金鑰", false);
  if (!w.valid && s.cwaKey[0]) sendf("<div class=row><small>最近一次連線：HTTP %d</small></div>", w.lastHttp);
  cardEnd();

  // ---- Wi-Fi ----
  char ssidEsc[200];
  escapeHtml(s.ssid, ssidEsc, sizeof(ssidEsc));
  cardStart("📶 Wi-Fi");
  sendf("<label class='row col'><span>名稱（SSID）</span><input type=text name=ssid maxlength=32 value=\"%s\" "
        "autocomplete=off></label>"
        "<label class='row col'><span>密碼</span><input type=password name=pass maxlength=64 autocomplete=off "
        "placeholder=\"留空 = 不變更\"></label>"
        "<div class=row><small>只支援 2.4GHz。改了 Wi-Fi 後板子會重新連線，此頁面會斷線。</small></div>",
        ssidEsc);
  cardEnd();

  server.sendContent("<div class=save><button type=submit>💾 儲存設定</button></div></form>");

  sendDiary();

  cardStart("⚙️ 其他");
  server.sendContent("<div class=row style='border:0'>");
  actionButton("/unpair", "取消 iPhone 配對", "bad", "確定要取消 iPhone 配對？");
  server.sendContent("</div>");
  cardEnd();
  server.sendContent("<p class=note>⚠️ 此頁面沒有密碼保護，同一網路的人都能修改設定。</p></html>");
  server.sendContent("");  // 結束 chunked 傳輸
}

// 日記：內容只由程式內建文字 + 數字組成，仍一律跳脫後輸出
void sendDiary() {
  static char lines[Diary::MAX_LINES][Diary::LINE_LEN];
  char esc[Diary::LINE_LEN * 2];
  const Diary &diary = gApp->diary();
  cardStart("📔 每日小日記（最近 7 天）");
  for (uint8_t i = 0; i < diary.count(); i++) {
    const DiaryDay &d = diary.day(i);
    if (d.ymd != 0) {
      sendf("<div class=day><b>%lu/%lu %s%s</b><p>", (unsigned long)(d.ymd / 100 % 100),
            (unsigned long)(d.ymd % 100), Str::WEEKDAY[d.wday % 7], i == 0 ? "（今天）" : "");
    } else {
      server.sendContent("<div class=day><b>今天</b><p>");
    }
    const uint8_t n = Diary::compose(d, i == 0, lines, Diary::MAX_LINES);
    for (uint8_t k = 0; k < n; k++) {
      escapeHtml(lines[k], esc, sizeof(esc));
      sendf("%s", esc);
    }
    server.sendContent("</p></div>");
  }
  cardEnd();
}

void handleSave() {
  Settings n = gApp->webSettings();
  long v;
  if (!parseNum("costume", 0, gApp->costumes().count() - 1, v)) return badRequest("裝扮編號不正確");
  n.costume = (uint8_t)v;
  if (!parseNum("sleepS", 0, 23, v)) return badRequest("睡覺時間不正確");
  n.sleepStart = (uint8_t)v;
  if (!parseNum("sleepE", 0, 23, v)) return badRequest("起床時間不正確");
  n.sleepEnd = (uint8_t)v;
  if (!parseNum("bright", 10, 100, v)) return badRequest("亮度需為 10~100");
  n.brightness = (uint8_t)v;
  if (!parseNum("nap", 0, 60, v)) return badRequest("閒置小睡需為 0~60 分鐘");
  n.napMinutes = (uint8_t)v;
  if (!parseNum("focus", 1, 90, v)) return badRequest("專注時間需為 1~90 分鐘");
  n.focusMin = (uint8_t)v;
  if (!parseNum("break", 1, 30, v)) return badRequest("休息時間需為 1~30 分鐘");
  n.breakMin = (uint8_t)v;
  long m, d;
  if (!parseNum("bMonth", 0, 12, m) || !parseNum("bDay", 0, 31, d)) return badRequest("生日格式不正確");
  static const uint8_t DAYS[] = {31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
  if ((m == 0) != (d == 0) || (m > 0 && d > DAYS[m - 1])) return badRequest("生日日期不存在");
  n.birthMonth = (uint8_t)m;
  n.birthDay = (uint8_t)d;
  if (!parseNum("county", 0, WeatherService::COUNTY_COUNT - 1, v)) return badRequest("縣市不正確");
  n.county = (uint8_t)v;
  const String key = server.arg("cwaKey");
  if (server.hasArg("clearKey")) {
    n.cwaKey[0] = '\0';
  } else if (key.length() > 0) {
    if (key.length() > 64 || !WeatherService::validKey(key.c_str())) return badRequest("API 金鑰格式不正確");
    strncpy(n.cwaKey, key.c_str(), sizeof(n.cwaKey) - 1);
    n.cwaKey[sizeof(n.cwaKey) - 1] = '\0';
  }
  if (!parseNum("bgMode", 0, 4, v)) return badRequest("背景選項不正確");
  n.bgMode = (uint8_t)v;
  if (!parseNum("shake", 0, 2, v)) return badRequest("搖晃靈敏度不正確");
  n.shakeLevel = (uint8_t)v;
  if (!parseNum("patLv", 0, 3, v)) return badRequest("拍頭偵測設定不正確");
  n.patLevel = (uint8_t)v;
  if (!parseNum("vol", 0, 2, v)) return badRequest("音量設定不正確");
  n.soundVol = (uint8_t)v;
  n.soundOn = server.hasArg("sound");
  if (!parseNum("alarmH", 0, 23, v)) return badRequest("鬧鐘時間（時）不正確");
  n.alarmHour = (uint8_t)v;
  if (!parseNum("alarmM", 0, 59, v)) return badRequest("鬧鐘時間（分）需為 0~59");
  n.alarmMin = (uint8_t)v;
  if (!parseNum("alarmD", 0, 2, v)) return badRequest("鬧鐘日子不正確");
  n.alarmDays = (uint8_t)v;
  n.alarmOn = server.hasArg("alarmOn");
  if (!parseNum("pwrSave", 0, 2, v)) return badRequest("省電模式不正確");
  n.powerSave = (uint8_t)v;
  n.notifyOn = server.hasArg("notify");
  n.notifyDetail = server.hasArg("notifyDtl");
  n.weatherFx = server.hasArg("wxFx");
  n.tempMood = server.hasArg("tempMood");
  n.hourlyFx = server.hasArg("hourly");
  n.tiltOn = server.hasArg("tilt");
  n.sleepEnabled = server.hasArg("sleepOn");
  n.autoCostume = server.hasArg("autoCos");

  const String ssid = server.arg("ssid");
  const String pass = server.arg("pass");
  if (ssid.length() > 32) return badRequest("SSID 最多 32 字元");
  if (pass.length() > 64 || (pass.length() > 0 && pass.length() < 8)) return badRequest("密碼需為 8~64 字元");
  bool wifiChanged = false;
  if (ssid != n.ssid || pass.length() > 0) {
    // 密碼留空：同一個 SSID 保留原密碼；換了 SSID 則視為開放網路
    if (pass.length() > 0) {
      strncpy(n.pass, pass.c_str(), sizeof(n.pass) - 1);
      n.pass[sizeof(n.pass) - 1] = '\0';
    } else if (ssid != n.ssid) {
      n.pass[0] = '\0';
    }
    strncpy(n.ssid, ssid.c_str(), sizeof(n.ssid) - 1);
    n.ssid[sizeof(n.ssid) - 1] = '\0';
    wifiChanged = true;
  }

  gApp->webApply(n, wifiChanged);
  securityHeaders();
  server.sendHeader("Location", "/");
  server.send(303, "text/plain", "");
}

void handleWalk() {
  gApp->webStartWalk();
  securityHeaders();
  server.sendHeader("Location", "/");
  server.send(303, "text/plain", "");
}

void handlePet() {
  gApp->webPokePet();
  securityHeaders();
  server.sendHeader("Location", "/");
  server.send(303, "text/plain", "");
}

// ---------------- 設定熱點：強制登入頁 (captive portal) ----------------
DNSServer dns;
bool captive = false;

void redirectToSetup() {
  server.sendHeader("Location", String("http://") + WiFi.softAPIP().toString() + "/wifi");
  server.send(302, "text/plain", "");
}

// 手機連上熱點時會先打這些網址檢查能不能上網；導到設定頁就會自動跳出登入視窗
const char *const PROBE_PATHS[] = {"/hotspot-detect.html", "/library/test/success.html",
                                   "/generate_204", "/gen_204", "/connecttest.txt",
                                   "/ncsi.txt", "/redirect", "/fwlink", "/canonical.html"};

void handleWifiPage() {
  if (server.hasArg("rescan")) WiFi.scanNetworks(true);  // 非同步掃描
  securityHeaders();
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200, "text/html; charset=utf-8", "");
  sendPageHead();
  server.sendContent("<title>DeskPet Wi-Fi</title><h1>📶 <span>Wi-Fi 設定</span></h1>"
                     "<p class=sub>讓水伊布桌寵連上你家的網路</p><form method=post action=/wifi><div class=card><h2>選擇網路</h2>");

  const int n = WiFi.scanComplete();
  if (n > 0) {
    server.sendContent("<label class='row col'><span>附近的 Wi-Fi</span><select name=pick style='max-width:none'><option value=''>（自己輸入 ↓）</option>");
    char esc[200];
    for (int i = 0; i < n && i < 20; i++) {
      const String ssid = WiFi.SSID(i);
      if (ssid.length() == 0 || ssid.length() > 32) continue;
      escapeHtml(ssid.c_str(), esc, sizeof(esc));
      sendf("<option value=\"%s\">%s（%d dBm）</option>", esc, esc, (int)WiFi.RSSI(i));
    }
    server.sendContent("</select></label>");
  } else {
    if (n == WIFI_SCAN_FAILED) WiFi.scanNetworks(true);
    server.sendContent("<div class=row><small>正在掃描附近的 Wi-Fi…</small><a href='/wifi'>重新整理</a></div>");
  }
  server.sendContent(
      "<label class='row col'><span>或自己輸入名稱</span><input type=text name=ssid maxlength=32 autocomplete=off></label>"
      "<label class='row col'><span>密碼<small>開放網路請留空</small></span>"
      "<input type=password name=pass maxlength=64 autocomplete=off></label>"
      "<div class=row><button type=submit>連線</button></div></div></form>"
      "<div class=acts><a class='btn b2' href='/wifi?rescan=1'>🔄 重新掃描</a>"
      "<a class='btn b2' href='/'>⚙️ 其他設定</a></div>"
      "<p class=note>只支援 2.4GHz。連線成功後，這個設定熱點會自動關閉。</p></html>");
  server.sendContent("");
}

void handleWifiSave() {
  String ssid = server.arg("pick");
  if (ssid.length() == 0) ssid = server.arg("ssid");
  const String pass = server.arg("pass");
  if (ssid.length() == 0 || ssid.length() > 32) return badRequest("Wi-Fi 名稱需為 1~32 字元");
  if (pass.length() > 64 || (pass.length() > 0 && pass.length() < 8)) return badRequest("密碼需為 8~64 字元（開放網路請留空）");
  gApp->webSetWifi(ssid.c_str(), pass.c_str());

  char esc[200];
  escapeHtml(ssid.c_str(), esc, sizeof(esc));
  securityHeaders();
  server.setContentLength(CONTENT_LENGTH_UNKNOWN);
  server.send(200, "text/html; charset=utf-8", "");
  sendPageHead();
  sendf("<title>DeskPet Wi-Fi</title><div class=card><h2>⏳ 正在連線到「%s」…</h2>"
        "<div class=row>請看板子螢幕：連上後會顯示「Wi-Fi 已連線！」，這個熱點約 20 秒後關閉。</div>"
        "<div class=row><small>如果連不上，熱點會繼續開著，可以重新連上熱點再試一次。</small></div></div></html>", esc);
  server.sendContent("");
}
}  // namespace

void WebPanel::begin(App &app) {
  if (started_) return;
  app_ = &app;
  gApp = &app;
  server.on("/", HTTP_GET, []() {
    if (captive && !WiFi.isConnected()) return redirectToSetup();  // 熱點模式先設定 Wi-Fi
    handleRoot();
  });
  server.on("/save", HTTP_POST, handleSave);
  server.on("/pet", HTTP_POST, handlePet);
  server.on("/walk", HTTP_POST, handleWalk);
  server.on("/unpair", HTTP_POST, []() {
    gApp->webUnpairPhone();
    securityHeaders();
    server.sendHeader("Location", "/");
    server.send(303, "text/plain", "");
  });
  server.on("/wifi", HTTP_GET, handleWifiPage);
  server.on("/wifi", HTTP_POST, handleWifiSave);
  for (const char *p : PROBE_PATHS) {
    server.on(p, []() {
      if (captive) redirectToSetup();
      else server.send(404, "text/plain", "Not found");
    });
  }
  server.onNotFound([]() {
    if (captive) redirectToSetup();
    else server.send(404, "text/plain", "Not found");
  });
  server.begin();
  if (MDNS.begin("deskpet")) MDNS.addService("http", "tcp", 80);
  started_ = true;
  Serial.println("[DeskPet] web panel started (http://deskpet.local/)");
}

void WebPanel::setCaptive(bool on) {
  if (on == captive) return;
  captive = on;
  if (on) {
    dns.setErrorReplyCode(DNSReplyCode::NoError);
    dns.start(53, "*", WiFi.softAPIP());  // 所有網域都指向板子
    WiFi.scanNetworks(true);
  } else {
    dns.stop();
  }
}

void WebPanel::update() {
  if (!started_) return;
  if (captive) dns.processNextRequest();
  server.handleClient();
}
