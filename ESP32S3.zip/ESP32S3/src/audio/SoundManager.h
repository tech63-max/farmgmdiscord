#pragma once
#include <stdint.h>

// 音效：板載 ES8311 DAC + 喇叭功放 (GPIO7)。
// - 「音效」設定關閉時不初始化音訊硬體；需要時 (開啟音效，或使用者主動用鬧鐘 / 音樂盒 / 節奏遊戲) 才初始化
// - 只用 DAC (喇叭輸出)，不初始化麥克風 (ES7210)、不收音
// - 聲音全部用程式即時合成 (正弦、叫聲、雜音、八音盒)，不需要音檔；在背景 task 播放，不阻塞主迴圈
// - 功放只在播放時打開，播完關掉，避免底噪
// ES8311 暫存器設定照 Espressif esp_codec_dev 的 es8311 驅動 (16kHz、MCLK = 256 x fs、I2S Philips 16bit、slave)
enum class Sfx : uint8_t {
  Pat, Happy, Notify, TimerDone, Wake, Flower, Dress, Hour, Test,
  Cry, CryHappy, CrySleepy,  // 寵物叫聲
  Step, StepRain,            // 散步腳步聲
  Tick, TickAccent, Hit,     // 節奏遊戲
  Alarm,                     // 鬧鐘
  Count
};

class SoundManager {
 public:
  static constexpr uint32_t STREAM_LATENCY_MS = 90;  // 連續輸出模式下，送出到真的發出聲音的延遲 (約 DMA 緩衝長度)

  void setEnabled(bool on);       // 「音效」開關 (自動音效)
  void setVolume(uint8_t level);  // 0 低，1 中，2 高
  // 播放；force = true 時即使「音效」關閉也播 (使用者主動開的功能)。pitch = 音高偏移 (百分比)
  void play(Sfx s, bool force = false, int8_t pitch = 0);
  void playSong(uint8_t song);  // 音樂盒 (一定會播)
  void stop();                  // 清空佇列並中斷目前的聲音
  bool busy() const;            // 正在播放 (含佇列裡還有)
  // 連續輸出模式 (節奏遊戲)：功放一直開、持續送靜音，讓延遲固定在 STREAM_LATENCY_MS 左右
  void setStreaming(bool on);
  bool enabled() const { return enabled_; }
  bool ready() const { return hwReady_; }

  static uint8_t songCount();

 private:
  bool initHardware();
  void applyVolume();
  void send(uint8_t kind, uint8_t id, int8_t pitch, bool force);

  bool enabled_ = false;
  bool hwReady_ = false;
  bool hwFailed_ = false;
  uint8_t level_ = 1;
};
