#include "SoundManager.h"

#include <Arduino.h>
#include <ESP_I2S.h>
#include <Wire.h>
#include <math.h>

#include "../config/BoardConfig.h"

namespace {
constexpr uint8_t ES8311_ADDR = 0x18;  // 7-bit (I2C 掃描結果)
constexpr uint32_t RATE = 16000;
// DAC 音量暫存器 0x32：0x00 = -95.5dB … 0xBF = 0dB，每格 0.5dB
constexpr uint8_t VOLUME_REG[] = {0xA8, 0xB4, 0xBF};  // 低 -11.5dB / 中 -5.5dB / 高 0dB
constexpr float AMPLITUDE = 0.35f;                     // 合成波形的振幅 (滿刻度的比例)，避免太吵或破音

I2SClass i2s;
QueueHandle_t queue = nullptr;
TaskHandle_t task = nullptr;
volatile bool playEnabled = false;

bool wr(uint8_t reg, uint8_t val) {
  Wire.beginTransmission(ES8311_ADDR);
  Wire.write(reg);
  Wire.write(val);
  return Wire.endTransmission() == 0;
}

bool rd(uint8_t reg, uint8_t &val) {
  Wire.beginTransmission(ES8311_ADDR);
  Wire.write(reg);
  if (Wire.endTransmission(false) != 0) return false;
  if (Wire.requestFrom(ES8311_ADDR, (uint8_t)1) != 1) return false;
  val = Wire.read();
  return true;
}

// 讀-改-寫：(reg & keep) | set
bool rmw(uint8_t reg, uint8_t keep, uint8_t set) {
  uint8_t v = 0;
  if (!rd(reg, v)) return false;
  return wr(reg, (uint8_t)((v & keep) | set));
}

// ---- ES8311 初始化 (順序與數值照 esp_codec_dev es8311.c：open → set_fs → start) ----
bool es8311Init() {
  bool ok = true;
  uint8_t v = 0;
  // es8311_open
  ok &= rd(0x0D, v);
  if (v != 0xFA) ok &= wr(0x0D, 0xFA);
  wr(0x44, 0x08);  // 提高 I2C 抗干擾 (官方驅動寫兩次，第一次偶爾會失敗)
  ok &= wr(0x44, 0x08);
  ok &= wr(0x01, 0x30);
  ok &= wr(0x02, 0x00);
  ok &= wr(0x03, 0x10);
  ok &= wr(0x16, 0x24);
  ok &= wr(0x04, 0x10);
  ok &= wr(0x05, 0x00);
  ok &= wr(0x0B, 0x00);
  ok &= wr(0x0C, 0x00);
  ok &= wr(0x10, 0x1F);
  ok &= wr(0x11, 0x7F);
  ok &= wr(0x00, 0x80);
  ok &= rmw(0x00, 0xBF, 0x00);  // slave mode
  ok &= wr(0x01, 0x3F);         // 用 MCLK 腳當時脈、不反相
  ok &= rmw(0x06, (uint8_t)~0x20, 0x00);  // SCLK 不反相
  ok &= wr(0x13, 0x10);
  ok &= wr(0x1B, 0x0A);
  ok &= wr(0x1C, 0x6A);
  ok &= wr(0x44, 0x58);
  // es8311_set_fs：16bit、I2S normal、16kHz (係數表 {4096000, 16000, 1,1,1,1,0,0x00,0xff,4,0x10,0x20})
  ok &= rmw(0x09, 0xFF, 0x0C);
  ok &= rmw(0x0A, 0xFF, 0x0C);
  ok &= rmw(0x09, 0xFC, 0x00);
  ok &= rmw(0x0A, 0xFC, 0x00);
  ok &= rmw(0x02, 0x07, (0 << 5) | (0 << 3));  // pre_div 1、pre_multi x1
  ok &= wr(0x05, 0x00);                         // adc_div 1、dac_div 1
  ok &= rmw(0x03, 0x80, (0 << 6) | 0x10);       // single speed、adc_osr
  ok &= rmw(0x04, 0x80, 0x20);                  // dac_osr
  ok &= rmw(0x07, 0xC0, 0x00);                  // lrck_h
  ok &= wr(0x08, 0xFF);                         // lrck_l
  ok &= rmw(0x06, 0xE0, 4 - 1);                 // bclk_div 4
  // es8311_start (只開 DAC)
  ok &= wr(0x00, 0x80);
  ok &= wr(0x01, 0x3F);
  ok &= rmw(0x09, 0xBF, 0x00);
  ok &= rmw(0x0A, 0xBF, 0x00);
  ok &= wr(0x17, 0xBF);
  ok &= wr(0x0E, 0x02);
  ok &= wr(0x12, 0x00);
  ok &= wr(0x14, 0x1A);
  ok &= rmw(0x14, (uint8_t)~0x40, 0x00);  // 不用數位麥克風
  ok &= wr(0x0D, 0x01);
  ok &= wr(0x15, 0x40);
  ok &= wr(0x37, 0x08);
  ok &= wr(0x45, 0x00);
  ok &= rmw(0x31, 0x9F, 0x00);  // 取消靜音
  return ok;
}

// ---- 音效合成 ----
enum Voice : uint8_t { V_SINE, V_VOICE, V_NOISE, V_BELL, V_CLICK };
struct Note {
  uint16_t hz;     // 0 = 休止；雜音時 = 濾波頻率
  uint16_t ms;
  uint16_t hzEnd;  // 0 = 不滑音；否則從 hz 滑到 hzEnd
  uint8_t voice;
  uint8_t amp;     // 0~100
};
// 一般音效 (柔和正弦)
#define S(hz, ms) {hz, ms, 0, V_SINE, 100}
#define R(ms) {0, ms, 0, V_SINE, 0}
// 叫聲：「咿～布！」(有泛音 + 顫音 + 滑音)
#define VC(hz, ms, to) {hz, ms, to, V_VOICE, 100}
const Note SFX_PAT[] = {S(784, 70), R(25), S(988, 110)};
const Note SFX_HAPPY[] = {S(880, 60), S(1175, 60), S(1568, 100)};
const Note SFX_NOTIFY[] = {S(1319, 110), S(1760, 220)};
const Note SFX_TIMER[] = {S(1047, 140), S(1319, 140), S(1568, 140), R(70), S(2093, 320)};
const Note SFX_WAKE[] = {{420, 360, 900, V_SINE, 100}, R(40), S(1175, 90)};
const Note SFX_FLOWER[] = {S(2093, 50), S(2637, 50), S(3136, 90)};
const Note SFX_DRESS[] = {S(1568, 40), S(2093, 40), S(2637, 40), S(3136, 80)};
const Note SFX_HOUR[] = {{1047, 400, 0, V_BELL, 100}, {784, 600, 0, V_BELL, 100}};
const Note SFX_CRY[] = {VC(1050, 150, 1450), VC(1450, 110, 1250), R(35), VC(950, 170, 700)};
const Note SFX_CRY_HAPPY[] = {VC(1200, 90, 1550), R(25), VC(1000, 80, 850), R(25), VC(1300, 140, 1700)};
const Note SFX_CRY_SLEEPY[] = {VC(650, 260, 900), VC(900, 320, 620)};
const Note SFX_STEP[] = {{900, 35, 0, V_NOISE, 45}};        // 草地上「噠」
const Note SFX_STEP_RAIN[] = {{3500, 50, 0, V_NOISE, 40}};  // 踩水「啪」
const Note SFX_TICK[] = {{1800, 30, 0, V_CLICK, 70}};
const Note SFX_TICK_ACCENT[] = {{2400, 40, 0, V_CLICK, 100}};
const Note SFX_HIT[] = {S(1568, 45), S(2093, 70)};
const Note SFX_ALARM[] = {{1047, 130, 0, V_BELL, 100}, {1319, 130, 0, V_BELL, 100}, {1568, 130, 0, V_BELL, 100},
                          {2093, 300, 0, V_BELL, 100}, R(120), {1568, 130, 0, V_BELL, 100},
                          {2093, 400, 0, V_BELL, 100}};
struct SfxDef {
  const Note *notes;
  uint8_t count;
};
#define SFX(a) {a, (uint8_t)(sizeof(a) / sizeof(a[0]))}
const SfxDef SFX_TABLE[] = {SFX(SFX_PAT),       SFX(SFX_HAPPY),      SFX(SFX_NOTIFY),         SFX(SFX_TIMER),
                            SFX(SFX_WAKE),      SFX(SFX_FLOWER),     SFX(SFX_DRESS),          SFX(SFX_HOUR),
                            SFX(SFX_HAPPY),     SFX(SFX_CRY),        SFX(SFX_CRY_HAPPY),      SFX(SFX_CRY_SLEEPY),
                            SFX(SFX_STEP),      SFX(SFX_STEP_RAIN),  SFX(SFX_TICK),           SFX(SFX_TICK_ACCENT),
                            SFX(SFX_HIT),       SFX(SFX_ALARM)};
static_assert(sizeof(SFX_TABLE) / sizeof(SFX_TABLE[0]) == (size_t)Sfx::Count, "SFX_TABLE 與 Sfx 數量不一致");

// ---- 音樂盒曲目 (傳統兒歌 / 公共領域旋律)。音高 = MIDI 編號 (0 = 休止)，長度單位 = 16 分音符 ----
struct SongNote {
  uint8_t midi;
  uint8_t len;
};
const SongNote SONG_BIRTHDAY[] = {  // 生日快樂歌
    {67, 3}, {67, 1}, {69, 4}, {67, 4}, {72, 4}, {71, 8}, {67, 3}, {67, 1}, {69, 4}, {67, 4}, {74, 4}, {72, 8},
    {67, 3}, {67, 1}, {79, 4}, {76, 4}, {72, 4}, {71, 4}, {69, 8}, {77, 3}, {77, 1}, {76, 4}, {72, 4}, {74, 4},
    {72, 8}};
const SongNote SONG_TWINKLE[] = {  // 小星星
    {60, 4}, {60, 4}, {67, 4}, {67, 4}, {69, 4}, {69, 4}, {67, 8}, {65, 4}, {65, 4}, {64, 4}, {64, 4},
    {62, 4}, {62, 4}, {60, 8}, {67, 4}, {67, 4}, {65, 4}, {65, 4}, {64, 4}, {64, 4}, {62, 8}, {67, 4},
    {67, 4}, {65, 4}, {65, 4}, {64, 4}, {64, 4}, {62, 8}, {60, 4}, {60, 4}, {67, 4}, {67, 4}, {69, 4},
    {69, 4}, {67, 8}, {65, 4}, {65, 4}, {64, 4}, {64, 4}, {62, 4}, {62, 4}, {60, 8}};
const SongNote SONG_TIGERS[] = {  // 兩隻老虎
    {60, 4}, {62, 4}, {64, 4}, {60, 4}, {60, 4}, {62, 4}, {64, 4}, {60, 4}, {64, 4}, {65, 4}, {67, 8},
    {64, 4}, {65, 4}, {67, 8}, {67, 2}, {69, 2}, {67, 2}, {65, 2}, {64, 4}, {60, 4}, {67, 2}, {69, 2},
    {67, 2}, {65, 2}, {64, 4}, {60, 4}, {60, 4}, {55, 4}, {60, 8}, {60, 4}, {55, 4}, {60, 8}};
const SongNote SONG_BEE[] = {  // 小蜜蜂
    {67, 4}, {64, 4}, {64, 8}, {65, 4}, {62, 4}, {62, 8}, {60, 4}, {62, 4}, {64, 4}, {65, 4}, {67, 4},
    {67, 4}, {67, 8}, {67, 4}, {64, 4}, {64, 8}, {65, 4}, {62, 4}, {62, 8}, {60, 4}, {64, 4}, {67, 4},
    {67, 4}, {64, 16}, {62, 4}, {62, 4}, {62, 4}, {62, 4}, {62, 4}, {64, 4}, {65, 8}, {64, 4}, {64, 4},
    {64, 4}, {64, 4}, {64, 4}, {65, 4}, {67, 8}, {67, 4}, {64, 4}, {64, 8}, {65, 4}, {62, 4}, {62, 8},
    {60, 4}, {64, 4}, {67, 4}, {67, 4}, {60, 16}};
struct SongDef {
  const SongNote *notes;
  uint8_t count;
  uint16_t unitMs;  // 16 分音符的長度
};
#define SONG(a, unit) {a, (uint8_t)(sizeof(a) / sizeof(a[0])), unit}
const SongDef SONGS[] = {SONG(SONG_BIRTHDAY, 115), SONG(SONG_TWINKLE, 95), SONG(SONG_TIGERS, 105),
                         SONG(SONG_BEE, 80)};

constexpr int FRAMES = 128;
int16_t frameBuf[FRAMES * 2];  // 立體聲 (左右聲道相同)
volatile bool abortPlay = false;
volatile bool streaming = false;
volatile bool playing = false;
uint32_t noiseState = 0x12345678;

struct Req {
  uint8_t kind;  // 0 = 音效，1 = 曲子
  uint8_t id;
  int8_t pitch;
  bool force;
};

void writeSilence(uint32_t ms) {
  memset(frameBuf, 0, sizeof(frameBuf));
  uint32_t frames = RATE * ms / 1000;
  while (frames > 0) {
    const uint32_t n = frames > FRAMES ? FRAMES : frames;
    i2s.write((const uint8_t *)frameBuf, n * 4);
    frames -= n;
  }
}

void playNote(const Note &n, float pitchMul) {
  const uint32_t total = RATE * n.ms / 1000;
  if (n.hz == 0 || n.amp == 0) {
    writeSilence(n.ms);
    return;
  }
  const uint32_t attack = n.voice == V_CLICK || n.voice == V_NOISE ? RATE / 2000 : RATE * 4 / 1000;
  const uint32_t release = total > RATE / 25 ? RATE / 25 : total / 2;  // 40ms 收尾 (避免爆音)
  const float amp = AMPLITUDE * n.amp / 100.0f;
  const float hz0 = n.hz * pitchMul, hz1 = (n.hzEnd ? n.hzEnd : n.hz) * pitchMul;
  float phase = 0, lp = 0;
  uint32_t i = 0;
  while (i < total && !abortPlay) {
    int k = 0;
    for (; k < FRAMES && i < total; k++, i++) {
      const float t = (float)i / (float)total;
      float env = 1.0f;
      if (i < attack) env = (float)i / attack;
      float s;
      switch (n.voice) {
        case V_VOICE: {  // 叫聲：滑音 + 6Hz 顫音 + 二三次泛音
          const float vib = 1.0f + 0.03f * sinf(2.0f * (float)M_PI * 6.0f * i / RATE);
          phase += 2.0f * (float)M_PI * (hz0 + (hz1 - hz0) * t) * vib / RATE;
          s = sinf(phase) * 0.6f + sinf(phase * 2.0f) * 0.28f + sinf(phase * 3.0f) * 0.12f;
          if (i > total - release) env = (float)(total - i) / release;
          break;
        }
        case V_NOISE: {  // 腳步：低通雜音，快速衰減
          noiseState = noiseState * 1664525u + 1013904223u;
          const float x = (float)(int32_t)noiseState / 2147483648.0f;
          const float a = hz0 / (float)RATE * 6.0f;
          lp += (x - lp) * (a > 1.0f ? 1.0f : a);
          s = lp * 2.0f;
          env *= expf(-t * 5.0f);
          break;
        }
        case V_BELL:  // 八音盒：泛音 + 指數衰減
          phase += 2.0f * (float)M_PI * hz0 / RATE;
          s = sinf(phase) * 0.7f + sinf(phase * 2.0f) * 0.2f + sinf(phase * 4.0f) * 0.1f;
          env *= expf(-t * 4.0f);
          if (i > total - RATE / 200) env *= (float)(total - i) / (RATE / 200);
          break;
        case V_CLICK:  // 節拍器：很短的「噠」
          phase += 2.0f * (float)M_PI * hz0 / RATE;
          s = sinf(phase);
          env *= expf(-t * 7.0f);
          break;
        default:  // 柔和正弦 (+ 一點二次泛音)
          phase += 2.0f * (float)M_PI * (hz0 + (hz1 - hz0) * t) / RATE;
          s = sinf(phase) * 0.85f + sinf(phase * 2.0f) * 0.15f;
          if (i > total - release) env = (float)(total - i) / release;
          break;
      }
      if (phase > 2.0f * (float)M_PI * 64.0f) phase -= 2.0f * (float)M_PI * 64.0f;  // 避免浮點誤差累積
      const int16_t v = (int16_t)(s * env * amp * 32767.0f);
      frameBuf[k * 2] = v;
      frameBuf[k * 2 + 1] = v;
    }
    i2s.write((const uint8_t *)frameBuf, k * 4);
  }
}

void playSfx(uint8_t id, int8_t pitch) {
  if (id >= (uint8_t)Sfx::Count) return;
  const SfxDef &d = SFX_TABLE[id];
  const float mul = 1.0f + pitch / 100.0f;
  for (uint8_t i = 0; i < d.count && !abortPlay; i++) playNote(d.notes[i], mul);
}

void playSongNotes(uint8_t id) {
  if (id >= sizeof(SONGS) / sizeof(SONGS[0])) return;
  const SongDef &song = SONGS[id];
  for (uint8_t i = 0; i < song.count && !abortPlay; i++) {
    const SongNote &sn = song.notes[i];
    const uint16_t ms = sn.len * song.unitMs;
    if (sn.midi == 0) {
      writeSilence(ms);
      continue;
    }
    const uint16_t hz = (uint16_t)(440.0f * powf(2.0f, (sn.midi - 69) / 12.0f));
    const Note n = {hz, ms, 0, V_BELL, 100};
    playNote(n, 1.0f);
  }
}

void soundTask(void *) {
  Req r;
  bool wasStreaming = false;
  for (;;) {
    if (wasStreaming && !streaming) {  // 連續輸出剛結束：關功放
      writeSilence(40);
      digitalWrite(Pins::AMP_CTRL, LOW);
      playing = false;
    }
    wasStreaming = streaming;
    // 連續輸出模式：沒有聲音時也一直送靜音 (延遲固定)
    if (xQueueReceive(queue, &r, streaming ? 0 : portMAX_DELAY) != pdTRUE) {
      if (streaming) {
        digitalWrite(Pins::AMP_CTRL, HIGH);
        playing = true;
        writeSilence(4);
      } else {
        playing = false;
      }
      continue;
    }
    playing = true;
    abortPlay = false;
    digitalWrite(Pins::AMP_CTRL, HIGH);  // 開功放
    if (!streaming) writeSilence(15);    // 等功放穩定
    for (;;) {
      if (playEnabled || r.force) {
        if (r.kind == 1) playSongNotes(r.id);
        else playSfx(r.id, r.pitch);
        abortPlay = false;
      }
      // 連續播放 (例如腳步聲) 時，300ms 內有下一個就不關功放，避免一直「啪」
      if (xQueueReceive(queue, &r, pdMS_TO_TICKS(streaming ? 0 : 300)) != pdTRUE) break;
    }
    if (!streaming) {
      writeSilence(40);  // 把 DMA 裡的聲音放完再關功放
      digitalWrite(Pins::AMP_CTRL, LOW);
      playing = false;
    }
  }
}
}  // namespace

bool SoundManager::initHardware() {
  if (hwReady_) return true;
  if (hwFailed_) return false;
  pinMode(Pins::AMP_CTRL, OUTPUT);
  digitalWrite(Pins::AMP_CTRL, LOW);
  i2s.setPins(Pins::I2S_BCLK, Pins::I2S_LRCK, Pins::I2S_DOUT, -1, Pins::I2S_MCLK);
  if (!i2s.begin(I2S_MODE_STD, RATE, I2S_DATA_BIT_WIDTH_16BIT, I2S_SLOT_MODE_STEREO)) {
    Serial.println("[Sound] I2S init failed");
    hwFailed_ = true;
    return false;
  }
  delay(5);  // 只在第一次需要聲音時執行：讓 MCLK 先跑起來
  if (!es8311Init()) {
    Serial.println("[Sound] ES8311 init failed");
    i2s.end();
    hwFailed_ = true;
    return false;
  }
  queue = xQueueCreate(6, sizeof(Req));
  if (queue == nullptr || xTaskCreate(soundTask, "sound", 4096, nullptr, 3, &task) != pdPASS) {
    Serial.println("[Sound] task create failed");
    hwFailed_ = true;
    return false;
  }
  hwReady_ = true;
  applyVolume();
  Serial.println("[Sound] ES8311 ready");
  return true;
}

void SoundManager::applyVolume() {
  if (hwReady_) wr(0x32, VOLUME_REG[level_ <= 2 ? level_ : 1]);
}

void SoundManager::setEnabled(bool on) {
  enabled_ = on;
  playEnabled = on;
  if (on) initHardware();
  else if (!hwReady_) digitalWrite(Pins::AMP_CTRL, LOW);
}

void SoundManager::setVolume(uint8_t level) {
  level_ = level <= 2 ? level : 1;
  applyVolume();
}

void SoundManager::send(uint8_t kind, uint8_t id, int8_t pitch, bool force) {
  if (!force && !enabled_) return;
  if (!initHardware() || queue == nullptr) return;  // 主動功能第一次用到時才初始化
  const Req r = {kind, id, pitch, force};
  xQueueSend(queue, &r, 0);  // 佇列滿就丟掉，不等待
}

void SoundManager::play(Sfx s, bool force, int8_t pitch) { send(0, (uint8_t)s, pitch, force); }

void SoundManager::playSong(uint8_t song) {
  if (song >= songCount()) return;
  stop();
  send(1, song, 0, true);
}

void SoundManager::stop() {
  if (!hwReady_ || queue == nullptr) return;
  xQueueReset(queue);
  abortPlay = true;
}

bool SoundManager::busy() const {
  if (!hwReady_ || queue == nullptr) return false;
  return uxQueueMessagesWaiting(queue) > 0 || (playing && !streaming);
}

void SoundManager::setStreaming(bool on) {
  if (on && !initHardware()) return;
  streaming = on;
  if (on && queue != nullptr) {  // 叫醒 task 進入連續輸出
    const Req r = {0, (uint8_t)Sfx::Count, 0, true};  // 無效 id = 只是喚醒
    xQueueSend(queue, &r, 0);
  }
}

uint8_t SoundManager::songCount() { return sizeof(SONGS) / sizeof(SONGS[0]); }
