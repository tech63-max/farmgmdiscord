# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project

ESP32-S3 desktop clock pet ("DeskPet", Vaporeon-style pixel pet) for the **Waveshare ESP32-S3 1.54" LCD, non-touch** board (ST7789 240x240 SPI LCD — the user sometimes calls it "OLED"). Arduino framework, all code under `src/`; `ESP32S3.ino` is an empty entry stub (Arduino compiles `src/**` recursively). User-facing docs: `README.md` (developer, Traditional Chinese) and `使用手冊.md` (end-user manual) — keep both in sync when behavior, buttons, or settings change. Reply to the user in Traditional Chinese.

## Build / flash / verify

```
arduino-cli compile --fqbn "esp32:esp32:esp32s3:CDCOnBoot=cdc,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB" --warnings default --upload -p COM6 .
```

- Toolchain: Arduino-ESP32 core **3.3.12**, GFX Library for Arduino **1.6.9** (1.6.0 does not compile on core 3.3.x). App partition is 3 MB and ~81% full — watch flash size.
- If the board sits silent after flashing (stuck in download mode): `esptool --port COM6 --before no-reset --after watchdog-reset chip-id`. Pulsing RTS from pyserial (`dtr=False; rts=True→False`) also does a clean reset.
- There are no unit tests. Verification = compile with zero warnings + drive the device over USB serial (115200) with pyserial and read logs. Useful console commands: `status` (heap/PSRAM/min heap), `walk`, `diary`, `tap` (tap-detection debug), `sound on|off`, `sound`, `cry`, `song 0~3`, `rhythm`, `alarm test` (actually rings; reset the board to stop it), `i2c`, `imu`. The host PC is usually on a different subnet than the board, so the web panel cannot be fetched from here; screen output cannot be observed — say so instead of claiming visual results.

## Asset / font pipeline (generated code — don't hand-edit outputs)

- `python tools/gen_draft_art.py` → regenerates **all** PNGs in `assets/` (deterministic; overwrites) + `assets/anchors.json`.
- `python tools/png2c.py` → `src/assets/Sprites.h/.cpp` (palette-indexed, index 0 = transparent). New UI sprites must be added to `REQUIRED_UI` in `png2c.py`.
- `python tools/gen_font.py` → `src/assets/Font12.*` (full Cubic 11 charset, ~31.7k glyphs; emoji render as boxes).
- Meadow backgrounds must stay **horizontally periodic over 120 px** (walk mode scrolls the ground rows ≥ y=52 with wrap-around).

## Architecture

- `App` (`src/app/App.cpp`, plus `AppFun.cpp` for menu/alarm/rhythm/music/cries, `Layout.h` for shared screen constants) is the only orchestrator: owns every module, a `Screen` state machine (`enter()` redraws a screen; per-screen `update*`/`handleButton`), sleep state (`Awake/Nap/Night`), and top-area popups (`Popup::Passkey/Notify/Alarm` drawn over y 0–59). Everything is non-blocking, driven from `loop()` with `millis()`.
- Rendering: `PixelCanvas` is a 64x68 logical canvas scaled 2x for the pet area (pushed at x=56, y=60). `Scene` composes a 120x68 RGB565 background (time-of-day base + weather overlays); the pet canvas copies its slice from that buffer. `WalkMode` keeps its own scrolled copy and the pet is pointed at it via `pet_.setScene()` during walks. Large buffers are allocated in PSRAM via `allocLarge()` to keep internal RAM free for Wi-Fi/BLE/TLS.
- Menu-screen UI is built from `drawHeader` / `drawCard` / `drawToggle` / `drawKeyHints(left, mid, right)`. Physical buttons left→right are **BOOT (GPIO0), PWR (GPIO5), PLUS (GPIO4)**; key hints are three slots aligned to that order, and labels on screen are Chinese (左鍵/中鍵/右鍵).
- Settings: `SettingsManager` (NVS namespace `deskpet`, writes only changed keys, `sanitize()` on load). Adding a setting touches: `Settings` struct + load/save/sanitize, `SETTING_ITEMS` + `changeSetting()` + `drawSettings()` + `settingGroup()` table in App.cpp, `Str::` labels, the web panel row **and** `handleSave()` validation, README/manual settings tables.
- `Diary` stores a fixed-size 7-day blob in NVS (`diary`/`days`, versioned). Changing `DiaryDay`/`DiaryStat::Count` changes the blob size and wipes saved diaries unless you migrate/bump `VERSION`.
- Background work: `WeatherService` (CWA F-C0032-001 over HTTPS with cert bundle) runs in its own FreeRTOS task; `SoundManager` has a playback task fed by a queue; `AncsClient` is iPhone ANCS on raw NimBLE APIs (client role on an inbound connection).
- `WebPanel` (port 80, mDNS `deskpet`) streams HTML in chunks from a fixed 768-byte buffer (`sendf`); also hosts the Wi-Fi setup captive portal when `WifiManager` opens the `DeskPet-XXXX` AP.
- All UI text lives in `src/ui/Strings.h`.

## Constraints and decisions from the user

- **Sound is default OFF.** Automatic effects (pat, notify, cries, footsteps, hourly) require the 音效 setting AND the pet awake. User-initiated features (alarm, music box, rhythm game) play regardless (`sound_.play(..., force=true)`). Audio HW (I2S + ES8311) is initialized lazily on first need; amp GPIO7 is HIGH only while playing. **Never initialize the microphone (ES7210)** without explicit user consent.
- No RPG battles, collection/unlock systems, in-game currency, or complex quests. Walk/rhythm events are cosmetic and only counted in the diary.
- Secrets (Wi-Fi password, CWA API key) live only in NVS — never in source, logs, or web output. The web panel has **no password by the user's choice**; keep backend validation of every field and HTML-escape all output.
- The "screen face-down = blank" feature was removed at the user's request; don't reintroduce it.
- Don't guess hardware details: pins/registers come from Waveshare's official repo `waveshareteam/ESP32-S3-Touch-LCD-1.54` (the non-touch repo URL 404s) and Espressif's `esp_codec_dev` es8311 driver. No RTC on the board (I2C: 0x18 ES8311, 0x40 ES7210, 0x6B QMI8658).

## Gotchas

- Compare `millis()` timestamps with signed differences (`(int32_t)(now - t)`): web/serial handlers call `millis()` later than the loop's cached `now`, and unsigned subtraction underflow previously caused instant naps and absurd walk durations.
- Tap/pat detection is software on QMI8658 (5 ms polling, short-impulse episodes); button edges block taps for 400 ms. Thresholds in `MotionSensor.cpp` are not yet calibrated on hardware.
- Tilt axis/sign (`TILT_AXIS`, `TILT_SIGN` in `src/config/BoardConfig.h`) are unverified guesses.
- When patching files via Python inside a bash heredoc, `\n` inside Python string literals becomes a real newline in the C++ output (this broke several string literals); use `chr(92)+"n"` or the Edit tool for C escape sequences, and check for stray NUL bytes after writing `'\0'`.
