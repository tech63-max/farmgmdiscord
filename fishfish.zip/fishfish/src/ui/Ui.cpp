#include "Ui.h"
#include <stdio.h>
#include <string.h>
#include "../aquarium/Environment.h"
#include "../aquarium/Fish.h"
#include "../config/AquariumConfig.h"
#include "../core/Util.h"
#include "../events/EventManager.h"
#include "../gfx/Gfx.h"
#include "../storage/SaveData.h"

namespace ui {
namespace {
Screen scr = MAIN;
uint8_t infoMode = 0;          // 0 無, 1 角落時間, 2 生態面板
uint32_t infoUntil = 0;
char noticeText[64];
uint32_t noticeAt = 0, noticeUntil = 0;
int menuSel = 0;
int evSel = 1;
int logPage = 0;
bool resetArmed = false;
uint32_t lastInput = 0;

constexpr uint32_t NOTICE_MS = 3500;
const uint16_t WHITE = 0xFFFF;
uint16_t DIM, ACCENT, SHADOW, PANEL, BORDER;

enum MenuItem { M_BRIGHT, M_DAYLEN, M_FREQ, M_NOTICE, M_GORE, M_TIME, M_EVTEST, M_SAVE, M_RESET, M_CLOSE, M_COUNT };

void panel(int x, int y, int w, int h) {
  gfx::blendRect(x, y, w, h, PANEL, 205);
  gfx::hline(x, y, w, BORDER);
  gfx::hline(x, y + h - 1, w, BORDER);
  gfx::vline(x, y, h, BORDER);
  gfx::vline(x + w - 1, y, h, BORDER);
}

void menuLine(int i, char* buf, int cap) {
  const save::Settings& s = save::settings;
  static const char* FREQ[] = {"低", "中", "高"};
  static const char* NOTI[] = {"關閉", "特殊以上", "全部"};
  static const char* GORE[] = {"關閉", "輕微", "完整"};
  switch (i) {
    case M_BRIGHT: snprintf(buf, cap, "亮度　　　%u%%", s.brightness); break;
    case M_DAYLEN: snprintf(buf, cap, "一天長度　%u 分鐘", acfg::DAY_LEN_OPTIONS[s.dayLenIdx]); break;
    case M_FREQ: snprintf(buf, cap, "事件頻率　%s", FREQ[s.freq]); break;
    case M_NOTICE: snprintf(buf, cap, "事件提示　%s", NOTI[s.notices]); break;
    case M_GORE: snprintf(buf, cap, "血腥效果　%s", GORE[s.gore]); break;
    case M_TIME: snprintf(buf, cap, "時間跳到下一個時段"); break;
    case M_EVTEST: snprintf(buf, cap, "事件測試 (指定 ID)"); break;
    case M_SAVE: snprintf(buf, cap, "立即存檔"); break;
    case M_RESET: snprintf(buf, cap, resetArmed ? "再按一次確認重設" : "重設水族箱"); break;
    default: snprintf(buf, cap, "關閉選單"); break;
  }
}

Action menuConfirm(uint32_t ms) {
  save::Settings& s = save::settings;
  Action a;
  if (menuSel != M_RESET) resetArmed = false;
  switch (menuSel) {
    case M_BRIGHT: s.brightness = s.brightness >= 100 ? 20 : s.brightness + 20; a.type = A_SETTINGS; break;
    case M_DAYLEN: s.dayLenIdx = (s.dayLenIdx + 1) % 5; a.type = A_SETTINGS; break;
    case M_FREQ: s.freq = (s.freq + 1) % 3; a.type = A_SETTINGS; break;
    case M_NOTICE: s.notices = (s.notices + 1) % 3; a.type = A_SETTINGS; break;
    case M_GORE: s.gore = (s.gore + 1) % 3; a.type = A_SETTINGS; break;
    case M_TIME: a.type = A_JUMP_TIME; break;
    case M_EVTEST: scr = EVTEST; break;
    case M_SAVE: a.type = A_SAVE; break;
    case M_RESET:
      if (!resetArmed) resetArmed = true;
      else { resetArmed = false; a.type = A_RESET; scr = MAIN; }
      break;
    default: scr = MAIN; break;
  }
  return a;
}
}  // namespace

const char* modeName(uint8_t m) {
  static const char* N[] = {"餵食", "敲玻璃", "打氣"};
  return m < 3 ? N[m] : "?";
}

void begin() {
  DIM = gfx::rgb(0xa8c8d8);
  ACCENT = gfx::rgb(0xffe080);
  SHADOW = gfx::rgb(0x061018);
  PANEL = gfx::rgb(0x0a1a26);
  BORDER = gfx::rgb(0x4a7a90);
  noticeText[0] = 0;
}

Screen screen() { return scr; }

void notice(const char* text, uint32_t ms, bool important) {
  (void)important;
  strncpy(noticeText, text, sizeof(noticeText) - 1);
  noticeText[sizeof(noticeText) - 1] = 0;
  noticeAt = ms;
  noticeUntil = ms + NOTICE_MS;
}

void onEventStart(int id, bool user, uint32_t ms) {
  const ev::Def& d = ev::def(id);
  const uint8_t level = save::settings.notices;
  if (user || level == 0) return;            // 玩家自己的操作另外提示
  if (level == 1 && d.rarity == ev::COMMON && !d.big) return;  // 大型事件一定提示
  char buf[64];
  if (d.big) snprintf(buf, sizeof(buf), "【%s】", d.name);
  else if (d.rarity >= ev::RARE) snprintf(buf, sizeof(buf), "★ %s", d.name);
  else snprintf(buf, sizeof(buf), "%s", d.name);
  notice(buf, ms);
}

Action handle(const buttons::Event& e, uint32_t ms) {
  Action a;
  if (e.btn == buttons::NONE) return a;
  lastInput = ms;
  using buttons::BOOT;
  using buttons::LONG;
  using buttons::PLUS;
  using buttons::PWR;
  using buttons::SHORT;
  switch (scr) {
    case MAIN:
      if (e.btn == PLUS && e.kind == SHORT) {
        a.type = save::settings.mode == 0 ? A_FEED : (save::settings.mode == 1 ? A_TAP : A_AIR);
      } else if (e.btn == PLUS && e.kind == LONG) {
        save::settings.mode = (save::settings.mode + 1) % 3;
        char buf[48];
        snprintf(buf, sizeof(buf), "互動模式：%s", modeName(save::settings.mode));
        notice(buf, ms);
        a.type = A_SETTINGS;
      } else if (e.btn == BOOT && e.kind == SHORT) {
        infoMode = (infoMode + 1) % 3;
        if (infoMode == 2) infoUntil = ms + 12000;
      } else if (e.btn == BOOT && e.kind == LONG) {
        scr = MENU; menuSel = 0; resetArmed = false;
      } else if (e.btn == PWR && e.kind == SHORT) {
        scr = LOG; logPage = 0;
      } else if (e.btn == PWR && e.kind == LONG) {
        a.type = A_SHUTDOWN;
      }
      break;
    case LOG:
      if (e.btn == PLUS) logPage++;
      else if (e.btn == PWR || e.btn == BOOT) scr = MAIN;
      break;
    case MENU:
      if (e.btn == PLUS) { menuSel = (menuSel + (e.kind == LONG ? M_COUNT - 1 : 1)) % M_COUNT; resetArmed = false; }
      else if (e.btn == BOOT && e.kind == SHORT) a = menuConfirm(ms);
      else if (e.btn == PWR || (e.btn == BOOT && e.kind == LONG)) { scr = MAIN; resetArmed = false; }
      break;
    case EVTEST:
      if (e.btn == PLUS) {
        // 只在已實作的事件之間切換
        for (int k = 0; k < (e.kind == LONG ? 10 : 1); k++)
          do { if (++evSel > ev::EVENT_COUNT) evSel = 1; } while (!ev::def(evSel).impl);
      }
      else if (e.btn == BOOT && e.kind == SHORT) { a.type = A_PLAY_EVENT; a.arg = evSel; scr = MAIN; }
      else if (e.btn == PWR || (e.btn == BOOT && e.kind == LONG)) scr = MENU;
      break;
  }
  return a;
}

void update(uint32_t ms) {
  if (infoMode == 2 && util::reached(ms, infoUntil)) infoMode = 0;
  // 紀錄/選單太久沒操作就回到主畫面
  if (scr != MAIN && ms - lastInput > 60000) scr = MAIN;
}

void draw(uint32_t ms) {
  char buf[96];
  // 角落時間 (在魚缸上蓋的位置，不擋到水族箱)
  if (infoMode >= 1 && scr == MAIN) {
    char t[32];
    env::virtualTime(t, sizeof(t));
    snprintf(buf, sizeof(buf), "%s %s", t, env::phaseName(env::phase()));
    gfx::textShadow(gfx::W - gfx::textWidth(buf) - 4, 3, buf, DIM, SHADOW);
  }
  if (infoMode == 2 && scr == MAIN) {
    const env::Eco& e = env::eco;
    panel(18, 46, 204, 146);
    int y = 50;
    gfx::textShadow(26, y, "水族箱狀態", ACCENT, SHADOW); y += 16;
    snprintf(buf, sizeof(buf), "水溫 %.1f°C (模擬值)", e.waterTemp); gfx::text(26, y, buf, WHITE); y += 15;
    snprintf(buf, sizeof(buf), "清澈度 %d%%　水草 %d%%", (int)(e.clarity * 100), (int)(e.plantGrowth * 100)); gfx::text(26, y, buf, WHITE); y += 15;
    snprintf(buf, sizeof(buf), "魚群心情 %d%%　精力 %d%%", (int)(e.fishMood * 100), (int)(e.fishEnergy * 100)); gfx::text(26, y, buf, WHITE); y += 15;
    snprintf(buf, sizeof(buf), "水中飼料 %d%%　餵食 %lu 次", (int)(e.food * 100), (unsigned long)e.feeds); gfx::text(26, y, buf, WHITE); y += 15;
    snprintf(buf, sizeof(buf), "已發現事件 %d / %d", ev::discoveredCount(), ev::implementedCount()); gfx::text(26, y, buf, WHITE); y += 15;
    snprintf(buf, sizeof(buf), "互動模式：%s", modeName(save::settings.mode)); gfx::text(26, y, buf, WHITE); y += 15;
    gfx::text(26, y, save::status(), DIM);
  }

  if (scr == LOG) {
    panel(8, 20, 224, 200);
    snprintf(buf, sizeof(buf), "生態紀錄　已發現 %d/%d", ev::discoveredCount(), ev::implementedCount());
    gfx::textShadow(16, 25, buf, ACCENT, SHADOW);
    constexpr int PER = 10;
    const int logPages = (ev::logCount() + PER - 1) / PER;
    const int pages = logPages + 2;  // 倒數第二頁 = 稀有發現，最後一頁 = 死亡紀錄
    const int page = logPage % (pages > 0 ? pages : 1);
    if (page < logPages) {
      for (int i = 0; i < PER; i++) {
        int idx = page * PER + i;
        if (idx >= ev::logCount()) break;
        const ev::LogEntry& le = ev::logAt(idx);
        const ev::Def& d = ev::def(le.id);
        snprintf(buf, sizeof(buf), "%lu天%02u:%02u %s%s", (unsigned long)le.day, le.minute / 60, le.minute % 60, d.rarity >= ev::RARE ? "★" : "", d.name);
        gfx::text(16, 44 + i * 16, buf, le.user ? DIM : WHITE);
      }
      if (ev::logCount() == 0) gfx::text(16, 50, "還沒有紀錄", DIM);
    } else if (page == pages - 1) {
      snprintf(buf, sizeof(buf), "死亡紀錄　累計 %d 條", fish::deathCount());
      gfx::text(16, 44, buf, DIM);
      for (int i = 0; i < fish::deathLogN() && i < 9; i++) {
        const fish::Death& d = fish::deathAt(i);
        snprintf(buf, sizeof(buf), "%lu天 %s (%s) %s", (unsigned long)d.day, fish::nameAt(d.nameIdx), fish::info(d.sp).name,
                 d.cause ? ev::def(d.cause).name : "");
        gfx::text(16, 62 + i * 15, buf, WHITE);
      }
      if (fish::deathLogN() == 0) gfx::text(16, 62, "還沒有魚死掉", DIM);
    } else {
      gfx::text(16, 44, "稀有發現", DIM);
      int row = 0;
      for (int id = 1; id <= ev::EVENT_COUNT && row < 18; id++) {
        const ev::Def& d = ev::def(id);
        if (d.rarity < ev::RARE || !d.impl) continue;
        bool got = ev::discovered(id);
        snprintf(buf, sizeof(buf), "%s %s", got ? "✓" : "?", got ? d.name : "？？？");
        gfx::text(16 + (row % 2) * 108, 60 + (row / 2) * 15, buf, got ? WHITE : DIM);
        row++;
      }
    }
    snprintf(buf, sizeof(buf), "右鍵 下一頁 %d/%d　中鍵 返回", page + 1, pages);
    gfx::text(16, 202, buf, DIM);
  }

  if (scr == MENU) {
    panel(14, 22, 212, 196);
    gfx::textShadow(22, 27, "設定", ACCENT, SHADOW);
    for (int i = 0; i < M_COUNT; i++) {
      menuLine(i, buf, sizeof(buf));
      const int y = 45 + i * 15;
      if (i == menuSel) gfx::blendRect(18, y - 1, 204, 15, gfx::rgb(0x3a7aa0), 170);
      gfx::text(26, y, buf, i == menuSel ? WHITE : DIM);
    }
    gfx::text(22, 201, "右鍵 移動　左鍵 確認　中鍵 返回", DIM);
  }

  if (scr == EVTEST) {
    const ev::Def& d = ev::def(evSel);
    panel(14, 60, 212, 120);
    gfx::textShadow(22, 66, "事件測試", ACCENT, SHADOW);
    snprintf(buf, sizeof(buf), "#%03d %s", evSel, d.name);
    gfx::text(22, 88, buf, WHITE);
    snprintf(buf, sizeof(buf), "%s・%s・看過 %u 次", ev::categoryName(d.category), ev::rarityName(d.rarity), ev::timesSeen(evSel));
    gfx::text(22, 106, buf, DIM);
    gfx::text(22, 130, "右鍵 +1 (長按 +10)", DIM);
    gfx::text(22, 146, "左鍵 播放　中鍵 返回", DIM);
  }

  // 事件提示 (底部，淡入淡出)
  if (noticeText[0] && !util::reached(ms, noticeUntil)) {
    const uint32_t age = ms - noticeAt, left = noticeUntil - ms;
    float a = util::clamp01(age / 300.0f) * util::clamp01(left / 500.0f);
    const int w = gfx::textWidth(noticeText) + 14;
    const int x = (gfx::W - w) / 2, y = 216;
    gfx::blendRect(x, y, w, 18, PANEL, (uint8_t)(170 * a));
    gfx::textAlpha(x + 7, y + 3, noticeText, WHITE, (uint8_t)(255 * a));
  }
}

}  // namespace ui
