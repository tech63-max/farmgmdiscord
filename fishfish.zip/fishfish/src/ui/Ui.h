// 畫面上的文字 UI：事件提示、資訊顯示、設定選單、事件測試、生態紀錄
// 主畫面預設不顯示任何 UI，提示會自動消失
#pragma once
#include <stdint.h>
#include "../hw/ButtonManager.h"

namespace ui {

enum Screen : uint8_t { MAIN, LOG, MENU, EVTEST };
enum ActionType : uint8_t {
  A_NONE, A_FEED, A_TAP, A_AIR, A_SAVE, A_RESET, A_SHUTDOWN, A_SETTINGS, A_PLAY_EVENT, A_JUMP_TIME
};
struct Action { ActionType type = A_NONE; int arg = 0; };

void begin();
Action handle(const buttons::Event& e, uint32_t ms);
void update(uint32_t ms);
void draw(uint32_t ms);
void notice(const char* text, uint32_t ms, bool important = true);
void onEventStart(int id, bool user, uint32_t ms);
Screen screen();
const char* modeName(uint8_t mode);

}  // namespace ui
