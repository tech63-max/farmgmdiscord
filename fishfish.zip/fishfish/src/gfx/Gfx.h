// 畫面緩衝與基本繪圖 (240x240 RGB565)
// 場景以「美術像素 = 2x2 螢幕像素」的方塊像素風繪製，但座標用螢幕原生像素，物件可以平滑移動。
// 日夜/特殊光色在每幀最後以 LUT 對整個畫面做色彩分級 (grade)，發光物件在分級之後才疊上去。
#pragma once
#include <stdint.h>
#include "Sprite.h"

namespace gfx {

constexpr int W = 240, H = 240;
constexpr int PX = 2;                 // 一個美術像素 = 2x2 螢幕像素
constexpr int CW = W / PX, CH = H / PX;  // 美術畫布 120x120 (遮罩用)

extern uint16_t* fb;  // 畫面 (優先放內部 RAM)
extern uint16_t* bg;  // 烘好的靜態背景 (PSRAM)

bool begin();
void blitBg();

inline uint16_t rgb(uint8_t r, uint8_t g, uint8_t b) { return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3); }
inline uint16_t rgb(uint32_t hex) { return rgb(hex >> 16, (hex >> 8) & 0xFF, hex & 0xFF); }
inline void unpack(uint16_t c, int& r, int& g, int& b) {
  r = (c >> 8) & 0xF8; r |= r >> 5;
  g = (c >> 3) & 0xFC; g |= g >> 6;
  b = (c << 3) & 0xF8; b |= b >> 5;
}
inline uint32_t expand565(uint16_t c) { return (c | ((uint32_t)c << 16)) & 0x07E0F81Fu; }
inline uint16_t blendFast(uint16_t bgc, uint32_t fgx, uint32_t a32) {  // a32: 0..32
  uint32_t b = expand565(bgc);
  b = (b + (((fgx - b) * a32) >> 5)) & 0x07E0F81Fu;
  return (uint16_t)(b | (b >> 16));
}
uint16_t mix(uint16_t a, uint16_t b, uint8_t t);  // t=0 → a，255 → b

inline void pset(int x, int y, uint16_t c) {
  if ((unsigned)x < (unsigned)W && (unsigned)y < (unsigned)H) fb[y * W + x] = c;
}
void pblend(int x, int y, uint16_t c, uint8_t a);
void padd(int x, int y, int r, int g, int b);  // 加色 (發光)

void fillRect(int x, int y, int w, int h, uint16_t c);
void blendRect(int x, int y, int w, int h, uint16_t c, uint8_t a);
void hline(int x, int y, int w, uint16_t c);
void vline(int x, int y, int h, uint16_t c);
void line(int x0, int y0, int x1, int y1, uint16_t c);
void fillCircle(int cx, int cy, int r, uint16_t c);
void blendCircle(int cx, int cy, int r, uint16_t c, uint8_t a);
void ring(int cx, int cy, int r, uint16_t c, uint8_t a);           // 1px 圓框 (半透明)
void ellipseArc(int cx, int cy, int rx, int ry, uint16_t c, uint8_t a, bool upperOnly);
void glow(int cx, int cy, int r, uint32_t hex, uint8_t intensity);  // 柔和光暈 (加色)
// 美術像素 (2x2 方塊，對齊到偶數座標，維持方塊感)
inline void block(int x, int y, uint16_t c) {
  x &= ~1; y &= ~1;
  pset(x, y, c); pset(x + 1, y, c); pset(x, y + 1, c); pset(x + 1, y + 1, c);
}
void blockBlend(int x, int y, uint16_t c, uint8_t a);

// ---- 岩石遮罩 (美術畫布解析度)：躲在岩石後面的魚不畫在這些像素上 ----
void setRock(int cx, int cy);
bool rockAt(int x, int y);  // 螢幕座標

// ---- Sprite ----
struct SprOpt {
  int px = PX;            // 一個美術像素的螢幕邊長
  float xs = 1;           // 水平縮放 (負 = 翻轉，接近 0 = 轉身中)
  float tailPhase = 0;    // 擺尾相位
  float tailAmp = 0;      // 擺尾幅度 (螢幕像素)
  float wave = 0;         // 全身波動 (跳舞/伸展)
  bool eyesClosed = false;
  uint8_t alpha = 255;
  bool behindRock = false;  // 套用岩石遮罩
  float glint = -1;       // 0..1 = 反光帶位置
  int32_t solid = -1;     // >= 0：整張圖畫成單一顏色 (影子/剪影)
  bool additive = false;  // 加色 (發光體)
  int frame = 0;          // 動畫格 (超過格數會取餘數)
  uint8_t hue = 0;        // 配色變體：0 原色，1/2 = RGB 色版輪換 (同一張圖換顏色)
  uint32_t tint = 0;      // 疊色 (受傷閃紅、屍體發灰)
  uint8_t tintA = 0;      // 疊色強度 0..255
  bool flipY = false;     // 上下翻 (翻肚子的屍體)
  uint8_t u0 = 0, u1 = 255;  // 只畫圖上第 u0..u1 欄 (被咬成兩半)
  uint8_t woundU = 255;   // 這一欄畫成傷口紅色 (被咬掉的切口)
};
void sprite(const SpriteDef& s, float cx, float cy, const SprOpt& o);

// ---- 色彩分級 (日夜光色、混濁、特殊色調) ----
// 每個色版：out = in * mul + add (add 以 0..255 表示)
void setGrade(float mr, float mg, float mb, float ar, float ag, float ab);
void applyGrade();

// ---- 文字 (Cubic11 12px 繁中點陣字) ----
constexpr int TEXT_H = 13;
int textWidth(const char* utf8);
int text(int x, int y, const char* utf8, uint16_t color);
void textAlpha(int x, int y, const char* utf8, uint16_t color, uint8_t alpha);
void textShadow(int x, int y, const char* utf8, uint16_t color, uint16_t shadow);
void textCenter(int y, const char* utf8, uint16_t color, uint16_t shadow);

}  // namespace gfx
