// 索引色像素圖 (資料由 tools/gen_sprites.py 產生到 SpriteData.h)
#pragma once
#include <stdint.h>

struct SpriteDef {
  uint8_t w, h;
  uint8_t tail;          // 最左邊幾欄是尾巴 (擺尾動畫用)
  uint8_t eye, lid;      // 眼睛的調色盤索引；閉眼時改用 lid 的顏色 (0 = 無)
  uint8_t frames;        // 動畫格數 (魚 = 4 格游泳動畫)
  const uint8_t* px;     // frames*w*h 個索引，0 = 透明
  const uint32_t* pal;   // 0xRRGGBB，索引 0 不用
};
