#include "Gfx.h"
#include <Arduino.h>
#include <esp_heap_caps.h>
#include <math.h>
#include "../core/Util.h"
#include <string.h>
#include "Font12.h"

namespace gfx {

uint16_t* fb = nullptr;
uint16_t* bg = nullptr;
static uint8_t rockBits[CW * CH / 8];

bool begin() {
  const size_t n = (size_t)W * H * sizeof(uint16_t);
  // 畫面緩衝優先放內部 RAM (逐點繪圖較快)，不夠才放 PSRAM；背景只在每幀開頭整塊複製，放 PSRAM
  fb = (uint16_t*)heap_caps_malloc(n, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  if (!fb) fb = (uint16_t*)heap_caps_malloc(n, MALLOC_CAP_SPIRAM);
  bg = (uint16_t*)heap_caps_malloc(n, MALLOC_CAP_SPIRAM);
  if (!fb || !bg) return false;
  memset(fb, 0, n);
  memset(bg, 0, n);
  memset(rockBits, 0, sizeof(rockBits));
  return true;
}

void blitBg() { memcpy(fb, bg, (size_t)W * H * sizeof(uint16_t)); }

uint16_t mix(uint16_t a, uint16_t b, uint8_t t) { return blendFast(a, expand565(b), (t + 4) >> 3); }

void pblend(int x, int y, uint16_t c, uint8_t a) {
  if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H || !a) return;
  uint16_t* p = fb + y * W + x;
  *p = a >= 250 ? c : blendFast(*p, expand565(c), (a + 4) >> 3);
}

void padd(int x, int y, int r, int g, int b) {
  if ((unsigned)x >= (unsigned)W || (unsigned)y >= (unsigned)H) return;
  uint16_t* p = fb + y * W + x;
  int R, G, B;
  unpack(*p, R, G, B);
  R += r; G += g; B += b;
  *p = rgb(R > 255 ? 255 : R, G > 255 ? 255 : G, B > 255 ? 255 : B);
}

void fillRect(int x, int y, int w, int h, uint16_t c) {
  if (x < 0) { w += x; x = 0; }
  if (y < 0) { h += y; y = 0; }
  if (x + w > W) w = W - x;
  if (y + h > H) h = H - y;
  if (w <= 0 || h <= 0) return;
  for (int j = 0; j < h; j++) {
    uint16_t* p = fb + (y + j) * W + x;
    for (int i = 0; i < w; i++) p[i] = c;
  }
}

void blendRect(int x, int y, int w, int h, uint16_t c, uint8_t a) {
  if (x < 0) { w += x; x = 0; }
  if (y < 0) { h += y; y = 0; }
  if (x + w > W) w = W - x;
  if (y + h > H) h = H - y;
  if (w <= 0 || h <= 0 || !a) return;
  const uint32_t fx = expand565(c), a32 = (a + 4) >> 3;
  for (int j = 0; j < h; j++) {
    uint16_t* p = fb + (y + j) * W + x;
    for (int i = 0; i < w; i++) p[i] = blendFast(p[i], fx, a32);
  }
}

void hline(int x, int y, int w, uint16_t c) { fillRect(x, y, w, 1, c); }
void vline(int x, int y, int h, uint16_t c) { fillRect(x, y, 1, h, c); }

void line(int x0, int y0, int x1, int y1, uint16_t c) {
  int dx = abs(x1 - x0), sx = x0 < x1 ? 1 : -1, dy = -abs(y1 - y0), sy = y0 < y1 ? 1 : -1, err = dx + dy;
  for (;;) {
    pset(x0, y0, c);
    if (x0 == x1 && y0 == y1) break;
    int e2 = 2 * err;
    if (e2 >= dy) { err += dy; x0 += sx; }
    if (e2 <= dx) { err += dx; y0 += sy; }
  }
}

void fillCircle(int cx, int cy, int r, uint16_t c) {
  for (int y = -r; y <= r; y++) {
    int hw = (int)sqrtf((float)(r * r - y * y) + 0.25f);
    hline(cx - hw, cy + y, hw * 2 + 1, c);
  }
}

void blendCircle(int cx, int cy, int r, uint16_t c, uint8_t a) {
  for (int y = -r; y <= r; y++) {
    int hw = (int)sqrtf((float)(r * r - y * y) + 0.25f);
    blendRect(cx - hw, cy + y, hw * 2 + 1, 1, c, a);
  }
}

void ring(int cx, int cy, int r, uint16_t c, uint8_t a) {
  if (r <= 0) { pblend(cx, cy, c, a); return; }
  int x = r, y = 0, err = 1 - r;
  while (x >= y) {
    pblend(cx + x, cy + y, c, a); pblend(cx - x, cy + y, c, a);
    pblend(cx + x, cy - y, c, a); pblend(cx - x, cy - y, c, a);
    if (x != y) {
      pblend(cx + y, cy + x, c, a); pblend(cx - y, cy + x, c, a);
      pblend(cx + y, cy - x, c, a); pblend(cx - y, cy - x, c, a);
    }
    y++;
    if (err < 0) err += 2 * y + 1; else { x--; err += 2 * (y - x) + 1; }
  }
}

void ellipseArc(int cx, int cy, int rx, int ry, uint16_t c, uint8_t a, bool upperOnly) {
  if (rx <= 0 || ry <= 0) return;
  const int steps = rx * 4 + 8;
  int lx = -9999, ly = -9999;
  for (int i = 0; i <= steps; i++) {
    float t = (upperOnly ? (float)M_PI : 2 * (float)M_PI) * i / steps;
    int x = cx + (int)lroundf(util::fcos(t) * rx), y = cy - (int)lroundf(util::fsin(t) * ry);
    if (x != lx || y != ly) pblend(x, y, c, a);
    lx = x; ly = y;
  }
}

void glow(int cx, int cy, int r, uint32_t hex, uint8_t intensity) {
  // 方塊式光暈：以 2x2 為單位、亮度只有 3 階 (不做平滑漸層)
  const int R = (hex >> 16) & 255, G = (hex >> 8) & 255, B = hex & 255;
  const int r2 = r * r;
  cx &= ~1; cy &= ~1;
  for (int y = -r; y <= r; y += 2)
    for (int x = -r; x <= r; x += 2) {
      const int d2 = x * x + y * y;
      if (d2 > r2) continue;
      const float f = d2 * 9 < r2 ? 1.0f : (d2 * 3 < r2 ? 0.55f : 0.25f);
      const float k = f * intensity / 255.0f;
      const int ar = (int)(R * k), ag = (int)(G * k), ab = (int)(B * k);
      padd(cx + x, cy + y, ar, ag, ab); padd(cx + x + 1, cy + y, ar, ag, ab);
      padd(cx + x, cy + y + 1, ar, ag, ab); padd(cx + x + 1, cy + y + 1, ar, ag, ab);
    }
}

void blockBlend(int x, int y, uint16_t c, uint8_t a) {
  x &= ~1; y &= ~1;
  pblend(x, y, c, a); pblend(x + 1, y, c, a); pblend(x, y + 1, c, a); pblend(x + 1, y + 1, c, a);
}

void setRock(int cx, int cy) {
  if ((unsigned)cx >= (unsigned)CW || (unsigned)cy >= (unsigned)CH) return;
  int i = cy * CW + cx;
  rockBits[i >> 3] |= 1 << (i & 7);
}
bool rockAt(int x, int y) {
  x >>= 1; y >>= 1;
  if ((unsigned)x >= (unsigned)CW || (unsigned)y >= (unsigned)CH) return false;
  int i = y * CW + x;
  return rockBits[i >> 3] & (1 << (i & 7));
}

// ---- Sprite ----
void sprite(const SpriteDef& s, float cx, float cy, const SprOpt& o) {
  const float axs = fabsf(o.xs);
  int dw = (int)lroundf(s.w * o.px * axs);
  if (dw < 1) dw = 1;
  const int dh = s.h * o.px;
  const int x0 = (int)lroundf(cx - dw * 0.5f), y0 = (int)lroundf(cy - dh * 0.5f);
  if (x0 >= W || x0 + dw <= 0 || y0 - 8 >= H || y0 + dh + 8 <= 0) return;
  const bool flip = o.xs < 0;
  const uint32_t a32 = (o.alpha + 4) >> 3;
  const uint16_t solid = o.solid >= 0 ? rgb((uint32_t)o.solid) : 0;
  const uint32_t solidX = expand565(solid);
  const uint8_t* px = s.px + (size_t)((s.frames > 1 ? (o.frame % s.frames + s.frames) % s.frames : 0)) * s.w * s.h;
  for (int c = 0; c < dw; c++) {
    const int sx = x0 + c;
    if ((unsigned)sx >= (unsigned)W) continue;
    int u = (int)((c + 0.5f) * s.w / dw);
    if (u >= s.w) u = s.w - 1;
    if (flip) u = s.w - 1 - u;
    if (u < o.u0 || u > o.u1) continue;
    const bool wound = u == o.woundU;
    int off = 0;
    if (s.tail && u < s.tail && o.tailAmp != 0)
      off = (int)lroundf(util::fsin(o.tailPhase) * o.tailAmp * (float)(s.tail - u) / s.tail);
    if (o.wave != 0) off += (int)lroundf(util::fsin(o.tailPhase * 0.5f + u * 0.7f) * o.wave);
    bool glintCol = false;
    if (o.glint >= 0) {
      float gu = (float)u / s.w;
      glintCol = fabsf(gu - o.glint) < 0.13f;
    }
    for (int v = 0; v < s.h; v++) {
      uint8_t idx = px[(o.flipY ? s.h - 1 - v : v) * s.w + u];
      if (!idx) continue;
      uint16_t col;
      if (o.solid >= 0) col = solid;
      else {
        if (o.eyesClosed && idx == s.eye && s.lid) idx = s.lid;
        uint32_t hx = s.pal[idx];
        if (o.hue && idx != s.eye) {
          const uint32_t r = hx >> 16, g = (hx >> 8) & 0xFF, b = hx & 0xFF;
          hx = o.hue == 1 ? (b << 16 | r << 8 | g) : (g << 16 | b << 8 | r);
        }
        col = rgb(hx);
        if (o.tintA) col = mix(col, rgb(o.tint), o.tintA);
        if (wound) col = (v & 1) ? rgb(0xc01820) : rgb(0xe86070);
      }
      const int yy0 = y0 + v * o.px + off;
      for (int k = 0; k < o.px; k++) {
        const int sy = yy0 + k;
        if ((unsigned)sy >= (unsigned)H) continue;
        if (o.behindRock && rockAt(sx, sy)) continue;
        uint16_t* p = fb + sy * W + sx;
        if (o.additive) {
          int r, g, b;
          unpack(col, r, g, b);
          padd(sx, sy, r * o.alpha / 255, g * o.alpha / 255, b * o.alpha / 255);
        } else if (o.alpha >= 250) {
          *p = col;
        } else {
          *p = blendFast(*p, o.solid >= 0 ? solidX : expand565(col), a32);
        }
        if (glintCol) *p = blendFast(*p, expand565(0xFFFF), 18);
      }
    }
  }
}

// ---- 色彩分級 ----
static uint16_t lutR[32], lutG[64], lutB[32];
static bool gradeIdentity = true;

void setGrade(float mr, float mg, float mb, float ar, float ag, float ab) {
  gradeIdentity = fabsf(mr - 1) < 0.01f && fabsf(mg - 1) < 0.01f && fabsf(mb - 1) < 0.01f && fabsf(ar) < 1 && fabsf(ag) < 1 &&
                  fabsf(ab) < 1;
  auto ch = [](int v, float m, float a) {
    int o = (int)(v * m + a);
    return o < 0 ? 0 : (o > 255 ? 255 : o);
  };
  for (int i = 0; i < 32; i++) {
    int v = (i << 3) | (i >> 2);
    lutR[i] = (uint16_t)((ch(v, mr, ar) & 0xF8) << 8);
    lutB[i] = (uint16_t)(ch(v, mb, ab) >> 3);
  }
  for (int i = 0; i < 64; i++) {
    int v = (i << 2) | (i >> 4);
    lutG[i] = (uint16_t)((ch(v, mg, ag) & 0xFC) << 3);
  }
}

void applyGrade() {
  if (gradeIdentity) return;
  uint16_t* p = fb;
  for (int i = 0; i < W * H; i++) {
    uint16_t c = p[i];
    p[i] = lutR[c >> 11] | lutG[(c >> 5) & 63] | lutB[c & 31];
  }
}

// ---- 文字 ----
static uint32_t nextCp(const char*& s) {
  uint8_t c = (uint8_t)*s++;
  if (c < 0x80) return c;
  int n = (c >= 0xF0) ? 3 : (c >= 0xE0) ? 2 : (c >= 0xC0) ? 1 : 0;
  uint32_t cp = c & (0x3F >> n);
  while (n-- > 0 && (*s & 0xC0) == 0x80) cp = (cp << 6) | (*s++ & 0x3F);
  return cp;
}

static int glyphIndex(uint32_t cp) {
  if (cp > 0xFFFF) return -1;
  int lo = 0, hi = FONT12_COUNT - 1;
  while (lo <= hi) {
    int mid = (lo + hi) >> 1;
    if (FONT12_CODES[mid] == cp) return mid;
    if (FONT12_CODES[mid] < cp) lo = mid + 1; else hi = mid - 1;
  }
  return -1;
}

int textWidth(const char* s) {
  int w = 0;
  while (*s) { int g = glyphIndex(nextCp(s)); w += g >= 0 ? FONT12_WIDTHS[g] : 6; }
  return w;
}

static int drawText(int x, int y, const char* s, uint16_t color, uint8_t alpha) {
  int x0 = x;
  while (*s) {
    int g = glyphIndex(nextCp(s));
    if (g < 0) { x += 6; continue; }
    const uint16_t* rows = &FONT12_ROWS[(uint32_t)g * FONT12_HEIGHT];
    int gw = FONT12_WIDTHS[g];
    for (int j = 0; j < FONT12_HEIGHT; j++) {
      uint16_t bits = rows[j];
      for (int i = 0; i < gw && bits; i++, bits <<= 1)
        if (bits & 0x8000) { if (alpha >= 250) pset(x + i, y + j, color); else pblend(x + i, y + j, color, alpha); }
    }
    x += gw;
  }
  return x - x0;
}

int text(int x, int y, const char* s, uint16_t color) { return drawText(x, y, s, color, 255); }
void textAlpha(int x, int y, const char* s, uint16_t color, uint8_t alpha) { if (alpha) drawText(x, y, s, color, alpha); }
void textShadow(int x, int y, const char* s, uint16_t color, uint16_t shadow) {
  drawText(x + 1, y + 1, s, shadow, 255);
  drawText(x, y, s, color, 255);
}
void textCenter(int y, const char* s, uint16_t color, uint16_t shadow) { textShadow((W - textWidth(s)) / 2, y, s, color, shadow); }

}  // namespace gfx
