#include "ButtonManager.h"
#include <Arduino.h>
#include "../config/BoardConfig.h"

namespace buttons {
namespace {
constexpr uint32_t DEBOUNCE_MS = 25, LONG_MS = 700;
struct State {
  int pin;
  bool raw, stable, ignore, longSent;
  uint32_t changedAt, pressedAt;
};
State st[BTN_COUNT] = {{board::PIN_BTN_BOOT}, {board::PIN_BTN_PWR}, {board::PIN_BTN_PLUS}};
}  // namespace

void begin(uint32_t ms) {
  for (auto& b : st) {
    pinMode(b.pin, INPUT_PULLUP);
    b.raw = b.stable = digitalRead(b.pin) == LOW;
    b.ignore = b.stable;  // 開機時按著 (例如按 PWR 開機) → 放開前不算
    b.longSent = false;
    b.changedAt = b.pressedAt = ms;
  }
}

Event poll(uint32_t ms) {
  Event out;
  for (int i = 0; i < BTN_COUNT; i++) {
    State& b = st[i];
    const bool down = digitalRead(b.pin) == LOW;
    if (down != b.raw) { b.raw = down; b.changedAt = ms; }
    if (ms - b.changedAt >= DEBOUNCE_MS && down != b.stable) {
      b.stable = down;
      if (down) { b.pressedAt = ms; b.longSent = false; }
      else {
        if (b.ignore) b.ignore = false;
        else if (!b.longSent && out.btn == NONE) { out.btn = (Btn)i; out.kind = SHORT; }
      }
    }
    if (b.stable && !b.ignore && !b.longSent && ms - b.pressedAt >= LONG_MS) {
      b.longSent = true;
      if (out.btn == NONE) { out.btn = (Btn)i; out.kind = LONG; }
    }
  }
  return out;
}

bool anyDown() {
  for (auto& b : st) if (b.stable) return true;
  return false;
}
}  // namespace buttons
