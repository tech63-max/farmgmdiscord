// microSD (SDMMC 4-bit) —— 選配。沒插卡或讀寫失敗時水族箱照常運作，只是不存檔到 SD
#pragma once
#include <stddef.h>
#include <stdint.h>

namespace storage {
bool begin();      // 掛載 (不自動格式化)，建立 /aquarium 目錄
bool ok();
// 讀整個檔案到 buf (會補 '\0')，回傳長度；失敗回傳 -1
int readFile(const char* path, char* buf, size_t cap);
// 安全寫入：寫 .tmp → 驗證大小 → 舊檔改名 .bak → .tmp 改正式名。資料經過內部 RAM 對齊緩衝區
bool safeWrite(const char* path, const char* data, size_t len);
// 開機復原：正式檔不存在時，用驗證過的 .tmp 或 .bak 頂上
void recover(const char* path);
// 刪除正式檔與 .tmp / .bak (重設水族箱用)
void removeAll(const char* path);
uint32_t writeErrors();
}
