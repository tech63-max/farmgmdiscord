#include "PowerManager.h"
#include <Arduino.h>
#include "../config/BoardConfig.h"
#include "Display.h"

namespace power {
void earlyInit() {
  pinMode(board::PIN_POWER_LATCH, OUTPUT);
  digitalWrite(board::PIN_POWER_LATCH, HIGH);  // 電池供電必須最先做
  pinMode(board::PIN_AMP, OUTPUT);
  digitalWrite(board::PIN_AMP, LOW);           // 不使用聲音：功放關閉，不初始化 codec / 麥克風
}

bool shutdown() {
  display::setBacklight(0);
  digitalWrite(board::PIN_POWER_LATCH, LOW);
  delay(400);  // 只在關機時等待電源放電，不在一般流程使用
  // 還在執行 = USB 供電中，重新鎖住電源，避免之後拔 USB 時突然斷電
  digitalWrite(board::PIN_POWER_LATCH, HIGH);
  return false;
}
}  // namespace power
