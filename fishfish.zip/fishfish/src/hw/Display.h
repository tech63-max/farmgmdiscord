// LCD 與背光
#pragma once
#include <stdint.h>

namespace display {
bool begin();                 // 初始化 LCD (背光保持關閉)
void push();                  // 把 gfx::fb 送到 LCD
void setBacklight(float pct); // 0..100
float backlight();
}
