#include "Display.h"
#include <Arduino.h>
#include <Arduino_GFX_Library.h>
#include <esp_heap_caps.h>
#include <string.h>
#include "../config/BoardConfig.h"
#include "../gfx/Gfx.h"

namespace display {
namespace {
Arduino_ESP32SPI bus(board::PIN_LCD_DC, board::PIN_LCD_CS, board::PIN_LCD_SCK, board::PIN_LCD_MOSI, GFX_NOT_DEFINED);
Arduino_ST7789 panel(&bus, board::PIN_LCD_RST, board::LCD_ROTATION, true /*IPS*/, board::LCD_W, board::LCD_H);
float level = 0;
bool fbInternal = false;
constexpr int STRIP_H = 16;
uint16_t strip[board::LCD_W * STRIP_H];  // 內部 RAM 分條緩衝 (畫面緩衝在 PSRAM 時用)
}  // namespace

bool begin() {
  ledcAttach(board::PIN_LCD_BL, board::BL_PWM_HZ, board::BL_PWM_BITS);
  ledcWrite(board::PIN_LCD_BL, 0);  // 初始化期間關背光，避免看到雜訊
  if (!panel.begin(board::LCD_SPI_HZ)) return false;
  panel.fillScreen(0);
  fbInternal = gfx::fb && esp_ptr_internal(gfx::fb);
  return true;
}

void push() {
  if (fbInternal) {
    panel.draw16bitRGBBitmap(0, 0, gfx::fb, gfx::W, gfx::H);  // 非 const 指標 (PINOUT 坑 #2)
    return;
  }
  for (int y0 = 0; y0 < gfx::H; y0 += STRIP_H) {
    memcpy(strip, gfx::fb + y0 * gfx::W, sizeof(strip));
    panel.draw16bitRGBBitmap(0, y0, strip, gfx::W, STRIP_H);
  }
}

void setBacklight(float pct) {
  if (pct < 0) pct = 0;
  if (pct > 100) pct = 100;
  level = pct;
  ledcWrite(board::PIN_LCD_BL, (uint32_t)(1023 * pct / 100));
}
float backlight() { return level; }
}  // namespace display
