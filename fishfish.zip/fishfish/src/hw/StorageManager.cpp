#include "StorageManager.h"
#include <Arduino.h>
#include <SD_MMC.h>
#include <string.h>
#include "../config/BoardConfig.h"

namespace storage {
namespace {
bool mounted = false;
uint32_t errors = 0;
// PINOUT 坑 #1：FATFS 會把來源指標直接交給 DMA，寫入資料必須先複製到內部 RAM、對齊的緩衝區
alignas(16) uint8_t wbuf[2048];

void pathWith(char* out, size_t cap, const char* path, const char* ext) { snprintf(out, cap, "%s%s", path, ext); }

size_t fileSize(const char* path) {
  File f = SD_MMC.open(path, FILE_READ);
  if (!f) return 0;
  size_t n = f.size();
  f.close();
  return n;
}
}  // namespace

bool begin() {
  if (!SD_MMC.setPins(board::SD_CLK, board::SD_CMD, board::SD_D0, board::SD_D1, board::SD_D2, board::SD_D3)) return false;
  // mountpoint, 4-bit, 不自動格式化, 20 MHz, 最多 5 個檔
  if (!SD_MMC.begin("/sdcard", false, false, SDMMC_FREQ_DEFAULT, 5)) return false;
  if (SD_MMC.cardType() == CARD_NONE) { SD_MMC.end(); return false; }
  if (!SD_MMC.exists("/aquarium")) SD_MMC.mkdir("/aquarium");
  if (!SD_MMC.exists("/aquarium/assets")) SD_MMC.mkdir("/aquarium/assets");
  mounted = true;
  return true;
}

bool ok() { return mounted; }
uint32_t writeErrors() { return errors; }

int readFile(const char* path, char* buf, size_t cap) {
  if (!mounted || cap < 2) return -1;
  File f = SD_MMC.open(path, FILE_READ);
  if (!f) return -1;
  size_t n = f.size();
  if (n >= cap) { f.close(); return -1; }
  size_t got = 0;
  while (got < n) {
    size_t chunk = n - got > sizeof(wbuf) ? sizeof(wbuf) : n - got;
    int r = f.read(wbuf, chunk);
    if (r <= 0) break;
    memcpy(buf + got, wbuf, r);
    got += r;
  }
  f.close();
  if (got != n) return -1;
  buf[got] = 0;
  return (int)got;
}

bool safeWrite(const char* path, const char* data, size_t len) {
  if (!mounted) return false;
  char tmp[64], bak[64];
  pathWith(tmp, sizeof(tmp), path, ".tmp");
  pathWith(bak, sizeof(bak), path, ".bak");
  File f = SD_MMC.open(tmp, FILE_WRITE);
  if (!f) { errors++; return false; }
  size_t done = 0;
  while (done < len) {
    size_t chunk = len - done > sizeof(wbuf) ? sizeof(wbuf) : len - done;
    memcpy(wbuf, data + done, chunk);
    if (f.write(wbuf, chunk) != chunk) break;
    done += chunk;
  }
  f.close();
  if (done != len || fileSize(tmp) != len) { SD_MMC.remove(tmp); errors++; return false; }
  // FAT 的 rename 不會覆蓋既有檔案 (PINOUT 坑 #7)
  if (SD_MMC.exists(path)) {
    if (SD_MMC.exists(bak)) SD_MMC.remove(bak);
    if (!SD_MMC.rename(path, bak)) { errors++; return false; }
  }
  if (!SD_MMC.rename(tmp, path)) { SD_MMC.rename(bak, path); errors++; return false; }
  return true;
}

void recover(const char* path) {
  if (!mounted) return;
  char tmp[64], bak[64];
  pathWith(tmp, sizeof(tmp), path, ".tmp");
  pathWith(bak, sizeof(bak), path, ".bak");
  if (!SD_MMC.exists(path)) {
    // 上次在改名途中斷電：.tmp 已完整寫好 (大小 > 0) 就用它，否則退回 .bak
    if (SD_MMC.exists(tmp) && fileSize(tmp) > 0) SD_MMC.rename(tmp, path);
    else if (SD_MMC.exists(bak)) SD_MMC.rename(bak, path);
  }
  if (SD_MMC.exists(tmp)) SD_MMC.remove(tmp);
}

void removeAll(const char* path) {
  if (!mounted) return;
  char tmp[64], bak[64];
  pathWith(tmp, sizeof(tmp), path, ".tmp");
  pathWith(bak, sizeof(bak), path, ".bak");
  if (SD_MMC.exists(path)) SD_MMC.remove(path);
  if (SD_MMC.exists(tmp)) SD_MMC.remove(tmp);
  if (SD_MMC.exists(bak)) SD_MMC.remove(bak);
}
}  // namespace storage
