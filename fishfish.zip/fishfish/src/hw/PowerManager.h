// 電源鎖定 / 功放 / 安全關機
#pragma once

namespace power {
void earlyInit();           // 開機第一件事：鎖住電源、關閉功放
// 存檔後關背光並放開電源鎖定。電池供電時會真的斷電 (不會返回)；
// 插著 USB 時 GPIO2 拉低無法斷電，回傳 false，由呼叫端進入待機畫面
bool shutdown();
}
