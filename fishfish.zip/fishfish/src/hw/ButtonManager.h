// 三顆實體按鍵：去抖動 25 ms、長按 700 ms、短按在放開時觸發、已送長按就不送短按 (millis 非阻塞輪詢)
#pragma once
#include <stdint.h>

namespace buttons {
enum Btn : uint8_t { BOOT, PWR, PLUS, BTN_COUNT, NONE = 0xFF };
enum Kind : uint8_t { SHORT, LONG };
struct Event { Btn btn = NONE; Kind kind = SHORT; };
void begin(uint32_t ms);
Event poll(uint32_t ms);
bool anyDown();
}
