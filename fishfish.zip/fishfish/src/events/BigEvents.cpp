// 大型事件 (101～200，見 BIG_EVENTS_PLAN.md)。每個事件都走「預兆 → 進場 → 主體 → 高潮 → 收尾」。
// 目前已實作：124 鯊魚巡游、129 鯊魚來襲、199 新的開始。其餘 ID 只有資料，不會被排程。
#include <Arduino.h>
#include <math.h>
#include <stdio.h>
#include "../aquarium/Creatures.h"
#include "../aquarium/Environment.h"
#include "../aquarium/Fish.h"
#include "../aquarium/ParticleSystem.h"
#include "../aquarium/Remains.h"
#include "../gfx/Gfx.h"
#include "../aquarium/Scene.h"
#include "../core/Util.h"
#include "Event.h"
#include "EventManager.h"

namespace ev {
namespace {
using util::rng;
using fish::F;
namespace P = particles;
namespace CR = creatures;
constexpr float PI_F = 3.14159265f;

void next(Inst& in) { in.stage++; in.st = 0; in.entered = false; in.arriveT = -1; in.acc = 0; }
bool enter(Inst& in) { if (in.entered) return false; in.entered = true; return true; }
bool every(Inst& in, float period, float dt) {
  in.acc += dt;
  if (in.acc >= period) { in.acc -= period; return true; }
  return false;
}
// 同一幀需要第二、第三個計時器時用這個 (acc 放在 in.v[])
bool timer(float& acc, float period, float dt) {
  acc += dt;
  if (acc >= period) { acc -= period; return true; }
  return false;
}

// ---- 魚 ----
bool mine(const Inst& in, int i) { return i >= 0 && i < fish::count() && F[i].on && F[i].owner == in.owner; }
int mineCount(const Inst& in) {
  int c = 0;
  for (int i = 0; i < fish::count(); i++) c += mine(in, i);
  return c;
}
// 借用所有活著、沒被別的事件佔用的魚
int claimAll(Inst& in) {
  int c = 0;
  for (int i = 0; i < fish::count(); i++) {
    fish::Fish& f = F[i];
    if (!f.on || (f.owner && f.owner != in.owner)) continue;
    fish::claim(i, in.owner);
    f.manual = false;
    c++;
  }
  return c;
}
// 往遠離 (sx,sy) 的方向逃
void fleeFrom(int i, float sx, float sy, float spdMul) {
  fish::Fish& f = F[i];
  float dx = f.x - sx, dy = f.y - sy, d = sqrtf(dx * dx + dy * dy) + 0.01f;
  // 逃離方向 + 往中間拉一點 (不要全部擠進角落)
  const float tx = (f.x + dx / d * 70) * 0.7f + 120 * 0.3f, ty = (f.y + dy / d * 40) * 0.7f + 105 * 0.3f;
  fish::command(i, fish::FLEE, tx, ty, fish::info(f.sp).fast * spdMul, 5);
  f.wiggle = 0;
}
// 挑一條自由的魚：睡著的也可以 (大型事件會把牠叫醒；夜晚大部分的魚都在睡)
int pickAny() { return fish::pick(0xFFFFFFFF, true); }
// 縮在一起發抖
void cower(int i, float cx, float cy) {
  fish::Fish& f = F[i];
  fish::command(i, fish::HIDE, cx + rng.range(-22, 22), cy + rng.range(-14, 14), fish::info(f.sp).speed * 0.9f, 6);
  f.wiggle = 0.45f;
}

// ---- 鯊魚 ----
int spawnShark(Inst& in, int slot, float x, float y, int8_t dir, uint8_t layer) {
  int i = CR::spawn(CR::SHARK, x, y, dir, in.owner);
  if (i < 0) return -1;
  CR::C& c = CR::at(i);
  c.alpha = c.alphaT = 1;  // 從畫面外游進來，不用淡入
  c.layer = layer;
  in.cr[slot] = (int8_t)i;
  if (in.nCr <= slot) in.nCr = (uint8_t)(slot + 1);
  return i;
}
CR::C* sharkAt(Inst& in, int slot) {
  if (slot >= in.nCr || in.cr[slot] < 0) return nullptr;
  CR::C& c = CR::at(in.cr[slot]);
  return (c.on && c.type == CR::SHARK) ? &c : nullptr;
}
float mouthX(const CR::C& s) { return s.x + s.dir * 32; }
float mouthY(const CR::C& s) { return s.y + 4; }
// 咬得到：魚在鯊魚頭部前半段 (嘴巴附近) 的範圍內
bool atMouth(const CR::C& s, int i, float r) {
  const float dx = (F[i].x - s.x) * s.dir;  // 正 = 在鯊魚前方
  return dx > 10 && dx < 34 + r && fabsf(F[i].y - mouthY(s)) < r + 4;
}
void sharkTo(CR::C& s, float x, float y, float spd) {
  s.tx = util::clamp(x, -60.0f, 300.0f);
  s.ty = util::clamp(y, (float)scene::SWIM_TOP + 12, (float)scene::swimBottom((int)util::clamp(x, 0.0f, 239.0f)) - 12);
  s.spd = spd;
  s.mode = CR::SWIM;
}
// 追獵物：讓「嘴巴」對準魚 (鯊魚中心停在魚後方)，並稍微衝過頭才咬得到
void chase(CR::C& s, int i, float spd) {
  const float dx = F[i].x - s.x;
  const int8_t want = fabsf(dx) > 14 ? (dx > 0 ? 1 : -1) : s.dir;
  sharkTo(s, F[i].x - want * 18, F[i].y - 4, spd);
}

// 被咬：依血腥設定 (完整 = 血霧 + 鱗片，輕微 = 紅色閃光，關閉 = 魚嚇得逃出魚缸，之後原封不動游回來)
void eat(CR::C& s, int i, uint8_t cause) {
  const float x = F[i].x, y = F[i].y;
  char buf[48];
  s.bite = 0.6f;
  if (gore::death()) {
    P::gib(x, y, 30);
    // 完整血腥：一半機率被咬成兩半，半截沉到沙地上
    const bool split = gore::blood() && rng.chance(0.5f);
    if (split) remains::halves(i, 34);
    snprintf(buf, sizeof(buf), split ? "%s被鯊魚咬成兩半" : "%s被鯊魚吃掉了", fish::nameOf(i));
  } else {
    P::bubbles(x, y, 6, 6);
    snprintf(buf, sizeof(buf), "%s嚇得逃出魚缸", fish::nameOf(i));
  }
  fish::kill(i, cause);
  message(buf);
}

// 選下一個獵物：先抓看得到的、離嘴巴近的；河豚 (還沒被吐過) 和躲在岩石後的放到最後
int pickPrey(Inst& in, const CR::C& s) {
  int best = -1;
  float bd = 1e9f;
  for (int i = 0; i < fish::count(); i++) {
    if (!mine(in, i)) continue;
    float dx = F[i].x - mouthX(s), dy = F[i].y - mouthY(s);
    float d = sqrtf(dx * dx + dy * dy);
    if (F[i].sp == fish::PUFFER && !(in.k[2] & (1 << i))) d += 1000;
    if (F[i].layer == 0) d += 600;
    if (d < bd) { bd = d; best = i; }
  }
  return best;
}

// ================================================================ 124 鯊魚巡游
// 預兆 (魚停住) → 鯊魚游進來 → 咬傷一條魚的尾巴 → 鯊魚離開
bool start124(Inst& in) {
  if (claimAll(in) < 1) return false;
  env::fx.dreadT = 0.6f;
  return true;
}
void update124(Inst& in, float dt) {
  env::Fx& fx = env::fx;
  CR::C* s = sharkAt(in, 0);
  switch (in.stage) {
    case 0:  // 預兆：魚群突然停住、發抖
      if (enter(in))
        for (int i = 0; i < fish::count(); i++)
          if (mine(in, i)) { fish::command(i, fish::IDLE, F[i].x, F[i].y, 2, 10); F[i].wiggle = 0.45f; }
      if (in.st > 4) next(in);
      break;
    case 1:  // 進場：鯊魚從左邊慢慢游進來
      if (enter(in)) {
        float y = rng.range(80, 130);
        if (spawnShark(in, 0, -50, y, 1, 1) < 0) { in.done = true; break; }
        s = sharkAt(in, 0);
        sharkTo(*s, 120, y, 34);
      }
      if (!s || s->x > 70 || in.st > 10) next(in);
      break;
    case 2: {  // 主體：衝向最近的魚，咬掉一塊尾巴
      if (!s) { next(in); break; }
      if (enter(in)) in.k[0] = (int16_t)pickPrey(in, *s);
      const int i = in.k[0];
      if (!mine(in, i)) { next(in); break; }
      chase(*s, i, 100);
      if (every(in, 0.4f, dt)) fleeFrom(i, s->x, s->y, 0.8f);
      if (atMouth(*s, i, 12)) {
        s->bite = 0.6f;
        const float tx = F[i].x - F[i].dir * fish::halfW(i);
        P::blood(tx, F[i].y, 10, 4);
        P::scales(tx, F[i].y, 2);
        fish::hurt(i, 240);
        char buf[48];
        snprintf(buf, sizeof(buf), "%s的尾巴被咬了一口", fish::nameOf(i));
        message(buf);
        fleeFrom(i, s->x, s->y, 1.0f);
        next(in);
      } else if (in.st > 10) next(in);
      break;
    }
    case 3:  // 收尾：鯊魚離開，魚四散
      if (enter(in)) {
        if (s) { s->dir = 1; sharkTo(*s, 300, s->y - 10, 45); }
        float sx = s ? s->x : 120, sy = s ? s->y : 110;
        for (int i = 0; i < fish::count(); i++)
          if (mine(in, i) && F[i].hurt <= 0) { fish::release(i); }
        fish::startle(sx, sy, 90);
        fx.dreadT = 0;
      }
      if (!s || s->x > 280 || in.st > 12) in.done = true;
      break;
    default: in.done = true; break;
  }
}

// ================================================================ 129 鯊魚來襲
// v[0] 獵殺計時、v[1] 下一次換目標前的盤旋時間、v[5] 空缸秒數；k[0] 目前獵物、k[1] 吃掉的數量、k[2] 吐過的河豚 (bit)
bool start129(Inst& in) {
  stopMinor();  // 小事件放掉所有魚
  if (claimAll(in) < 1) return false;
  fish::setRefillHold(true);
  env::fx.dreadT = 1;
  env::fx.swayT = 0.35f;
  in.k[0] = -1;
  in.v[5] = rng.range(30, 60);
  return true;
}
void update129(Inst& in, float dt) {
  env::Fx& fx = env::fx;
  CR::C* s = sharkAt(in, 0);
  switch (in.stage) {
    case 0: {  // 預兆：水變暗、魚擠到左下角發抖，背景有鯊魚剪影繞過
      if (enter(in)) {
        for (int i = 0; i < fish::count(); i++) if (mine(in, i)) cower(i, 78, 118);
        int b = spawnShark(in, 1, 280, 70, -1, 0);
        if (b >= 0) sharkTo(CR::at(b), -70, 76, 26);
      }
      if (every(in, 1.5f, dt))
        for (int i = 0; i < fish::count(); i++) if (mine(in, i)) cower(i, 78, 118);
      if (in.st > 10) next(in);
      break;
    }
    case 1: {  // 進場：鯊魚從右邊衝進來，水草被帶得大幅傾斜
      if (enter(in)) {
        if (spawnShark(in, 0, 300, 110, -1, 1) < 0) { in.done = true; break; }
        s = sharkAt(in, 0);
        sharkTo(*s, 150, 110, 110);
        fx.currentT = -30;
        fx.swayT = 2.2f;
        P::burst(P::DUST, 200, scene::sandTop(200) - 3, 14, 26, 2.5f);
      }
      if (s && in.st > 1.5f && every(in, 0.5f, dt))
        for (int i = 0; i < fish::count(); i++)
          if (mine(in, i) && fabsf(F[i].x - s->x) < 80) fleeFrom(i, s->x, s->y, 0.7f);
      if (in.st > 5) { fx.currentT = 0; fx.swayT = 0.6f; next(in); }
      break;
    }
    case 2: {  // 獵殺：一條一條追、咬
      if (!s) { next(in); break; }
      in.v[0] += dt;
      if (mineCount(in) == 0) { next(in); break; }
      // 超過 90 秒還沒吃完 (被卡住)：剩下的一口一條
      if (in.v[0] > 90) {
        if (every(in, 1.0f, dt))
          for (int i = 0; i < fish::count(); i++)
            if (mine(in, i)) { sharkTo(*s, F[i].x, F[i].y, 140); eat(*s, i, 129); in.k[1]++; break; }
        break;
      }
      // 盤旋一下再換目標
      if (in.v[1] > 0) {
        in.v[1] -= dt;
        if (in.entered == false) {
          in.entered = true;
          sharkTo(*s, rng.range(50, 190), rng.range(70, 140), 45);
        }
      } else {
        int i = in.k[0];
        if (!mine(in, i)) { i = pickPrey(in, *s); in.k[0] = (int16_t)i; in.v[2] = 0; }
        if (i < 0) break;
        in.v[2] += dt;  // 追這條的時間
        fish::Fish& f = F[i];
        // 躲在岩石後面：鯊魚游過去把牠拖出來
        if (f.layer == 0 && fabsf(f.x - s->x) < 40 && fabsf(f.y - s->y) < 30) {
          f.layer = 1; f.wantLayer = 1;
          if (gore::blood()) P::blood(f.x, f.y, 4, 4);
        }
        const float spd = in.v[2] > 12 ? 150 : 92;  // 追太久 → 猛衝
        chase(*s, i, spd);
        if (timer(in.v[3], 0.35f, dt)) fleeFrom(i, s->x, s->y, 0.9f);
        if (atMouth(*s, i, 11)) {
          if (f.sp == fish::PUFFER && !(in.k[2] & (1 << i))) {
            // 河豚：全膨脹卡在嘴裡，第一口吐出來
            in.k[2] |= (int16_t)(1 << i);
            f.inflate = f.inflateMax = 4.5f;
            fish::hurt(i, 300);
            s->bite = 0.5f;
            P::blood(mouthX(*s), mouthY(*s), 5, 3);
            char buf[48];
            snprintf(buf, sizeof(buf), "%s鼓起刺來，被鯊魚吐了出來", fish::nameOf(i));
            message(buf);
            fleeFrom(i, s->x, s->y, 1.2f);
            sharkTo(*s, s->x - s->dir * 50, s->y - 20, 60);  // 被刺到往後退
            in.k[0] = -1;
            in.v[1] = 3;
            in.entered = false;
          } else {
            eat(*s, i, 129);
            in.k[1]++;
            in.k[0] = -1;
            in.v[1] = rng.range(2.5f, 4);  // 盤旋一下
            in.entered = false;
          }
        }
      }
      // 其他的魚：靠近鯊魚就逃，遠的就縮著發抖
      if (timer(in.v[4], 0.6f, dt))
        for (int i = 0; i < fish::count(); i++) {
          if (!mine(in, i) || i == in.k[0]) continue;
          const float dx = F[i].x - s->x, dy = F[i].y - s->y;
          if (dx * dx + dy * dy < 75 * 75) fleeFrom(i, s->x, s->y, 0.75f);
          else if (F[i].st != fish::FLEE || F[i].stT < 1) cower(i, F[i].x, F[i].y);
        }
      break;
    }
    case 3:  // 高潮：吃光了，鯊魚停在中央張嘴，整缸泛紅
      if (!s) { next(in); break; }
      if (enter(in)) sharkTo(*s, 120, 110, 30);
      if (every(in, 1.4f, dt)) { s->bite = 0.5f; if (gore::blood()) P::blood(mouthX(*s), mouthY(*s), 4, 5); }
      if (in.st > 6) next(in);
      break;
    case 4:  // 收尾：鯊魚慢慢游走，血霧沉澱，光線恢復
      if (enter(in)) {
        if (s) sharkTo(*s, 310, (s ? s->y : 100) - 8, 40);
        fx.dreadT = 0.3f;
        fx.swayT = 0.8f;
      }
      if (!s || s->x > 290 || in.st > 14) next(in);
      break;
    case 5:  // 空缸：沒有魚，只剩水草和氣泡
      if (enter(in)) { fx.dreadT = 0; fx.swayT = 1; }
      if (every(in, 4, dt)) P::bubbles(rng.range(40, 200), scene::sandTop(120) - 4, 2, 3);
      if (in.st > in.v[5]) in.done = true;
      break;
    default: in.done = true; break;
  }
}
void end129(Inst& in) {
  env::Fx& fx = env::fx;
  fx.dreadT = 0; fx.swayT = 1; fx.currentT = 0;
  fish::releaseOwner(in.owner);
  World& w = world();
  w.lastSharkDay = env::day();
  if (w.sharks < 65535) w.sharks++;
  // 回流：新的魚一條一條從不同方向游進來 (每 20～40 秒一條)
  fish::setRefillHold(false);
  if (fish::alive() < fish::ROSTER_TARGET) {
    fish::queueRefill(in.stage >= 5 ? 3 : 10, 20, 40);
    w.newStart = true;
  }
  if (in.k[1] > 0) {
    char buf[48];
    snprintf(buf, sizeof(buf), gore::death() ? "鯊魚吃掉了 %d 條魚" : "%d 條魚逃走了", in.k[1]);
    message(buf);
  }
}

// ================================================================ 199 新的開始
// 鯊魚之後新來的魚第一次集合：圍成一圈認識彼此 → 排隊游一趟 → 在水草旁休息
bool start199(Inst& in) {
  world().newStart = false;
  for (int k = 0; k < 8; k++) {
    int i = pickAny();
    if (i < 0) break;
    fish::claim(i, in.owner);
    in.fish[in.nFish++] = (int8_t)i;
  }
  if (in.nFish < 3) return false;
  message("新的魚群集合了");
  return true;
}
void update199(Inst& in, float dt) {
  const int n = in.nFish;
  const float cx = 120, cy = 105;
  switch (in.stage) {
    case 0:  // 集合到中央
      if (enter(in))
        for (int k = 0; k < n; k++) {
          float a = 2 * PI_F * k / n;
          fish::command(in.fish[k], fish::SWIM, cx + cosf(a) * 34, cy + sinf(a) * 20, fish::info(F[in.fish[k]].sp).speed * 1.1f, 20);
        }
      if (in.st > 8) next(in);
      break;
    case 1: {  // 繞圈認識彼此
      in.v[0] += dt * 0.7f;
      for (int k = 0; k < n; k++) {
        float a = in.v[0] + 2 * PI_F * k / n;
        fish::moveTo(in.fish[k], cx + util::fcos(a) * 34, cy + util::fsin(a) * 20, dt);
      }
      if (every(in, 1.2f, dt)) { int k = rng.irange(0, n - 1); P::bubbles(F[in.fish[k]].x, F[in.fish[k]].y - 4, 2, 2); }
      if (in.st > 10) next(in);
      break;
    }
    case 2:  // 排成一列往左
    case 3:  // 再一起往右
      if (enter(in))
        for (int k = 0; k < n; k++) {
          const float x = in.stage == 2 ? 46 + k * 18 : 194 - k * 18;
          fish::command(in.fish[k], fish::SWIM, x, 92 + (k & 1) * 6, fish::info(F[in.fish[k]].sp).speed * 1.2f, 20);
        }
      if (in.st > 8) next(in);
      break;
    case 4:  // 在水草旁休息
      if (enter(in)) {
        float px, py;
        scene::plantPoint(scene::nearestPlant(120, false), 0.25f, px, py);
        for (int k = 0; k < n; k++)
          fish::command(in.fish[k], fish::REST, px + rng.range(-30, 30), py + rng.range(-12, 12), fish::info(F[in.fish[k]].sp).speed, 20);
      }
      if (in.st > 9) in.done = true;
      break;
    default: in.done = true; break;
  }
}

// ================================================================ 第二批：魚群內鬥、餵食慘劇、屍體 (101–110、161、163、171、172、174)
int take(Inst& in, int i) {
  if (i < 0 || in.nFish >= 8 || F[i].owner) return -1;
  fish::claim(i, in.owner);
  in.fish[in.nFish] = (int8_t)i;
  return in.nFish++;
}
int fk(const Inst& in, int k) { return k < in.nFish ? in.fish[k] : -1; }
bool live(const Inst& in, int k) { return mine(in, fk(in, k)); }
float spdOf(int i) { return fish::info(F[i].sp).speed; }
float fastOf(int i) { return fish::info(F[i].sp).fast; }
// 挑一條自由的魚：largest = true 挑最大的，false 挑最小的 (同大小隨機)
int pickBy(bool largest, int exclude) {
  int best = -1;
  float bs = -1e9f;
  for (int i = 0; i < fish::count(); i++) {
    const fish::Fish& f = F[i];
    if (!f.on || f.owner || f.manual || i == exclude) continue;
    float s = fish::info(f.sp).size * (largest ? 1 : -1) + rng.range(0, 0.5f);
    if (s > bs) { bs = s; best = i; }
  }
  return best;
}
bool nearFish(int a, int b, float r) {
  const float dx = F[a].x - F[b].x, dy = F[a].y - F[b].y;
  return dx * dx + dy * dy < r * r;
}
void face(int a, int b) {  // a 面向 b
  F[a].dir = F[b].x >= F[a].x ? 1 : -1;
}
// 咬一口：在被咬的魚身上噴血、扣血 (受傷)、被撞開一點
void bite(int att, int vic, int amount, float hurtSec, uint8_t tear = 0) {
  const float x = (F[att].x + F[vic].x) * 0.5f, y = (F[att].y + F[vic].y) * 0.5f;
  P::gib(x, y, amount);
  fish::hurt(vic, hurtSec);
  if (tear && gore::death()) F[vic].torn = (uint8_t)util::clamp((int)F[vic].torn + tear, 0, 7);
  F[vic].x += (F[vic].x >= F[att].x ? 1 : -1) * 4;
}
// 可以讓魚死掉嗎 (血腥設定、死亡額度、至少留 5 條)
bool canKill() { return gore::death() && deathBudget(millis()); }
enum Style : uint8_t { BODY, HALVES, GONE };
// 魚死掉：完整 = 噴血 + 肉塊 + 屍體/半截；輕微 = 紅色閃光後消失
void slay(int i, Style st, uint8_t cause, const char* fmt, int other = -1) {
  char buf[56];
  if (other >= 0) snprintf(buf, sizeof(buf), fmt, fish::nameOf(i), fish::nameOf(other));
  else snprintf(buf, sizeof(buf), fmt, fish::nameOf(i));
  P::gib(F[i].x, F[i].y, st == GONE ? 26 : 18);
  if (st == BODY) remains::corpse(i);
  else if (st == HALVES) remains::halves(i, 26);
  fish::kill(i, cause);
  noteDeath(millis());
  message(buf);
  // 單條死亡：5～15 分鐘後從畫面邊緣游進一條新的、不同的魚
  if (!fish::refilling()) fish::queueRefill(rng.range(300, 900), 20, 40);
}
// 沒有死亡額度：改成重傷逃走
void maul(int i, float sx, float sy, const char* fmt) {
  char buf[56];
  snprintf(buf, sizeof(buf), fmt, fish::nameOf(i));
  fish::hurt(i, 600);
  if (gore::death()) F[i].torn = 5;
  fleeFrom(i, sx, sy, 1.1f);
  message(buf);
}
void releaseAll(Inst& in) { fish::releaseOwner(in.owner); }

// ---- 101 搶地盤 ----  v[0..1] 水草位置；k[1]/k[2] 兩邊被咬的次數；k[3] 下一個攻擊者
bool start101(Inst& in) {
  if (take(in, pickAny()) < 0 || take(in, pickAny()) < 0) return false;
  int p;
  do { p = rng.irange(0, scene::PLANT_N - 1); } while (scene::plants[p].front);
  scene::plantPoint(p, 0.45f, in.v[0], in.v[1]);
  in.v[0] = util::clamp(in.v[0], 50.0f, 190.0f);
  return true;
}
// 兩條魚互咬 (101、161 共用)：每 1.4 秒一邊衝過去咬一口
void duel(Inst& in, float dt, int a, int b, int dmg) {
  if (timer(in.v[3], 1.4f, dt)) {
    in.k[3] ^= 1;
    const int att = in.k[3] ? a : b, vic = in.k[3] ? b : a;
    fish::command(att, fish::FAST, F[vic].x, F[vic].y, fastOf(att), 1.2f);
    in.v[4] = 0.01f;  // 正在衝
  }
  if (in.v[4] > 0) {
    in.v[4] += dt;
    const int att = in.k[3] ? a : b, vic = in.k[3] ? b : a;
    if (nearFish(att, vic, 13) || in.v[4] > 0.9f) {
      bite(att, vic, dmg, 90, 1);
      in.k[1 + (vic == b)]++;
      fish::command(att, fish::IDLE, F[att].x - (F[vic].x - F[att].x) * 0.6f, F[att].y, spdOf(att), 2);
      in.v[4] = 0;
    }
  }
  face(a, b); face(b, a);
}
void update101(Inst& in, float dt) {
  if (!live(in, 0) || !live(in, 1)) { in.done = true; return; }
  const int a = fk(in, 0), b = fk(in, 1);
  switch (in.stage) {
    case 0:
      if (enter(in)) {
        fish::command(a, fish::SWIM, in.v[0] - 16, in.v[1], spdOf(a) * 1.2f, 10);
        fish::command(b, fish::SWIM, in.v[0] + 16, in.v[1], spdOf(b) * 1.2f, 10);
      }
      if (in.st > 6) next(in);
      break;
    case 1:  // 對峙：繞小圈威嚇、魚鰭張開
      if (enter(in)) { F[a].wiggle = F[b].wiggle = 0.6f; }
      in.v[2] += dt * 1.6f;
      fish::moveTo(a, in.v[0] - 14 + util::fcos(in.v[2]) * 4, in.v[1] + util::fsin(in.v[2]) * 4, dt);
      fish::moveTo(b, in.v[0] + 14 - util::fcos(in.v[2]) * 4, in.v[1] - util::fsin(in.v[2]) * 4, dt);
      face(a, b); face(b, a);
      if (in.st > 5) { F[a].manual = F[b].manual = false; F[a].wiggle = F[b].wiggle = 0; next(in); }
      break;
    case 2:  // 互咬
      duel(in, dt, a, b, 8);
      if (in.st > 11) next(in);
      break;
    case 3: {  // 輸的帶傷逃走，贏的守著水草
      if (enter(in)) {
        const int lose = in.k[2] >= in.k[1] ? b : a, win = lose == a ? b : a;
        fish::hurt(lose, 240);
        if (gore::death()) F[lose].torn = (uint8_t)util::clamp((int)F[lose].torn + 2, 0, 7);
        fleeFrom(lose, F[win].x, F[win].y, 1.0f);
        fish::command(win, fish::IDLE, in.v[0], in.v[1], spdOf(win), 8);
        char buf[48];
        snprintf(buf, sizeof(buf), "%s搶贏了地盤", fish::nameOf(win));
        message(buf);
      }
      if (in.st > 6) in.done = true;
      break;
    }
    default: in.done = true;
  }
}

// ---- 102 咬尾巴 ----
bool start102(Inst& in) { return take(in, pickAny()) >= 0 && take(in, pickAny()) >= 0; }
void update102(Inst& in, float dt) {
  if (!live(in, 0) || !live(in, 1)) { in.done = true; return; }
  const int a = fk(in, 0), b = fk(in, 1);
  switch (in.stage) {
    case 0:  // 偷偷跟在後面
      if (enter(in)) fish::command(b, fish::SWIM, rng.range(50, 190), rng.range(70, 150), spdOf(b), 12);
      if (timer(in.v[3], 0.3f, dt)) fish::command(a, fish::SWIM, F[b].x - F[b].dir * 20, F[b].y, spdOf(a) * 1.3f, 2);
      if (in.st > 7) next(in);
      break;
    case 1: {  // 一口咬住尾巴
      const float tx = F[b].x - F[b].dir * fish::halfW(b);
      if (enter(in)) fish::command(a, fish::FAST, tx, F[b].y, fastOf(a) * 1.2f, 3);
      F[a].tx = tx; F[a].ty = F[b].y;
      if (fabsf(fish::mouthX(a) - tx) < 8 && fabsf(F[a].y - F[b].y) < 8 || in.st > 3) {
        P::gib(tx, F[b].y, 14);
        fish::hurt(b, 300);
        if (gore::death()) F[b].torn = 5;
        char buf[48];
        snprintf(buf, sizeof(buf), "%s的尾巴被%s咬掉一塊", fish::nameOf(b), fish::nameOf(a));
        message(buf);
        float px, py;
        scene::plantPoint(scene::nearestPlant(F[b].x, true), 0.4f, px, py);
        fish::command(b, fish::FLEE, px, py, fastOf(b), 6);
        fish::command(a, fish::IDLE, F[a].x, F[a].y, 2, 6);
        F[a].wiggle = 0.5f;  // 嚼
        next(in);
      }
      break;
    }
    case 2:
      if (in.st > 5) in.done = true;
      break;
    default: in.done = true;
  }
}

// ---- 103 魚群霸凌 ----  fish[0] = 被欺負的 (最小)，其他 = 霸凌者
bool start103(Inst& in) {
  if (take(in, pickBy(false, -1)) < 0) return false;
  for (int k = 0; k < 3; k++) take(in, pickBy(true, -1));
  return in.nFish >= 3;
}
void update103(Inst& in, float dt) {
  if (!live(in, 0)) { in.done = true; return; }
  const int v = fk(in, 0);
  switch (in.stage) {
    case 0:  // 圍住
    case 1: {
      if (in.stage == 0 && enter(in)) fish::command(v, fish::IDLE, util::clamp(F[v].x, 60.0f, 180.0f), util::clamp(F[v].y, 70.0f, 150.0f), spdOf(v), 30);
      F[v].wiggle = 0.6f;
      for (int k = 1; k < in.nFish; k++) {
        if (!live(in, k)) continue;
        const int b = fk(in, k);
        const float a = 2 * PI_F * k / (in.nFish - 1) + in.st * 0.5f;
        if (in.stage == 0 || F[b].st != fish::FAST) {
          F[b].tx = F[v].x + util::fcos(a) * 26;
          F[b].ty = F[v].y + util::fsin(a) * 16;
          if (F[b].st != fish::SWIM) fish::command(b, fish::SWIM, F[b].tx, F[b].ty, spdOf(b) * 1.3f, 30);
        }
      }
      if (in.stage == 0 && in.st > 6) next(in);
      if (in.stage == 1) {
        // 輪流衝過去咬
        if (timer(in.v[3], 1.1f, dt)) {
          const int k = rng.irange(1, in.nFish - 1);
          if (live(in, k)) { fish::command(fk(in, k), fish::FAST, F[v].x, F[v].y, fastOf(fk(in, k)), 0.8f); in.k[0] = (int16_t)k; }
        }
        if (in.k[0] > 0 && live(in, in.k[0]) && nearFish(fk(in, in.k[0]), v, 12)) {
          bite(fk(in, in.k[0]), v, 6, 300, rng.chance(0.4f) ? 1 : 0);
          in.k[0] = 0;
        }
        if (in.st > 12) next(in);
      }
      break;
    }
    case 2:  // 被欺負的躲進岩縫
      if (enter(in)) {
        F[v].wiggle = 0;
        fish::command(v, fish::HIDE, scene::ROCK_L.cx, scene::ROCK_L.cy - 4, fastOf(v), 20);
        F[v].wantLayer = 0;
        for (int k = 1; k < in.nFish; k++) if (live(in, k)) fish::release(fk(in, k));
        char buf[48];
        snprintf(buf, sizeof(buf), "%s被欺負得躲起來了", fish::nameOf(v));
        message(buf);
      }
      if (in.st > 8) in.done = true;
      break;
    default: in.done = true;
  }
}

// ---- 104 決鬥 ----
bool start104(Inst& in) {
  if (take(in, pickBy(true, -1)) < 0) return false;
  return take(in, pickBy(true, -1)) >= 0;
}
void update104(Inst& in, float dt) {
  if (!live(in, 0) || !live(in, 1)) { in.done = true; return; }
  const int a = fk(in, 0), b = fk(in, 1);
  const float cx = 120, cy = 108;
  switch (in.stage) {
    case 0:
      if (enter(in)) {
        fish::command(a, fish::SWIM, cx - 24, cy, spdOf(a) * 1.2f, 10);
        fish::command(b, fish::SWIM, cx + 24, cy, spdOf(b) * 1.2f, 10);
      }
      if (in.st > 6) next(in);
      break;
    case 1:  // 慢慢繞圈
      in.v[2] += dt * 1.2f;
      fish::moveTo(a, cx + util::fcos(in.v[2]) * 24, cy + util::fsin(in.v[2]) * 12, dt);
      fish::moveTo(b, cx - util::fcos(in.v[2]) * 24, cy - util::fsin(in.v[2]) * 12, dt);
      F[a].dir = util::fsin(in.v[2]) > 0 ? -1 : 1;
      F[b].dir = -F[a].dir;
      if (in.st > 6) { F[a].manual = F[b].manual = false; next(in); }
      break;
    case 2:  // 反覆互咬，血越來越多
      duel(in, dt, a, b, 10 + (int)in.st);
      if (in.st > 14) next(in);
      break;
    case 3: {
      if (enter(in)) {
        const int lose = in.k[2] >= in.k[1] ? b : a, win = lose == a ? b : a;
        fish::hurt(win, 300);
        fleeFrom(win, F[lose].x, F[lose].y, 0.8f);
        if (canKill()) slay(lose, BODY, 104, "%s在決鬥中被%s咬死了", win);
        else maul(lose, F[win].x, F[win].y, "%s輸了決鬥，重傷逃走");
      }
      if (in.st > 6) in.done = true;
      break;
    }
    default: in.done = true;
  }
}

// ---- 106 同類相殘 (餓太久) ----  fish[0] = 掠食者 (最大)，fish[1] = 獵物 (最小)
bool start106(Inst& in) {
  const int p = pickBy(true, -1);
  if (take(in, p) < 0) return false;
  return take(in, pickBy(false, p)) >= 0;
}
void update106(Inst& in, float dt) {
  if (in.stage < 2 && (!live(in, 0) || !live(in, 1))) { in.stage = 2; in.st = 0; }
  if (in.stage >= 2) { if (in.st > 6) in.done = true; return; }
  const int p = fk(in, 0), v = fk(in, 1);
  switch (in.stage) {
    case 0:  // 盯上
      if (enter(in)) { fish::command(p, fish::IDLE, F[p].x, F[p].y, 2, 6); F[p].wiggle = 0.3f; }
      face(p, v);
      if (in.st > 4) { F[p].wiggle = 0; next(in); }
      break;
    case 1:  // 追
      if (timer(in.v[3], 0.3f, dt)) {
        fish::command(p, fish::CHASE, F[v].x, F[v].y, fastOf(p) * 1.05f, 2);
        fleeFrom(v, F[p].x, F[p].y, 0.85f);
      }
      if (fabsf(fish::mouthX(p) - F[v].x) < 9 && fabsf(F[p].y - F[v].y) < 8) {
        if (canKill()) slay(v, GONE, 106, "%s被%s吞掉了", p);
        else { bite(p, v, 14, 600, 4); maul(v, F[p].x, F[p].y, "%s被咬了一大口，逃走了"); }
        fish::startle(F[p].x, F[p].y, 80);
        next(in);
      } else if (in.st > 15) next(in);
      break;
    default:
      if (in.st > 6) in.done = true;
  }
}

// ---- 109 血之漩渦 ----
bool start109(Inst& in) {
  for (int k = 0; k < 8; k++) take(in, pickAny());
  if (in.nFish < 6) return false;
  return true;
}
void update109(Inst& in, float dt) {
  const float cx = 120, cy = 105;
  switch (in.stage) {
    case 0:  // 一滴血在水中擴散
      if (enter(in)) P::blood(cx, cy - 20, 8, 3);
      if (in.st > 3) next(in);
      break;
    case 1:  // 聞到血，圍過來
      if (enter(in))
        for (int k = 0; k < in.nFish; k++)
          if (live(in, k)) { float a = 2 * PI_F * k / in.nFish; fish::command(fk(in, k), fish::FAST, cx + cosf(a) * 50, cy + sinf(a) * 28, fastOf(fk(in, k)), 8); }
      if (in.st > 5) next(in);
      break;
    case 2: {  // 高速打轉、互咬
      const float r = 50 - in.st * 1.8f, sp = 1.2f + in.st * 0.25f;
      in.v[2] += dt * sp;
      for (int k = 0; k < in.nFish; k++) {
        if (!live(in, k)) continue;
        const int i = fk(in, k);
        const float a = in.v[2] + 2 * PI_F * k / in.nFish;
        fish::moveTo(i, cx + util::fcos(a) * r, cy + util::fsin(a) * r * 0.55f, dt);
        F[i].dir = util::fsin(a) > 0 ? -1 : 1;
      }
      if (timer(in.v[3], 0.45f, dt)) {
        const int k = rng.irange(0, in.nFish - 1), j = (k + 1) % in.nFish;
        if (live(in, k) && live(in, j)) bite(fk(in, j), fk(in, k), 6, 200, rng.chance(0.3f) ? 1 : 0);
      }
      if (rng.chance(dt * 3)) P::bubbles(cx + rng.range(-20, 20), cy + 10, 1, 4);
      if (in.st > 14) next(in);
      break;
    }
    case 3: {  // 中心爆出血霧，1～2 條沒有游出來
      if (enter(in)) {
        P::gib(cx, cy, 34);
        int killed = 0;
        for (int k = 0; k < in.nFish && killed < 2; k++) {
          if (!live(in, k) || !canKill() || (killed && rng.chance(0.5f))) continue;
          const int i = fk(in, k);
          fish::moveTo(i, cx + rng.range(-8, 8), cy + rng.range(-6, 6), 0);
          slay(i, HALVES, 109, "%s在血之漩渦裡被撕成兩半");
          killed++;
        }
        for (int k = 0; k < in.nFish; k++) if (live(in, k)) { F[fk(in, k)].manual = false; fish::hurt(fk(in, k), 120); }
        releaseAll(in);
        fish::startle(cx, cy, 120);
      }
      if (in.st > 7) in.done = true;
      break;
    }
    default: in.done = true;
  }
}

// ---- 110 叛徒 ----  fish[0] = 隊長 … fish[n-1] = 叛徒，fish[n-2] = 被咬的
bool start110(Inst& in) {
  for (int k = 0; k < 5; k++) take(in, pickAny());
  return in.nFish >= 4;
}
void update110(Inst& in, float dt) {
  const int n = in.nFish, tr = n - 1, vk = n - 2;
  if (!live(in, tr)) { in.done = true; return; }
  const int t = fk(in, tr);
  switch (in.stage) {
    case 0: {  // 排成一列跟著隊長游
      if (!live(in, 0)) { next(in); break; }
      const int L = fk(in, 0);
      if (enter(in)) fish::command(L, fish::SWIM, F[L].x < 120 ? 200 : 40, rng.range(80, 130), spdOf(L), 20);
      if (timer(in.v[3], 0.3f, dt))
        for (int k = 1; k < n; k++) {
          if (!live(in, k)) continue;
          fish::command(fk(in, k), fish::SWIM, F[L].x - F[L].dir * 18 * k, F[L].y + (k & 1) * 4, spdOf(L) * 1.4f, 2);
        }
      if (in.st > 8) next(in);
      break;
    }
    case 1: {  // 隊尾那條突然轉身咬住同伴，不放
      if (!live(in, vk)) { next(in); break; }
      const int v = fk(in, vk);
      if (enter(in)) {
        for (int k = 0; k < vk; k++) if (live(in, k)) fish::command(fk(in, k), fish::IDLE, F[fk(in, k)].x, F[fk(in, k)].y, 2, 10);
        bite(t, v, 16, 600, 2);
        char buf[48];
        snprintf(buf, sizeof(buf), "%s突然咬住了%s", fish::nameOf(t), fish::nameOf(v));
        message(buf);
      }
      // 咬著不放：被咬的掙扎、血一直滴
      fish::moveTo(v, F[v].x + rng.range(-1.5f, 1.5f), F[v].y + rng.range(-1, 1), dt);
      fish::moveTo(t, F[v].x - F[t].dir * (fish::halfW(t) + 2), F[v].y, dt);
      face(t, v);
      F[v].wiggle = 0.8f;
      if (timer(in.v[3], 0.35f, dt)) P::blood(F[v].x, F[v].y, 3, 3);
      if (in.st > 6) {
        F[v].manual = F[t].manual = false;
        F[v].wiggle = 0;
        if (canKill()) slay(v, BODY, 110, "%s失血過多沉下去了");
        else maul(v, F[t].x, F[t].y, "%s掙脫了，帶著傷逃走");
        next(in);
      }
      break;
    }
    case 2:  // 其他的魚把叛徒趕走
      if (enter(in)) fleeFrom(t, 120, 110, 1.0f);
      if (timer(in.v[3], 0.4f, dt)) {
        for (int k = 0; k < vk; k++) if (live(in, k)) fish::command(fk(in, k), fish::CHASE, F[t].x, F[t].y, fastOf(fk(in, k)) * 0.8f, 2);
        fleeFrom(t, F[fk(in, 0)].x, F[fk(in, 0)].y, 1.0f);
      }
      if (in.st > 7) in.done = true;
      break;
    default: in.done = true;
  }
}

// ---- 161 搶食流血 ----
bool start161(Inst& in) {
  P::dropFood(120, 12);
  for (int k = 0; k < 6; k++) take(in, pickAny());
  return in.nFish >= 2;
}
void update161(Inst& in, float dt) {
  switch (in.stage) {
    case 0:  // 擠成一團搶
      if (enter(in)) for (int k = 0; k < in.nFish; k++) if (live(in, k)) fish::command(fk(in, k), fish::EAT, 120, 100, fastOf(fk(in, k)), 30);
      if (in.st > 6) next(in);
      break;
    case 1: {  // 兩條搶同一顆互咬
      if (!live(in, 0) || !live(in, 1)) { next(in); break; }
      const int a = fk(in, 0), b = fk(in, 1);
      if (enter(in)) { fish::command(a, fish::IDLE, F[a].x, F[a].y, 2, 10); fish::command(b, fish::IDLE, F[b].x, F[b].y, 2, 10); }
      duel(in, dt, a, b, 9);
      if (in.st > 8) next(in);
      break;
    }
    case 2:
      if (enter(in) && live(in, 0) && live(in, 1)) {
        const int lose = in.k[2] >= in.k[1] ? fk(in, 1) : fk(in, 0);
        float px, py;
        scene::plantPoint(scene::nearestPlant(F[lose].x, false), 0.25f, px, py);
        fish::hurt(lose, 300);
        fish::command(lose, fish::HIDE, px, py, fastOf(lose), 15);
        char buf[48];
        snprintf(buf, sizeof(buf), "%s搶輸了，躲到海草後面", fish::nameOf(lose));
        message(buf);
        for (int k = 0; k < in.nFish; k++) if (live(in, k) && fk(in, k) != lose) fish::command(fk(in, k), fish::EAT, 120, 110, 0, 10);
      }
      if (in.st > 8) in.done = true;
      break;
    default: in.done = true;
  }
}

// ---- 163 暴食 ----
bool start163(Inst& in) {
  P::dropFood(rng.range(80, 160), 16);
  return take(in, pickAny()) >= 0;
}
void update163(Inst& in, float dt) {
  if (!live(in, 0)) { in.done = true; return; }
  const int g = fk(in, 0);
  switch (in.stage) {
    case 0:  // 一直吃，肚子越來越大
      if (enter(in)) fish::command(g, fish::EAT, 120, 100, fastOf(g), 30);
      F[g].swell = util::clamp01(in.st / 14);
      F[g].wiggle = F[g].swell > 0.7f ? 0.4f : 0;
      if (in.st > 15) next(in);
      break;
    case 1:  // 游不動、翻過來往下沉
      if (enter(in)) fish::command(g, fish::IDLE, F[g].x, F[g].y, 1, 10);
      fish::moveTo(g, F[g].x, F[g].y + 6 * dt, dt);
      F[g].wiggle = 0.8f;
      if (in.st > 5) {
        F[g].manual = false;
        F[g].wiggle = 0;
        if (canKill()) {
          // 肚子撐破
          P::gib(F[g].x, F[g].y + 2, 30);
          for (int k = 0; k < 6; k++) P::spawn(P::FOOD, F[g].x, F[g].y, rng.range(-20, 20), rng.range(-12, 4), 20, 1, 0xa85a20);
          slay(g, BODY, 163, "%s吃太多，肚子撐破了");
        } else {
          for (int k = 0; k < 6; k++) P::spawn(P::FOOD, fish::mouthX(g), F[g].y, F[g].dir * rng.range(6, 18), rng.range(-6, 6), 20, 1, 0xa85a20);
          F[g].swell = 0;
          char buf[48];
          snprintf(buf, sizeof(buf), "%s吃太多，全部吐出來了", fish::nameOf(g));
          message(buf);
        }
        next(in);
      }
      break;
    default:
      if (in.st > 5) in.done = true;
  }
}

// ---- 171 魚骨 ----  k[0] 魚骨、cr[0] 蝦子
bool start171(Inst& in) {
  const float x = rng.range(50, 190);
  int b = remains::bones(x, scene::sandTop((int)x) - 5);
  if (b < 0) return false;
  remains::at(b).landed = true;
  remains::at(b).y = scene::sandTop((int)x) - 5;
  remains::at(b).life = 600;
  in.k[0] = (int16_t)b;
  in.v[0] = x;
  P::burst(P::DUST, x, scene::sandTop((int)x) - 2, 14, 18, 2.5f);
  for (int k = 0; k < 3; k++) take(in, pickAny());
  return true;
}
void update171(Inst& in, float dt) {
  remains::R& b = remains::at(in.k[0]);
  if (!b.on || b.kind != remains::BONES) { in.done = true; return; }
  switch (in.stage) {
    case 0:  // 魚圍過來看
      if (enter(in))
        for (int k = 0; k < in.nFish; k++)
          if (live(in, k)) fish::command(fk(in, k), fish::INSPECT, b.x + rng.range(-22, 22), b.y - rng.range(8, 20), spdOf(fk(in, k)), 20);
      if (in.st > 9) { releaseAll(in); next(in); }
      break;
    case 1: {  // 蝦子來把骨頭拖走
      if (enter(in)) {
        int c = CR::spawn(CR::SHRIMP, scene::plants[1].x, 0, 1, in.owner);
        if (c < 0) { in.done = true; break; }
        in.cr[0] = (int8_t)c; in.nCr = 1;
        CR::walkTo(c, b.x - 10, 14);
      }
      if (in.nCr && CR::at(in.cr[0]).on && fabsf(CR::at(in.cr[0]).x - (b.x - 10)) < 3) next(in);
      if (in.st > 14) next(in);
      break;
    }
    case 2: {  // 拖著走
      if (!in.nCr || !CR::at(in.cr[0]).on) { in.done = true; break; }
      CR::C& c = CR::at(in.cr[0]);
      if (enter(in)) CR::walkTo(in.cr[0], b.x < 120 ? 10 : 230, 8);
      b.x = c.x - c.dir * 12;  // 骨頭跟在蝦子後面
      if (in.st > 10) { b.life = 3; in.done = true; }
      break;
    }
    default: in.done = true;
  }
}

// ---- 172 清道夫 ----  k[0] 屍體
int findBody() {
  int i = remains::find(remains::CORPSE);
  if (i < 0) i = remains::find(remains::HALF_HEAD);
  if (i < 0) i = remains::find(remains::HALF_TAIL);
  return i;
}
// 沙地上沒有屍體時 (例如從選單測試)：放一具 (最近死掉的魚，沒有就隨機魚種)
int ensureCorpse() {
  int b = findBody();
  if (b >= 0) return b;
  uint8_t sp = (uint8_t)rng.irange(0, fish::SP_COUNT - 1), var = (uint8_t)rng.irange(0, 2);
  if (fish::deathLogN() > 0) { sp = fish::deathAt(0).sp; var = fish::deathAt(0).var; }
  const float x = rng.range(50, 190);
  b = remains::corpseFrom(sp, var, x, scene::sandTop((int)x) - 8, rng.chance(0.5f) ? 1 : -1);
  if (b >= 0) remains::at(b).t = 30;  // 已經死了一陣子 (不要剛死的大量滲血)
  return b;
}
bool start172(Inst& in) {
  const int b = ensureCorpse();
  if (b < 0) return false;  // 血腥效果不是「完整」就沒有屍體
  in.k[0] = (int16_t)b;
  const float x = remains::at(b).x;
  int c = CR::spawn(CR::SHRIMP, x < 120 ? 230 : 10, 0, 1, in.owner);
  if (c >= 0) { in.cr[in.nCr++] = (int8_t)c; CR::walkTo(c, x - 8, 16); }
  c = CR::spawn(CR::SNAIL, scene::ROCK_L.cx, 0, 1, in.owner);
  if (c >= 0) { in.cr[in.nCr++] = (int8_t)c; CR::walkTo(c, x + 8, 5); CR::at(c).layer = 0; }
  int c2 = CR::spawn(CR::SHRIMP, x < 120 ? 220 : 20, 0, -1, in.owner);
  if (c2 >= 0) { in.cr[in.nCr++] = (int8_t)c2; CR::walkTo(c2, x + 4, 18); }
  return in.nCr > 0;
}
void update172(Inst& in, float dt) {
  remains::R& b = remains::at(in.k[0]);
  const bool body = b.on && b.kind != remains::BONES && b.kind != remains::STAIN;
  for (int k = 0; k < in.nCr; k++) if (in.cr[k] >= 0 && CR::at(in.cr[k]).on && CR::at(in.cr[k]).type == CR::SNAIL) {
    CR::C& c = CR::at(in.cr[k]);
    if (c.layer == 0 && !gfx::rockAt((int)c.x, (int)c.y)) c.layer = 1;
  }
  switch (in.stage) {
    case 0:
      if (!body) { in.done = true; break; }
      if (in.st > 9) next(in);
      break;
    case 1:  // 一口一口啃，冒出血霧和碎肉
      if (body && timer(in.v[3], 0.9f, dt)) {
        remains::nibble(in.k[0], 0.06f);
        if (gore::blood()) {
          P::blood(b.x + rng.range(-6, 6), b.y, 3, 2);
          if (rng.chance(0.4f)) P::spawn(P::CHUNK, b.x, b.y - 2, rng.range(-8, 8), -6, 20, 1, 0xc8485a);
        }
      }
      if (!body || in.st > 22) next(in);
      break;
    default:
      if (enter(in)) { CR::leaveOwner(in.owner); message("清道夫把屍體吃得只剩骨頭"); }
      if (in.st > 4) in.done = true;
  }
}

// ---- 174 浮屍 ----
bool start174(Inst& in) {
  int b = remains::find(remains::CORPSE);
  if (b < 0) b = ensureCorpse();
  if (b < 0 || remains::at(b).kind != remains::CORPSE) return false;  // 血腥效果不是「完整」就沒有屍體
  in.k[0] = (int16_t)b;
  remains::at(b).life = fmaxf(remains::at(b).life, 120);
  for (int k = 0; k < 3; k++) take(in, pickAny());
  return true;
}
void update174(Inst& in, float dt) {
  remains::R& b = remains::at(in.k[0]);
  if (!b.on || b.kind != remains::CORPSE) { in.done = true; return; }
  switch (in.stage) {
    case 0:  // 脹氣浮起來
      if (enter(in)) b.bloat = 14;
      if (b.y <= scene::SWIM_TOP + 4 || in.st > 14) { b.bloat = 0.01f; next(in); }
      break;
    case 1:  // 魚去戳牠
      b.bloat = 0.5f;  // 停在水面
      if (enter(in))
        for (int k = 0; k < in.nFish; k++) if (live(in, k)) fish::command(fk(in, k), fish::INSPECT, b.x + rng.range(-16, 16), b.y + 10, spdOf(fk(in, k)), 20);
      if (timer(in.v[3], 1.2f, dt) && gore::blood()) P::blood(b.x, b.y + 2, 2, 3);
      if (in.st > 9) { b.bloat = 0; next(in); }
      break;
    default:  // 又慢慢沉下去
      if (enter(in)) { releaseAll(in); b.landed = false; b.vy = 1; }
      if (in.st > 10) in.done = true;
  }
}

}  // namespace

bool bigCondition(int id, uint32_t ms) {
  (void)ms;
  const World& w = world();
  const uint32_t day = env::day();
  switch (id) {
    case 124: return day >= 2 && fish::alive() >= 3 && !fish::refilling();
    case 129: return day >= 3 && fish::alive() >= 6 && !fish::refilling() && (w.sharks == 0 || day - w.lastSharkDay >= 2);
    case 199: return w.newStart && fish::alive() >= fish::ROSTER_TARGET;
    case 101: case 102: return fish::freeCount() >= 2;
    case 103: case 110: return fish::freeCount() >= 4;
    case 104: return fish::freeCount() >= 2 && fish::alive() >= 5;
    case 106: {  // 6 小時沒餵食
      const uint32_t last = env::lastFeedMs;
      return fish::freeCount() >= 2 && ms - last > 6UL * 3600000UL && ms > 6UL * 3600000UL;
    }
    case 109: return fish::freeCount() >= 6;
    case 161: return feedsWithin(ms, 60000) >= 3 && fish::freeCount() >= 2;
    case 163: return feedsWithin(ms, 120000) >= 5 && fish::freeCount() >= 1;
    case 171: return gore::blood() && fish::deathCount() > 0 && remains::count(remains::BONES) < 3;
    case 172: return gore::blood() && findBody() >= 0;
    case 174: return gore::blood() && (remains::find(remains::CORPSE) >= 0 || fish::deathCount() > 0);
    default: return false;
  }
}

bool bigStart(Inst& in) {
  switch (in.id) {
    case 124: return start124(in);
    case 129: return start129(in);
    case 199: return start199(in);
    case 101: return start101(in);
    case 102: return start102(in);
    case 103: return start103(in);
    case 104: return start104(in);
    case 106: return start106(in);
    case 109: return start109(in);
    case 110: return start110(in);
    case 161: return start161(in);
    case 163: return start163(in);
    case 171: return start171(in);
    case 172: return start172(in);
    case 174: return start174(in);
    default: return false;  // 規劃中
  }
}

void bigUpdate(Inst& in, float dt) {
  switch (in.id) {
    case 124: update124(in, dt); break;
    case 129: update129(in, dt); break;
    case 199: update199(in, dt); break;
    case 101: update101(in, dt); break;
    case 102: update102(in, dt); break;
    case 103: update103(in, dt); break;
    case 104: update104(in, dt); break;
    case 106: update106(in, dt); break;
    case 109: update109(in, dt); break;
    case 110: update110(in, dt); break;
    case 161: update161(in, dt); break;
    case 163: update163(in, dt); break;
    case 171: update171(in, dt); break;
    case 172: update172(in, dt); break;
    case 174: update174(in, dt); break;
    default: in.done = true; break;
  }
}

void bigEnd(Inst& in) {
  switch (in.id) {
    case 124: env::fx.dreadT = 0; fish::releaseOwner(in.owner); break;
    case 129: end129(in); break;
    case 163:
      if (in.nFish && in.fish[0] >= 0) F[in.fish[0]].swell = 0;
      fish::releaseOwner(in.owner);
      break;
    case 174:
      if (in.k[0] >= 0 && remains::at(in.k[0]).on) { remains::at(in.k[0]).bloat = 0; remains::at(in.k[0]).landed = false; }
      fish::releaseOwner(in.owner);
      break;
    default:
      for (int i = 0; i < fish::count(); i++) if (F[i].owner == in.owner) { F[i].wiggle = 0; F[i].manual = false; }
      fish::releaseOwner(in.owner);
      break;
  }
}

}  // namespace ev
