// 執行中的事件實例 (EventManager 與 EventEffects 共用)
#pragma once
#include <stdint.h>

namespace ev {

struct Inst {
  bool on;
  bool user;          // 玩家觸發 (餵食/打氣)
  bool done;          // 效果自己宣告提早結束
  bool entered;       // 目前階段的進場動作是否已執行
  uint8_t id;
  uint8_t owner;      // 事件槽 + 1 (用來標記被借用的魚/生物)
  uint8_t stage;
  float t, dur;       // 經過時間 / 持續時間 (秒)
  float st;           // 目前階段經過時間
  float arriveT;      // 抵達目標的時間 (-1 = 尚未)
  float acc;          // 通用計時器
  int8_t fish[8];
  uint8_t nFish;
  int8_t cr[10];
  uint8_t nCr;
  float v[12];        // 事件自己的暫存值
  int16_t k[4];
};

// 每個 Event ID 的效果 (EventEffects.cpp)
bool fxStart(Inst& in);              // 回傳 false = 現在條件不足 (例如沒有空閒的魚)
void fxUpdate(Inst& in, float dt);
void fxEnd(Inst& in);

// 大型事件 (101～200，BigEvents.cpp)
bool bigStart(Inst& in);
void bigUpdate(Inst& in, float dt);
void bigEnd(Inst& in);
bool bigCondition(int id, uint32_t ms);  // 大型事件的觸發條件 (前置事件在 EventManager 檢查)

}  // namespace ev
