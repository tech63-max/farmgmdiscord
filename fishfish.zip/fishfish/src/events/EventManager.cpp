#include "EventManager.h"
#include <Arduino.h>
#include <string.h>
#include "../aquarium/Environment.h"
#include "../aquarium/Fish.h"
#include "../aquarium/ParticleSystem.h"
#include "../aquarium/Scene.h"
#include "../config/AquariumConfig.h"
#include "../core/Util.h"
#include "Event.h"

namespace ev {
namespace {
using util::rng;

Inst slots[acfg::EVENT_SLOTS];  // [0] = 重要事件，[1..] = 日常/環境小事件
uint32_t lastAt[EVENT_COUNT + 1];
bool everRan[EVENT_COUNT + 1];
uint16_t seen[EVENT_COUNT + 1];
uint8_t lastId = 0;
uint32_t nextAt[RARITY_COUNT];
uint32_t nextBig = 0;
World wld;
uint32_t feedRing[8];
int feedHead = 0;
uint32_t deathRing[8];
int deathHead2 = 0, deathN2 = 0;
MsgCb msgCb = nullptr;
float freqMult = 1.0f;
StartCb startCb = nullptr;

LogEntry logRing[acfg::EVENT_LOG_CAP];
int logHead = 0, logN = 0;

// 餵食後的連鎖事件
int pendingId = 0;
uint32_t pendingAt = 0;

// 自動測試
int seqCur = 0, seqEnd = 0;
float seqSec = 0;
uint32_t seqNext = 0;

uint32_t interval(uint8_t r) {
  uint16_t lo, hi;
  switch (r) {
    case COMMON: lo = acfg::COMMON_MIN; hi = acfg::COMMON_MAX; break;
    case SPECIAL: lo = acfg::SPECIAL_MIN; hi = acfg::SPECIAL_MAX; break;
    case RARE: lo = acfg::RARE_MIN; hi = acfg::RARE_MAX; break;
    default: lo = acfg::ULTRA_MIN; hi = acfg::ULTRA_MAX; break;
  }
  return (uint32_t)(rng.irange(lo, hi) * freqMult * 1000);
}

uint32_t bigInterval() { return (uint32_t)(rng.irange(acfg::BIG_MIN, acfg::BIG_MAX) * freqMult * 1000); }

bool slotFree(int s) { return !slots[s].on; }
bool bigRunning() { return slots[0].on && def(slots[0].id).big; }
// 大型事件進行中，不開始會改光色/水流的小事件 (避免調色打架)
bool clashesWithBig(int id) {
  switch (id) {
    case 59: case 60: case 61: case 67: case 70: case 72: case 73: case 74: case 91: case 97: case 98: return true;
    default: return false;
  }
}
int freeMinorSlot() {
  for (int s = 1; s < acfg::EVENT_SLOTS; s++) if (slotFree(s)) return s;
  return -1;
}

void endSlot(int s) {
  Inst& in = slots[s];
  if (!in.on) return;
  fxEnd(in);
  in.on = false;
}

bool cooledDown(int id, uint32_t ms) {
  if (!everRan[id]) return true;
  return ms - lastAt[id] >= (uint32_t)def(id).cooldownS * 1000;
}

void record(int id, bool user, uint32_t ms) {
  lastAt[id] = ms;
  everRan[id] = true;
  if (seen[id] < 65535) seen[id]++;
  lastId = (uint8_t)id;
  LogEntry e;
  e.id = (uint8_t)id;
  e.user = user;
  e.minute = (uint16_t)(env::clock() * 1440);
  e.day = env::day();
  pushLog(e);
  if (startCb) startCb(id, user);
}

// 在 tier 裡依權重挑一個可以開始的事件
bool startFromTier(uint8_t tier, uint32_t ms) {
  static int cand[EVENT_COUNT], w[EVENT_COUNT];
  int n = 0, sum = 0;
  const bool majorFree = slotFree(0), minorFree = freeMinorSlot() >= 0;
  for (int id = 1; id <= EVENT_COUNT; id++) {
    const Def& d = def(id);
    if (d.big || d.rarity != tier || id == lastId || active(id)) continue;
    if (bigRunning() && clashesWithBig(id)) continue;
    if (d.major ? !majorFree : !minorFree) continue;
    if (!cooledDown(id, ms) || !conditionMet(id, ms)) continue;
    int weight = d.weight;
    // 夜晚提高睡眠類事件、白天提高光線類事件的機會
    if (env::isNight() && (id == 11 || id == 71 || id == 75)) weight *= 2;
    cand[n] = id; w[n] = weight; sum += weight; n++;
  }
  for (int tries = 0; tries < 4 && n > 0 && sum > 0; tries++) {
    int r = rng.irange(1, sum), k = 0;
    while (r > w[k]) { r -= w[k]; k++; }
    if (trigger(cand[k], ms, false) == 0) return true;
    sum -= w[k];  // 效果無法開始 (例如魚不夠) → 換一個
    w[k] = 0;
  }
  return false;
}
// 大型事件：從已實作、冷卻好、條件符合的事件裡依權重挑一個
bool startBig(uint32_t ms) {
  static int cand[EVENT_COUNT - BIG_FIRST + 1], w[EVENT_COUNT - BIG_FIRST + 1];
  int n = 0, sum = 0;
  for (int id = BIG_FIRST; id <= EVENT_COUNT; id++) {
    const Def& d = def(id);
    if (!d.impl || id == 199) continue;  // 199 由補魚完成觸發
    if (d.once && seen[id]) continue;
    if (!cooledDown(id, ms) || !conditionMet(id, ms)) continue;
    cand[n] = id; w[n] = d.weight; sum += d.weight; n++;
  }
  for (int tries = 0; tries < 3 && n > 0 && sum > 0; tries++) {
    int r = rng.irange(1, sum), k = 0;
    while (r > w[k]) { r -= w[k]; k++; }
    if (trigger(cand[k], ms, false) == 0) return true;
    sum -= w[k];
    w[k] = 0;
  }
  return false;
}
}  // namespace

void begin(uint32_t ms) {
  memset(slots, 0, sizeof(slots));
  memset(lastAt, 0, sizeof(lastAt));
  memset(everRan, 0, sizeof(everRan));
  for (int r = 0; r < RARITY_COUNT; r++) nextAt[r] = ms + interval(r) / (r == COMMON ? 3 : 1);
  nextBig = ms + bigInterval();
}

void setFrequency(uint8_t f) {
  freqMult = acfg::FREQ_MULT[f < 3 ? f : 1];
}

bool conditionMet(int id, uint32_t ms) {
  if (id >= BIG_FIRST) {
    const Def& d = def(id);
    if (!d.impl) return false;
    if (d.req && !seen[d.req]) return false;
    return bigCondition(id, ms);
  }
  const uint16_t c = def(id).cond;
  const env::Phase ph = env::phase();
  if ((c & C_DAY) && ph != env::DAY) return false;
  if ((c & C_NIGHT) && !env::isNight()) return false;
  if ((c & C_DAWN) && ph != env::DAWN) return false;
  if ((c & C_DUSK) && ph != env::DUSK) return false;
  if ((c & C_LIGHT) && env::isNight()) return false;
  if ((c & C_FED) && !env::fedRecently(ms, 120000)) return false;
  if ((c & C_FOOD) && particles::count(particles::FOOD) == 0) return false;
  if ((c & C_FED_END) && (!env::fedRecently(ms, 120000) || particles::count(particles::FOOD) > 0)) return false;
  if ((c & C_DEBRIS) && scene::debrisCount() == 0) return false;
  if ((c & C_ALGAE) && scene::algaeVisible() == 0) return false;
  if ((c & C_CLEANUP) && scene::debrisCount() == 0 && scene::algaeVisible() < 3) return false;
  if (c & C_WAKE) {
    bool sleeping = false;
    for (int i = 0; i < fish::count(); i++) if (fish::F[i].on && fish::F[i].st == fish::SLEEP && !fish::F[i].owner) sleeping = true;
    if (ph != env::DAWN && !sleeping) return false;
  }
  const int nf = fish::freeCount();
  if ((c & C_FISH2) && nf < 2) return false;
  if ((c & C_FISH3) && nf < 3) return false;
  if ((c & C_FISH4) && nf < 4) return false;
  return true;
}

bool bigActive() { return bigRunning(); }

bool active(int id) {
  for (auto& s : slots) if (s.on && s.id == id) return true;
  return false;
}

int activeIds(uint8_t* out, int cap) {
  int n = 0;
  for (auto& s : slots) if (s.on && n < cap) out[n++] = s.id;
  return n;
}

int trigger(int id, uint32_t ms, bool force, bool user) {
  if (id < 1 || id > EVENT_COUNT) return 1;
  const Def& d = def(id);
  if (d.big && !d.impl) return 6;  // 規劃中，還沒做
  if (!force && !user) {
    if (!cooledDown(id, ms)) return 2;
    if (!conditionMet(id, ms)) return 3;
  }
  // 強制播放大型事件 (選單測試)：先結束小事件，把被借走的魚放回來
  if (force && d.big) stopMinor();
  // 同一個事件正在播：強制/玩家觸發時先結束舊的
  for (int s = 0; s < acfg::EVENT_SLOTS; s++)
    if (slots[s].on && slots[s].id == id) {
      if (!force && !user) return 4;
      endSlot(s);
    }
  int s;
  if (d.major) {
    if (!slotFree(0)) { if (!force) return 4; endSlot(0); }
    s = 0;
  } else {
    s = freeMinorSlot();
    if (s < 0) { if (!force && !user) return 4; endSlot(1); s = 1; }
  }
  Inst& in = slots[s];
  memset(&in, 0, sizeof(in));
  in.id = (uint8_t)id;
  in.owner = (uint8_t)(s + 1);
  in.dur = d.durationS;
  in.user = user;
  in.arriveT = -1;
  for (auto& f : in.fish) f = -1;
  for (auto& c : in.cr) c = -1;
  if (!fxStart(in)) {
    fxEnd(in);  // 釋放已借用的魚
    return 5;
  }
  in.on = true;
  record(id, user, ms);
  return 0;
}

void stopMinor() {
  for (int s = 1; s < acfg::EVENT_SLOTS; s++) endSlot(s);
  pendingId = 0;
}

void stopAll() {
  for (int s = 0; s < acfg::EVENT_SLOTS; s++) endSlot(s);
  pendingId = 0;
}

void tick(uint32_t ms) {
  // 自動測試序列
  if (seqCur > 0 && util::reached(ms, seqNext)) {
    int r = trigger(seqCur, ms, true);
    Serial.printf("[EvTest] %03d %s -> %s\n", seqCur, def(seqCur).name, r == 0 ? "OK" : "FAIL");
    seqNext = ms + (uint32_t)(seqSec * 1000);
    if (++seqCur > seqEnd) { seqCur = 0; Serial.println("[EvTest] done"); }
    return;
  }
  // 餵食連鎖
  if (pendingId && util::reached(ms, pendingAt)) {
    int id = pendingId;
    pendingId = 0;
    trigger(id, ms, false);
  }
  // 鯊魚之後補魚完成：新的魚群第一次集合
  if (wld.newStart && !fish::refilling() && fish::alive() >= fish::ROSTER_TARGET && slotFree(0)) {
    if (trigger(199, ms, false) == 0) return;
  }
  // 大型事件 (獨立計時器)
  if (util::reached(ms, nextBig)) {
    if (slotFree(0) && !fish::refilling() && startBig(ms)) { nextBig = ms + bigInterval(); return; }
    nextBig = ms + 30000;  // 現在不行 (槽被佔用 / 補魚中 / 沒有符合的)，30 秒後再試
  }
  // 分級調度 (高稀有度先檢查)
  for (int r = ULTRA; r >= COMMON; r--) {
    if (!util::reached(ms, nextAt[r])) continue;
    if (r == ULTRA && !rng.chance(acfg::ULTRA_CHANCE)) { nextAt[r] = ms + interval(r); continue; }
    if (startFromTier((uint8_t)r, ms)) nextAt[r] = ms + interval(r);
    else nextAt[r] = ms + 10000;  // 現在沒有可以播的 (槽滿/條件不符)，10 秒後再試
    break;  // 一秒最多開始一個事件，避免同時觸發
  }
}

void update(float dt, uint32_t ms) {
  for (int s = 0; s < acfg::EVENT_SLOTS; s++) {
    Inst& in = slots[s];
    if (!in.on) continue;
    in.t += dt;
    in.st += dt;
    fxUpdate(in, dt);
    if (in.done || in.t >= in.dur) endSlot(s);
  }
}

void onFeed(uint32_t ms) {
  feedRing[feedHead] = ms;
  feedHead = (feedHead + 1) % 8;
  env::lastFeedMs = ms;
  env::eco.feeds++;
  trigger(41, ms, false, true);
  // 連鎖：魚群聚餐 / 一起尋找食物 / 歡騰
  static const int FOLLOW[] = {47, 47, 31, 50, 42};
  pendingId = FOLLOW[rng.irange(0, 4)];
  pendingAt = ms + (pendingId == 50 ? 12000 : 2500);
}

void onPhase(uint8_t phase, uint32_t ms) {
  switch (phase) {
    case env::DAWN: trigger(73, ms, false); break;
    case env::DUSK: trigger(74, ms, false); break;
    case env::NIGHT: if (rng.chance(0.6f)) trigger(72, ms, false); break;
    case env::DEEP_NIGHT: trigger(rng.chance(0.5f) ? 71 : 75, ms, false); break;
    default: break;
  }
}

void runSequence(int a, int b, float sec, uint32_t ms) {
  seqCur = util::clamp(a, 1, EVENT_COUNT);
  seqEnd = util::clamp(b, seqCur, EVENT_COUNT);
  seqSec = sec < 2 ? 2 : sec;
  seqNext = ms;
}

void printSchedule(uint32_t ms) {
  static const char* N[] = {"common", "special", "rare", "ultra"};
  for (int r = 0; r < RARITY_COUNT; r++) Serial.printf("  %s in %ld s\n", N[r], (long)((int32_t)(nextAt[r] - ms) / 1000));
  Serial.printf("  big in %ld s | alive %d refill %d | sharks %u lastSharkDay %lu newStart %d | deaths %d | blood %d gore %u\n", (long)((int32_t)(nextBig - ms) / 1000),
                fish::alive(), fish::refilling(), wld.sharks, (unsigned long)wld.lastSharkDay, wld.newStart, fish::deathCount(),
                particles::bloodAmount(), gore::level);
  for (int s = 0; s < acfg::EVENT_SLOTS; s++)
    if (slots[s].on) Serial.printf("  slot %d: %03u %s t=%.1f/%.0f stage %u\n", s, slots[s].id, def(slots[s].id).name, slots[s].t, slots[s].dur, slots[s].stage);
  if (pendingId) Serial.printf("  pending %d\n", pendingId);
}

uint16_t timesSeen(int id) { return (id >= 1 && id <= EVENT_COUNT) ? seen[id] : 0; }
void setTimesSeen(int id, uint16_t n) { if (id >= 1 && id <= EVENT_COUNT) seen[id] = n; }
bool discovered(int id) { return timesSeen(id) > 0; }
int discoveredCount() {
  int n = 0;
  for (int id = 1; id <= EVENT_COUNT; id++) n += seen[id] > 0 && def(id).impl;
  return n;
}
int implementedCount() {
  int n = 0;
  for (int id = 1; id <= EVENT_COUNT; id++) n += def(id).impl;
  return n;
}
World& world() { return wld; }
int feedsWithin(uint32_t ms, uint32_t window) {
  int n = 0;
  for (uint32_t f : feedRing) n += f && ms - f < window;
  return n;
}
bool deathBudget(uint32_t ms) {
  if (fish::alive() <= 5) return false;
  int hour = 0, day = 0;
  for (int i = 0; i < deathN2; i++) {
    const uint32_t d = ms - deathRing[i];
    hour += d < 3600000UL;
    day += d < 86400000UL;
  }
  return hour < 2 && day < 8;
}
void noteDeath(uint32_t ms) {
  deathRing[deathHead2] = ms;
  deathHead2 = (deathHead2 + 1) % 8;
  if (deathN2 < 8) deathN2++;
}
void setMessageCallback(MsgCb cb) { msgCb = cb; }
void message(const char* text) {
  Serial.printf("[Event] %s\n", text);
  if (msgCb) msgCb(text);
}
int logCount() { return logN; }
const LogEntry& logAt(int i) {
  int idx = (logHead - 1 - i + acfg::EVENT_LOG_CAP * 2) % acfg::EVENT_LOG_CAP;
  return logRing[idx];
}
void clearLog() { logHead = logN = 0; }
void pushLog(const LogEntry& e) {
  logRing[logHead] = e;
  logHead = (logHead + 1) % acfg::EVENT_LOG_CAP;
  if (logN < acfg::EVENT_LOG_CAP) logN++;
}
void setStartCallback(StartCb cb) { startCb = cb; }

}  // namespace ev
