// 事件調度器：分級計時、權重、冷卻、觸發條件、事件槽、紀錄
#pragma once
#include <stdint.h>
#include "EventCatalog.h"

namespace ev {

struct LogEntry { uint8_t id; uint8_t user; uint16_t minute; uint32_t day; };

void begin(uint32_t ms);
void tick(uint32_t ms);                 // 每秒：調度
void update(float dt, uint32_t ms);     // 每幀：推進執行中的事件
// 觸發事件。force = 開發測試 (忽略條件/冷卻，必要時中止正在播的事件)
// 回傳 0 = 成功，其他 = 失敗原因 (1 ID 錯誤, 2 冷卻中, 3 條件不符, 4 沒有空槽, 5 效果無法開始)
int trigger(int id, uint32_t ms, bool force, bool user = false);
void stopAll();
bool active(int id);
bool bigActive();                       // 大型事件進行中
int activeIds(uint8_t* out, int cap);
bool conditionMet(int id, uint32_t ms);

// 玩家互動 / 時段變化
void onFeed(uint32_t ms);
void onPhase(uint8_t phase, uint32_t ms);
void setFrequency(uint8_t f);           // 0 低 / 1 中 / 2 高

// 測試：自動依序播放 a..b，每個間隔 sec 秒
void runSequence(int a, int b, float sec, uint32_t ms);
void printSchedule(uint32_t ms);

// 紀錄 / 發現 (存檔用)
uint16_t timesSeen(int id);
void setTimesSeen(int id, uint16_t n);
bool discovered(int id);
int discoveredCount();
int logCount();
const LogEntry& logAt(int i);           // 0 = 最新
void clearLog();
void pushLog(const LogEntry& e);        // 讀檔時用 (依舊→新的順序呼叫)

// 有事件開始時的通知 (UI 顯示提示)
typedef void (*StartCb)(int id, bool user);
void setStartCallback(StartCb cb);
// 事件內的文字提示 (例如「小灰被鯊魚吃掉了」)
typedef void (*MsgCb)(const char* text);
void setMessageCallback(MsgCb cb);
void message(const char* text);

// 大型事件的世界狀態 (存檔)
struct World {
  uint32_t lastSharkDay = 0;  // 上次鯊魚來襲的虛擬天
  uint16_t sharks = 0;        // 鯊魚來襲次數
  bool newStart = false;      // 鯊魚之後補魚完成 → 播 199 新的開始
};
World& world();
int implementedCount();       // 已實作的事件數 (圖鑑分母)
void stopMinor();             // 結束所有小事件 (大型事件需要全部的魚時)
int feedsWithin(uint32_t ms, uint32_t windowMs);  // 最近 windowMs 內餵食幾次
// 死亡額度 (鯊魚以外)：每小時最多 2 條、每 24 小時最多 8 條，而且至少留 5 條魚
bool deathBudget(uint32_t ms);
void noteDeath(uint32_t ms);

}  // namespace ev
