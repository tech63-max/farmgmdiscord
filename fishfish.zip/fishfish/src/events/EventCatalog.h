// 生態事件的固定資料 (資料由 tools/gen_events.py 產生到 EventCatalog.cpp)
// Event ID 001～100 = 一般事件，101～200 = 大型事件 (BIG_EVENTS_PLAN.md)。ID 固定不變 (存檔以 ID 記錄)，不要重排或刪除
#pragma once
#include <stdint.h>

namespace ev {

constexpr int EVENT_COUNT = 200;
constexpr int BIG_FIRST = 101;

enum Category : uint8_t {
  CAT_SOLO, CAT_SOCIAL, CAT_FOOD, CAT_ENV, CAT_VISITOR, CAT_RARE,
  CAT_BIG_A, CAT_BIG_B, CAT_BIG_C, CAT_BIG_D, CAT_BIG_E, CAT_BIG_F, CAT_BIG_G, CAT_BIG_H, CAT_BIG_I, CAT_BIG_J, CAT_COUNT
};
enum Rarity : uint8_t { COMMON, SPECIAL, RARE, ULTRA, RARITY_COUNT };

// 觸發條件 (可組合)
enum Cond : uint16_t {
  C_NONE = 0,
  C_DAY = 1 << 0,       // 白天
  C_NIGHT = 1 << 1,     // 夜晚或深夜
  C_DAWN = 1 << 2,      // 清晨
  C_DUSK = 1 << 3,      // 黃昏
  C_LIGHT = 1 << 4,     // 不是夜晚 (清晨/白天/黃昏)
  C_FED = 1 << 5,       // 2 分鐘內有餵食
  C_FOOD = 1 << 6,      // 水中有飼料
  C_FED_END = 1 << 7,   // 剛餵過但飼料已經吃完
  C_DEBRIS = 1 << 8,    // 底部有殘渣
  C_ALGAE = 1 << 9,     // 岩石有藻類
  C_CLEANUP = 1 << 10,  // 殘渣或藻類其中之一
  C_WAKE = 1 << 11,     // 清晨或有魚在睡覺
  C_FISH2 = 1 << 12,    // 至少 2 條自由的魚
  C_FISH3 = 1 << 13,
  C_FISH4 = 1 << 14,
};

struct Def {
  uint8_t id;
  const char* name;
  uint8_t category;
  uint8_t rarity;
  uint8_t weight;
  uint16_t cooldownS;
  uint16_t durationS;
  uint16_t cond;
  bool major;            // true = 重要事件 (一次只播一個)；false = 日常/環境小事件 (可與其他事件同時)
  bool big;              // 大型事件 (101～200)：獨立計時器，30～120 秒
  bool impl;             // 已實作 (未實作的大型事件不會被排程、不算進圖鑑)
  bool lethal;           // 會有魚死亡
  bool once;             // 一次性
  uint8_t req;           // 需要先看過的事件 ID (0 = 無)
};

const Def& def(int id);  // id: 1..EVENT_COUNT
const char* categoryName(uint8_t c);
const char* rarityName(uint8_t r);

}  // namespace ev
