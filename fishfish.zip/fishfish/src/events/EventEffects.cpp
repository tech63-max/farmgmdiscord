// 100 個事件的行為與動畫。每個 Event ID 在 fxStart / fxUpdate / fxEnd 都有自己的 case。
// 共用的小工具：借用魚 (grab)、讓魚走一段路並停留 (leg)、生成訪客 (spawnCr)、閃光 (spark)。
#include <Arduino.h>
#include <math.h>
#include "../aquarium/Creatures.h"
#include "../aquarium/Environment.h"
#include "../aquarium/Fish.h"
#include "../aquarium/ParticleSystem.h"
#include "../aquarium/Scene.h"
#include "../core/Util.h"
#include "../gfx/Gfx.h"
#include "Event.h"
#include "EventCatalog.h"

namespace ev {
namespace {
using util::rng;
using fish::F;
namespace P = particles;
namespace CR = creatures;
uint32_t nowMs = 0;
constexpr float PI_F = 3.14159265f;
constexpr uint32_t ALL = 0xFFFFFFFF;

// ---------------------------------------------------------------- 工具

int grab(Inst& in, uint32_t mask = ALL) {
  if (in.nFish >= 8) return -1;
  int i = fish::pick(mask);
  if (i < 0) return -1;
  fish::claim(i, in.owner);
  in.fish[in.nFish] = (int8_t)i;
  return in.nFish++;
}
int grabSize(Inst& in, uint8_t lo, uint8_t hi) {
  uint32_t mask = 0;
  for (int s = 0; s < fish::SP_COUNT; s++) if (fish::info(s).size >= lo && fish::info(s).size <= hi) mask |= 1u << s;
  return grab(in, mask);
}
// 借 n 條魚，不足 need 條就失敗
bool grabN(Inst& in, int n, int need, uint32_t mask = ALL) {
  for (int k = 0; k < n; k++) if (grab(in, mask) < 0) break;
  return in.nFish >= need;
}
fish::Fish& FF(Inst& in, int k) { return F[in.fish[k]]; }
float spdOf(Inst& in, int k) { return fish::info(FF(in, k).sp).speed; }
void go(Inst& in, int k, fish::State st, float x, float y, float spd) { fish::command(in.fish[k], st, x, y, spd); }
bool atPos(Inst& in, int k, float x, float y, float r = 6) { return fish::near(in.fish[k], x, y, r); }
void next(Inst& in) { in.stage++; in.st = 0; in.entered = false; in.arriveT = -1; }
bool enter(Inst& in) { if (in.entered) return false; in.entered = true; return true; }

// 一條魚走到 (x,y)，抵達後停留 dwell 秒就進入下一階段 (逾時也會前進，避免卡住)
bool leg(Inst& in, int k, fish::State st, float x, float y, float spd, float dwell, float tol = 6, float timeout = 14) {
  fish::clampTarget(x, y);
  if (enter(in)) go(in, k, st, x, y, spd);
  if (in.arriveT < 0 && atPos(in, k, x, y, tol)) in.arriveT = in.st;
  if ((in.arriveT >= 0 && in.st - in.arriveT >= dwell) || in.st > timeout) { next(in); return true; }
  return false;
}
// 多條魚同時移動到各自的位置
bool groupLeg(Inst& in, fish::State st, const float* xs, const float* ys, float spdMul, float dwell, float timeout = 12) {
  if (enter(in))
    for (int k = 0; k < in.nFish; k++) {
      float x = xs[k], y = ys[k];
      fish::clampTarget(x, y);
      go(in, k, st, x, y, spdOf(in, k) * spdMul);
    }
  bool all = true;
  for (int k = 0; k < in.nFish; k++) if (!atPos(in, k, FF(in, k).tx, FF(in, k).ty, 8)) all = false;
  if (all && in.arriveT < 0) in.arriveT = in.st;
  if ((in.arriveT >= 0 && in.st - in.arriveT >= dwell) || in.st > timeout) { next(in); return true; }
  return false;
}

int spawnCr(Inst& in, CR::Type t, float x, float y, int8_t dir) {
  if (in.nCr >= 10) return -1;
  int i = CR::spawn(t, x, y, dir, in.owner);
  if (i < 0) return -1;
  in.cr[in.nCr] = (int8_t)i;
  return in.nCr++;
}
CR::C& CC(Inst& in, int k) { return CR::at(in.cr[k]); }
bool crOk(Inst& in, int k) { return k < in.nCr && in.cr[k] >= 0 && CR::at(in.cr[k]).on; }

void spark(float x, float y, int n, uint32_t c = 0xfff4b0) { P::burst(P::SPARK, x, y, n, 16, 0.9f, c); }
float bottomY(float x) { return (float)scene::swimBottom((int)x); }
float randX() { return rng.range(40, 200); }
float midY() { return rng.range(60, 150); }
// 每隔 period 秒回傳一次 true
bool every(Inst& in, float period, float dt) {
  in.acc += dt;
  if (in.acc >= period) { in.acc -= period; return true; }
  return false;
}
// 讓走路的訪客從岩石後方出來後換到前景
void emergeLayer(Inst& in, int k) {
  if (!crOk(in, k)) return;
  CR::C& c = CC(in, k);
  if (c.layer == 0 && !gfx::rockAt((int)c.x, (int)c.y) && !gfx::rockAt((int)c.x - 8, (int)c.y)) c.layer = 1;
}
int foodNear(float x) {
  int best = -1;
  float bd = 1e9f;
  for (int i = 0; i < P::cap(); i++) {
    const P::P& p = P::at(i);
    if (!p.on || p.type != P::FOOD) continue;
    float d = fabsf(p.x - x);
    if (d < bd) { bd = d; best = i; }
  }
  return best;
}
}  // namespace

// ================================================================ START
bool fxStart(Inst& in) {
  nowMs = millis();
  env::Fx& fx = env::fx;
  switch (in.id) {
    // ---------- A. 單隻魚類日常 ----------
    case 1: case 2: case 3: case 5: case 6: case 9: case 10: case 11: case 13: case 14: case 15:
    case 16: case 17: case 18: case 19: case 20: case 49: {
      if (grab(in) < 0) return false;
      in.v[0] = FF(in, 0).x; in.v[1] = FF(in, 0).y;  // 原本的位置
      if (in.id == 5) in.v[2] = randX();
      if (in.id == 3 || in.id == 11) in.k[0] = (int16_t)scene::nearestPlant(FF(in, 0).x, false);
      return true;
    }
    case 4: return grab(in) >= 0;
    case 7: {
      if (grab(in) < 0) return false;
      int p;
      do { p = rng.irange(0, scene::PLANT_N - 1); } while (scene::plants[p].type == scene::GRASS || scene::plants[p].front);
      in.k[0] = (int16_t)p;
      return true;
    }
    case 8: {
      if (grab(in) < 0) return false;
      in.v[0] = util::clamp(FF(in, 0).x, 50.0f, 190.0f);
      return true;
    }
    case 12: {
      // 優先挑正在睡覺的魚
      int pickI = -1;
      for (int i = 0; i < fish::count(); i++) if (F[i].on && !F[i].owner && F[i].st == fish::SLEEP) { pickI = i; break; }
      if (pickI >= 0) { fish::claim(pickI, in.owner); in.fish[in.nFish++] = (int8_t)pickI; }
      else if (grab(in) < 0) return false;
      FF(in, 0).eyesClosed = true;
      go(in, 0, fish::SLEEP, FF(in, 0).x, FF(in, 0).y, 1);
      return true;
    }
    // ---------- B. 魚群社交 ----------
    case 21: case 24: case 25: case 29: case 30: case 38: case 39: return grabN(in, 2, 2);
    case 22: case 28: return grabN(in, 3, 3);
    case 23: {
      // 群游類魚種優先
      uint32_t social = (1u << fish::TROP_BY) | (1u << fish::LEMON) | (1u << fish::TROP_RW) | (1u << fish::TROP_OW);
      grabN(in, 4, 0, social);
      if (in.nFish < 3) grabN(in, 4 - in.nFish, 0);
      for (int k = 0; k < in.nFish; k++) in.k[k] = (int16_t)k;
      return in.nFish >= 3;
    }
    case 26: return grabN(in, 6, 4);
    case 27: if (!grabN(in, 5, 4)) return false; in.v[0] = 120; in.v[1] = 100; return true;
    case 31: if (P::count(P::FOOD) == 0) P::dropFood(randX(), 3); return grabN(in, 3, 3);
    case 32: {
      if (grabSize(in, 2, 2) < 0) return false;
      grabSize(in, 0, 0);
      grabSize(in, 0, 0);
      return in.nFish >= 3;
    }
    case 33: if (!grabN(in, 2, 2)) return false; in.k[0] = (int16_t)scene::nearestPlant(FF(in, 0).x, false); return true;
    case 34: case 35: return grabN(in, 4, 4);
    case 36: {
      if (!grabN(in, 3, 3)) return false;
      int c = spawnCr(in, CR::SNAIL, scene::ROCK_L.cx + 22, 0, 1);
      if (c < 0) return false;
      CC(in, c).layer = 0;
      CR::walkTo(in.cr[c], 140, 3.5f);
      return true;
    }
    case 37: {
      if (grab(in) < 0) return false;
      int c = spawnCr(in, CR::SHRIMP, scene::plants[1].x, 0, 1);
      if (c < 0) return false;
      CR::walkTo(in.cr[c], 196, 11);
      return true;
    }
    case 40: return grabN(in, 8, 4);
    // ---------- C. 餵食與覓食 ----------
    case 41:
      P::dropFood(in.user ? rng.range(70, 170) : randX(), in.user ? rng.irange(5, 7) : rng.irange(3, 5));
      if (!in.user) env::lastFeedMs = nowMs;
      return true;
    case 42: {
      if (P::count(P::FOOD) == 0) {
        int any = fish::pick();
        P::dropFood(any >= 0 ? F[any].x : randX(), 1);
      }
      int fi = foodNear(120);
      const P::P& p = P::at(fi < 0 ? 0 : fi);
      int i = fish::pickNear(p.x, p.y, -1);
      if (i >= 0 && !F[i].owner && !F[i].manual) { fish::claim(i, in.owner); in.fish[in.nFish++] = (int8_t)i; }
      else if (grab(in) < 0) return false;
      go(in, 0, fish::EAT, p.x, p.y, spdOf(in, 0) * 1.6f);
      in.v[0] = (float)(nowMs & 0xFFFFFF);
      return true;
    }
    case 43: {
      if (grab(in) < 0) return false;
      float x = util::clamp(FF(in, 0).x + rng.range(-40, 40), 40.0f, 200.0f);
      in.k[0] = (int16_t)P::spawn(P::FOOD, x, scene::SURFACE_Y + 4, 0, 2, 40, 1, 0xc8702a);
      return in.k[0] >= 0;
    }
    case 44: {
      in.k[0] = (int16_t)P::spawn(P::FOOD, scene::plants[1].x + 18, scene::SURFACE_Y + 3, 0, 2, 60, 1, 0xa85a20);
      if (in.k[0] < 0) return false;
      int c = spawnCr(in, CR::SHRIMP, scene::plants[1].x - 4, 0, 1);
      if (c < 0) return false;
      CC(in, c).alphaT = 0.0f;  // 先躲在水草下
      grab(in);
      return true;
    }
    case 45: {
      if (scene::debrisCount() == 0) for (int i = 0; i < 3; i++) scene::addDebris(rng.range(90, 170));
      int c = spawnCr(in, CR::SNAIL, scene::ROCK_L.cx + 24, 0, 1);
      if (c < 0) return false;
      CC(in, c).layer = 0;
      return true;
    }
    case 46: {
      if (scene::algaeVisible() == 0) return false;
      if (grab(in) < 0) return false;
      scene::algaePoint(rng.irange(0, scene::algaeVisible() - 1), in.v[0], in.v[1]);
      return true;
    }
    case 47: if (P::count(P::FOOD) == 0) P::dropFood(rng.range(80, 160), 6); return grabN(in, 6, 3);
    case 48: {
      int pickI = -1;
      for (int i = 0; i < fish::count(); i++)
        if (F[i].on && !F[i].owner && F[i].lastAte && nowMs - F[i].lastAte < 120000) { pickI = i; break; }
      if (pickI >= 0) { fish::claim(pickI, in.owner); in.fish[in.nFish++] = (int8_t)pickI; }
      else if (grab(in) < 0) return false;
      in.k[0] = (int16_t)scene::nearestPlant(FF(in, 0).x, false);
      return true;
    }
    case 50: return grabN(in, 6, 3);
    case 51: {
      in.v[0] = rng.range(40, 160);
      for (int i = 0; i < 10; i++) P::spawn(P::MICRO, in.v[0] + rng.range(0, 60), 0, rng.range(0, 6), 0, in.dur);
      fish::attract(in.v[0] + 30, bottomY(in.v[0] + 30) - 8, 1);
      return true;
    }
    case 52: {
      for (int i = 0; i < 24; i++)
        P::spawn(P::PLANKTON, rng.range(-12, 8), rng.range(70, 130), rng.range(11, 17), rng.range(-1, 1), 24, 1, rng.chance(0.5f) ? 0xb8e8a0 : 0xd8f0b0);
      grabN(in, 2, 0);
      return true;
    }
    case 53: in.v[0] = env::eco.algae; return true;
    case 54: {
      if (scene::debrisCount() == 0 && scene::algaeVisible() == 0) { scene::addDebris(rng.range(100, 160)); env::eco.algae = 0.25f; }
      spawnCr(in, CR::SHRIMP, scene::plants[1].x, 0, 1);
      int s = spawnCr(in, CR::SNAIL, scene::ROCK_L.cx + 22, 0, 1);
      if (s >= 0) CC(in, s).layer = 0;
      return in.nCr > 0;
    }
    case 55: return grabN(in, 4, 2);
    // ---------- D. 環境 ----------
    case 56: P::bubbles(randX(), scene::sandTop(120) - 2, 6); return true;
    case 57: in.v[0] = in.user ? 200 : randX(); return true;
    case 58: case 61: case 65: case 67: case 68: case 69: case 70: case 71: case 72: case 73: case 74: case 75: {
      if (in.id == 65) for (int i = 0; i < 40; i++) P::spawn(P::MOTE, rng.range(5, 235), rng.range(25, 190), rng.range(-2, 2), rng.range(-1, 1), in.dur);
      if (in.id == 67) in.v[0] = rng.chance(0.5f) ? 20 : -20;
      if (in.id == 70) for (int i = 0; i < 25; i++) P::spawn(P::MOTE, rng.range(5, 235), rng.range(25, 190), rng.range(-3, 3), rng.range(-1, 1), in.dur * 0.8f);
      if (in.id == 71) for (int i = 0; i < 18; i++) P::spawn(P::GLOWDOT, rng.range(10, 230), rng.range(30, 185), rng.range(-3, 3), rng.range(-2, 1), in.dur, 1, 0x50ffd0);
      if (in.id == 75)
        for (int i = 0; i < 10; i++) {
          float x, y;
          scene::plantPoint(rng.irange(0, scene::PLANT_N - 1), rng.range(0.4f, 1.0f), x, y);
          P::spawn(P::GLOWDOT, x, y, rng.range(-2, 2), rng.range(-3, -1), in.dur, 1, 0x60ffe0);
        }
      return true;
    }
    case 59: fx.beamsT = 1; return true;
    case 60: fx.shadowX = -110; return true;
    case 62: P::spawn(P::LEAF, rng.range(30, 180), scene::SURFACE_Y + 1, 0, 0, 60); return true;
    case 63: {
      int p;
      do { p = rng.irange(0, scene::PLANT_N - 1); } while (scene::plants[p].type == scene::GRASS);
      in.k[0] = (int16_t)p;
      if (!scene::growLeaf(p)) {
        float x, y;
        scene::plantPoint(p, 0.9f, x, y);
        P::spawn(P::LEAF, x, y, 0, 0, 40);  // 已達上限：舊葉飄落、換新葉
      }
      env::eco.plantGrowth = fminf(1, env::eco.plantGrowth + 0.03f);
      return true;
    }
    case 64: {
      int p;
      do { p = rng.irange(0, scene::PLANT_N - 1); } while (scene::plants[p].type == scene::GRASS);
      fx.flowerPlant = (int8_t)p;
      fx.flowerT = 1;
      return true;
    }
    case 66: {
      float x = randX();
      P::burst(P::DUST, x, scene::sandTop((int)x) - 1, 16, 22, 3.5f);
      fish::startle(x, scene::sandTop((int)x) - 10, 40);
      return true;
    }
    // ---------- E. 訪客 ----------
    case 76: {
      int c = spawnCr(in, CR::SNAIL, scene::ROCK_L.cx + 18, 0, 1);
      if (c < 0) return false;
      CC(in, c).layer = 0;
      CR::walkTo(in.cr[c], 130, 3.5f);
      return true;
    }
    case 77: {
      int c = spawnCr(in, CR::SNAIL, 214, 0, 1);
      if (c < 0) return false;
      CR::walkTo(in.cr[c], 228, 4);
      return true;
    }
    case 78: case 79: case 80: case 85: {
      CR::Type t = in.id == 85 ? CR::GHOST_SHRIMP : CR::SHRIMP;
      float x = in.id == 85 ? 176 : (in.id == 80 ? 84 : scene::plants[1].x);
      int c = spawnCr(in, t, x, 0, in.id == 85 ? -1 : 1);
      if (c < 0) return false;
      if (in.id == 80) { CC(in, c).carry = true; CR::walkTo(in.cr[c], 204, 8); }
      if (in.id == 79) CR::walkTo(in.cr[c], 150, 10);
      if (in.id == 85) CR::walkTo(in.cr[c], 96, 7);
      return true;
    }
    case 81: {
      int c = spawnCr(in, CR::CLEANER, -20, 110, 1);
      if (c < 0) return false;
      CR::swimTo(in.cr[c], 18, 100, 26);
      return true;
    }
    case 82: {
      const bool fromLeft = rng.chance(0.5f);
      for (int j = 0; j < 8; j++) {
        int c = spawnCr(in, CR::FRY, fromLeft ? -20 - j * 9 : 260 + j * 9, 90 + (j % 3) * 8 + rng.range(-3, 3), fromLeft ? 1 : -1);
        if (c < 0) break;
        CC(in, c).spd = 58;
        CR::leave(in.cr[c]);
      }
      return in.nCr > 0;
    }
    case 83: {
      int c = spawnCr(in, CR::GOLDFISH, -20, 95, 1);
      if (c < 0) return false;
      CC(in, c).glint = true;
      CR::swimTo(in.cr[c], 120, 95, 20);
      return true;
    }
    case 84: {
      int c = spawnCr(in, CR::BLUEFISH, 262, 70, -1);
      if (c < 0) return false;
      CC(in, c).layer = 0;
      CC(in, c).spd = 20;
      CR::leave(in.cr[c]);
      return true;
    }
    case 86: {
      int c = spawnCr(in, CR::SNAIL, scene::SHELL_X - 40, 0, 1);
      if (c < 0) return false;
      CR::walkTo(in.cr[c], scene::SHELL_X - 22, 4);
      return true;
    }
    case 87: {
      int c = spawnCr(in, CR::SHADOWFISH, -80, 82, 1);
      if (c < 0) return false;
      CC(in, c).spd = 22;
      CR::leave(in.cr[c]);
      return true;
    }
    case 88: if (grab(in) < 0) return false; return true;
    case 89: {
      int c = spawnCr(in, CR::CRAB, scene::ROCK_L.cx + 26, 0, 1);
      if (c < 0) return false;
      CC(in, c).layer = 0;
      CR::walkTo(in.cr[c], 116, 9);
      return true;
    }
    case 90: {
      if (grab(in) < 0) return false;
      in.v[0] = FF(in, 0).x < 120 ? 210 : 30;
      return true;
    }
    // ---------- F. 稀有 ----------
    case 91: fx.rainbowT = 1; fx.shimmerT = 0.6f; return true;
    case 92: case 94: case 95: case 96: case 97: case 98: case 100: {
      if (in.id == 96) { fx.meteorX = -30; fx.meteorY = 24; }
      if (in.id == 97) {
        fx.starsT = 1;
        for (int i = 0; i < 40; i++) P::spawn(P::STAR, rng.range(6, 234), rng.range(24, 190), 0, 0, in.dur - rng.range(0, 6), (uint8_t)rng.irange(0, 1));
      }
      if (in.id == 98) {
        fx.mysticT = 1;
        fx.swayT = 1.6f;
        for (int i = 0; i < 12; i++) P::spawn(P::GLOWDOT, rng.range(10, 230), rng.range(60, 190), rng.range(-2, 2), rng.range(-2, 0), in.dur, 1, 0xc070ff);
      }
      if (in.id == 95) fx.pearlT = 1;
      return true;
    }
    case 93: {
      fx.orbX = rng.range(60, 180);
      fx.orbY = bottomY(fx.orbX) - 10;
      fx.orbT = 1;
      return true;
    }
    case 99: {
      for (int j = 0; j < 7; j++) {
        int c = spawnCr(in, CR::RAREFISH, 268 + abs(j - 3) * 12, 84 + (j - 3) * 8, -1);
        if (c < 0) break;
        CC(in, c).layer = 0;
        CC(in, c).spd = 28;
        CR::leave(in.cr[c]);
      }
      return in.nCr > 0;
    }
    default: return in.id >= BIG_FIRST ? bigStart(in) : false;
  }
}

// ================================================================ UPDATE
void fxUpdate(Inst& in, float dt) {
  nowMs = millis();
  env::Fx& fx = env::fx;
  const float t = in.t;
  switch (in.id) {
    // ---------- A. 單隻魚類日常 ----------
    case 1:  // 水面探索
      if (in.stage == 0) leg(in, 0, fish::SWIM, in.v[0] + rng.range(-1, 1), scene::SWIM_TOP + 2, spdOf(in, 0), 3.5f);
      else if (in.stage == 1) leg(in, 0, fish::SWIM, in.v[0], in.v[1], spdOf(in, 0), 0.2f);
      else in.done = true;
      break;
    case 2:  // 深水探索
      if (in.stage == 0) leg(in, 0, fish::EXPLORE, in.v[0], bottomY(in.v[0]), spdOf(in, 0), 0.5f);
      else if (in.stage == 1) {
        float x = in.v[0] + (in.v[0] < 120 ? 45 : -45);
        if (leg(in, 0, fish::EXPLORE, x, bottomY(x), spdOf(in, 0) * 0.6f, 0.8f)) P::burst(P::DUST, FF(in, 0).x, scene::sandTop((int)FF(in, 0).x), 5, 10, 2);
      } else if (in.stage == 2) leg(in, 0, fish::SWIM, in.v[0], in.v[1], spdOf(in, 0), 0.1f);
      else in.done = true;
      break;
    case 3:  // 水草休息
    case 11: {  // 悠閒睡眠
      float px, py;
      scene::plantPoint(in.k[0], 0.25f, px, py);
      px += FF(in, 0).x < px ? -12 : 12;
      if (in.stage == 0) leg(in, 0, fish::REST, px, py, spdOf(in, 0) * 0.8f, 0.3f, 6, 10);
      else if (in.stage == 1) {
        if (enter(in)) go(in, 0, in.id == 11 ? fish::SLEEP : fish::REST, px, py, 1);
        FF(in, 0).tailBoost = -0.4f;
        if (in.id == 11) FF(in, 0).eyesClosed = in.st > 1.0f;
        if (in.id == 3 && in.st > 9) in.done = true;
      }
      break;
    }
    case 4: {  // 岩石探險：右側 → 岩石後面 → 上方冒出
      const scene::Rock& r = scene::ROCK_L;
      if (in.stage == 0) leg(in, 0, fish::EXPLORE, r.cx + r.rx + 14, r.cy - 14, spdOf(in, 0), 0.3f);
      else if (in.stage == 1) {
        FF(in, 0).wantLayer = 0;
        FF(in, 0).layer = 0;
        leg(in, 0, fish::EXPLORE, r.cx, r.cy + 2, spdOf(in, 0) * 0.7f, 1.5f, 8);
      } else if (in.stage == 2) {
        FF(in, 0).wantLayer = 1;
        leg(in, 0, fish::SWIM, r.cx - 4, r.cy - r.ry - 14, spdOf(in, 0) * 0.8f, 0.5f, 8);
      } else in.done = true;
      break;
    }
    case 5: {  // 追逐泡泡
      if (in.stage <= 1 && every(in, 0.22f, dt))
        P::spawn(P::BUBBLE, in.v[2] + rng.range(-2, 2), scene::sandTop((int)in.v[2]) - 2, 0, -rng.range(18, 24), 12, (uint8_t)rng.irange(1, 2));
      if (in.stage == 0) leg(in, 0, fish::SWIM, in.v[2] + 10, bottomY(in.v[2]) - 16, spdOf(in, 0) * 1.2f, 0.8f);
      else if (in.stage == 1) leg(in, 0, fish::SWIM, in.v[2] + 8, scene::SWIM_TOP + 4, 20, 0.5f);
      else if (in.stage == 2) leg(in, 0, fish::SWIM, in.v[0], in.v[1], spdOf(in, 0), 0.1f);
      else in.done = true;
      break;
    }
    case 6:  // 快速衝刺
      if (in.stage == 0) {
        if (enter(in)) {
          float x = FF(in, 0).x < 120 ? 222 : 18;
          go(in, 0, fish::FAST, x, FF(in, 0).y + rng.range(-20, 20), fish::info(FF(in, 0).sp).fast * 1.2f);
          FF(in, 0).tailBoost = 1.2f;
        }
        if (atPos(in, 0, FF(in, 0).tx, FF(in, 0).ty, 10)) next(in);
      } else { FF(in, 0).tailBoost = 0; in.done = in.st > 1; }
      break;
    case 7: {  // 繞水草游泳 (遠側畫在水草後面)
      float px, py;
      scene::plantPoint(in.k[0], 0.45f, px, py);
      if (in.stage == 0) leg(in, 0, fish::SWIM, px + 20, py, spdOf(in, 0), 0.1f, 8);
      else if (in.stage == 1) {
        in.v[3] += dt * 1.5f;
        float a = in.v[3];
        fish::moveTo(in.fish[0], px + cosf(a) * 20, py + sinf(a) * 5, dt);
        FF(in, 0).wantLayer = FF(in, 0).layer = sinf(a) < 0 ? 0 : 1;
        if (a > 4 * PI_F) next(in);
      } else { FF(in, 0).manual = false; FF(in, 0).wantLayer = 1; in.done = true; }
      break;
    }
    case 8: {  // 水面跳躍
      fish::Fish& f = FF(in, 0);
      if (in.stage == 0) leg(in, 0, fish::FAST, in.v[0], scene::SWIM_TOP + 6, fish::info(f.sp).fast, 0.05f, 8);
      else if (in.stage == 1) {
        if (enter(in)) { in.v[1] = f.x; in.v[2] = f.y; in.v[4] = f.dir; }
        float p = fminf(1, in.st / 1.1f);
        float y = in.v[2] - 34 * sinf(PI_F * p);
        float prevY = f.y;
        fish::moveTo(in.fish[0], in.v[1] + in.v[4] * 44 * p, y, dt);
        f.dir = (int8_t)in.v[4];
        if ((prevY > scene::SURFACE_Y) != (y > scene::SURFACE_Y)) {
          P::burst(P::SPLASH, f.x, scene::SURFACE_Y - 1, 7, 40, 1.0f);
          scene::addRipple(f.x, 0.8f);
        }
        if (p >= 1) next(in);
      } else if (in.stage == 2) { f.manual = false; leg(in, 0, fish::SWIM, f.x + f.dir * 20, f.y + 40, fish::info(f.sp).speed, 0.1f); }
      else in.done = true;
      break;
    }
    case 9:  // 搖擺尾巴
      if (enter(in)) go(in, 0, fish::IDLE, FF(in, 0).x, FF(in, 0).y, 2);
      FF(in, 0).tailBoost = 3.0f;
      break;
    case 10:  // 吐泡泡
      if (enter(in)) go(in, 0, fish::IDLE, FF(in, 0).x, FF(in, 0).y, 1);
      if (in.t > 0.8f && every(in, 0.45f, dt))
        P::spawn(P::BUBBLE, fish::mouthX(in.fish[0]), FF(in, 0).y - 2, 0, -rng.range(14, 20), 10, (uint8_t)rng.irange(1, 2));
      break;
    case 12: {  // 睡醒伸展
      fish::Fish& f = FF(in, 0);
      if (in.stage == 0) { f.eyesClosed = true; if (in.st > 2) next(in); }
      else if (in.stage == 1) {
        f.eyesClosed = false;
        f.wiggle = 1.6f * sinf(in.st * 2);
        f.tailBoost = 1.5f;
        if (in.st > 2.6f) next(in);
      } else if (in.stage == 2) {
        f.wiggle = 0; f.tailBoost = 0;
        if (enter(in)) go(in, 0, fish::SWIM, f.x + f.dir * 70, f.y - 10, 4);
        f.spd = fminf(fish::info(f.sp).speed, f.spd + dt * 3);
        if (in.st > 5) in.done = true;
      }
      break;
    }
    case 13: {  // 沙地探索
      if (in.stage < 4) {
        float x = util::clamp(in.v[0] + (in.stage % 2 ? -30.0f : 30.0f) * (in.stage + 1) * 0.5f, 24.0f, 216.0f);
        if (leg(in, 0, fish::EXPLORE, x, bottomY(x) + 2, spdOf(in, 0) * 0.5f, 1.0f, 6, 8))
          P::burst(P::DUST, FF(in, 0).x + FF(in, 0).dir * 8, scene::sandTop((int)FF(in, 0).x), 5, 9, 2);
      } else in.done = true;
      break;
    }
    case 14: {  // 表面好奇：游到中央靠近玻璃
      fish::Fish& f = FF(in, 0);
      if (in.stage == 0) leg(in, 0, fish::INSPECT, 120, 110, spdOf(in, 0) * 1.2f, 0.2f, 8);
      else if (in.stage == 1) { f.closer = 1; f.tailBoost = -0.3f; if (in.st > 5) next(in); }
      else { f.closer = 0; in.done = in.st > 1; }
      break;
    }
    case 15: {  // 玻璃探頭
      fish::Fish& f = FF(in, 0);
      const float edge = in.v[0] < 120 ? scene::SWIM_LEFT : scene::SWIM_RIGHT;
      if (in.stage == 0) leg(in, 0, fish::SWIM, edge, in.v[1], spdOf(in, 0), 2.2f, 4);
      else if (in.stage == 1) { f.wiggle = 0; leg(in, 0, fish::SWIM, edge + (edge < 120 ? 50 : -50), in.v[1] + 8, spdOf(in, 0), 0.1f); }
      else in.done = true;
      if (in.stage == 0 && in.arriveT >= 0) f.wiggle = 0.6f;
      break;
    }
    case 16: {  // 轉身觀察
      fish::Fish& f = FF(in, 0);
      if (enter(in)) { go(in, 0, fish::IDLE, f.x, f.y, 1); f.backward = true; }
      int turns = (int)(t / 1.4f);
      if (turns != in.k[1] && turns <= 3) { in.k[1] = (int16_t)turns; if (turns > 0) f.dir = -f.dir; }
      break;
    }
    case 17: {  // 倒退游動
      fish::Fish& f = FF(in, 0);
      if (enter(in)) { go(in, 0, fish::SWIM, f.x - f.dir * 28, f.y + 2, 7); f.backward = true; }
      f.tailBoost = 0.8f;
      break;
    }
    case 18:  // 原地懸停
      if (enter(in)) go(in, 0, fish::IDLE, FF(in, 0).x, FF(in, 0).y, 0.5f);
      FF(in, 0).tailBoost = -0.3f;
      break;
    case 19: {  // 追自己的尾巴
      in.v[3] += dt * 4.6f;
      float a = in.v[3];
      fish::moveTo(in.fish[0], in.v[0] + cosf(a) * 10 - 10, in.v[1] + sinf(a) * 7, dt);
      FF(in, 0).tailBoost = 1.0f;
      if (a > 4 * PI_F) in.done = true;
      break;
    }
    case 20: {  // 快樂跳舞
      fish::Fish& f = FF(in, 0);
      fish::moveTo(in.fish[0], in.v[0] + sinf(t * 4) * 16, in.v[1] + sinf(t * 8) * 3, dt);
      f.wiggle = 1.5f;
      f.tailBoost = 1.5f;
      if (every(in, 0.6f, dt)) spark(f.x, f.y - 8, 2);
      break;
    }
    // ---------- B. 魚群社交 ----------
    case 21: case 25: case 39: {  // 雙魚同行 / 跟隨領隊 / 重新和好
      fish::Fish& a = FF(in, 0);
      fish::Fish& b = FF(in, 1);
      if (in.id == 39 && in.stage == 0) {
        // 先往彼此靠近
        float mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2;
        if (enter(in)) { go(in, 0, fish::SWIM, mx - 10, my, spdOf(in, 0)); go(in, 1, fish::SWIM, mx + 10, my, spdOf(in, 1)); }
        if (fish::near(in.fish[0], b.x, b.y, 24) || in.st > 6) next(in);
        break;
      }
      if (enter(in) || atPos(in, 0, a.tx, a.ty, 8)) {
        float x = a.x < 120 ? rng.range(150, 215) : rng.range(25, 90);
        go(in, 0, fish::SWIM, x, midY(), spdOf(in, 0));
      }
      const float lead = fish::info(a.sp).speed;
      if (in.id == 25) fish::command(in.fish[1], fish::FOLLOW, a.x - a.dir * 22, a.y + 2, lead * 1.25f);
      else fish::command(in.fish[1], fish::SWIM, a.x - a.dir * 2, a.y + 20, lead * 1.15f);
      break;
    }
    case 22: {  // 三魚群游 (三角隊形)
      fish::Fish& a = FF(in, 0);
      if (enter(in) || atPos(in, 0, a.tx, a.ty, 8)) go(in, 0, fish::SCHOOL, a.x < 120 ? rng.range(150, 215) : rng.range(25, 90), midY(), spdOf(in, 0));
      const float sp = fish::info(a.sp).speed * 1.2f;
      fish::command(in.fish[1], fish::SCHOOL, a.x - a.dir * 28, a.y - 16, sp);
      fish::command(in.fish[2], fish::SCHOOL, a.x - a.dir * 28, a.y + 16, sp);
      break;
    }
    case 23: {  // 群游領袖交替
      const int n = in.nFish;
      fish::Fish& lead = FF(in, in.k[0]);
      if (enter(in) || atPos(in, in.k[0], lead.tx, lead.ty, 8))
        go(in, in.k[0], fish::SCHOOL, lead.x < 120 ? rng.range(160, 215) : rng.range(25, 80), midY(), spdOf(in, in.k[0]));
      for (int j = 1; j < n; j++)
        fish::command(in.fish[in.k[j]], fish::SCHOOL, lead.x - lead.dir * 26 * j, lead.y + (j % 2 ? 6 : -6), fish::info(lead.sp).speed * 1.4f);
      if (in.stage == 0 && t > in.dur * 0.45f) {
        // 最後一條加速超前成為新的領隊
        int16_t last = in.k[n - 1];
        for (int j = n - 1; j > 0; j--) in.k[j] = in.k[j - 1];
        in.k[0] = last;
        in.stage = 1;
        in.entered = false;
        FF(in, last).tailBoost = 1;
      }
      break;
    }
    case 24: case 30: {  // 互相問候 / 鼻尖碰觸
      fish::Fish& a = FF(in, 0);
      if (in.stage == 0) {
        if (enter(in)) {
          in.v[0] = util::clamp((a.x + FF(in, 1).x) / 2, 50.0f, 190.0f);
          in.v[1] = util::clamp((a.y + FF(in, 1).y) / 2, 50.0f, 160.0f);
        }
        const float gap = in.id == 30 ? fish::halfW(in.fish[0]) * 0.5f + fish::halfW(in.fish[1]) * 0.5f + 2 : 26;
        float xs[2] = {in.v[0] - gap, in.v[0] + gap}, ys[2] = {in.v[1], in.v[1]};
        groupLeg(in, fish::INSPECT, xs, ys, 1.0f, 0.1f, 8);
        FF(in, 0).dir = 1; FF(in, 1).dir = -1;
      } else if (in.stage == 1) {
        FF(in, 0).backward = FF(in, 1).backward = true;
        FF(in, 0).dir = 1; FF(in, 1).dir = -1;
        if (in.id == 24 && every(in, 0.7f, dt)) P::spawn(P::BUBBLE, in.v[0], in.v[1] - 4, 0, -16, 8, 1);
        if (in.id == 30 && enter(in)) {  // 碰一下彈開
          go(in, 0, fish::IDLE, in.v[0] - 14, in.v[1], 12);
          go(in, 1, fish::IDLE, in.v[0] + 14, in.v[1], 12);
        }
        if (in.st > (in.id == 24 ? 2.5f : 1.2f)) next(in);
      } else if (in.stage == 2) {
        FF(in, 0).backward = FF(in, 1).backward = false;
        if (enter(in)) { go(in, 0, fish::SWIM, in.v[0] - 70, in.v[1] + 10, spdOf(in, 0)); go(in, 1, fish::SWIM, in.v[0] + 70, in.v[1] - 10, spdOf(in, 1)); }
        if (in.st > 3) in.done = true;
      }
      break;
    }
    case 26: {  // 魚群分流
      const int n = in.nFish;
      float xs[8], ys[8];
      for (int k = 0; k < n; k++) {
        float a = k * 2 * PI_F / n;
        if (in.stage == 0 || in.stage == 2) { xs[k] = 120 + cosf(a) * 26; ys[k] = 100 + sinf(a) * 16; }
        else { bool left = k % 2; xs[k] = (left ? 60 : 180) + cosf(a) * 16; ys[k] = (left ? 85 : 120) + sinf(a) * 12; }
      }
      if (in.stage <= 2) groupLeg(in, fish::SCHOOL, xs, ys, 1.1f, in.stage == 1 ? 3 : 1.5f, 8);
      else in.done = true;
      break;
    }
    case 27: {  // 魚群旋轉：先滑進圓形軌道，再一起繞中心轉
      const int n = in.nFish;
      const float k = t < 2.5f ? fminf(1, dt * 2.5f) : 1.0f;
      for (int j = 0; j < n; j++) {
        fish::Fish& f = FF(in, j);
        float a = t * 1.3f + j * 2 * PI_F / n;
        float ox = in.v[0] + cosf(a) * 44, oy = in.v[1] + sinf(a) * 22;
        fish::moveTo(in.fish[j], f.x + (ox - f.x) * k, f.y + (oy - f.y) * k, dt);
      }
      break;
    }
    case 28: {  // 魚群捉迷藏
      float sx[3], sy[3];
      scene::plantPoint(1, 0.4f, sx[0], sy[0]);
      scene::plantPoint(5, 0.4f, sx[1], sy[1]);
      sx[2] = scene::ROCK_L.cx; sy[2] = scene::ROCK_L.cy;
      if (in.stage <= 1) {
        float xs[3], ys[3];
        for (int k = 0; k < 3; k++) {
          int s = (k + in.stage) % 3;
          xs[k] = sx[s]; ys[k] = sy[s];
          FF(in, k).wantLayer = s == 2 ? 0 : 1;
          if (s == 2) FF(in, k).layer = 0;
        }
        groupLeg(in, fish::HIDE, xs, ys, 1.1f, 3.0f, 10);
      } else if (in.stage == 2) {
        float xs[3] = {90, 130, 170}, ys[3] = {90, 110, 95};
        for (int k = 0; k < 3; k++) FF(in, k).wantLayer = 1;
        groupLeg(in, fish::SWIM, xs, ys, 1.0f, 0.5f, 6);
      } else in.done = true;
      break;
    }
    case 29: {  // 小型游泳競賽
      if (in.stage == 0) {
        float xs[2] = {30, 30}, ys[2] = {76, 104};
        groupLeg(in, fish::SWIM, xs, ys, 1.2f, 1.0f, 10);
      } else if (in.stage == 1) {
        if (enter(in)) {
          go(in, 0, fish::FAST, 222, 76, fish::info(FF(in, 0).sp).fast * 1.0f);
          go(in, 1, fish::FAST, 222, 104, fish::info(FF(in, 1).sp).fast * 0.85f);
          FF(in, 0).tailBoost = FF(in, 1).tailBoost = 1.2f;
        }
        if (in.st > 5 || (atPos(in, 0, 222, 76, 8) && atPos(in, 1, 222, 104, 8))) next(in);
      } else in.done = true;
      break;
    }
    case 31: case 47: {  // 一起尋找食物 / 魚群聚餐
      for (int k = 0; k < in.nFish; k++) if (FF(in, k).st != fish::EAT) go(in, k, fish::EAT, FF(in, k).x, FF(in, k).y, spdOf(in, k) * 1.6f);
      if (t > 4 && P::count(P::FOOD) == 0) in.done = true;
      break;
    }
    case 32: {  // 大魚帶小魚
      fish::Fish& a = FF(in, 0);
      if (enter(in) || atPos(in, 0, a.tx, a.ty, 10)) go(in, 0, fish::SWIM, a.x < 120 ? rng.range(150, 210) : rng.range(30, 90), midY(), spdOf(in, 0) * 0.9f);
      for (int k = 1; k < in.nFish; k++)
        fish::command(in.fish[k], fish::FOLLOW, a.x - a.dir * (fish::halfW(in.fish[0]) + 18 * k + 4), a.y + 2, fish::info(a.sp).speed * 1.4f);
      break;
    }
    case 33: {  // 水草旁聊天
      float px, py;
      scene::plantPoint(in.k[0], 0.3f, px, py);
      if (in.stage == 0) {
        float xs[2] = {px + 20, px + 22}, ys[2] = {py - 10, py + 12};
        groupLeg(in, fish::REST, xs, ys, 1.0f, 0.1f, 10);
      } else {
        const int who = ((int)(in.st / 1.5f)) & 1;
        FF(in, who).tailBoost = 1.5f;
        FF(in, 1 - who).tailBoost = -0.3f;
        FF(in, 0).dir = FF(in, 1).dir = -1;
        FF(in, 0).backward = FF(in, 1).backward = true;
        if (every(in, 1.5f, dt)) P::spawn(P::BUBBLE, fish::mouthX(in.fish[who]), FF(in, who).y - 2, 0, -14, 8, 1);
      }
      break;
    }
    case 34: case 35: {  // 同步上升 / 下降
      if (in.stage == 0) {
        float xs[4], ys[4];
        for (int k = 0; k < in.nFish; k++) { xs[k] = 60 + k * 36; ys[k] = in.id == 34 ? 150 : 50; }
        groupLeg(in, fish::SWIM, xs, ys, 1.2f, 0.6f, 9);
      } else if (in.stage == 1) {
        float xs[4], ys[4];
        for (int k = 0; k < in.nFish; k++) { xs[k] = 60 + k * 36; ys[k] = in.id == 34 ? scene::SWIM_TOP + 4 : bottomY(xs[k]); }
        if (enter(in)) for (int k = 0; k < in.nFish; k++) go(in, k, fish::SWIM, xs[k], ys[k], 18);
        if (in.st > 6.5f) next(in);
      } else in.done = true;
      break;
    }
    case 36: {  // 觀察蝸牛
      emergeLayer(in, 0);
      if (!crOk(in, 0)) break;
      CR::C& s = CC(in, 0);
      if (every(in, 1.0f, dt))
        for (int k = 0; k < in.nFish; k++)
          go(in, k, fish::INSPECT, s.x - 20 + k * 20, s.y - 18 - (k % 2) * 6, spdOf(in, k));
      if (t > in.dur - 4) CR::leave(in.cr[0]);
      break;
    }
    case 37: {  // 追蹤蝦子
      if (!crOk(in, 0)) break;
      CR::C& s = CC(in, 0);
      if (in.nFish > 0) go(in, 0, fish::FOLLOW, s.x - s.dir * 6, s.y - 16, 16);
      if (s.mode == CR::IDLE && t > 3) CR::leave(in.cr[0]);
      break;
    }
    case 38: {  // 調皮搶位
      float px, py;
      scene::plantPoint(0, 0.3f, px, py);
      px += 14;
      if (in.stage == 0) {
        float xs[2] = {px, px}, ys[2] = {py, py};
        groupLeg(in, fish::REST, xs, ys, 1.1f, 0.6f, 9);
      } else if (in.stage == 1) {
        if (enter(in)) {
          go(in, 0, fish::FAST, px - 50, py - 16, fish::info(FF(in, 0).sp).fast * 0.7f);
          go(in, 1, fish::FAST, px + 50, py + 10, fish::info(FF(in, 1).sp).fast * 0.7f);
          P::bubbles(px, py - 4, 3, 2);
        }
        if (in.st > 3) in.done = true;
      }
      break;
    }
    case 40: {  // 新朋友聚集
      if (in.stage == 0) {
        float xs[8], ys[8];
        for (int k = 0; k < in.nFish; k++) { float a = k * 2.4f; xs[k] = 120 + cosf(a) * (22 + k * 5); ys[k] = 100 + sinf(a) * (14 + k * 3); }
        groupLeg(in, fish::SCHOOL, xs, ys, 1.1f, 3.0f, 8);
      } else in.done = true;
      break;
    }
    // ---------- C. 餵食與覓食 ----------
    case 41:
      if (t > 3 && P::count(P::FOOD) == 0) in.done = true;
      break;
    case 42: {
      fish::Fish& f = FF(in, 0);
      if (f.st != fish::EAT) go(in, 0, fish::EAT, f.x, f.y, spdOf(in, 0) * 1.6f);
      if (f.lastAte && (f.lastAte & 0xFFFFFF) >= (uint32_t)in.v[0] && t > 1) { in.done = in.st > 2; }
      if (P::count(P::FOOD) == 0 && t > 2) in.done = true;
      break;
    }
    case 43: {  // 錯過食物
      if (in.k[0] < 0) { in.done = true; break; }
      P::P& p = P::at(in.k[0]);
      fish::Fish& f = FF(in, 0);
      if (in.stage == 0) {
        if (!p.on || p.type != P::FOOD) { in.done = true; break; }
        go(in, 0, fish::SWIM, p.x - f.dir * 6, p.y, spdOf(in, 0) * 1.4f);
        if (fabsf(fish::mouthX(in.fish[0]) - p.x) < 12 && fabsf(f.y - p.y) < 10 && t > 1.5f) {
          p.y += 16;  // 被水流帶走，往下沉
          p.x += f.dir * 10;
          P::bubbles(p.x, p.y, 2, 2);
          next(in);
        }
      } else if (in.stage == 1) {
        if (enter(in)) { go(in, 0, fish::IDLE, f.x - f.dir * 8, f.y, 3); f.dir = -f.dir; f.backward = true; }
        if (in.st > 2.5f) { f.backward = false; in.done = true; }
      }
      break;
    }
    case 44: {  // 蝦子搶食
      if (in.k[0] < 0 || !crOk(in, 0)) { in.done = t > 3; break; }
      P::P& p = P::at(in.k[0]);
      CR::C& s = CC(in, 0);
      const bool foodOk = p.on && p.type == P::FOOD;
      if (in.stage == 0) {
        if (in.nFish > 0) go(in, 0, fish::SWIM, p.x + 30, p.y - 10, spdOf(in, 0) * 0.5f);
        if (!foodOk) { next(in); break; }
        if (p.flags & P::F_LANDED) { s.alphaT = 1; CR::walkTo(in.cr[0], p.x, 14); next(in); }
      } else if (in.stage == 1) {
        if (foodOk && fabsf(s.x - p.x) < 3) {
          p.on = false;
          s.carry = true;
          CR::walkTo(in.cr[0], 50, 10);
          next(in);
        } else if (!foodOk) next(in);
        if (in.nFish > 0) go(in, 0, fish::EAT, p.x, p.y - 6, spdOf(in, 0) * 0.5f);
      } else if (in.stage == 2) {
        if (in.nFish > 0 && enter(in)) go(in, 0, fish::IDLE, FF(in, 0).x, FF(in, 0).y, 2);
        if (in.st > 6) CR::leave(in.cr[0]);
      }
      break;
    }
    case 45: {  // 蝸牛清理殘渣
      emergeLayer(in, 0);
      if (!crOk(in, 0)) break;
      CR::C& s = CC(in, 0);
      int d = scene::nearestDebris(s.x);
      if (t > in.dur - 6 || d < 0) { if (s.mode != CR::LEAVE) CR::leave(in.cr[0]); break; }
      float dx = scene::debrisX(d);
      if (s.mode == CR::IDLE || fabsf(s.tx - dx) > 1) CR::walkTo(in.cr[0], dx, 5);
      if (fabsf(s.x - dx) < 3) { scene::removeDebrisNear(dx, 5); spark(dx, s.y - 4, 2, 0xd8fff0); }
      break;
    }
    case 46: {  // 啃食藻類
      fish::Fish& f = FF(in, 0);
      const float side = in.v[0] < 120 ? 1 : -1;
      if (in.stage == 0) leg(in, 0, fish::EAT, in.v[0] + side * (fish::halfW(in.fish[0]) + 2), in.v[1] - 4, spdOf(in, 0), 0.1f, 8);
      else {
        f.dir = side > 0 ? -1 : 1;
        f.backward = true;
        f.wiggle = (((int)(in.st * 3)) & 1) ? 0.6f : 0;
        if (every(in, 0.5f, dt)) P::spawn(P::CRUMB, in.v[0], in.v[1], rng.range(-6, 6), 0, 0.8f, 1, 0x58a83a);
        if (in.st > 6) in.done = true;
      }
      break;
    }
    case 48: {  // 吃飽休息
      float px, py;
      scene::plantPoint(in.k[0], 0.2f, px, py);
      if (in.stage == 0) leg(in, 0, fish::REST, px + 12, py, spdOf(in, 0) * 0.7f, 0.1f, 8);
      else { FF(in, 0).tailBoost = -0.5f; FF(in, 0).energy = fminf(1, FF(in, 0).energy + dt * 0.02f); }
      break;
    }
    case 49: {  // 尋找食物
      float x = 0, y = 0;
      if (in.stage == 0) { scene::plantPoint(2, 0.1f, x, y); x += 14; }
      else if (in.stage == 1) { x = scene::ROCK_L.cx + 20; y = scene::ROCK_L.cy - scene::ROCK_L.ry - 6; }
      else if (in.stage == 2) { x = scene::SHELL_X + 10; y = bottomY(x); }
      else { in.done = true; break; }
      leg(in, 0, fish::INSPECT, x, y, spdOf(in, 0), 1.3f, 8, 9);
      break;
    }
    case 50: {  // 餵食後歡騰
      for (int k = 0; k < in.nFish; k++) {
        fish::Fish& f = FF(in, k);
        if (atPos(in, k, f.tx, f.ty, 10) || f.st != fish::FAST) {
          float x = util::clamp(f.x + rng.range(-70, 70), 20.0f, 220.0f);
          go(in, k, fish::FAST, x, util::clamp(f.y + rng.range(-40, 40), 40.0f, 170.0f), fish::info(f.sp).fast * 0.8f);
        }
        f.wiggle = 0.6f;
      }
      if (every(in, 0.5f, dt)) { int k = rng.irange(0, in.nFish - 1); spark(FF(in, k).x, FF(in, k).y, 2); }
      break;
    }
    case 51:
      break;  // 微生物粒子自己移動
    case 52: {  // 浮游生物漂過
      float cx = 0, cy = 0;
      int c = 0;
      for (int i = 0; i < P::cap(); i++) { const P::P& p = P::at(i); if (p.on && p.type == P::PLANKTON) { cx += p.x; cy += p.y; c++; } }
      if (c == 0) { in.done = t > 3; break; }
      cx /= c; cy /= c;
      for (int k = 0; k < in.nFish; k++) {
        go(in, k, fish::EAT, cx + k * 10, cy + (k ? 8 : -6), spdOf(in, k) * 1.2f);
        for (int i = 0; i < P::cap(); i++) {
          P::P& p = P::at(i);
          if (p.on && p.type == P::PLANKTON && fabsf(fish::mouthX(in.fish[k]) - p.x) < 5 && fabsf(FF(in, k).y - p.y) < 5) p.on = false;
        }
      }
      break;
    }
    case 53: {  // 藻類微量生長
      const int before = scene::algaeVisible();
      env::eco.algae = fminf(fminf(0.6f, in.v[0] + 0.12f), env::eco.algae + dt * 0.01f);
      if (scene::algaeVisible() > before) { float x, y; scene::algaePoint(scene::algaeVisible() - 1, x, y); spark(x, y, 3, 0x9af070); }
      break;
    }
    case 54: {  // 生態清潔完成
      for (int k = 0; k < in.nCr; k++) {
        emergeLayer(in, k);
        if (!crOk(in, k)) continue;
        CR::C& c = CC(in, k);
        if (c.mode == CR::LEAVE) continue;
        int d = scene::nearestDebris(c.x);
        float target = d >= 0 ? scene::debrisX(d) : (k == 0 ? 170 : 110);
        if (fabsf(c.tx - target) > 1) CR::walkTo(in.cr[k], target, c.type == CR::SNAIL ? 5 : 11);
        if (d >= 0 && fabsf(c.x - target) < 3) scene::removeDebrisNear(target, 5);
      }
      env::eco.algae = fmaxf(0.08f, env::eco.algae - dt * 0.01f);
      if (in.stage == 0 && t > in.dur - 6) {
        next(in);
        for (int i = 0; i < 24; i++) P::spawn(P::SPARK, rng.range(10, 230), rng.range(30, 190), 0, -2, rng.range(0.8f, 1.6f), 1, 0xe8ffff);
        fx.murkT = 0;
        env::eco.clarity = 1;
        for (int k = 0; k < in.nCr; k++) if (crOk(in, k)) CR::leave(in.cr[k]);
      }
      break;
    }
    case 55: {  // 食物搜尋結束
      if (in.stage == 0) {
        if (enter(in) || every(in, 1.5f, dt))
          for (int k = 0; k < in.nFish; k++) go(in, k, fish::INSPECT, rng.range(30, 210), rng.range(60, 170), spdOf(in, k));
        if (in.st > 5) next(in);
      } else if (in.stage == 1) {
        if (enter(in)) for (int k = 0; k < in.nFish; k++) go(in, k, fish::SWIM, rng.range(30, 210), rng.range(50, 150), spdOf(in, k) * 0.6f);
        if (in.st > 4) in.done = true;
      }
      break;
    }
    // ---------- D. 環境 ----------
    case 56: break;
    case 57:  // 氣泡柱
      if (every(in, 0.14f, dt) && t < in.dur - 2)
        P::spawn(P::BUBBLE, in.v[0] + rng.range(-2, 2), scene::sandTop((int)in.v[0]) - 2, 0, -rng.range(22, 30), 12, (uint8_t)rng.irange(1, 2));
      break;
    case 58:  // 水面漣漪
      if (every(in, 1.1f, dt) && t < in.dur - 1) scene::addRipple(rng.range(30, 210), rng.range(0.5f, 1.2f));
      break;
    case 59: if (t > in.dur - 6) fx.beamsT = 0; break;
    case 60: {  // 巨大陰影經過
      fx.shadowX = -110 + 460 * (t / in.dur);
      if (in.stage == 0 && fx.shadowX > 40) { fish::startle(fx.shadowX + 40, 60, 110); next(in); }
      if (in.stage == 1 && fx.shadowX > 150) { fish::startle(fx.shadowX + 40, 60, 110); next(in); }
      break;
    }
    case 61: fx.swayT = 2.6f; fx.currentT = sinf(t * 0.7f) * 8; if (t > in.dur - 3) { fx.swayT = 1; fx.currentT = 0; } break;
    case 62: break;
    case 63: {
      if (t < 6 && every(in, 0.8f, dt)) { float x, y; scene::plantPoint(in.k[0], 0.9f, x, y); spark(x, y, 2, 0xb8ff90); }
      break;
    }
    case 64: {
      if (in.stage == 0 && t > 6) { float x, y; scene::plantPoint(fx.flowerPlant, 1, x, y); fish::attract(x, y + 10, 2); next(in); }
      if (t > in.dur - 8) fx.flowerT = 0;
      break;
    }
    case 65: case 66: break;
    case 67: fx.currentT = t < in.dur - 3 ? in.v[0] : 0; break;
    case 68: fx.shimmerT = t < in.dur - 2 ? 1 : 0; break;
    case 69: fx.causticsT = t < in.dur - 3 ? 1 : 0; break;
    case 70: fx.murkT = t < in.dur * 0.3f ? 0.75f : 0; break;
    case 71: break;
    case 72: { const bool on = t < in.dur - 10; fx.moonT = on; fx.shimmerT = on ? 0.4f : 0; fx.beamsT = on ? 0.35f : 0; break; }
    case 73: { fx.sunriseT = t < in.dur * 0.6f ? 1 : 0; fx.beamsT = t < in.dur - 5 ? 0.7f : 0; break; }
    case 74: { fx.sunsetT = t < in.dur * 0.7f ? 1 : 0; fx.beamsT = t < in.dur - 6 ? 0.3f : 0; break; }
    case 75: fx.biolumT = t < in.dur - 5 ? 1 : 0; break;
    // ---------- E. 訪客 ----------
    case 76: {  // 蝸牛現身
      emergeLayer(in, 0);
      if (crOk(in, 0) && t > in.dur - 9 && CC(in, 0).mode != CR::LEAVE) CR::leave(in.cr[0]);
      break;
    }
    case 77: {  // 蝸牛爬玻璃
      if (!crOk(in, 0)) break;
      CR::C& s = CC(in, 0);
      if (in.stage == 0 && s.mode == CR::IDLE && t > 1) { s.mode = CR::CLIMB; s.climbSide = 1; s.ty = 96; s.spd = 5; next(in); }
      else if (in.stage == 1 && fabsf(s.y - s.ty) < 1) { if (in.st > 1) { s.ty = CR::groundY(CR::SNAIL, 230) - 4; next(in); } }
      else if (in.stage == 2 && fabsf(s.y - s.ty) < 1) { s.mode = CR::IDLE; s.x = 226; CR::leave(in.cr[0]); next(in); }
      break;
    }
    case 78: {  // 蝦子現身
      if (crOk(in, 0) && every(in, 4.0f, dt) && t < in.dur - 6) CR::walkTo(in.cr[0], rng.range(70, 200), 12);
      if (crOk(in, 0) && t > in.dur - 6 && CC(in, 0).mode != CR::LEAVE) CR::leave(in.cr[0]);
      break;
    }
    case 79: {  // 蝦子脫殼
      if (!crOk(in, 0)) break;
      CR::C& s = CC(in, 0);
      if (in.stage == 0 && s.mode == CR::IDLE) next(in);
      else if (in.stage == 1) {
        s.hop += dt * 6;  // 原地抖動
        if (in.st > 3) {
          int m = spawnCr(in, CR::MOLT, s.x, 0, s.dir);
          if (m >= 0) CC(in, m).alpha = 1;
          CR::walkTo(in.cr[0], 214, 16);
          next(in);
        }
      } else if (in.stage == 2 && t > in.dur - 7) { CR::leave(in.cr[0]); next(in); }
      break;
    }
    case 80: if (crOk(in, 0) && CC(in, 0).mode == CR::IDLE) CR::leave(in.cr[0]); break;
    case 81: {  // 清潔魚
      if (!crOk(in, 0)) break;
      CR::C& c = CC(in, 0);
      if (in.stage == 0 && fabsf(c.x - 18) < 4) next(in);
      else if (in.stage == 1) {
        if (every(in, 5.0f, dt)) { in.k[0] = !in.k[0]; CR::swimTo(in.cr[0], 16, in.k[0] ? 60 : 150, 9); }
        if (t > in.dur - 6) { c.dir = -1; CR::leave(in.cr[0]); c.tx = -50; next(in); }
      }
      break;
    }
    case 82: case 84: case 87: case 99: break;  // 生成時就設定好路線
    case 83: {  // 黃金魚
      if (!crOk(in, 0)) break;
      CR::C& c = CC(in, 0);
      if (every(in, 0.7f, dt)) spark(c.x + rng.range(-8, 8), c.y + rng.range(-6, 6), 2, 0xffe080);
      if (in.stage == 0 && fabsf(c.x - 120) < 4) next(in);
      if (in.stage == 1 && in.st > 5) { CR::leave(in.cr[0]); next(in); }
      break;
    }
    case 85: if (crOk(in, 0) && t > in.dur - 6 && CC(in, 0).mode != CR::LEAVE) { CC(in, 0).dir = 1; CR::leave(in.cr[0]); } break;
    case 86: {  // 泡泡蝸牛
      if (!crOk(in, 0)) break;
      CR::C& s = CC(in, 0);
      if (s.mode == CR::IDLE && t < in.dur - 5 && every(in, 0.4f, dt)) P::spawn(P::BUBBLE, s.x + 4, s.y - 8, 0, -16, 10, (uint8_t)rng.irange(1, 2));
      if (t > in.dur - 5 && s.mode != CR::LEAVE) CR::leave(in.cr[0]);
      break;
    }
    case 88: {  // 藏在水草後的魚
      float px, py;
      scene::plantPoint(1, 0.35f, px, py);
      fish::Fish& f = FF(in, 0);
      if (in.stage == 0) leg(in, 0, fish::HIDE, px, py, spdOf(in, 0), 2.5f, 6, 10);
      else if (in.stage == 1 || in.stage == 2) {
        float peek = in.st < 0.9f ? -16 : 0;  // 探頭再縮回
        if (enter(in)) f.backward = false;
        go(in, 0, fish::HIDE, px + peek, py, spdOf(in, 0));
        if (in.st > 2.0f) next(in);
      } else if (in.stage == 3) {
        if (enter(in)) { spark(f.x, f.y, 8); go(in, 0, fish::SWIM, px - 50, py - 30, spdOf(in, 0) * 1.2f); }
        if (in.st > 3) in.done = true;
      }
      break;
    }
    case 89: {  // 淡水蟹
      emergeLayer(in, 0);
      if (!crOk(in, 0)) break;
      CR::C& c = CC(in, 0);
      if (in.stage == 0 && c.mode == CR::IDLE) next(in);
      else if (in.stage == 1) {
        if (every(in, 0.8f, dt)) P::spawn(P::BUBBLE, c.x, c.y - 8, 0, -14, 8, 1);
        if (in.st > 6) { CR::leave(in.cr[0]); next(in); }
      }
      break;
    }
    case 90: {  // 稀有魚鱗反光
      fish::Fish& f = FF(in, 0);
      if (enter(in)) go(in, 0, fish::SWIM, in.v[0], f.y, spdOf(in, 0) * 0.8f);
      if ((t > 0.8f && in.k[0] == 0) || (t > 4.0f && in.k[0] == 1)) { f.glint = 0; in.k[0]++; }
      if (f.glint >= 0 && every(in, 0.25f, dt)) spark(f.x + rng.range(-8, 8), f.y + rng.range(-5, 5), 1, 0xe8f8ff);
      break;
    }
    // ---------- F. 稀有 ----------
    case 91: if (t > in.dur - 4) { fx.rainbowT = 0; fx.shimmerT = 0; } break;
    case 92:
      if (in.k[0] < 5 && every(in, 2.0f, dt)) {
        float x = randX();
        P::spawn(P::CRYSTAL, x, scene::sandTop((int)x) - 6, 0, -rng.range(8, 11), 30, (uint8_t)rng.irange(1, 2));
        in.k[0]++;
      }
      break;
    case 93: {  // 神秘光點
      fx.orbX = util::clamp(fx.orbX + sinf(t * 0.6f) * 9 * dt, 30.0f, 210.0f);
      fx.orbY = util::clamp(fx.orbY - 2.5f * dt + cosf(t * 1.1f) * 3 * dt, 60.0f, 200.0f);
      if (every(in, 4.0f, dt) && t < in.dur - 4) fish::attract(fx.orbX, fx.orbY, 2);
      if (in.stage == 0 && t > in.dur - 3) { fx.orbT = 0; spark(fx.orbX, fx.orbY, 12, 0x80ffe0); next(in); }
      break;
    }
    case 94: {  // 沉睡古貝殼
      const bool open = t > 2.5f && t < in.dur - 4;
      fx.shellOpenT = open;
      if (open && every(in, 0.7f, dt)) P::spawn(P::BUBBLE, scene::SHELL_X + rng.range(-3, 3), scene::sandTop(scene::SHELL_X) - 8, 0, -15, 10, 1);
      if (in.stage == 0 && t > 4) { fish::attract(scene::SHELL_X, scene::sandTop(scene::SHELL_X) - 20, 2); next(in); }
      break;
    }
    case 95: {  // 珍珠
      fx.pearlT = t < in.dur - 4;
      if (every(in, 1.2f, dt) && t < in.dur - 4) spark(scene::PEARL_X + rng.range(-3, 3), scene::sandTop(scene::PEARL_X) - 4, 1, 0xffffff);
      if (in.stage == 0 && t > 3) { fish::attract(scene::PEARL_X + 10, scene::sandTop(scene::PEARL_X) - 18, 2); next(in); }
      break;
    }
    case 96: {  // 流星般的光影
      float p = t / in.dur;
      fx.meteorX = -30 + 300 * p;
      fx.meteorY = 24 + 40 * p;
      break;
    }
    case 97: fx.starsT = t < in.dur - 6; break;
    case 98: { const bool on = t < in.dur - 6; fx.mysticT = on; fx.swayT = on ? 1.6f : 1; break; }
    case 100: {  // 深海寶藏
      const float sx = scene::CHEST_X, sy = scene::sandTop(scene::CHEST_X);
      if (t < 3) { if (every(in, 0.3f, dt)) spark(sx + rng.range(-12, 12), sy - 2, 1, 0xffe890); }
      else if (t < 12) { if (in.stage == 0) { P::burst(P::DUST, sx, sy - 2, 12, 18, 3); next(in); } fx.chestUpT = 1; }
      else if (t < 19) {
        if (in.stage == 1) { fish::attract(sx, sy - 24, 3); next(in); }
        fx.chestOpenT = 1;
        if (every(in, 0.35f, dt)) spark(sx + rng.range(-10, 10), sy - 16 - rng.range(0, 10), 2, 0xfff0a0);
      } else if (t < 21) fx.chestOpenT = 0;
      else {
        if (in.stage == 2) { P::burst(P::DUST, sx, sy - 4, 18, 20, 3.5f); next(in); }
        fx.chestUpT = 0;
      }
      break;
    }
    default: if (in.id >= BIG_FIRST) bigUpdate(in, dt); break;
  }
}

// ================================================================ END
void fxEnd(Inst& in) {
  env::Fx& fx = env::fx;
  // 共同：放回借來的魚、讓訪客離開
  for (int k = 0; k < in.nFish; k++) if (in.fish[k] >= 0 && F[in.fish[k]].owner == in.owner) fish::release(in.fish[k]);
  CR::leaveOwner(in.owner);
  switch (in.id) {
    case 59: fx.beamsT = 0; break;
    case 60: fx.shadowX = -999; break;
    case 61: fx.swayT = 1; fx.currentT = 0; break;
    case 64: fx.flowerT = 0; break;
    case 67: fx.currentT = 0; break;
    case 68: fx.shimmerT = 0; break;
    case 69: fx.causticsT = 0; break;
    case 70: fx.murkT = 0; break;
    case 72: fx.moonT = 0; fx.shimmerT = 0; fx.beamsT = 0; break;
    case 73: fx.sunriseT = 0; fx.beamsT = 0; break;
    case 74: fx.sunsetT = 0; fx.beamsT = 0; break;
    case 75: fx.biolumT = 0; break;
    case 91: fx.rainbowT = 0; fx.shimmerT = 0; break;
    case 93: fx.orbT = 0; break;
    case 94: fx.shellOpenT = 0; break;
    case 95: fx.pearlT = 0; break;
    case 96: fx.meteorX = -999; break;
    case 97: fx.starsT = 0; break;
    case 98: fx.mysticT = 0; fx.swayT = 1; break;
    case 100: fx.chestOpenT = 0; fx.chestUpT = 0; break;
    case 48: break;
    default: if (in.id >= BIG_FIRST) bigEnd(in); break;
  }
}

}  // namespace ev
