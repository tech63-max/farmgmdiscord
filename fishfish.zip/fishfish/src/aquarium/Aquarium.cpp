#include "Aquarium.h"
#include <Arduino.h>
#include "../core/Util.h"
#include "../events/EventManager.h"
#include "../gfx/Gfx.h"
#include "Creatures.h"
#include "Environment.h"
#include "Fish.h"
#include "ParticleSystem.h"
#include "Remains.h"
#include "Scene.h"

namespace aquarium {

void begin() {
  scene::begin();
  particles::begin();
  creatures::begin();
  remains::begin();
  fish::begin();
}

void updateAi(float dt, uint32_t ms) {
  fish::update(dt, ms);
  creatures::update(dt);
  particles::update(dt);
  remains::update(dt);
}

void updateFrame(float dt, uint32_t ms) {
  uint32_t t0 = micros();
  env::update(dt);
  if (env::phaseChanged()) ev::onPhase(env::phase(), ms);
  scene::update(dt);
  ev::update(dt, ms);
  env::fx.bloodT = gore::blood() ? util::clamp01(particles::bloodAmount() / 70.0f) : 0;
  // 平常偶爾冒一顆小泡泡、漂一點微粒 (不是事件，讓畫面一直有生氣)
  if (util::rng.chance(dt * 0.25f)) particles::bubbles(util::rng.range(20, 220), scene::sandTop(120) - 2, 1, 2);
  if (util::rng.chance(dt * 0.3f))
    particles::spawn(particles::MOTE, util::rng.range(5, 235), util::rng.range(30, 190), util::rng.range(-2, 2), 0, 14);
  prof[9] = micros() - t0;
}

uint32_t prof[PROF_N];

void render() {
  uint32_t t = micros();
  auto mark = [&](int i) { uint32_t n = micros(); prof[i] = n - t; t = n; };
  gfx::blitBg(); mark(0);
  scene::drawBackFx(); mark(1);
  creatures::draw(0);       // 背景訪客 (被岩石/水草擋住)
  fish::draw(0);            // 躲在後面的魚
  scene::drawPlants(false); // 後景水草
  mark(2);
  scene::drawDecor(); mark(3);
  creatures::draw(1);
  fish::draw(1); mark(4);
  scene::drawPlants(true);  // 前景水草 (魚可以躲在後面)
  particles::draw(); mark(5);
  scene::drawSurface(); mark(6);
  gfx::applyGrade(); mark(7);  // 日夜/特殊光色
  // 血腥的東西在分級之後畫：夜晚背光變暗時也看得清楚
  remains::drawGround();
  remains::draw();
  particles::drawGore();
  scene::drawGlow();        // 發光的東西在分級之後加上去，夜晚也看得到
  creatures::drawGlow();
  particles::drawGlow(); mark(8);
}

void feed(uint32_t ms) { ev::onFeed(ms); }

void tap(uint32_t ms) {
  // 敲玻璃：附近的魚游到前面看，河豚會鼓起來
  fish::attract(120, 110, 4);
  for (int i = 0; i < fish::count(); i++)
    if (fish::F[i].on && fish::F[i].sp == fish::PUFFER && !fish::F[i].owner) { fish::F[i].inflate = 3; fish::F[i].inflateMax = 3; }
  ev::trigger(14, ms, false);
}

void air(uint32_t ms) { ev::trigger(57, ms, true, true); }

}  // namespace aquarium
