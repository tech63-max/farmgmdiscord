#include "ParticleSystem.h"
#include <math.h>
#include <string.h>
#include "../config/AquariumConfig.h"
#include "../core/Util.h"
#include "../gfx/Gfx.h"
#include "../gfx/SpriteData.h"
#include "Environment.h"
#include "Remains.h"
#include "Scene.h"

namespace particles {
namespace {
P pool[acfg::PARTICLE_CAP];
float t = 0;
using util::rng;

bool passive(uint8_t type) { return type != STAR && type != SPLASH && type != MICRO; }
}  // namespace

void begin() { memset(pool, 0, sizeof(pool)); }
P& at(int i) { return pool[i]; }
int cap() { return acfg::PARTICLE_CAP; }

int spawn(Type type, float x, float y, float vx, float vy, float life, uint8_t size, uint32_t color) {
  for (int i = 0; i < acfg::PARTICLE_CAP; i++) {
    P& p = pool[i];
    if (p.on) continue;
    p = {};
    p.on = true;
    p.type = type;
    p.x = x; p.y = y; p.vx = vx; p.vy = vy;
    p.life = p.maxLife = life;
    p.size = size;
    p.color = color;
    p.phase = rng.range(0, 6.28f);
    if (type == STAR || type == GLOWDOT) p.flags |= F_GLOW;
    return i;
  }
  return -1;  // 池子滿了就不產生 (限制同時粒子數)
}

void bubbles(float x, float y, int n, float spread) {
  for (int i = 0; i < n; i++)
    spawn(BUBBLE, x + rng.range(-spread, spread), y + rng.range(0, 4) + i * 3, 0, -rng.range(16, 28), 12, (uint8_t)rng.irange(1, 2));
}

void burst(Type type, float x, float y, int n, float speed, float life, uint32_t color) {
  for (int i = 0; i < n; i++) {
    float a = rng.range(0, 6.28f), s = rng.range(0.3f, 1.0f) * speed;
    spawn(type, x, y, util::fcos(a) * s, util::fsin(a) * s - (type == DUST ? speed * 0.5f : 0), life * rng.range(0.7f, 1.2f), 1, color);
  }
}

int count(Type type) {
  int n = 0;
  for (auto& p : pool) if (p.on && p.type == type && !(p.flags & F_EATEN)) n++;
  return n;
}

void dropFood(float x, int n) {
  for (int i = 0; i < n; i++)
    spawn(FOOD, util::clamp(x + rng.range(-26, 26), 16.0f, 224.0f), scene::SURFACE_Y + rng.range(0, 3), 0, rng.range(1, 3), 40, 1,
          rng.chance(0.5f) ? 0xc8702a : 0xa85a20);
}

void blood(float x, float y, int n, float spread) {
  if (gore::blood()) {
    for (int i = 0; i < n; i++)
      spawn(BLOOD, x + rng.range(-spread, spread), y + rng.range(-spread, spread), rng.range(-10, 10), rng.range(-6, 3),
            rng.range(5, 10), (uint8_t)rng.irange(1, 2), rng.chance(0.6f) ? 0xe0121c : 0x9a0a12);
  } else if (gore::death()) {
    burst(SPARK, x, y, n > 4 ? 4 : n, 14, 0.5f, 0xff3030);
  }
}

void scales(float x, float y, int n) {
  if (!gore::death()) return;
  for (int i = 0; i < n; i++) spawn(SCALE, x, y, rng.range(-26, 26), rng.range(-26, 6), rng.range(2.5f, 4), 1);
}

int bloodAmount() { return count(BLOOD); }

void gib(float x, float y, int amount) {
  if (!gore::blood()) { blood(x, y, amount); return; }
  blood(x, y, amount, 6);
  // 噴濺：幾顆跑得比較遠的血
  for (int i = 0; i < amount / 3; i++) {
    float a = rng.range(0, 6.28f), s = rng.range(25, 55);
    spawn(BLOOD, x, y, util::fcos(a) * s, util::fsin(a) * s * 0.7f, rng.range(3, 6), 1, 0xff2a2a);
  }
  // 肉塊：沉到沙地上放一陣子
  for (int i = 0; i < 2 + amount / 6; i++)
    spawn(CHUNK, x + rng.range(-4, 4), y + rng.range(-3, 3), rng.range(-22, 22), rng.range(-18, 4), rng.range(25, 45),
          (uint8_t)rng.irange(1, 2), rng.chance(0.5f) ? 0xe85868 : 0xb82838);
  scales(x, y, 2 + amount / 8);
}

int nearestFood(float x, float y, float maxDist) {
  int best = -1;
  float bd = maxDist * maxDist;
  for (int i = 0; i < acfg::PARTICLE_CAP; i++) {
    const P& p = pool[i];
    if (!p.on || p.type != FOOD || (p.flags & F_EATEN)) continue;
    float dx = p.x - x, dy = p.y - y, d = dx * dx + dy * dy;
    if (d < bd) { bd = d; best = i; }
  }
  return best;
}

bool eatFood(int i) {
  if (i < 0 || i >= acfg::PARTICLE_CAP) return false;
  P& p = pool[i];
  if (!p.on || p.type != FOOD || (p.flags & F_EATEN)) return false;
  p.on = false;
  burst(CRUMB, p.x, p.y, 3, 10, 0.6f, 0xb06428);
  return true;
}

void update(float dt) {
  t += dt;
  const float cur = env::fx.current;
  for (auto& p : pool) {
    if (!p.on) continue;
    p.life -= dt;
    if (p.life <= 0) {
      if (p.type == FOOD && (p.flags & F_LANDED)) scene::addDebris(p.x);  // 沒吃掉的飼料變成殘渣
      p.on = false;
      continue;
    }
    p.phase += dt;
    const float drift = passive(p.type) ? cur * 0.5f : 0;
    switch (p.type) {
      case BUBBLE:
      case CRYSTAL:
        p.x += (util::fsin(p.phase * 5) * (p.type == CRYSTAL ? 6 : 10) + drift) * dt;
        p.y += p.vy * dt;
        if (p.y <= scene::SURFACE_Y + 2) {
          if (p.size >= 2 || p.type == CRYSTAL) scene::addRipple(p.x, 0.2f);
          p.on = false;
        }
        break;
      case FOOD: {
        const int st = scene::sandTop((int)p.x);
        if (p.flags & F_LANDED) break;
        if (p.maxLife - p.life < 1.0f) { p.y += 2 * dt; break; }  // 先在水面漂一下
        p.x += (util::fsin(p.phase * 2.2f) * 4 + drift) * dt;
        p.y += 9 * dt;
        if (p.y >= st - 1) { p.y = st - 1; p.flags |= F_LANDED; p.life = fminf(p.life, 25); }
        break;
      }
      case LEAF: {
        const int st = scene::sandTop((int)p.x);
        if (p.flags & F_LANDED) break;
        if (p.maxLife - p.life < 3.0f) { p.x += (6 + drift) * dt; p.y = scene::SURFACE_Y + 1; break; }
        p.x += (util::fsin(p.phase * 1.6f) * 14 + drift) * dt;
        p.y += 7 * dt;
        if (p.y >= st - 2) { p.y = st - 2; p.flags |= F_LANDED; p.life = fminf(p.life, 18); }
        break;
      }
      case DUST:
        p.vx *= 1 - 1.5f * dt;
        p.vy = p.vy * (1 - 1.5f * dt) + 3 * dt;
        p.x += (p.vx + drift) * dt;
        p.y += p.vy * dt;
        break;
      case SPLASH:
        p.vy += 120 * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        if (p.vy > 0 && p.y > scene::SURFACE_Y) p.on = false;
        break;
      case CRUMB:
        p.vx *= 1 - 2 * dt;
        p.y += (p.vy + 12) * dt;
        p.x += p.vx * dt;
        break;
      case MICRO: {
        p.x += (util::fsin(p.phase * 3 + p.vx) * 8) * dt;
        p.y = scene::sandTop((int)p.x) + 1 + util::fsin(p.phase * 7) * 1.0f;
        break;
      }
      case STAR:
        break;
      case BLOOD:  // 血霧：慢慢擴散、往下沉、變淡
        p.vx *= 1 - 0.8f * dt;
        p.vy = p.vy * (1 - 0.8f * dt) + 2.5f * dt;
        p.x += (p.vx + drift + util::fsin(p.phase * 0.8f) * 2) * dt;
        p.y += p.vy * dt;
        if (p.size < 3 && p.maxLife - p.life > 1.5f * p.size) p.size++;  // 擴散成更大的方塊
        if (p.y >= scene::sandTop((int)p.x) - 2) {  // 沉到沙地 → 留下血跡
          if (rng.chance(0.3f)) remains::stain(p.x, 4);
          p.on = false;
        }
        break;
      case CHUNK: {
        const float st = scene::sandTop((int)p.x) - 2;
        if (p.flags & F_LANDED) break;
        p.vx *= 1 - 1.4f * dt;
        p.vy = util::approach(p.vy, 14, 30 * dt);
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        if (rng.chance(dt * 2) && gore::blood()) spawn(BLOOD, p.x, p.y, 0, 0, 2.5f, 1, 0x7a0a0e);  // 一路滴血
        if (p.y >= st) { p.y = st; p.flags |= F_LANDED; }
        break;
      }
      case SCALE:
        p.vx *= 1 - 1.5f * dt;
        p.vy += 22 * dt;
        p.x += p.vx * dt;
        p.y += p.vy * dt;
        break;
      default:  // 浮游、塵粒、發光點、閃光：隨水漂
        p.x += (p.vx + drift + util::fsin(p.phase * 0.9f) * 3) * dt;
        p.y += (p.vy + util::fcos(p.phase * 0.7f) * 2) * dt;
        break;
    }
    if (p.x < -10 || p.x > 250 || p.y > 245) p.on = false;
  }
  env::eco.food = util::clamp01(count(FOOD) / 10.0f);
}

void draw() {
  for (auto& p : pool) {
    if (!p.on || (p.flags & F_GLOW) || p.type == BLOOD || p.type == CHUNK) continue;
    const float fade = util::clamp01(p.life / (p.maxLife * 0.3f));
    const int x = (int)p.x, y = (int)p.y;
    switch (p.type) {
      case BUBBLE: {
        // 方塊氣泡：方形外框 + 左上亮點，位置對齊 2px
        const int bx = x & ~1, by = y & ~1, sz = p.size >= 2 ? 6 : 4;
        const uint16_t edge = gfx::rgb(0xd0f4ff);
        gfx::blendRect(bx, by, sz, 2, edge, 210);
        gfx::blendRect(bx, by + sz - 2, sz, 2, edge, 210);
        gfx::blendRect(bx, by + 2, 2, sz - 4, edge, 210);
        gfx::blendRect(bx + sz - 2, by + 2, 2, sz - 4, edge, 210);
        if (sz > 4) gfx::blendRect(bx + 2, by + 2, 2, 2, gfx::rgb(0xffffff), 255);
        else gfx::pset(bx, by, gfx::rgb(0xffffff));
        break;
      }
      case CRYSTAL: {
        // 水晶泡泡：大方塊泡泡，四角輪流換彩虹色
        const int bx = x & ~1, by = y & ~1, sz = 8 + p.size * 2;
        const uint32_t RB[] = {0xff8080, 0xfff080, 0x80ff9a, 0x80c8ff, 0xd090ff};
        const int k0 = (int)(p.phase * 3);
        gfx::blendRect(bx, by, sz, sz, gfx::rgb(0xe8fcff), 50);
        gfx::blendRect(bx, by, sz, 2, gfx::rgb(0xffffff), 170);
        gfx::blendRect(bx, by + sz - 2, sz, 2, gfx::rgb(0xffffff), 170);
        gfx::blendRect(bx, by, 2, sz, gfx::rgb(0xffffff), 170);
        gfx::blendRect(bx + sz - 2, by, 2, sz, gfx::rgb(0xffffff), 170);
        gfx::block(bx, by, gfx::rgb(RB[k0 % 5]));
        gfx::block(bx + sz - 2, by, gfx::rgb(RB[(k0 + 1) % 5]));
        gfx::block(bx + sz - 2, by + sz - 2, gfx::rgb(RB[(k0 + 2) % 5]));
        gfx::block(bx, by + sz - 2, gfx::rgb(RB[(k0 + 3) % 5]));
        break;
      }
      case FOOD:
        gfx::block(x, y, gfx::rgb(p.color));
        break;
      case CRUMB:
        gfx::blockBlend(x, y, gfx::rgb(p.color), (uint8_t)(255 * fade));
        break;
      case LEAF: {
        gfx::SprOpt o;
        o.xs = util::fsin(p.phase * 1.6f) > 0 ? 1 : -1;
        o.alpha = (uint8_t)(255 * fade);
        gfx::sprite(spr::leaf, p.x, p.y, o);
        break;
      }
      case DUST:
        gfx::blockBlend(x, y, gfx::rgb(p.color ? p.color : 0xd8c49a), (uint8_t)(170 * fade));
        break;
      case SPLASH:
        gfx::block(x, y, gfx::rgb(0xd8f4ff));
        break;
      case SPARK: {
        // 方塊十字閃光：亮/暗兩格交替
        const uint8_t a = (uint8_t)(255 * fade);
        const uint16_t c = gfx::rgb(p.color ? p.color : 0xffffff);
        gfx::blockBlend(x, y, c, a);
        if (p.size > 1 || ((int)(p.phase * 8) & 1)) {
          gfx::blockBlend(x - 2, y, c, a / 2); gfx::blockBlend(x + 2, y, c, a / 2);
          gfx::blockBlend(x, y - 2, c, a / 2); gfx::blockBlend(x, y + 2, c, a / 2);
        }
        break;
      }
      case PLANKTON:
        gfx::blockBlend(x, y, gfx::rgb(p.color ? p.color : 0xb8e8a0), (uint8_t)(200 * fade));
        break;
      case BLOOD: {
        // 方塊血霧：越老越大、越淡 (2/4/6 px 方塊)
        const int s = p.size * 2;
        const float age = util::clamp01(p.life / p.maxLife);
        gfx::blendRect(x & ~1, y & ~1, s, s, gfx::rgb(p.color), (uint8_t)(200 * age * fade + 20 * fade));
        break;
      }
      case CHUNK: {
        const int s = p.size * 2;
        gfx::blendRect(x & ~1, y & ~1, s, s, gfx::rgb(p.color), (uint8_t)(255 * fade));
        if (s > 2) gfx::blendRect(x & ~1, y & ~1, 2, 2, gfx::rgb(0xf0a0a8), (uint8_t)(200 * fade));  // 亮面
        break;
      }
      case SCALE: {
        const uint16_t c = gfx::rgb(((int)(p.phase * 6) & 1) ? 0xd8d0c0 : 0x9a9488);
        gfx::blockBlend(x, y, c, (uint8_t)(255 * fade));
        break;
      }
      case MOTE:
        gfx::blockBlend(x, y, gfx::rgb(0xe0f0f0), (uint8_t)(90 * fade));
        break;
      case MICRO:
        gfx::pset(x, y, gfx::rgb(0xf0e8d0));
        gfx::pset(x + 1, y, gfx::rgb(0xb8a888));
        break;
      default: break;
    }
  }
}

void drawGore() {
  for (auto& p : pool) {
    if (!p.on || (p.type != BLOOD && p.type != CHUNK)) continue;
    const float fade = util::clamp01(p.life / (p.maxLife * 0.3f));
    const int x = (int)p.x, y = (int)p.y;
    if (p.type == BLOOD) {
      const int s = p.size * 2;
      const float age = util::clamp01(p.life / p.maxLife);
      gfx::blendRect(x & ~1, y & ~1, s, s, gfx::rgb(p.color), (uint8_t)(215 * age * fade + 25 * fade));
    } else {
      const int s = p.size * 2;
      gfx::blendRect(x & ~1, y & ~1, s, s, gfx::rgb(p.color), (uint8_t)(255 * fade));
      if (s > 2) gfx::blendRect(x & ~1, y & ~1, 2, 2, gfx::rgb(0xffb0b8), (uint8_t)(220 * fade));
    }
  }
}

void drawGlow() {
  for (auto& p : pool) {
    if (!p.on || !(p.flags & F_GLOW)) continue;
    const float fade = util::clamp01(p.life / (p.maxLife * 0.3f)) * util::clamp01((p.maxLife - p.life) / 1.0f);
    const float tw = 0.5f + 0.5f * util::fsin(p.phase * (p.type == STAR ? 3.3f : 2.0f));
    const uint32_t c = p.color ? p.color : (p.type == STAR ? 0xfff6d0 : 0x60ffd0);
    const int x = (int)p.x, y = (int)p.y;
    gfx::glow(x, y, p.size + 2, c, (uint8_t)(200 * fade * tw));
    if (tw > 0.6f) gfx::padd(x, y, (int)(120 * fade), (int)(120 * fade), (int)(120 * fade));
  }
}

}  // namespace particles
