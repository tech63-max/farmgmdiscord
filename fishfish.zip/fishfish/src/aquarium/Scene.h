// 水族箱場景：幾何、靜態背景烘焙、水草、岩石、裝飾、水面
#pragma once
#include <stdint.h>

namespace scene {

constexpr int SURFACE_Y = 18;     // 水面 (螢幕座標)
constexpr int SWIM_TOP = 30;
constexpr int SWIM_LEFT = 12, SWIM_RIGHT = 228;
int sandTop(int x);               // 沙地表面高度
inline int swimBottom(int x) { return sandTop(x) - 10; }

// 岩石 (左大右小)、可以繞過/躲藏
struct Rock { int16_t cx, cy, rx, ry; };
constexpr Rock ROCK_L = {42, 192, 36, 30};
constexpr Rock ROCK_R = {188, 202, 22, 16};
// 固定裝飾位置
constexpr int SHELL_X = 140, CHEST_X = 104, PEARL_X = 82;

// RIBBON = 分段式海帶、FAN = 階梯狀高海草叢、GRASS = 矮海草、GLOWP = 小型發光植物
enum PlantType : uint8_t { RIBBON, FAN, GRASS, GLOWP };
struct Plant {
  int16_t x;
  uint8_t type, height, blades;
  bool front;          // true = 畫在魚前面 (可以躲在後面)
  uint8_t shade;       // 0/1 兩種綠色
  uint8_t extra;       // 長出的新葉數 (有上限)
  float grow;          // 新葉成長動畫 0..1
  float phase;
};
constexpr int PLANT_N = 8;
extern Plant plants[PLANT_N];

void begin();                    // 烘焙背景
void update(float dt);
void drawBackFx();               // 光束、陰影、光斑 (魚的後面)
void drawPlants(bool front);
void drawDecor();                // 貝殼、寶箱、珍珠、殘渣、藻類
void drawSurface();              // 水面線、漣漪、閃光、彩虹
void drawGlow();                 // 分級之後：發光的水草尖端、珍珠、神秘光點

// 水草上某高度 (0 = 根部, 1 = 頂端) 的位置 (含擺動)
void plantPoint(int i, float h, float& x, float& y);
int nearestPlant(float x, bool frontOnly);
bool growLeaf(int i);            // 回傳 false = 已達上限 (改成舊葉換新)

// 水面漣漪
void addRipple(float x, float strength);

// 底部殘渣 (吃剩的飼料)：會自然分解，蝸牛/蝦子會清掉
void addDebris(float x);
int debrisCount();
int nearestDebris(float x);
float debrisX(int i);
void removeDebrisNear(float x, float r);

// 岩石上的藻類點 (數量跟著 env::eco.algae)
int algaeVisible();
void algaePoint(int i, float& x, float& y);

}  // namespace scene
