// 訪客與小生物：蝸牛、蝦子、螃蟹、清潔魚、魚苗、稀有魚、大型魚影、蝦殼…
#pragma once
#include <stdint.h>

namespace creatures {

enum Type : uint8_t {
  SNAIL, SHRIMP, GHOST_SHRIMP, CRAB, CLEANER, FRY, GOLDFISH, BLUEFISH, RAREFISH, SHADOWFISH, MOLT, SHARK, TYPE_COUNT
};
enum Mode : uint8_t { WALK, SWIM, CLIMB, IDLE, LEAVE };

struct C {
  bool on;
  uint8_t type, owner, mode, layer;
  int8_t dir;
  float x, y, vx, vy;
  float tx, ty, spd;
  float t, phase, alpha, alphaT;
  float hop;           // 蝦子跳躍
  bool carry;          // 帶著食物
  bool glint;
  int8_t climbSide;    // 爬玻璃：-1 左邊、+1 右邊
  float life;          // > 0 = 時間到自動離開
  float bite;          // 鯊魚：> 0 = 張嘴咬的造型 (秒)
};

void begin();
void update(float dt);
void draw(uint8_t layer);
void drawGlow();
int spawn(Type type, float x, float y, int8_t dir, uint8_t owner);
int find(Type type);
int countType(Type type);
C& at(int i);
int cap();
void walkTo(int i, float x, float spd);
void swimTo(int i, float x, float y, float spd);
void leave(int i);
void leaveOwner(uint8_t owner);   // 事件結束：該事件帶來的生物自己離開
float groundY(uint8_t type, float x);
const char* name(uint8_t type);

}  // namespace creatures
