#include "Creatures.h"
#include <math.h>
#include <string.h>
#include "../config/AquariumConfig.h"
#include "../core/Util.h"
#include "../gfx/Gfx.h"
#include "../gfx/SpriteData.h"
#include "Scene.h"

namespace creatures {
namespace {
C pool[acfg::CREATURE_CAP];
using util::rng;

const SpriteDef* sprOf(uint8_t t) {
  switch (t) {
    case SNAIL: return &spr::snail;
    case SHRIMP: case GHOST_SHRIMP: case MOLT: return &spr::shrimp;
    case CRAB: return &spr::crab;
    case CLEANER: return &spr::cleaner;
    case FRY: return &spr::fry;
    case GOLDFISH: return &spr::goldfish;
    case BLUEFISH: return &spr::bluefish;
    case RAREFISH: return &spr::rarefish;
    case SHADOWFISH: return &spr::cod;
    case SHARK: return &spr::shark;
    default: return &spr::fry;
  }
}
bool walker(uint8_t t) { return t == SNAIL || t == SHRIMP || t == GHOST_SHRIMP || t == CRAB || t == MOLT; }

// 爬玻璃：圖旋轉 90°，腳貼著玻璃、頭朝上
void drawRotated(const SpriteDef& s, float cx, float cy, int side, uint8_t alpha) {
  const int px = 2;
  const int x0 = (int)cx - s.h * px / 2, y0 = (int)cy - s.w * px / 2;
  for (int v = 0; v < s.h; v++)
    for (int u = 0; u < s.w; u++) {
      uint8_t idx = s.px[v * s.w + u];
      if (!idx) continue;
      int sx = side < 0 ? (s.h - 1 - v) : v;
      int sy = s.w - 1 - u;
      const uint16_t c = gfx::rgb(s.pal[idx]);
      for (int a = 0; a < px; a++)
        for (int b = 0; b < px; b++) gfx::pblend(x0 + sx * px + a, y0 + sy * px + b, c, alpha);
    }
}
}  // namespace

const char* name(uint8_t t) {
  static const char* N[TYPE_COUNT] = {"蝸牛", "蝦子", "透明蝦", "淡水蟹", "清潔魚", "魚苗", "黃金魚", "藍光魚", "稀有魚", "大型魚影", "蝦殼", "鯊魚"};
  return t < TYPE_COUNT ? N[t] : "?";
}

void begin() { memset(pool, 0, sizeof(pool)); }
C& at(int i) { return pool[i]; }
int cap() { return acfg::CREATURE_CAP; }

float groundY(uint8_t type, float x) {
  const SpriteDef* s = sprOf(type);
  return scene::sandTop((int)x) - s->h + 1;
}

int spawn(Type type, float x, float y, int8_t dir, uint8_t owner) {
  for (int i = 0; i < acfg::CREATURE_CAP; i++) {
    C& c = pool[i];
    if (c.on) continue;
    c = {};
    c.on = true;
    c.type = type;
    c.owner = owner;
    c.dir = dir >= 0 ? 1 : -1;
    c.x = x;
    c.y = walker(type) ? groundY(type, x) : y;
    c.tx = c.x; c.ty = c.y;
    c.mode = walker(type) ? IDLE : SWIM;
    c.layer = 1;
    c.alpha = 0;
    c.alphaT = 1;
    c.phase = rng.range(0, 6.28f);
    c.spd = 10;
    if (type == SHADOWFISH) c.layer = 0;
    return i;
  }
  return -1;
}

int find(Type type) {
  for (int i = 0; i < acfg::CREATURE_CAP; i++) if (pool[i].on && pool[i].type == type && pool[i].mode != LEAVE) return i;
  return -1;
}
int countType(Type type) {
  int n = 0;
  for (auto& c : pool) n += c.on && c.type == type;
  return n;
}

void walkTo(int i, float x, float spd) {
  if (i < 0) return;
  C& c = pool[i];
  c.tx = util::clamp(x, 8.0f, 232.0f);
  c.spd = spd;
  c.mode = WALK;
}

void swimTo(int i, float x, float y, float spd) {
  if (i < 0) return;
  C& c = pool[i];
  c.tx = x; c.ty = y; c.spd = spd;
  c.mode = SWIM;
}

void leave(int i) {
  if (i < 0) return;
  C& c = pool[i];
  c.mode = LEAVE;
  c.owner = 0;
  if (c.type == SNAIL || c.type == CRAB) c.tx = scene::ROCK_L.cx;          // 回到岩石後面
  else if (c.type == SHRIMP || c.type == GHOST_SHRIMP) c.tx = scene::plants[1].x;  // 回到水草底下
  else if (c.type == MOLT) c.alphaT = 0;
  else c.tx = c.dir > 0 ? 290 : -50;
  if (walker(c.type)) c.alphaT = 0;
}

void leaveOwner(uint8_t owner) {
  for (int i = 0; i < acfg::CREATURE_CAP; i++) if (pool[i].on && pool[i].owner == owner) leave(i);
}

void update(float dt) {
  for (auto& c : pool) {
    if (!c.on) continue;
    c.t += dt;
    c.phase += dt;
    if (c.bite > 0) c.bite -= dt;
    if (c.life > 0) { c.life -= dt; if (c.life <= 0) { int i = &c - pool; leave(i); } }
    const float fadeRate = (c.type == SNAIL || c.type == CRAB) ? 0.6f : 1.5f;
    c.alpha = util::approach(c.alpha, c.alphaT, dt * fadeRate);
    if (c.mode == LEAVE && walker(c.type) && c.alpha < 0.03f) { c.on = false; continue; }
    if (c.type == MOLT) continue;

    if (walker(c.type) && c.mode != CLIMB) {
      float dx = c.tx - c.x;
      if (fabsf(dx) > 1) {
        float step = (dx > 0 ? 1 : -1) * c.spd * dt;
        if (c.type == SHRIMP || c.type == GHOST_SHRIMP) {
          // 蝦子：一小段一小段地跳著走
          c.hop += dt * 3.2f;
          step *= 0.6f + 1.4f * fmaxf(0, util::fsin(c.hop * 3.14159f));
        }
        if (fabsf(step) > fabsf(dx)) step = dx;
        c.x += step;
        c.vx = step / dt;
        if (c.type != CRAB) c.dir = dx > 0 ? 1 : -1;
      } else {
        c.vx = 0;
        if (c.mode == WALK) c.mode = IDLE;
      }
      c.y = groundY(c.type, c.x) - ((c.type == SHRIMP || c.type == GHOST_SHRIMP) ? fmaxf(0, util::fsin(c.hop * 3.14159f)) * 3 : 0);
    } else if (c.mode == CLIMB) {
      c.x = c.climbSide < 0 ? 7 : 233;
      c.y = util::approach(c.y, c.ty, c.spd * dt);
    } else {
      float dx = c.tx - c.x, dy = c.ty - c.y;
      float d = sqrtf(dx * dx + dy * dy);
      float sp = c.spd * (d < 12 && c.mode != LEAVE ? d / 12 + 0.1f : 1);
      float dvx = d > 0.5f ? dx / d * sp : 0, dvy = d > 0.5f ? dy / d * sp * 0.6f : 0;
      c.vx += (dvx - c.vx) * fminf(1, 2.5f * dt);
      c.vy += (dvy - c.vy) * fminf(1, 2.5f * dt);
      c.x += c.vx * dt;
      c.y += c.vy * dt;
      if (fabsf(c.vx) > 2) c.dir = c.vx > 0 ? 1 : -1;
      if (c.mode == LEAVE && (c.x < -45 || c.x > 285)) c.on = false;
    }
  }
}

void draw(uint8_t layer) {
  for (auto& c : pool) {
    if (!c.on || c.layer != layer) continue;
    const SpriteDef& s = (c.type == SHARK && c.bite > 0) ? spr::shark_bite : *sprOf(c.type);
    uint8_t alpha = (uint8_t)(255 * util::clamp01(c.alpha));
    if (alpha < 4) continue;
    if (c.mode == CLIMB) { drawRotated(s, c.x, c.y, c.climbSide, alpha); continue; }
    gfx::SprOpt o;
    o.xs = c.type == CRAB ? 1 : c.dir;
    o.tailPhase = c.phase * 10;
    o.tailAmp = s.tail ? 1.5f : 0;
    o.frame = (int)(c.phase * (c.type == FRY ? 10 : 6));
    o.alpha = alpha;
    o.behindRock = layer == 0;
    if (c.type == GHOST_SHRIMP) o.alpha = (uint8_t)(alpha * 0.45f);
    if (c.type == MOLT) { o.solid = 0xe8f2f0; o.alpha = (uint8_t)(alpha * 0.5f); }
    if (c.type == SHADOWFISH) { o.solid = 0x0a2236; o.alpha = (uint8_t)(alpha * 0.45f); o.px = 6; o.tailPhase = c.phase * 3; o.tailAmp = 4; }
    if (c.type == BLUEFISH || c.type == RAREFISH) {
      if (c.layer == 0) o.alpha = (uint8_t)(alpha * 0.8f);
    }
    if (c.type == SHARK) {
      o.tailAmp = 0;
      o.frame = (int)(c.phase * (fabsf(c.vx) > 50 ? 12 : 5));
      if (c.layer == 0) { o.solid = 0x0a2236; o.alpha = (uint8_t)(alpha * 0.45f); o.px = 3; }  // 遠處的鯊魚剪影
    }
    if (c.glint) o.glint = fmodf(c.t * 0.6f, 1.4f);
    float bob = (c.type == CRAB || walker(c.type)) ? 0 : (util::fsin(c.phase * 1.5f) > 0.3f ? 2 : 0);
    gfx::sprite(s, (float)(((int)c.x) & ~1), (float)((((int)c.y) & ~1) + (int)bob), o);
    // 蝦子搬運食物
    if (c.carry) gfx::block((int)(c.x + c.dir * s.w), (int)c.y - 2, gfx::rgb(0xc8702a));
  }
}

void drawGlow() {
  for (auto& c : pool) {
    if (!c.on || c.alpha < 0.05f) continue;
    if (c.type == BLUEFISH) gfx::glow((int)c.x, (int)c.y, 14, 0x30c8ff, (uint8_t)(90 * c.alpha * (0.8f + 0.2f * util::fsin(c.phase * 3))));
    if (c.type == GOLDFISH) gfx::glow((int)c.x, (int)c.y, 12, 0xffc040, (uint8_t)(60 * c.alpha));
    if (c.type == RAREFISH) gfx::glow((int)c.x, (int)c.y, 6, 0xff60c0, (uint8_t)(50 * c.alpha));
  }
}

}  // namespace creatures
