// 粒子：泡泡、飼料、閃光、浮游生物、沙塵、落葉、水花、星光… (固定大小的粒子池)
#pragma once
#include <stdint.h>

namespace particles {

enum Type : uint8_t {
  BUBBLE, FOOD, SPARK, PLANKTON, DUST, LEAF, SPLASH, CRYSTAL, STAR, GLOWDOT, MICRO, MOTE, CRUMB, BLOOD, SCALE, CHUNK, TYPE_COUNT
};

struct P {
  uint8_t type;
  bool on;
  uint8_t size;
  uint8_t flags;
  float x, y, vx, vy;
  float life, maxLife;
  float phase;
  uint32_t color;
};
constexpr uint8_t F_GLOW = 1;    // 在色彩分級之後以加色畫 (夜晚也亮)
constexpr uint8_t F_EATEN = 2;
constexpr uint8_t F_LANDED = 4;  // 飼料落到沙地

void begin();
void update(float dt);
void draw();       // 一般粒子 (分級前)
void drawGlow();   // 發光粒子 (分級後)
void drawGore();   // 血霧、肉塊 (分級後畫，夜晚也看得清楚)
int spawn(Type t, float x, float y, float vx, float vy, float life, uint8_t size = 1, uint32_t color = 0);
void bubbles(float x, float y, int n, float spread = 3);
void burst(Type t, float x, float y, int n, float speed, float life, uint32_t color = 0);
int count(Type t);
P& at(int i);
int cap();
// 飼料
int nearestFood(float x, float y, float maxDist);
bool eatFood(int i);       // 被吃掉 (回傳是否成功)
void dropFood(float x, int n);
// 血：依血腥設定 (完整 = 方塊血霧，輕微 = 紅色閃光，關閉 = 沒有)
void blood(float x, float y, int n, float spread = 4);
void scales(float x, float y, int n);  // 被咬時噴出的鱗片碎塊
int bloodAmount();                    // 目前水中的血霧量 (整缸泛紅用)
// 撕咬：血往外噴 + 肉塊 + 鱗片 (完整)；輕微 = 紅色閃光；關閉 = 沒有
void gib(float x, float y, int amount);

}  // namespace particles
