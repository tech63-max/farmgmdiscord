#include "Environment.h"
#include <math.h>
#include <stdio.h>
#include "../config/AquariumConfig.h"
#include "../core/Util.h"
#include "../gfx/Gfx.h"

namespace env {

Eco eco;
Fx fx;
uint32_t lastFeedMs = 0, lastEatMs = 0;

namespace {
float clk = acfg::FIRST_BOOT_CLOCK;
uint32_t dayN = 1;
uint16_t dayLen = 120;
float scale = 1;
Phase cur = DAY;
bool changed = false;

struct Key { float t, mr, mg, mb, ar, ag, ab; };
// 一天的光色關鍵格 (0 = 午夜)
const Key KEYS[] = {
    {0.00f, 0.36f, 0.45f, 0.72f, 0, 4, 14},
    {0.18f, 0.38f, 0.47f, 0.74f, 0, 4, 14},
    {0.24f, 0.95f, 0.78f, 0.72f, 14, 4, 0},
    {0.30f, 1.00f, 1.00f, 1.00f, 0, 0, 0},
    {0.70f, 1.00f, 1.00f, 1.00f, 0, 0, 0},
    {0.78f, 1.05f, 0.70f, 0.55f, 18, 4, 0},
    {0.86f, 0.48f, 0.58f, 0.85f, 0, 4, 12},
    {1.00f, 0.36f, 0.45f, 0.72f, 0, 4, 14},
};

Phase phaseOf(float c) {
  if (c < 0.20f) return DEEP_NIGHT;
  if (c < 0.28f) return DAWN;
  if (c < 0.74f) return DAY;
  if (c < 0.82f) return DUSK;
  if (c < 0.96f) return NIGHT;
  return DEEP_NIGHT;
}

void toward(float& v, float t, float rate, float dt) { v = util::approach(v, t, rate * dt); }

void blendKey(Key& g, float k, float mr, float mg, float mb, float ar, float ag, float ab) {
  if (k <= 0) return;
  g.mr += (mr - g.mr) * k; g.mg += (mg - g.mg) * k; g.mb += (mb - g.mb) * k;
  g.ar += (ar - g.ar) * k; g.ag += (ag - g.ag) * k; g.ab += (ab - g.ab) * k;
}

void updateGrade() {
  Key g = KEYS[0];
  for (unsigned i = 0; i + 1 < sizeof(KEYS) / sizeof(KEYS[0]); i++) {
    const Key &a = KEYS[i], &b = KEYS[i + 1];
    if (clk >= a.t && clk <= b.t) {
      float t = util::smooth((clk - a.t) / (b.t - a.t));
      g = {clk, util::lerp(a.mr, b.mr, t), util::lerp(a.mg, b.mg, t), util::lerp(a.mb, b.mb, t),
           util::lerp(a.ar, b.ar, t), util::lerp(a.ag, b.ag, t), util::lerp(a.ab, b.ab, t)};
      break;
    }
  }
  // 事件光色覆蓋
  blendKey(g, fx.sunrise, 1.08f, 0.86f, 0.68f, 20, 8, 0);
  blendKey(g, fx.sunset, 1.12f, 0.62f, 0.45f, 24, 4, 0);
  blendKey(g, fx.moon, 0.55f, 0.72f, 1.05f, 0, 6, 24);
  blendKey(g, fx.mystic * 0.85f, 0.62f, 0.95f, 0.92f, 18, 0, 30);
  blendKey(g, fx.stars * 0.9f, 0.30f, 0.36f, 0.62f, 0, 0, 10);
  blendKey(g, fx.dread * 0.85f, 0.42f, 0.50f, 0.62f, 0, 2, 8);
  blendKey(g, fx.blood * 0.7f, 1.0f, 0.55f, 0.55f, 46, 0, 4);
  // 混濁：往灰綠色靠攏
  const float m = fx.murk * 0.55f;
  g.mr *= 1 - m; g.mg *= 1 - m; g.mb *= 1 - m;
  g.ar += 90 * m; g.ag += 105 * m; g.ab += 70 * m;
  gfx::setGrade(g.mr, g.mg, g.mb, g.ar, g.ag, g.ab);
}
}  // namespace

const char* phaseName(Phase p) {
  static const char* N[] = {"深夜", "清晨", "白天", "黃昏", "夜晚"};
  return p < PHASE_COUNT ? N[p] : "?";
}

void begin(float c, uint32_t d, uint16_t len) {
  clk = c >= 0 && c < 1 ? c : acfg::FIRST_BOOT_CLOCK;
  dayN = d ? d : 1;
  dayLen = len ? len : 120;
  cur = phaseOf(clk);
  updateGrade();
}

void update(float dt) {
  clk += dt * scale / (dayLen * 60.0f);
  while (clk >= 1) { clk -= 1; dayN++; }
  Phase p = phaseOf(clk);
  changed = p != cur;
  cur = p;

  toward(fx.beams, fx.beamsT, 0.25f, dt);
  toward(fx.caustics, fx.causticsT, 0.3f, dt);
  toward(fx.shimmer, fx.shimmerT, 0.5f, dt);
  toward(fx.murk, fx.murkT, 0.06f, dt);
  toward(fx.rainbow, fx.rainbowT, 0.25f, dt);
  toward(fx.stars, fx.starsT, 0.12f, dt);
  toward(fx.mystic, fx.mysticT, 0.1f, dt);
  toward(fx.moon, fx.moonT, 0.08f, dt);
  toward(fx.sunrise, fx.sunriseT, 0.07f, dt);
  toward(fx.sunset, fx.sunsetT, 0.07f, dt);
  toward(fx.biolum, fx.biolumT, 0.2f, dt);
  toward(fx.sway, fx.swayT, 0.6f, dt);
  toward(fx.current, fx.currentT, 6.0f, dt);
  toward(fx.shellOpen, fx.shellOpenT, 0.25f, dt);
  toward(fx.chestUp, fx.chestUpT, 0.12f, dt);
  toward(fx.chestOpen, fx.chestOpenT, 0.6f, dt);
  toward(fx.pearl, fx.pearlT, 0.3f, dt);
  toward(fx.flower, fx.flowerT, 0.15f, dt);
  toward(fx.orb, fx.orbT, 0.4f, dt);
  toward(fx.dread, fx.dreadT, 0.35f, dt);
  toward(fx.blood, fx.bloodT, 0.15f, dt);

  // 生態狀態 (模擬值，緩慢回到舒適範圍；不會因為沒操作而永久惡化)
  const float ang = (clk - 0.35f) * 2 * (float)M_PI;
  eco.waterTemp = 25.0f + 0.9f * cosf(ang);
  toward(eco.clarity, 1.0f - fx.murk * 0.6f, 0.02f, dt);
  if (eco.plantGrowth < 0.85f) eco.plantGrowth += dt * 0.00002f;
  if (eco.algae < 0.45f) eco.algae += dt * 0.00001f;
  updateGrade();
}

float clock() { return clk; }
uint32_t day() { return dayN; }
void setClock(float c) {
  while (c >= 1) c -= 1;
  while (c < 0) c += 1;
  clk = c;
  cur = phaseOf(clk);
  changed = true;
}
void setDayLength(uint16_t m) { if (m >= 5) dayLen = m; }
uint16_t dayLength() { return dayLen; }
void setTimeScale(float s) { scale = s < 0.1f ? 0.1f : (s > 500 ? 500 : s); }
float timeScale() { return scale; }
Phase phase() { return cur; }
bool phaseChanged() { return changed; }
bool isNight() { return cur == NIGHT || cur == DEEP_NIGHT; }

float darkness() {
  // 0 = 白天，1 = 深夜 (平滑)
  if (clk >= 0.30f && clk <= 0.70f) return 0;
  if (clk > 0.70f && clk < 0.86f) return util::smooth((clk - 0.70f) / 0.16f) * 0.75f;
  if (clk >= 0.86f) return 0.75f + util::smooth((clk - 0.86f) / 0.14f) * 0.25f;
  if (clk <= 0.18f) return 1;
  return 1 - util::smooth((clk - 0.18f) / 0.12f);
}

float backlightFactor() {
  const float d = darkness();
  if (d < 0.75f) return 1 - (1 - acfg::BL_NIGHT) * d / 0.75f;
  return acfg::BL_NIGHT - (acfg::BL_NIGHT - acfg::BL_DEEP_NIGHT) * (d - 0.75f) / 0.25f;
}

void virtualTime(char* buf, int cap) {
  int mins = (int)(clk * 24 * 60);
  snprintf(buf, cap, "第%lu天 %02d:%02d", (unsigned long)dayN, mins / 60, mins % 60);
}

bool fedRecently(uint32_t ms, uint32_t windowMs) { return lastFeedMs && ms - lastFeedMs < windowMs; }

}  // namespace env
