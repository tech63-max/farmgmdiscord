#include "Remains.h"
#include <math.h>
#include <string.h>
#include "../core/Util.h"
#include "../gfx/Gfx.h"
#include "../gfx/SpriteData.h"
#include "Fish.h"
#include "ParticleSystem.h"
#include "Scene.h"

namespace remains {
namespace {
constexpr int CAP = 16;
constexpr int MAX_BODIES = 4, MAX_BONES = 3, MAX_STAINS = 8;
constexpr float CORPSE_LIFE = 240, HALF_LIFE = 150, BONES_LIFE = 900, STAIN_LIFE = 300;
R pool[CAP];
using util::rng;

bool body(uint8_t k) { return k == CORPSE || k == HALF_HEAD || k == HALF_TAIL; }

// 同類太多：最舊的那個讓位 (屍體變魚骨、其他直接移除)
void makeRoom(uint8_t kind) {
  int lim = body(kind) ? MAX_BODIES : (kind == BONES ? MAX_BONES : MAX_STAINS);
  int n = 0, oldest = -1;
  float ot = -1;
  for (int i = 0; i < CAP; i++) {
    const R& r = pool[i];
    if (!r.on || (body(kind) ? !body(r.kind) : r.kind != kind)) continue;
    n++;
    if (r.t > ot) { ot = r.t; oldest = i; }
  }
  if (n >= lim && oldest >= 0) pool[oldest].on = false;
}

int alloc(uint8_t kind) {
  makeRoom(kind);
  for (int i = 0; i < CAP; i++)
    if (!pool[i].on) {
      pool[i] = {};
      pool[i].on = true;
      pool[i].kind = kind;
      return i;
    }
  return -1;
}

float restY(const R& r) {
  if (r.kind == BONES) return scene::sandTop((int)r.x) - 5;
  const SpriteDef* s = fish::info(r.sp).spr;
  return scene::sandTop((int)r.x) - s->h * acfg::FISH_PX * 0.5f + 3;
}
}  // namespace

void begin() { clear(); }
void clear() { memset(pool, 0, sizeof(pool)); }
R& at(int i) { return pool[i]; }
int cap() { return CAP; }
void remove(int i) { if (i >= 0 && i < CAP) pool[i].on = false; }

int count(Kind k) {
  int n = 0;
  for (auto& r : pool) n += r.on && r.kind == k;
  return n;
}
int find(Kind k) {
  for (int i = 0; i < CAP; i++) if (pool[i].on && pool[i].kind == k) return i;
  return -1;
}

int corpseFrom(uint8_t sp, uint8_t var, float x, float y, int8_t dir) {
  if (!gore::blood()) return -1;
  int i = alloc(CORPSE);
  if (i < 0) return -1;
  R& r = pool[i];
  r.sp = sp; r.var = var; r.dir = dir;
  r.x = x; r.y = y; r.vy = 2;
  r.life = CORPSE_LIFE;
  return i;
}

int corpse(int fi) {
  const fish::Fish& f = fish::F[fi];
  return corpseFrom(f.sp, f.var, f.x, f.y, f.dir);
}

void halves(int fi, float push) {
  if (!gore::blood()) return;
  const fish::Fish& f = fish::F[fi];
  for (int k = 0; k < 2; k++) {
    int i = alloc(k == 0 ? HALF_HEAD : HALF_TAIL);
    if (i < 0) return;
    R& r = pool[i];
    r.sp = f.sp; r.var = f.var; r.dir = f.dir;
    r.x = f.x; r.y = f.y;
    // 頭往前飛、尾巴往後飛
    const float s = (k == 0 ? 1 : -1) * f.dir;
    r.vx = s * push * rng.range(0.7f, 1.2f);
    r.vy = -rng.range(4, 14);
    r.life = HALF_LIFE;
  }
}

int bones(float x, float y) {
  int i = alloc(BONES);
  if (i < 0) return -1;
  R& r = pool[i];
  r.x = x; r.y = y; r.vy = 4;
  r.life = BONES_LIFE;
  return i;
}

void stain(float x, float w) {
  if (!gore::blood()) return;
  // 附近已經有血跡：擴大、加深，不另外開一塊
  for (auto& r : pool)
    if (r.on && r.kind == STAIN && fabsf(r.x - x) < r.w * 0.5f + 4) {
      r.w = fminf(r.w + w * 0.4f, 30);
      r.life = STAIN_LIFE;
      return;
    }
  int i = alloc(STAIN);
  if (i < 0) return;
  pool[i].x = x;
  pool[i].w = w;
  pool[i].life = STAIN_LIFE;
}

void nibble(int i, float amount) {
  if (i < 0 || i >= CAP || !pool[i].on) return;
  R& r = pool[i];
  r.eaten += amount;
  if (r.eaten >= 1 && r.kind == CORPSE) {
    const float x = r.x;
    r.on = false;
    bones(x, scene::sandTop((int)x) - 5);
  } else if (r.eaten >= 1) {
    r.on = false;
  }
}

void update(float dt) {
  for (int i = 0; i < CAP; i++) {
    R& r = pool[i];
    if (!r.on) continue;
    r.t += dt;
    r.life -= dt;
    if (r.life <= 0) {
      // 屍體放久了 → 魚骨；其他直接消失
      if (r.kind == CORPSE) { const float x = r.x; r.on = false; bones(x, scene::sandTop((int)x) - 5); }
      else r.on = false;
      continue;
    }
    if (r.kind == STAIN) continue;
    if (r.bloat > 0) {  // 浮屍：往上浮
      r.landed = false;
      r.y = fmaxf(r.y - 9 * dt, (float)scene::SWIM_TOP + 2);
      r.bloat -= dt;
      continue;
    }
    if (!r.landed) {
      r.vx *= 1 - 1.2f * dt;
      r.vy = util::approach(r.vy, r.kind == BONES ? 10 : 7, 18 * dt);
      r.x = util::clamp(r.x + r.vx * dt, 10.0f, 230.0f);
      r.y += r.vy * dt;
      const float ry = restY(r);
      if (r.y >= ry) {
        r.y = ry;
        r.landed = true;
        r.vx = r.vy = 0;
        if (r.kind != BONES) { particles::burst(particles::DUST, r.x, ry + 4, 5, 10, 1.6f); stain(r.x, 10); }
      }
    }
    // 屍體 / 半截：一路滲血 (剛死時最多)
    if (r.kind != BONES && gore::blood()) {
      const float rate = r.t < 8 ? 3.0f : (r.t < 60 ? 0.8f : 0.2f);
      if (rng.chance(dt * rate)) particles::blood(r.x + rng.range(-5, 5), r.y, 1, 2);
    }
  }
}

void drawGround() {
  for (auto& r : pool) {
    if (!r.on || r.kind != STAIN) continue;
    const float a = util::clamp01(r.life / 60.0f);
    const int w = ((int)r.w) & ~1, x0 = ((int)(r.x - w / 2)) & ~1;
    const int y = scene::sandTop((int)r.x);
    gfx::blendRect(x0, y - 1, w, 3, gfx::rgb(0x6a0a0e), (uint8_t)(170 * a));
    gfx::blendRect(x0 + 2, y + 2, w > 6 ? w - 4 : w, 2, gfx::rgb(0x4a0608), (uint8_t)(120 * a));
  }
}

void draw() {
  for (auto& r : pool) {
    if (!r.on || r.kind == STAIN) continue;
    const float fade = util::clamp01(r.life / 20.0f);
    gfx::SprOpt o;
    o.alpha = (uint8_t)(255 * fade);
    const int x = ((int)r.x) & ~1, y = ((int)r.y) & ~1;
    if (r.kind == BONES) {
      o.xs = r.dir < 0 ? -1 : 1;
      gfx::sprite(spr::bones, x, y, o);
      continue;
    }
    const SpriteDef& s = *fish::info(r.sp).spr;
    o.px = acfg::FISH_PX;
    o.xs = r.dir < 0 ? -1 : 1;
    o.hue = r.var;
    o.flipY = r.kind == CORPSE;   // 翻肚子
    o.eyesClosed = true;
    o.tint = 0x8a8a7a;
    o.tintA = (uint8_t)util::clamp(60.0f + r.t * 0.6f + r.eaten * 80, 0.0f, 170.0f);  // 越久越灰
    const int mid = s.w / 2;
    if (r.kind == HALF_HEAD) { o.u0 = (uint8_t)mid; o.woundU = (uint8_t)mid; }
    if (r.kind == HALF_TAIL) { o.u1 = (uint8_t)(mid - 1); o.woundU = (uint8_t)(mid - 1); }
    // 被清道夫吃掉：從尾巴開始少掉
    if (r.kind == CORPSE && r.eaten > 0) {
      o.u0 = (uint8_t)(s.w * r.eaten * 0.85f);
      o.woundU = o.u0;
    }
    gfx::sprite(s, x, y, o);
  }
}

}  // namespace remains
