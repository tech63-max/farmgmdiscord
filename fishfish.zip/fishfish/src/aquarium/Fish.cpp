#include "Fish.h"
#include <math.h>
#include <string.h>
#include "../core/Util.h"
#include "../gfx/Gfx.h"
#include "../gfx/SpriteData.h"
#include "Environment.h"
#include "ParticleSystem.h"
#include "Scene.h"

namespace fish {

Fish F[acfg::FISH_CAP];

namespace {
using util::rng;
int n = 0;

const Info INFO[SP_COUNT] = {
    // name, sprite, speed, fast, yMin, yMax, social, bold, playful, nightRest, tailAmp, tailFreq, size
    {"灰褐小型魚", &spr::cod, 14, 45, 0.55f, 0.95f, 0.20f, 0.60f, 0.20f, 0.60f, 2.0f, 6, 2},
    {"橘紅細長魚", &spr::salmon, 22, 70, 0.12f, 0.60f, 0.25f, 0.70f, 0.40f, 0.40f, 2.0f, 7, 2},
    {"刺刺膨脹魚", &spr::puffer, 9, 26, 0.30f, 0.80f, 0.10f, 0.85f, 0.50f, 0.70f, 1.0f, 10, 1},
    {"多彩斑點魚", &spr::trop_ow, 16, 50, 0.45f, 0.88f, 0.50f, 0.50f, 0.80f, 0.85f, 1.5f, 11, 0},
    {"藍黃熱帶魚", &spr::trop_by, 20, 60, 0.20f, 0.62f, 0.90f, 0.40f, 0.50f, 0.80f, 1.5f, 12, 0},
    {"紫色熱帶魚", &spr::trop_purple, 11, 36, 0.25f, 0.72f, 0.30f, 0.50f, 0.30f, 0.70f, 1.0f, 7, 1},
    {"黑金熱帶魚", &spr::trop_black, 18, 55, 0.40f, 0.92f, 0.20f, 0.25f, 0.30f, 0.20f, 1.5f, 9, 0},
    {"紅白條紋魚", &spr::trop_rw, 17, 55, 0.15f, 0.55f, 0.60f, 0.60f, 0.70f, 0.80f, 1.5f, 10, 0},
    {"黃色小魚", &spr::lemon, 21, 65, 0.10f, 0.50f, 0.80f, 0.40f, 0.60f, 0.80f, 1.0f, 14, 0},
};
const char* ST_NAME[ST_COUNT] = {"Idle", "Swim", "FastSwim", "Turn", "Explore", "Follow", "Chase", "Flee",
                                  "Rest", "Hide", "Eat", "Play", "Sleep", "Inspect", "School"};
const char* PERS_NAME[PERS_COUNT] = {"沉穩", "愛玩", "害羞", "好奇", "慵懶"};

// 預設魚缸成員 (9 條；藍黃熱帶魚 2 條可以成群)
const uint8_t DEFAULT_ROSTER[] = {COD, SALMON, PUFFER, TROP_OW, TROP_BY, TROP_BY, TROP_PURPLE, TROP_BLACK, TROP_RW};

// 魚的名字 (新魚從沒在缸裡的名字中挑)
const char* const NAMES[] = {
    "小灰", "阿橘", "胖胖", "斑斑", "小藍", "小黃", "紫紫", "金金", "條條", "豆豆", "米米", "球球",
    "泡泡", "皮皮", "小石", "海苔", "布丁", "可可", "奶茶", "芝麻", "麻糬", "湯圓", "糖糖", "小葉",
    "阿福", "小波", "跳跳", "妞妞", "鈴鈴", "多多", "樂樂", "飯糰", "小虎", "阿凱", "小雲", "星星",
    "小月", "阿光", "黑黑", "白白", "小丸", "花花", "蛋蛋", "嘟嘟", "咪咪", "小汪", "大頭", "小刺",
};
constexpr int NAME_N = sizeof(NAMES) / sizeof(NAMES[0]);

constexpr float BLEED_MAX = 40;  // 被咬後最多流血幾秒

Death deaths[DEATH_LOG_CAP];
int deathHead = 0, deathN = 0, deathTotal = 0;
// 血腥關閉時魚不會死，只是被嚇跑：先記在這裡，補魚時原封不動游回來
Record away[acfg::FISH_CAP];
int awayN = 0;
// 補魚
bool refillOn = false, refillHold = false;
float refillT = 0, refillMin = 20, refillMax = 40;

// 每個種類的群游目標 (同種魚群共用，定期換)
float schoolX[SP_COUNT], schoolY[SP_COUNT], schoolT[SP_COUNT];

float depthToY(float d, float x) {
  const float top = scene::SWIM_TOP, bot = scene::swimBottom((int)x);
  return top + (bot - top) * d;
}

void randomTarget(Fish& f, float spread = 1.0f) {
  const Info& in = INFO[f.sp];
  float x = util::clamp(f.x + rng.range(-120, 120) * spread, (float)scene::SWIM_LEFT, (float)scene::SWIM_RIGHT);
  if (rng.chance(0.3f)) x = rng.range(scene::SWIM_LEFT, scene::SWIM_RIGHT);
  f.tx = x;
  f.ty = depthToY(rng.range(in.yMin, in.yMax), x);
}

void setState(Fish& f, State st, float dur) {
  f.st = st;
  f.stT = dur;
  f.eyesClosed = (st == SLEEP);
  f.wiggle = 0;
  f.backward = false;
  const Info& in = INFO[f.sp];
  switch (st) {
    case SWIM: case EXPLORE: f.spd = in.speed * rng.range(0.8f, 1.2f); break;
    case FAST: f.spd = in.fast; randomTarget(f, 1.5f); break;
    case IDLE: case INSPECT: case REST: case SLEEP: f.spd = in.speed * 0.35f; break;
    case PLAY: f.spd = in.speed * 1.6f; break;
    case CHASE: f.spd = in.fast * 0.8f; break;
    case FLEE: f.spd = in.fast; break;
    case EAT: f.spd = in.speed * 1.5f; break;
    default: f.spd = in.speed; break;
  }
}

int sameSpeciesCount(uint8_t sp) {
  int c = 0;
  for (int i = 0; i < n; i++) if (F[i].on && F[i].sp == sp) c++;
  return c;
}

void think(Fish& f, int self) {
  const Info& in = INFO[f.sp];
  const float night = env::darkness();
  const bool shy = f.pers == SHY, playful = f.pers == PLAYFUL, curious = f.pers == CURIOUS, lazy = f.pers == LAZY;
  float w[ST_COUNT] = {0};
  w[SWIM] = 3.0f;
  w[IDLE] = 0.8f + (lazy ? 1.0f : 0);
  w[EXPLORE] = 0.8f + in.bold + (curious ? 1.2f : 0);
  w[FOLLOW] = 0.4f + in.social;
  w[CHASE] = (in.playful + (playful ? 0.8f : 0)) * f.energy * (1 - night) * 0.9f;
  w[REST] = 0.5f + (lazy ? 1.0f : 0) + (1 - f.energy) * 2.5f;
  w[HIDE] = (1 - in.bold) * 1.2f + (shy ? 1.2f : 0);
  w[PLAY] = (in.playful + (playful ? 0.6f : 0)) * f.energy * 0.8f * (1 - night);
  w[SLEEP] = night * in.nightRest * 5 + (1 - f.energy) * night * 2;
  w[INSPECT] = in.bold * 0.5f + (curious ? 0.8f : 0);
  w[SCHOOL] = sameSpeciesCount(f.sp) >= 2 ? in.social * 4 : 0;
  w[FAST] = 0.35f * f.energy * (1 - night);
  if (night > 0.5f) { w[SWIM] *= 0.5f; w[EXPLORE] *= 0.4f; }
  if (f.shy > 0) { w[HIDE] += 4; w[SCHOOL] = 0; w[FOLLOW] = 0; w[CHASE] = 0; w[PLAY] = 0; }  // 新來的魚怕生
  if (f.hurt > 0) { w[REST] += 3; w[HIDE] += 2; w[CHASE] = 0; w[PLAY] = 0; w[SCHOOL] *= 0.2f; w[FAST] = 0; }  // 受傷：躲起來休養
  float sum = 0;
  for (float v : w) sum += v;
  float r = rng.range(0, sum);
  int st = SWIM;
  for (int i = 0; i < ST_COUNT; i++) { r -= w[i]; if (r <= 0) { st = i; break; } }

  switch (st) {
    case SWIM: setState(f, SWIM, rng.range(4, 10)); randomTarget(f); break;
    case IDLE: setState(f, IDLE, rng.range(2, 5)); f.tx = f.x; f.ty = f.y; break;
    case FAST: setState(f, FAST, rng.range(1.5f, 3)); break;
    case EXPLORE: {
      setState(f, EXPLORE, rng.range(5, 10));
      int pick = rng.irange(0, 2);
      if (pick == 0) { int p = rng.irange(0, scene::PLANT_N - 1); float px, py; scene::plantPoint(p, rng.range(0.2f, 0.7f), px, py); f.tx = px + rng.range(-14, 14); f.ty = py; }
      else if (pick == 1) { f.tx = rng.chance(0.5f) ? scene::ROCK_L.cx + 30 : scene::ROCK_R.cx - 24; f.ty = scene::ROCK_L.cy - 40; }
      else { f.tx = rng.range(30, 210); f.ty = scene::swimBottom((int)f.tx) - 4; }
      break;
    }
    case FOLLOW: {
      int o = pickNear(f.x, f.y, self);
      if (o < 0) { setState(f, SWIM, 5); randomTarget(f); break; }
      setState(f, FOLLOW, rng.range(6, 12));
      f.other = (int8_t)o;
      break;
    }
    case CHASE: {
      int o = -1;
      for (int k = 0; k < 6 && o < 0; k++) {
        int c = rng.irange(0, n - 1);
        if (c != self && F[c].on && F[c].owner == 0 && F[c].st != SLEEP && INFO[F[c].sp].size <= in.size + 1) o = c;
      }
      if (o < 0) { setState(f, PLAY, 3); break; }
      setState(f, CHASE, rng.range(3, 6));
      f.other = (int8_t)o;
      Fish& g = F[o];
      setState(g, FLEE, f.stT);
      g.other = (int8_t)self;
      break;
    }
    case REST: {
      setState(f, REST, rng.range(5, 12));
      int p = scene::nearestPlant(f.x, false);
      float px, py;
      scene::plantPoint(p, 0.25f, px, py);
      f.tx = px + (f.x < px ? -12 : 12);
      f.ty = py;
      break;
    }
    case HIDE: {
      setState(f, HIDE, rng.range(6, 14));
      if (rng.chance(0.5f)) {
        int p = scene::nearestPlant(f.x, true);
        float px, py;
        scene::plantPoint(p, 0.35f, px, py);
        f.tx = px; f.ty = py;
      } else {
        f.tx = scene::ROCK_L.cx + rng.range(-12, 12);
        f.ty = scene::ROCK_L.cy - 4;
        f.wantLayer = 0;
        f.layer = 0;
      }
      break;
    }
    case PLAY: setState(f, PLAY, rng.range(3, 6)); randomTarget(f, 0.3f); break;
    case SLEEP: {
      setState(f, SLEEP, rng.range(20, 50));
      int p = rng.irange(0, scene::PLANT_N - 1);
      float px, py;
      scene::plantPoint(p, 0.15f, px, py);
      f.tx = px + rng.range(-16, 16);
      f.ty = fminf(py, (float)scene::swimBottom((int)f.tx) - 6);
      f.eyesClosed = false;  // 到了才閉眼
      break;
    }
    case INSPECT: {
      setState(f, INSPECT, rng.range(3, 6));
      if (rng.chance(0.5f)) { f.tx = scene::SHELL_X + rng.range(-14, 14); f.ty = scene::sandTop(scene::SHELL_X) - 14; }
      else { int o = pickNear(f.x, f.y, self); if (o >= 0) { f.tx = F[o].x - F[o].dir * 16; f.ty = F[o].y; } }
      break;
    }
    case SCHOOL: setState(f, SCHOOL, rng.range(10, 22)); break;
    default: setState(f, SWIM, 5); randomTarget(f); break;
  }
  clampTarget(f.tx, f.ty);
}

void steer(Fish& f, int self, float dt) {
  float dx = f.tx - f.x, dy = f.ty - f.y;
  float d = sqrtf(dx * dx + dy * dy);
  float sp = f.spd * (f.hurt > 0 ? 0.6f : 1.0f) * (f.shy > 0 ? 0.75f : 1.0f);
  if (d < 20) sp *= d / 20 + 0.05f;  // 接近目標時減速
  float dvx = d > 0.5f ? dx / d * sp : 0, dvy = d > 0.5f ? dy / d * sp * 0.7f : 0;
  // 分離：避免魚重疊太嚴重
  for (int j = 0; j < n; j++) {
    if (j == self || !F[j].on) continue;
    float ex = f.x - F[j].x, ey = f.y - F[j].y;
    float e2 = ex * ex + ey * ey;
    if (e2 < 196 && e2 > 0.01f) {
      float e = sqrtf(e2);
      dvx += ex / e * (14 - e) * 1.3f;
      dvy += ey / e * (14 - e) * 1.3f;
    }
  }
  const float acc = (f.st == FAST || f.st == FLEE) ? 4.0f : 2.2f;
  f.vx += (dvx - f.vx) * fminf(1, acc * dt);
  f.vy += (dvy - f.vy) * fminf(1, acc * dt);
  f.x += (f.vx + env::fx.current * 0.35f) * dt;
  f.y += f.vy * dt;
  f.x = util::clamp(f.x, (float)scene::SWIM_LEFT - 4, (float)scene::SWIM_RIGHT + 4);
  f.y = util::clamp(f.y, (float)scene::SWIM_TOP - 4, (float)scene::swimBottom((int)f.x) + 2);
}

void behave(Fish& f, int self, float dt, uint32_t ms) {
  const Info& in = INFO[f.sp];
  // 食物偵測：自由的魚會被附近的飼料吸引
  if (f.owner == 0 && f.st != EAT && f.st != FLEE && (f.st != SLEEP || rng.chance(0.02f))) {
    float range = 70 + in.bold * 60;
    if (particles::nearestFood(f.x, f.y, range) >= 0 && f.cd <= 0) { setState(f, EAT, 10); f.cd = 0; }
  }
  switch (f.st) {
    case SWIM: case EXPLORE:
      if (near(self, f.tx, f.ty, 6)) {
        if (f.st == SWIM && rng.chance(0.5f)) randomTarget(f);
        else { f.tx = f.x; f.ty = f.y; }
      }
      break;
    case PLAY:
      f.wiggle = 1.0f;
      if (near(self, f.tx, f.ty, 6) || rng.chance(dt * 0.8f)) {
        f.tx = f.x + rng.range(-40, 40);
        f.ty = f.y + rng.range(-18, 18);
        clampTarget(f.tx, f.ty);
      }
      break;
    case FOLLOW: {
      if (f.other < 0 || f.other >= n || !F[f.other].on) { f.stT = 0; break; }
      const Fish& o = F[f.other];
      f.tx = o.x - o.dir * (halfW(f.other) + halfW(self) + 4);
      f.ty = o.y + 3;
      f.spd = INFO[o.sp].speed * 1.3f + 4;
      break;
    }
    case CHASE: {
      if (f.other < 0 || f.other >= n || !F[f.other].on) { f.stT = 0; break; }
      Fish& o = F[f.other];
      f.tx = o.x; f.ty = o.y;
      if (near(self, o.x, o.y, 8)) {  // 追到了 → 結束，兩邊都轉開
        f.stT = 0;
        if (o.owner == 0 && o.st == FLEE) o.stT = 0.6f;
        if (o.sp == PUFFER) { o.inflate = 3; o.inflateMax = 3; }
      }
      break;
    }
    case FLEE: {
      float ax = f.x, ay = f.y;
      if (f.other >= 0 && f.other < n && F[f.other].on) { ax = F[f.other].x; ay = F[f.other].y; }
      float dx = f.x - ax, dy = f.y - ay, d = sqrtf(dx * dx + dy * dy) + 0.01f;
      f.tx = f.x + dx / d * 50;
      f.ty = f.y + dy / d * 30;
      clampTarget(f.tx, f.ty);
      break;
    }
    case EAT: {
      int fi = particles::nearestFood(f.x, f.y, 160);
      if (fi < 0) { if (f.owner == 0) f.stT = 0; break; }
      const particles::P& p = particles::at(fi);
      f.tx = p.x - f.dir * halfW(self) * 0.8f;
      f.ty = p.y;
      if (fabsf(mouthX(self) - p.x) < 6 && fabsf(f.y - p.y) < 6) {
        if (particles::eatFood(fi)) {
          f.lastAte = ms;
          env::lastEatMs = ms;
          env::eco.eaten++;
          f.mood = fminf(1, f.mood + 0.08f);
          f.energy = fminf(1, f.energy + 0.05f);
          f.cd = 1.2f;  // 吃完稍微停一下
          f.tx = f.x; f.ty = f.y;
        }
      }
      break;
    }
    case REST:
      if (near(self, f.tx, f.ty, 5)) { f.spd = 2; f.energy = fminf(1, f.energy + dt * 0.02f); }
      break;
    case SLEEP:
      if (near(self, f.tx, f.ty, 6)) { f.eyesClosed = true; f.spd = 1; f.energy = fminf(1, f.energy + dt * 0.03f); }
      if (env::darkness() < 0.3f && f.owner == 0 && f.stT > 4) f.stT = rng.range(1, 4);  // 天亮了就醒來
      break;
    case HIDE:
      if (near(self, f.tx, f.ty, 6)) f.spd = 2;
      break;
    case INSPECT:
      if (near(self, f.tx, f.ty, 8)) f.spd = 1.5f;
      break;
    case SCHOOL: {
      // 群游：聚合 + 對齊 + 共用目標 (分離在 steer 裡)
      float cx = 0, cy = 0, ax = 0;
      int c = 0;
      for (int j = 0; j < n; j++) {
        if (!F[j].on || F[j].sp != f.sp || F[j].st != SCHOOL) continue;
        cx += F[j].x; cy += F[j].y; ax += F[j].vx; c++;
      }
      if (c > 0) { cx /= c; cy /= c; ax /= c; }
      f.tx = cx * 0.4f + schoolX[f.sp] * 0.6f + ax * 0.4f + (self % 3 - 1) * 8;
      f.ty = cy * 0.4f + schoolY[f.sp] * 0.6f + (self % 2 ? 6 : -6);
      clampTarget(f.tx, f.ty);
      f.spd = in.speed * 1.1f;
      break;
    }
    case IDLE: default: break;
  }
}
}  // namespace

const Info& info(uint8_t sp) { return INFO[sp < SP_COUNT ? sp : 0]; }
const char* stateName(uint8_t st) { return st < ST_COUNT ? ST_NAME[st] : "?"; }
const char* persName(uint8_t p) { return p < PERS_COUNT ? PERS_NAME[p] : "?"; }

const Death& deathAt(int i);

static uint8_t pickName() {
  for (int tries = 0; tries < 40; tries++) {
    uint8_t k = (uint8_t)rng.irange(0, NAME_N - 1);
    bool used = false;
    for (int i = 0; i < n; i++) if (F[i].on && F[i].nameIdx == k) used = true;
    for (int i = 0; i < deathN && tries < 30; i++) if (deathAt(i).nameIdx == k) used = true;  // 也避開最近死掉的魚的名字
    if (!used) return k;
  }
  return (uint8_t)rng.irange(0, NAME_N - 1);
}

static void initFish(Fish& f, uint8_t sp, uint8_t pers, float mood, float energy) {
  memset(&f, 0, sizeof(f));
  f.on = true;
  f.sp = sp < SP_COUNT ? sp : TROP_OW;
  f.pers = pers < PERS_COUNT ? pers : CALM;
  f.x = rng.range(30, 210);
  f.y = depthToY(rng.range(INFO[f.sp].yMin, INFO[f.sp].yMax), f.x);
  f.dir = rng.chance(0.5f) ? 1 : -1;
  f.face = f.dir;
  f.mood = util::clamp01(mood);
  f.energy = util::clamp01(energy);
  f.other = -1;
  f.layer = f.wantLayer = 1;
  f.glint = -1;
  f.tail = rng.range(0, 6.28f);
  f.bob = rng.range(0, 6.28f);
  setState(f, SWIM, rng.range(1, 4));
  randomTarget(f);
  f.nameIdx = pickName();
  f.born = env::day();
}

void begin() {
  n = 0;
  for (uint8_t sp : DEFAULT_ROSTER) {
    if (n >= acfg::FISH_CAP) break;
    initFish(F[n], sp, (uint8_t)rng.irange(0, PERS_COUNT - 1), 0.6f, 0.8f);
    n++;
  }
  deathHead = deathN = deathTotal = 0;
  awayN = 0;
  refillOn = refillHold = false;
  for (int s = 0; s < SP_COUNT; s++) { schoolX[s] = 120; schoolY[s] = 100; schoolT[s] = 0; }
}

void setRoster(int cnt, const uint8_t* sp, const uint8_t* pers, const float* mood, const float* energy) {
  // 以目前的預設成員為準 (舊存檔若魚比較多會自動縮減)：
  // 每個成員沿用存檔裡同種魚的性格/心情/精力，存檔沒有的種類用新的隨機性格
  if (cnt <= 0) return;
  memset(F, 0, sizeof(F));
  bool used[acfg::FISH_CAP] = {false};
  n = 0;
  for (uint8_t want : DEFAULT_ROSTER) {
    int k = -1;
    for (int i = 0; i < cnt && i < acfg::FISH_CAP; i++) if (!used[i] && sp[i] == want) { k = i; break; }
    if (k >= 0) { used[k] = true; initFish(F[n], want, pers[k], mood[k], energy[k]); }
    else initFish(F[n], want, (uint8_t)rng.irange(0, PERS_COUNT - 1), 0.6f, 0.8f);
    n++;
  }
}

void setRecords(int cnt, const Record* r) {
  if (cnt < 0) return;
  memset(F, 0, sizeof(F));
  n = 0;
  for (int i = 0; i < cnt && n < acfg::FISH_CAP; i++) {
    Fish& f = F[n++];
    initFish(f, r[i].sp, r[i].pers, r[i].mood, r[i].energy);
    f.var = r[i].var < 3 ? r[i].var : 0;
    f.nameIdx = r[i].nameIdx < NAME_N ? r[i].nameIdx : 0;
    f.born = r[i].born;
    f.hurt = r[i].hurt;
  }
  // 存檔時還沒補滿 (例如鯊魚之後關機)：開機後接著補
  if (n < ROSTER_TARGET) queueRefill(rng.range(8, 15), 20, 40);
}

Record record(int i) {
  const Fish& f = F[i];
  Record r;
  r.sp = f.sp; r.pers = f.pers; r.var = f.var; r.nameIdx = f.nameIdx;
  r.mood = f.mood; r.energy = f.energy; r.hurt = f.hurt > 0 ? f.hurt : 0; r.born = f.born;
  return r;
}

int count() { return n; }
int alive() {
  int c = 0;
  for (int i = 0; i < n; i++) c += F[i].on;
  return c;
}
const char* nameAt(uint8_t k) { return k < NAME_N ? NAMES[k] : "?"; }
const char* nameOf(int i) { return (i >= 0 && i < n) ? nameAt(F[i].nameIdx) : "?"; }

void kill(int i, uint8_t cause) {
  if (i < 0 || i >= n || !F[i].on) return;
  Fish& f = F[i];
  if (!gore::death()) {
    if (awayN < acfg::FISH_CAP) away[awayN++] = record(i);  // 只是被嚇跑，之後原封不動游回來
  } else {
    Death& d = deaths[deathHead];
    d.sp = f.sp; d.var = f.var; d.nameIdx = f.nameIdx; d.cause = cause; d.day = env::day();
    deathHead = (deathHead + 1) % DEATH_LOG_CAP;
    if (deathN < DEATH_LOG_CAP) deathN++;
    deathTotal++;
  }
  for (int j = 0; j < n; j++) if (F[j].other == i) F[j].other = -1;
  f.on = false;
  f.owner = 0;
  f.manual = false;
}

void hurt(int i, float sec) {
  if (i < 0 || i >= n || !F[i].on) return;
  F[i].hurt = fmaxf(F[i].hurt, sec);
  F[i].bleed = fmaxf(F[i].bleed, fminf(sec, BLEED_MAX));
}

int spawnNew(float x, float y, float tx, float ty) {
  int slot = -1;
  for (int i = 0; i < acfg::FISH_CAP; i++) if (i >= n || !F[i].on) { slot = i; break; }
  if (slot < 0) return -1;
  Fish& f = F[slot];
  if (slot >= n) n = slot + 1;
  if (awayN > 0) {
    const Record r = away[--awayN];
    initFish(f, r.sp, r.pers, r.mood, r.energy);
    f.var = r.var; f.nameIdx = r.nameIdx; f.born = r.born;
  } else {
    // 新的、不同的魚：避開最近死掉的魚的 魚種+配色 組合
    uint8_t sp = 0, var = 0;
    for (int tries = 0; tries < 12; tries++) {
      sp = (uint8_t)rng.irange(0, SP_COUNT - 1);
      var = (uint8_t)(rng.chance(0.4f) ? 0 : rng.irange(1, 2));
      bool clash = false;
      for (int k = 0; k < deathN && k < ROSTER_TARGET; k++) {
        const Death& d = deathAt(k);
        if (d.sp == sp && d.var == var) clash = true;
      }
      if (!clash) break;
    }
    initFish(f, sp, (uint8_t)rng.irange(0, PERS_COUNT - 1), 0.5f, 0.7f);
    f.var = var;
    f.shy = 60;  // 剛進來的魚怕生一分鐘
  }
  f.x = x; f.y = y;
  f.dir = tx >= x ? 1 : -1;
  f.face = f.dir;
  setState(f, SWIM, rng.range(6, 10));
  f.tx = tx; f.ty = ty;
  clampTarget(f.tx, f.ty);
  f.spd = INFO[f.sp].speed * 0.8f;
  return slot;
}

void queueRefill(float firstDelay, float minGap, float maxGap) {
  refillOn = true;
  refillT = firstDelay;
  refillMin = minGap;
  refillMax = maxGap;
}
bool refilling() { return refillOn; }
void setRefillHold(bool hold) { refillHold = hold; }

int deathCount() { return deathTotal; }
int deathLogN() { return deathN; }
const Death& deathAt(int i) { return deaths[(deathHead - 1 - i + DEATH_LOG_CAP * 2) % DEATH_LOG_CAP]; }
void setDeaths(int total, int cnt, const Death* d) {
  deathHead = deathN = 0;
  for (int i = 0; i < cnt; i++) {
    deaths[deathHead] = d[i];
    deathHead = (deathHead + 1) % DEATH_LOG_CAP;
    if (deathN < DEATH_LOG_CAP) deathN++;
  }
  deathTotal = total > deathN ? total : deathN;
}

// 補魚：每隔一段時間從不同方向游進一條 (左、右、水面、岩石後、海帶後)
static void refillStep(float dt) {
  if (!refillOn || refillHold) return;
  if (alive() >= ROSTER_TARGET) { refillOn = false; return; }
  refillT -= dt;
  if (refillT > 0) return;
  refillT = rng.range(refillMin, refillMax);
  float x, y, tx = rng.range(60, 180), ty = rng.range(70, 150);
  bool behind = false;
  switch (rng.irange(0, 4)) {
    case 0: x = -20; y = rng.range(60, 150); break;
    case 1: x = 260; y = rng.range(60, 150); break;
    case 2: x = rng.range(50, 190); y = scene::SWIM_TOP - 2; ty = rng.range(60, 110); break;
    case 3: x = scene::ROCK_L.cx; y = scene::ROCK_L.cy - 6; behind = true; break;
    default: {
      float px, py;
      scene::plantPoint(rng.irange(0, scene::PLANT_N - 1), 0.4f, px, py);
      x = px; y = py; behind = true;
      break;
    }
  }
  int i = spawnNew(x, y, tx, ty);
  if (i >= 0 && behind) { F[i].layer = 0; F[i].wantLayer = 1; }  // 從東西後面鑽出來
}

void update(float dt, uint32_t ms) {
  // 群游目標
  for (int s = 0; s < SP_COUNT; s++) {
    schoolT[s] -= dt;
    if (schoolT[s] <= 0) {
      schoolT[s] = rng.range(5, 10);
      schoolX[s] = rng.range(40, 200);
      schoolY[s] = depthToY(rng.range(INFO[s].yMin, INFO[s].yMax), schoolX[s]);
    }
  }
  refillStep(dt);
  float moodSum = 0, energySum = 0;
  for (int i = 0; i < n; i++) {
    Fish& f = F[i];
    if (!f.on) continue;
    const Info& in = INFO[f.sp];
    f.stT -= dt;
    f.cd -= dt;
    if (f.inflate > 0) f.inflate -= dt;
    if (f.shy > 0) f.shy -= dt;
    if (f.torn > 0 && (f.tornT += dt) > 60) { f.tornT = 0; f.torn--; }  // 尾巴慢慢長回來
    if (f.hurt > 0) f.hurt -= dt;
    if (f.bleed > 0) {
      f.bleed -= dt;
      if (rng.chance(dt * (0.3f + 2.2f * f.bleed / BLEED_MAX))) particles::blood(f.x - f.dir * 4, f.y + 2, 1, 2);  // 剛被咬滴得多，慢慢止血
    }
    // 河豚的防禦性膨脹：有魚靠得太近時偶爾鼓起來
    if (f.sp == PUFFER && f.inflate <= 0 && f.owner == 0) {
      for (int j = 0; j < n; j++) {
        if (j == i || !F[j].on || F[j].sp == PUFFER) continue;
        float dx = F[j].x - f.x, dy = F[j].y - f.y;
        if (dx * dx + dy * dy < 15 * 15 && rng.chance(dt * 1.2f)) { f.inflate = f.inflateMax = 2.5f; break; }
      }
    }
    if (f.owner == 0 && f.stT <= 0) think(f, i);
    if (!f.manual) {
      if (f.owner == 0 || f.st == EAT) behave(f, i, dt, ms);
      steer(f, i, dt);
    }
    // 圖層：躲在岩石後面的魚，離開岩石範圍才回到前面
    if (f.owner == 0 && f.st != HIDE) f.wantLayer = 1;
    if (f.layer != f.wantLayer) {
      if (f.wantLayer == 0) f.layer = 0;
      else if (!gfx::rockAt((int)f.x, (int)f.y) && !gfx::rockAt((int)f.x - 10, (int)f.y) && !gfx::rockAt((int)f.x + 10, (int)f.y)) f.layer = 1;
    }
    // 朝向 + 轉身動畫
    if (!f.backward && fabsf(f.vx) > 2.5f) {
      int8_t want = f.vx > 0 ? 1 : -1;
      if (want != f.dir) f.dir = want;
    }
    f.face = util::approach(f.face, (float)f.dir, dt * 6);
    // 擺尾 / 起伏
    const float speedRatio = util::clamp01(sqrtf(f.vx * f.vx + f.vy * f.vy) / in.fast);
    f.tail += dt * in.tailFreq * (0.5f + speedRatio * 1.5f + f.tailBoost);
    f.bob += dt * 1.6f;
    if (f.tail > 1000) f.tail -= 4 * 3.14159265f * 80;  // 保持數值小 (擺尾用 0.5 倍相位，所以以 4π 為週期)
    if (f.bob > 1000) f.bob -= 2 * 3.14159265f * 150;
    // 精力與心情 (只影響行為，不會造成死亡)
    f.energy = util::clamp01(f.energy - dt * speedRatio * 0.004f + (f.st == SLEEP || f.st == REST ? dt * 0.004f : 0));
    f.mood += (0.6f - f.mood) * dt * 0.002f;
    if (f.st == PLAY || f.st == SCHOOL) f.mood = fminf(1, f.mood + dt * 0.002f);
    if (f.glint >= 0) { f.glint += dt * 0.8f; if (f.glint > 1.2f) f.glint = -1; }
    moodSum += f.mood;
    energySum += f.energy;
  }
  const int al = alive();
  if (al > 0) { env::eco.fishMood = moodSum / al; env::eco.fishEnergy = energySum / al; }
}

void draw(uint8_t layer) {
  for (int i = 0; i < n; i++) {
    const Fish& f = F[i];
    if (!f.on || f.layer != layer) continue;
    const Info& in = INFO[f.sp];
    // 河豚：受驚時 半膨脹 → 完全膨脹，快結束時再回到半膨脹
    const SpriteDef* s = in.spr;
    if (f.sp == PUFFER && f.inflate > 0) {
      const float total = f.inflateMax > 0 ? f.inflateMax : 3;
      s = (f.inflate > total - 0.35f || f.inflate < 0.6f) ? &spr::puffer_half : &spr::puffer_full;
    }
    gfx::SprOpt o;
    // 轉身：寬度以 100% / 60% / 30% 的方塊階梯變化 (不做平滑縮放)
    const float af = fabsf(f.face);
    const float q = af > 0.8f ? 1.0f : (af > 0.45f ? 0.6f : 0.3f);
    o.xs = f.face < 0 ? -q : q;
    // 游泳動畫：擺尾相位每 1/4 圈換一格 (低影格數)；休息/睡覺固定第 0 格
    o.frame = (f.st == SLEEP && f.eyesClosed) ? 0 : (int)(f.tail / 1.5708f);
    o.px = (f.closer > 0.5f || f.swell > 0.5f) ? acfg::FISH_PX + 1 : acfg::FISH_PX;
    if (f.torn > 0) { o.u0 = f.torn; o.woundU = gore::death() ? f.torn : 255; }  // 被咬掉的尾巴
    o.tailPhase = f.tail;
    o.tailAmp = 0;
    o.wave = f.wiggle > 0.3f ? 2.0f : 0.0f;
    o.eyesClosed = f.eyesClosed;
    o.behindRock = layer == 0;
    o.glint = f.glint;
    o.hue = f.var;
    if (f.bleed > 0 && gore::death() && ((int)(f.bleed * 4) & 1)) { o.tint = 0xff2020; o.tintA = 110; }  // 剛被咬：閃紅
    // 方塊像素：位置與起伏都對齊 2px 美術格
    const float bob = util::fsin(f.bob) > 0.3f ? 2.0f : 0.0f;
    gfx::sprite(*s, (float)(((int)f.x) & ~1), (float)((((int)(f.y)) & ~1) + (int)bob), o);
  }
}

// ---- 給事件/互動用 ----
int pick(uint32_t spMask, bool allowSleep) {
  int cand[acfg::FISH_CAP], c = 0;
  for (int i = 0; i < n; i++) {
    const Fish& f = F[i];
    if (!f.on || f.owner || f.manual || !(spMask & (1u << f.sp))) continue;
    if (!allowSleep && f.st == SLEEP && f.eyesClosed) continue;
    cand[c++] = i;
  }
  return c ? cand[rng.irange(0, c - 1)] : -1;
}

int pickNear(float x, float y, int exclude) {
  int best = -1;
  float bd = 1e9f;
  for (int i = 0; i < n; i++) {
    if (i == exclude || !F[i].on || F[i].manual) continue;
    float dx = F[i].x - x, dy = F[i].y - y, d = dx * dx + dy * dy + rng.range(0, 900);
    if (d < bd) { bd = d; best = i; }
  }
  return best;
}

int pickSize(uint8_t minSize, uint8_t maxSize) {
  uint32_t mask = 0;
  for (int s = 0; s < SP_COUNT; s++) if (INFO[s].size >= minSize && INFO[s].size <= maxSize) mask |= 1u << s;
  return pick(mask);
}

int freeCount() {
  int c = 0;
  for (int i = 0; i < n; i++) if (F[i].on && !F[i].owner && !F[i].manual) c++;
  return c;
}

void claim(int i, uint8_t owner) {
  if (i < 0 || i >= n) return;
  F[i].owner = owner;
  F[i].eyesClosed = false;
  F[i].wiggle = 0;
}

void release(int i) {
  if (i < 0 || i >= n) return;
  Fish& f = F[i];
  f.owner = 0;
  f.manual = false;
  f.backward = false;
  f.wiggle = 0;
  f.tailBoost = 0;
  f.closer = 0;
  f.eyesClosed = false;
  f.wantLayer = 1;
  if (f.y < scene::SWIM_TOP - 6) f.y = scene::SWIM_TOP;  // 跳出水面途中結束 → 放回水裡
  f.stT = 0;  // 下一幀重新思考
}

void releaseOwner(uint8_t owner) {
  for (int i = 0; i < n; i++) if (F[i].owner == owner) release(i);
}

void command(int i, State st, float tx, float ty, float spd, float dur) {
  if (i < 0 || i >= n) return;
  Fish& f = F[i];
  setState(f, st, dur);
  clampTarget(tx, ty);
  f.tx = tx;
  f.ty = ty;
  if (spd > 0) f.spd = spd;
  f.manual = false;
}

void moveTo(int i, float x, float y, float dt) {
  if (i < 0 || i >= n) return;
  Fish& f = F[i];
  f.manual = true;
  if (dt > 0) { f.vx = (x - f.x) / dt; f.vy = (y - f.y) / dt; }
  f.x = x;
  f.y = y;
}

bool near(int i, float x, float y, float r) {
  if (i < 0 || i >= n) return false;
  float dx = F[i].x - x, dy = F[i].y - y;
  return dx * dx + dy * dy <= r * r;
}

float halfW(int i) { return (i >= 0 && i < n) ? INFO[F[i].sp].spr->w * acfg::FISH_PX * 0.5f : 8; }
float mouthX(int i) { return (i >= 0 && i < n) ? F[i].x + F[i].dir * halfW(i) : 0; }

void startle(float x, float y, float r) {
  for (int i = 0; i < n; i++) {
    Fish& f = F[i];
    if (!f.on || f.owner || f.manual) continue;
    float dx = f.x - x, dy = f.y - y;
    if (dx * dx + dy * dy > r * r) continue;
    setState(f, FLEE, rng.range(1.5f, 3));
    f.other = -1;
    float d = sqrtf(dx * dx + dy * dy) + 0.01f;
    f.tx = f.x + dx / d * 60;
    f.ty = f.y + dy / d * 40 + 20;
    clampTarget(f.tx, f.ty);
    if (f.sp == PUFFER) { f.inflate = 4; f.inflateMax = 4; }
  }
}

void attract(float x, float y, int cnt) {
  for (int k = 0; k < cnt; k++) {
    int i = pickNear(x, y, -1);
    if (i < 0 || F[i].owner || F[i].manual) continue;
    setState(F[i], INSPECT, rng.range(3, 6));
    F[i].tx = x + rng.range(-30, 30);
    F[i].ty = y + rng.range(-20, 20);
    clampTarget(F[i].tx, F[i].ty);
    F[i].spd = INFO[F[i].sp].speed * 1.5f;
  }
}

void clampTarget(float& x, float& y) {
  x = util::clamp(x, (float)scene::SWIM_LEFT, (float)scene::SWIM_RIGHT);
  y = util::clamp(y, (float)scene::SWIM_TOP, (float)scene::swimBottom((int)x));
}

}  // namespace fish
