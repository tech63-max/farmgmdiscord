// 屍體、被咬斷的半截魚、魚骨、沙地上的血跡 (血腥效果「完整」才會出現)
#pragma once
#include <stdint.h>

namespace remains {

enum Kind : uint8_t { CORPSE, HALF_HEAD, HALF_TAIL, BONES, STAIN, KIND_COUNT };

struct R {
  bool on;
  uint8_t kind, sp, var;
  int8_t dir;
  bool landed;
  float x, y, vx, vy;
  float t, life;     // 已經過秒數 / 剩餘秒數
  float eaten;       // 0..1 被清道夫吃掉的程度 (到 1 變成魚骨)
  float bloat;       // 浮屍：> 0 往上浮
  float w;           // 血跡寬度
};

void begin();
void update(float dt);
void drawGround();   // 沙地血跡 (在魚之前畫)
void draw();         // 屍體、半截、魚骨

// 從活著的魚建立 (魚本身由 fish::kill 移除)
int corpse(int fishIdx);              // 整條翻肚子往下沉，一路滲血
void halves(int fishIdx, float push); // 被咬成兩半，往兩邊飛開再沉下去
int bones(float x, float y);          // 直接放一副魚骨
int corpseFrom(uint8_t sp, uint8_t var, float x, float y, int8_t dir);
void stain(float x, float w);         // 沙地血跡

int count(Kind k);
int find(Kind k);                     // 第一個 (-1 = 沒有)
R& at(int i);
int cap();
void remove(int i);
void nibble(int i, float amount);     // 被吃掉一點 (屍體 → 魚骨)
void clear();

}  // namespace remains
