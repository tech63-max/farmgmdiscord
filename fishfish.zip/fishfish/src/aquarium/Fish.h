// 魚類：種類資料、獨立行為狀態機、群游、互動、繪製
#pragma once
#include <stdint.h>
#include "../config/AquariumConfig.h"
#include "../gfx/Sprite.h"

namespace fish {

enum State : uint8_t {
  IDLE, SWIM, FAST, TURN, EXPLORE, FOLLOW, CHASE, FLEE, REST, HIDE, EAT, PLAY, SLEEP, INSPECT, SCHOOL, ST_COUNT
};
enum Species : uint8_t { COD, SALMON, PUFFER, TROP_OW, TROP_BY, TROP_PURPLE, TROP_BLACK, TROP_RW, LEMON, SP_COUNT };
enum Pers : uint8_t { CALM, PLAYFUL, SHY, CURIOUS, LAZY, PERS_COUNT };

struct Info {
  const char* name;
  const SpriteDef* spr;
  float speed, fast;     // 巡游 / 衝刺速度 (px/s)
  float yMin, yMax;      // 偏好的水深 (0 = 水面, 1 = 底部)
  float social;          // 群游傾向
  float bold;            // 膽量 (低 = 容易躲藏)
  float playful;
  float nightRest;       // 夜晚休息傾向
  float tailAmp, tailFreq;
  uint8_t size;          // 0 小, 1 中, 2 大
};
const Info& info(uint8_t sp);
const char* stateName(uint8_t st);
const char* persName(uint8_t p);

struct Fish {
  bool on;
  uint8_t sp, pers;
  uint8_t owner;          // 0 = 自由，否則 = 控制它的事件槽 + 1
  State st;
  float x, y, vx, vy;
  float tx, ty, spd;      // 目標點與期望速度
  float stT;              // 目前狀態剩餘秒數
  float face;             // 繪製時的水平縮放 (-1..1，轉身時經過 0)
  int8_t dir;             // 面向：+1 右，-1 左
  float tail, bob;
  float mood, energy;     // 0..1
  float cd;               // 行為冷卻
  int8_t other;           // 跟隨/追逐對象
  uint8_t layer, wantLayer;  // 0 = 在水草/岩石後面，1 = 一般
  bool manual;            // 事件直接控制座標 (跳躍、繞圈…)
  bool backward;          // 倒退游 (不轉身)
  bool eyesClosed;
  float wiggle;           // 身體波動幅度
  float tailBoost;        // 擺尾加強
  float closer;           // 0..1 靠近觀賞者 (放大)
  float glint;            // >= 0 反光帶位置
  float inflate;          // 河豚膨脹剩餘秒數
  float inflateMax;       // 這次膨脹的總秒數 (決定半膨脹/完全膨脹)
  uint32_t lastAte;
  // ---- 個體資料 (會存檔)：魚死掉後游回來的新魚，魚種/配色/名字都不同 ----
  uint8_t var;            // 配色變體 0..2
  uint8_t nameIdx;        // 名字 (NAMES 索引)
  uint32_t born;          // 進缸的虛擬天
  float hurt;             // 受傷剩餘秒數 (> 0 = 游得慢、躲起來休養)
  float bleed;            // 流血剩餘秒數 (被咬後最多 40 秒，越來越少；不存檔)
  float shy;              // 新來的魚怕生剩餘秒數
  uint8_t torn;           // 尾巴被咬掉的欄數 (每 60 秒長回一欄)
  float tornT;
  float swell;            // 0..1 吃太多撐大
};

// 一條魚的存檔資料
struct Record {
  uint8_t sp, pers, var, nameIdx;
  float mood, energy, hurt;
  uint32_t born;
};
// 死亡紀錄
struct Death {
  uint8_t sp, var, nameIdx, cause;  // cause = 造成死亡的事件 ID
  uint32_t day;
};
constexpr int ROSTER_TARGET = 9;    // 魚缸正常的魚數 (死掉會慢慢補回來)
constexpr int DEATH_LOG_CAP = 20;

extern Fish F[acfg::FISH_CAP];

void begin();                     // 預設魚缸成員
void setRoster(int n, const uint8_t* sp, const uint8_t* pers, const float* mood, const float* energy);  // 舊存檔 (只有魚種/性格)
void setRecords(int n, const Record* r);  // 新存檔：完整個體資料，讀到什麼就是什麼
Record record(int i);
int count();                      // 魚陣列使用到的長度 (迴圈上限；中間可能有 on = false 的空位)
int alive();                      // 活著的魚數
const char* nameOf(int i);
const char* nameAt(uint8_t nameIdx);

// ---- 死亡與補魚 ----
void kill(int i, uint8_t cause);  // 魚死掉 (從魚缸移除，寫入死亡紀錄)
void hurt(int i, float sec);      // 受傷 (流血、游得慢，時間到自己痊癒)
// 新的、不同的魚從畫面邊緣游進來；回傳索引 (-1 = 滿了)
int spawnNew(float x, float y, float tx, float ty);
void queueRefill(float firstDelay, float minGap, float maxGap);  // 慢慢補回到 ROSTER_TARGET 條
bool refilling();
void setRefillHold(bool hold);    // 鯊魚襲擊中：暫停補魚
int deathCount();                 // 累計死亡
const Death& deathAt(int i);      // 0 = 最新
int deathLogN();
void setDeaths(int total, int n, const Death* d);  // 讀檔 (舊 → 新)
void update(float dt, uint32_t ms);
void draw(uint8_t layer);

// ---- 給事件/互動用 ----
int pick(uint32_t spMask = 0xFFFFFFFF, bool allowSleep = false);  // 隨機挑一條自由的魚
int pickNear(float x, float y, int exclude = -1);
int pickSize(uint8_t minSize, uint8_t maxSize);
int freeCount();
void claim(int i, uint8_t owner);
void release(int i);
void releaseOwner(uint8_t owner);
void command(int i, State st, float tx, float ty, float spd, float dur = 9999);
void moveTo(int i, float x, float y, float dt);   // manual 模式下直接設位置 (自動算朝向)
bool near(int i, float x, float y, float r);
float mouthX(int i);
float halfW(int i);
void startle(float x, float y, float r);  // 嚇一跳 → 散開 (自由的魚)
void attract(float x, float y, int n);     // 吸引幾條自由的魚過來觀察
void clampTarget(float& x, float& y);

}  // namespace fish
