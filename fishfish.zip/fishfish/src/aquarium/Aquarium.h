// 水族箱整體：初始化、模擬更新、渲染順序
#pragma once
#include <stdint.h>

namespace aquarium {
void begin();
void updateAi(float dt, uint32_t ms);     // 魚類/訪客/粒子 (約 25 次/秒)
void updateFrame(float dt, uint32_t ms);  // 環境/場景動畫/事件
void render();                            // 畫整個場景到 gfx::fb (不含 UI)
void feed(uint32_t ms);
void tap(uint32_t ms);
void air(uint32_t ms);
// 效能檢查：render 各階段耗時 (us)：0 背景 1 光束 2 後景 3 裝飾 4 魚 5 前景+粒子 6 水面 7 分級 8 發光 9 updateFrame
constexpr int PROF_N = 10;
extern uint32_t prof[PROF_N];
}
