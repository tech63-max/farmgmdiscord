// 方塊像素風 (Voxel) 水下場景
// 場景的美術像素是 3x3 螢幕像素 (魚是 2x2，所以場景顯得比較大)。地形以 12x12 的「方塊」為單位
// (每個方塊是 4x4 美術像素的低解析度材質)，頂面亮、接縫暗；珊瑚由 6px 小方塊堆疊，水草/海帶以 3px 階梯擺動。
#include "Scene.h"
#include <math.h>
#include <string.h>
#include "../config/AquariumConfig.h"
#include "../core/Util.h"
#include "../gfx/Gfx.h"
#include "../gfx/SpriteData.h"
#include "Environment.h"

namespace scene {

Plant plants[PLANT_N] = {
    // x, type, height(場景美術像素 = 3px), blades, front, shade, extra, grow, phase
    {78, RIBBON, 36, 0, false, 0, 0, 1, 0.0f},   // 海帶
    {98, FAN, 14, 5, true, 1, 0, 1, 1.3f},       // 前景高海草叢 (可躲藏)
    {146, RIBBON, 45, 0, false, 0, 0, 1, 2.1f},  // 海帶
    {56, GRASS, 4, 4, true, 2, 0, 1, 0.7f},      // 矮海草
    {170, RIBBON, 27, 0, false, 0, 0, 1, 3.3f},  // 海帶
    {226, FAN, 20, 4, true, 1, 0, 1, 4.2f},      // 前景高海草叢 (可躲藏)
    {64, GLOWP, 4, 3, false, 3, 0, 1, 5.0f},     // 小型發光植物
    {130, GRASS, 3, 4, true, 2, 0, 1, 2.6f},     // 矮海草
};

namespace {
float t = 0;
constexpr int MAX_EXTRA = 3;
constexpr int AP = 3;           // 場景的一個美術像素 = 3x3 螢幕像素 (魚是 2x2，場景比較粗)
constexpr int BLK = AP * 4;     // 地形方塊邊長 12px (4x4 美術像素的低解析度材質)
constexpr int COLS = 240 / BLK;

// 地面高度 (方塊數，從畫面底部算起)
const uint8_t GH[COLS] = {4, 4, 3, 3, 3, 3, 3, 3, 2, 3, 3, 3, 3, 3, 2, 2, 3, 3, 4, 4};
// 岩丘高度 (方塊數，從地面算起)：左大右小
const uint8_t ML[COLS] = {4, 4, 3, 3, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 2, 1, 0};

enum Mat : uint8_t { M_SAND, M_GRAVEL, M_STONE, M_MOSSY, M_CRYSTAL, M_ORE, M_CAVE };
// 材質色：暗、中、亮、頂面
const uint32_t MATC[][4] = {
    {0xd2b878, 0xe4cc90, 0xf2e2b0, 0xfaf0d0},  // 沙
    {0x5a5654, 0x76726e, 0x96928c, 0xaaa6a0},  // 礫石
    {0x66666e, 0x84848c, 0xa2a2aa, 0xb8b8c0},  // 石頭
    {0x66666e, 0x84848c, 0xa2a2aa, 0x5cb044},  // 苔石 (頂面綠)
    {0x146e6c, 0x22a09a, 0x58e0d6, 0x9ef8f0},  // 藍綠晶體岩
    {0x34343e, 0x464652, 0x5a5a66, 0x6a6a76},  // 發光礦石 (礦點另外畫)
    {0x120e18, 0x120e18, 0x1c1824, 0x1c1824},  // 洞穴
};
const uint32_t WATER[] = {0x5ccdf4, 0x40b8ee, 0x2ca2e4, 0x228cd8, 0x1c76c6, 0x1660b0};

// 植物色組：外框/暗、中、亮、尖端
const uint32_t KELP[] = {0x2a6a24, 0x3e8e30, 0x64b440, 0xa6d856};
const uint32_t SEAG[] = {0x186c34, 0x24944a, 0x46c060, 0x96ec80};
const uint32_t SHORTG[] = {0x1c7a3a, 0x2ca452, 0x56cc64, 0xb0f08c};
const uint32_t GLOWC[] = {0x1a4a5a, 0x2a7a8a, 0x60e0f0, 0xc8ffff};
const uint32_t* PLANT_PAL[] = {KELP, SEAG, SHORTG, GLOWC};
// 珊瑚色組：暗、中、亮
const uint32_t C_PINK[] = {0xa8205e, 0xe8448e, 0xff8cc4};
const uint32_t C_MAGENTA[] = {0x6e1c84, 0xb03cc8, 0xe080f4};
const uint32_t C_YELLOW[] = {0xb08410, 0xecc428, 0xfff08a};
const uint32_t C_BLUE[] = {0x1a3aa8, 0x2c64ec, 0x84b0ff};
const uint32_t C_ORANGE[] = {0xb0420e, 0xf47424, 0xffb87a};
const uint32_t C_RED[] = {0x96141e, 0xdc3038, 0xff8a8a};
const uint32_t C_TEAL[] = {0x0e7a6e, 0x1cb8a4, 0x7af0dc};

struct Ripple { float x, r, life; bool on; };
Ripple ripples[6];
struct Debris { float x, life; bool on; };
Debris debris[acfg::DEBRIS_CAP];
struct Pt { int16_t x, y; };
Pt algae[acfg::ALGAE_CAP];
int algaeN = 0;
Pt tips[48];  // 本幀植物尖端 (發光用)
int tipN = 0;
Pt ores[8];   // 發光礦點
int oreN = 0;
Pt shrooms[4];  // 發光菌
int shroomN = 0;
int16_t baseY[PLANT_N];

int colOf(int x) { return util::clamp(x, 0, 239) / BLK; }
int groundTop(int c) { return 240 - GH[c] * BLK; }
int moundTop(int c) { return ML[c] ? groundTop(c) - ML[c] * BLK : 999; }

// ---- 烘焙：直接寫背景緩衝 ----
inline void bgPx(int x, int y, uint32_t c) {
  if ((unsigned)x < 240u && (unsigned)y < 240u) gfx::bg[y * gfx::W + x] = gfx::rgb(c);
}
inline void bgArt(int x, int y, uint32_t c) {  // 一個場景美術像素 (3x3)
  for (int j = 0; j < AP; j++)
    for (int i = 0; i < AP; i++) bgPx(x + i, y + j, c);
}
// 岩石遮罩 (遮罩解析度 2px)
void maskRect(int x, int y, int w, int h) {
  for (int cy = y / 2; cy <= (y + h - 1) / 2; cy++)
    for (int cx = x / 2; cx <= (x + w - 1) / 2; cx++) gfx::setRock(cx, cy);
}
// 每幀畫的場景方塊像素 (3x3)
inline void pb(int x, int y, uint16_t c) { gfx::fillRect(x, y, AP, AP, c); }
uint32_t mixc(uint32_t a, uint32_t b, float t) {
  int r = (int)(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
  int g = (int)(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
  int bl = (int)((a & 255) * (1 - t) + (b & 255) * t);
  return (r << 16) | (g << 8) | bl;
}
uint32_t darken(uint32_t c, float k) { return mixc(c, 0x000000, k); }

// 一個 12x12 方塊 (4x4 美術像素的低解析度材質)
void drawBlock(int bx, int by, Mat m, bool topExposed, bool mask, float shade = 0) {
  const uint32_t* C = MATC[m];
  for (int j = 0; j < 4; j++)
    for (int i = 0; i < 4; i++) {
      const uint32_t h = util::hash2(bx * 4 + i, by * 4 + j);
      uint32_t c = C[1];
      const int r = h % 10;
      if (r < 2) c = C[0];
      else if (r > 8) c = C[2];
      if (m == M_SAND && r == 9 && (h >> 8) % 3 == 0) c = 0xc0a070;  // 小石粒
      if (m == M_CRYSTAL && ((i + j) % 3 == 0)) c = C[2];            // 晶面
      if (m == M_CRYSTAL && i == 3) c = C[0];
      if (topExposed && j == 0) c = C[3];                             // 頂面亮
      if (m == M_MOSSY && topExposed && j == 1 && (h >> 4) % 2) c = 0x3e8a32;  // 苔蘚往下垂
      if (i == 3 || j == 3) c = darken(c, 0.18f);                     // 方塊接縫
      if (shade > 0) c = darken(c, shade);
      if (m == M_ORE && (h >> 12) % 5 == 0 && j > 0 && i < 3) c = 0x50f0ff;  // 礦點
      bgArt(bx + i * AP, by + j * AP, c);
    }
  if (mask) maskRect(bx, by, BLK, BLK);
}

// 珊瑚的小方塊 (2x2 美術像素)：左上亮、右下暗
constexpr int CB = AP * 2;
void cube(int x, int y, const uint32_t* C, bool mask) {
  bgArt(x, y, C[2]);
  bgArt(x + AP, y, C[1]);
  bgArt(x, y + AP, C[1]);
  bgArt(x + AP, y + AP, C[0]);
  if (mask) maskRect(x, y, CB, CB);
}
// 分枝珊瑚：往上長，隨機往左右跨一格、偶爾分岔
void branchCoral(int x, int baseY, int len, const uint32_t* C, uint32_t seed, int depth, bool mask) {
  int cx = x, cy = baseY - CB;
  for (int i = 0; i < len; i++) {
    cube(cx, cy, C, mask);
    const uint32_t h = util::hash32(seed + i * 977);
    if (depth > 0 && i > 0 && i < len - 2 && h % 4 == 0) {
      const int dx = (h >> 4) & 1 ? CB : -CB;
      cube(cx + dx, cy, C, mask);
      branchCoral(cx + dx, cy, len - i - 1, C, seed * 31 + i, depth - 1, mask);
    }
    if ((h >> 8) % 3 == 0) cx += ((h >> 10) & 1) ? CB : -CB;
    cy -= CB;
  }
}
// 腦珊瑚：一層層縮小的方塊圓頂，溝紋用暗色交錯
void brainCoral(int cx, int baseY, int w, const uint32_t* C, bool mask) {
  for (int row = 0; w - row * 2 > 0; row++) {
    const int n = w - row * 2;
    for (int k = 0; k < n; k++) {
      const int x = cx - n * CB / 2 + k * CB, y = baseY - CB - row * CB;
      cube(x, y, C, mask);
      if ((k + row) % 2) { bgArt(x, y, C[1]); bgArt(x + AP, y + AP, C[0]); }  // 溝紋
    }
  }
}
// 管狀珊瑚：幾根直立方塊管，頂端是暗色開口
void tubeCoral(int x, int baseY, int n, const uint32_t* C, uint32_t seed, int hmin, bool mask) {
  for (int k = 0; k < n; k++) {
    const int tx = x + k * (CB + AP) - n * CB / 2, h = hmin + (int)(util::hash32(seed + k * 13) % 3);
    for (int i = 0; i < h; i++) cube(tx, baseY - CB - i * CB, C, mask);
    bgArt(tx, baseY - CB - (h - 1) * CB, C[2]);
    bgArt(tx + AP, baseY - CB - (h - 1) * CB, 0x1a0e20);
  }
}
// 底部菌類：方塊蘑菇
void mushroom(int x, int baseY, uint32_t cap, uint32_t dot) {
  bgArt(x, baseY - AP, 0xe8dcc8);
  bgArt(x, baseY - AP * 2, 0xd8ccb8);
  for (int i = -2; i <= 2; i++) bgArt(x + i * AP, baseY - AP * 3, cap);
  for (int i = -1; i <= 1; i++) bgArt(x + i * AP, baseY - AP * 4, cap);
  bgArt(x - AP, baseY - AP * 4, dot);
  bgArt(x + AP, baseY - AP * 3, dot);
}

// 遠景 / 中景的方塊剪影高度 (每 12px 一欄)
int farTop(int c) {
  static const uint8_t F[COLS] = {12, 12, 13, 11, 10, 11, 12, 13, 12, 11, 10, 11, 12, 13, 13, 12, 10, 11, 12, 13};
  return 240 - F[c] * BLK;
}
int midTop(int c) {
  static const uint8_t M[COLS] = {7, 8, 8, 7, 6, 6, 7, 9, 9, 7, 6, 6, 7, 8, 9, 9, 8, 7, 7, 8};
  return 240 - M[c] * BLK;
}

void bake() {
  // 1) 水 (每個方塊一個色階，帶一點雜訊 → 低解析度水體材質) + 遠景/中景剪影
  for (int by = 0; by < 240; by += BLK)
    for (int bx = 0; bx < 240; bx += BLK) {
      const int c = bx / BLK;
      const float d = (float)(by - SURFACE_Y) / (200 - SURFACE_Y);
      const float lx = (bx - 236) / 210.0f, ly = by / 170.0f;
      const float light = util::clamp01(1 - sqrtf(lx * lx + ly * ly));
      const float n = ((util::hash2(bx, by) % 100) / 100.0f - 0.5f) * 0.7f;
      uint32_t col = WATER[util::clamp((int)(d * 5.6f - light * 1.8f + n), 0, 5)];
      bool far = by >= farTop(c), mid = by >= midTop(c);
      if (far) col = mixc(col, 0x9ad0f8, 0.38f);
      if (mid) col = mixc(col, (util::hash32(c / 3 + 5) % 2) ? 0x3a64b8 : 0x5a5cb8, 0.5f);
      for (int y = 0; y < BLK; y++)
        for (int x = 0; x < BLK; x++) {
          uint32_t v = col;
          if ((far && !mid && by == farTop(c) && y < AP) || (mid && by == midTop(c) && y < AP)) v = mixc(col, 0xffffff, 0.18f);  // 剪影頂面
          if (mid && (x >= BLK - 1 || y >= BLK - 1)) v = darken(v, 0.08f);  // 中景方塊接縫
          bgPx(bx + x, by + y, v);
        }
    }
  // 2) 水面以上
  for (int y = 0; y < SURFACE_Y; y++)
    for (int x = 0; x < 240; x++) bgPx(x, y, y < 4 ? 0x16263a : (y < 10 ? 0xb4ecfc : 0xd0f6ff));
  for (int x = 0; x < 240; x++) { bgPx(x, SURFACE_Y, 0x96e2fa); bgPx(x, SURFACE_Y + 1, 0x96e2fa); }

  // 3) 地面方塊 (頂層沙或礫石，下面的沙越深越暗)
  for (int c = 0; c < COLS; c++) {
    const int top = groundTop(c);
    for (int by = top; by < 240; by += BLK) {
      const int level = (by - top) / BLK;
      Mat m = M_SAND;
      if (level == 0 && (c == 7 || c == 12 || c == 19)) m = M_GRAVEL;
      drawBlock(c * BLK, by, m, level == 0, false, level * 0.08f);
    }
  }
  // 4) 岩丘 (石頭/苔石/晶體/發光礦石)，會遮住躲在後面的魚
  oreN = 0;
  for (int c = 0; c < COLS; c++) {
    for (int l = 0; l < ML[c]; l++) {
      const int by = groundTop(c) - (l + 1) * BLK;
      const bool top = l == ML[c] - 1;
      Mat m = top ? M_MOSSY : M_STONE;
      if ((c == 3 && top) || (c == 17 && top) || (c == 1 && l == 1)) m = M_CRYSTAL;
      if ((c == 0 && l == 2) || (c == 16 && l == 0)) m = M_ORE;
      if (c == 4 && l == 0) m = M_CAVE;  // 螃蟹的小洞
      drawBlock(c * BLK, by, m, top, true);
      if (m == M_ORE && oreN < 8) ores[oreN++] = {(int16_t)(c * BLK + BLK / 2), (int16_t)(by + BLK / 2)};
    }
  }
  // 晶體尖刺
  const int crystalCols[] = {3, 17};
  for (int c : crystalCols) {
    const int y = moundTop(c);
    for (int k = 0; k < 3; k++) bgArt(c * BLK + AP, y - AP - k * AP, k == 2 ? 0x9ef8f0 : 0x58e0d6);
    bgArt(c * BLK + AP * 3, y - AP, 0x58e0d6);
    bgArt(c * BLK + AP * 3, y - AP * 2, 0x9ef8f0);
    maskRect(c * BLK + AP, y - AP * 3, AP, AP * 3);
  }

  // 5) 體素珊瑚
  brainCoral(14, moundTop(1), 4, C_YELLOW, true);
  branchCoral(26, moundTop(2), 7, C_PINK, 11, 2, true);
  branchCoral(32, moundTop(2), 5, C_PINK, 19, 1, true);
  tubeCoral(52, moundTop(4), 2, C_BLUE, 5, 2, true);
  branchCoral(194, moundTop(16), 7, C_MAGENTA, 23, 2, true);
  brainCoral(212, moundTop(17), 3, C_ORANGE, true);
  tubeCoral(184, moundTop(15), 2, C_TEAL, 9, 2, true);
  branchCoral(230, groundTop(19), 6, C_YELLOW, 41, 1, false);
  branchCoral(120, groundTop(10), 4, C_RED, 53, 1, false);
  brainCoral(92, groundTop(7), 3, C_PINK, false);
  tubeCoral(158, groundTop(13), 2, C_YELLOW, 61, 2, false);
  // 6) 底部菌類 (紅蘑菇 + 會發光的藍綠蘑菇)
  mushroom(136, groundTop(11), 0xd83030, 0xffe8e8);
  mushroom(112, groundTop(9), 0xc87830, 0xffe0b8);
  shroomN = 0;
  const int gs[][2] = {{74, groundTop(6)}, {172, groundTop(14)}};
  for (auto& g : gs) {
    mushroom(g[0], g[1], 0x2ab8b0, 0xa0fff4);
    shrooms[shroomN++] = {(int16_t)g[0], (int16_t)(g[1] - AP * 3)};
  }

  // 藻類候選點：岩丘頂面 (順序固定，數量跟著 eco.algae)
  algaeN = 0;
  for (int k = 0; k < 400 && algaeN < acfg::ALGAE_CAP; k++) {
    const int c = util::hash32(k * 7919 + 13) % COLS;
    if (!ML[c]) continue;
    const int x = c * BLK + (util::hash32(k) % 3) * AP;
    bool dup = false;
    for (int j = 0; j < algaeN; j++) if (abs(algae[j].x - x) < 5) dup = true;
    if (dup) continue;
    algae[algaeN++] = {(int16_t)x, (int16_t)(moundTop(c) + AP + (util::hash32(k * 3) % 2) * AP)};
  }
  for (int i = 0; i < PLANT_N; i++) {
    const int c = colOf(plants[i].x);
    baseY[i] = (int16_t)(ML[c] ? moundTop(c) : groundTop(c));
  }
}

// 擺動量：以 3px 為單位 (階梯式動畫)
float swayRaw(const Plant& p, float frac, float extraPhase) {
  float amp = p.type == RIBBON ? 8.0f : (p.type == FAN ? 5.0f : 2.0f);
  float lean = util::clamp(env::fx.current * 0.7f, -15.0f, 15.0f);
  return util::fsin(t * 1.3f + p.phase + extraPhase + frac * 2.2f) * amp * powf(frac, 1.4f) * env::fx.sway + lean * powf(frac, 1.2f);
}
int swayOff(const Plant& p, float frac, float extraPhase) { return ((int)lroundf(swayRaw(p, frac, extraPhase) / AP)) * AP; }

void addTip(int x, int y) { if (tipN < 48) tips[tipN++] = {(int16_t)x, (int16_t)y}; }

// 分段式海帶：每節 3 美術像素高，左右交錯長出小葉與氣囊
void drawKelp(int i, const Plant& p, const uint32_t* G) {
  const int segs = p.height / 3 + p.extra;
  for (int s = 0; s < segs; s++) {
    const bool isNew = p.extra && s == segs - 1;
    if (isNew && p.grow < 0.5f) break;
    const float frac = (float)s / (p.height / 3 + MAX_EXTRA);
    const int x = p.x + swayOff(p, frac, 0);
    const int y = baseY[i] - s * AP * 3;
    for (int k = 0; k < 3; k++) {
      pb(x, y - k * AP - AP, gfx::rgb(k == 2 ? G[2] : G[1]));
      pb(x + AP, y - k * AP - AP, gfx::rgb(G[0]));
    }
    if (s > 0 && s % 2 == 0) {  // 小葉 + 氣囊
      const int side = (s / 2) % 2 ? 1 : -1;
      const int lx = side > 0 ? x + AP * 2 : x - AP;
      pb(lx, y - AP * 2, gfx::rgb(G[2]));
      pb(lx + side * AP, y - AP * 3, gfx::rgb(G[2]));
      pb(lx + side * AP * 2, y - AP * 3, gfx::rgb(G[3]));
    }
    if (s == segs - 1) { pb(x, y - AP * 4, gfx::rgb(G[3])); addTip(x + 1, y - AP * 4 + 1); }
  }
}

// 高海草叢：每根草葉 1 美術像素寬，每 2 格才往旁邊挪一步 (階梯狀)
void drawSeagrass(int i, const Plant& p, const uint32_t* G) {
  const int n = p.blades + p.extra;
  for (int b = 0; b < n; b++) {
    const bool isNew = b >= p.blades && b == n - 1;
    const int bh = (int)(p.height * (0.6f + 0.4f * util::hashf(i * 17 + b, 5)) * (isNew ? p.grow : 1.0f));
    const int bx = p.x + (b - n / 2) * AP * 2;
    const float ph = b * 0.9f;
    for (int s = 0; s < bh; s++) {
      const float frac = (float)(s & ~1) / p.height;  // 每 2 格同一個位移 → 階梯
      const int x = bx + swayOff(p, frac, ph) + ((b - n / 2) * s) / 10 * AP;
      const uint32_t c = s >= bh - 2 ? G[3] : (s < 2 ? G[0] : ((b + s / 3) % 2 ? G[1] : G[2]));
      pb(x, baseY[i] - AP - s * AP, gfx::rgb(c));
    }
    if (bh > 0) addTip(bx + swayOff(p, (float)((bh - 1) & ~1) / p.height, ph) + 1, baseY[i] - AP - (bh - 1) * AP + 1);
  }
}

// 小型發光植物：細莖 + 頂端發光球
void drawGlowPlant(int i, const Plant& p, const uint32_t* G) {
  for (int b = 0; b < p.blades; b++) {
    const int bx = p.x + (b - 1) * AP * 3;
    const int h = p.height - (b % 2);
    for (int s = 0; s < h; s++) pb(bx + swayOff(p, (float)s / h * 0.5f, b), baseY[i] - AP - s * AP, gfx::rgb(G[0]));
    const int tx = bx + swayOff(p, 0.5f, b), ty = baseY[i] - AP - h * AP;
    pb(tx, ty, gfx::rgb(G[2]));
    pb(tx + AP, ty, gfx::rgb(G[1]));
    pb(tx, ty - AP, gfx::rgb(G[3]));
    addTip(tx + 1, ty + 1);
  }
}

void drawShortGrass(int i, const Plant& p, const uint32_t* G) {
  for (int b = 0; b < p.blades + p.extra; b++) {
    const int bh = p.height - 1 + (int)(util::hashf(i, b) * 3);
    const int bx = p.x - p.blades * AP + b * AP * 2;
    for (int s = 0; s < bh; s++) {
      const uint32_t c = s >= bh - 1 ? G[3] : (s < 1 ? G[0] : G[2]);
      pb(bx + swayOff(p, (float)(s & ~1) / (bh + 2), b) + ((b - p.blades / 2) * s) / 3 * AP, baseY[i] - AP - s * AP, gfx::rgb(c));
    }
  }
}

// 方塊式柔光 (3 階亮度，不做平滑漸層)
void blockGlow(int cx, int cy, int r, uint32_t hex, float k) { gfx::glow(cx, cy, r, hex, (uint8_t)(util::clamp01(k) * 255)); }
}  // namespace

int sandTop(int x) { return groundTop(colOf(x)); }

void begin() {
  memset(ripples, 0, sizeof(ripples));
  memset(debris, 0, sizeof(debris));
  bake();
}

void update(float dt) {
  t += dt;
  for (auto& r : ripples) {
    if (!r.on) continue;
    r.r += dt * 18;
    r.life -= dt;
    if (r.life <= 0) r.on = false;
  }
  for (auto& d : debris) {
    if (!d.on) continue;
    d.life -= dt;
    if (d.life <= 0) d.on = false;
  }
  for (auto& p : plants) if (p.grow < 1) p.grow = fminf(1, p.grow + dt * 0.08f);
}

void drawBackFx() {
  const env::Fx& f = env::fx;
  // 光束：從右上方照下來，每 8px 往左跨一步 (階梯狀)。白天常駐 (淡)，事件時更亮
  const float beams = fmaxf(f.beams, 0.42f * (1 - env::darkness()));
  if (beams > 0.01f) {
    for (int b = 0; b < 4; b++) {
      const int bx = 130 + b * 30 + ((int)(util::fsin(t * 0.15f + b * 1.7f) * 4)) * 2;
      const int w = 8 + (b % 2) * 8;
      for (int y = SURFACE_Y + 2; y < 200; y += BLK) {
        const float depth = (float)(y - SURFACE_Y) / 180.0f;
        const float flick = ((int)(t * 2 + b) % 3 == 0) ? 0.85f : 1.0f;
        const uint8_t a = (uint8_t)(beams * 70 * (1 - depth) * flick);
        if (a < 3) continue;
        const int x0 = bx - ((y - SURFACE_Y) / BLK) * (6 + b * 3);
        gfx::blendRect(x0, y, w, BLK, gfx::rgb(0xf0ffff), a);
      }
    }
  }
  // 光斑：地面上閃爍的亮方塊
  if (f.caustics > 0.01f) {
    for (int i = 0; i < 16; i++) {
      const int phase = (int)(t * 3 + i * 7) % 4;
      if (phase == 0) continue;
      const int x = ((int)(util::hashf(i, (int)(t * 0.5f)) * 76)) * AP;
      const int y = (i < 10) ? sandTop(x) + 2 : (60 + (int)(util::hashf(i, 9) * 110)) & ~3;
      gfx::blendRect(x, y, AP * 2 + (i % 2) * AP * 2, AP * 2, gfx::rgb(0xf0fcff), (uint8_t)(f.caustics * 40 * phase));
    }
  }
  // 巨大陰影 (方塊階梯狀的橢圓)
  if (f.shadowX > -500) {
    for (int y = SURFACE_Y; y < 96; y += 4) {
      const float dy = (y - 52) / 36.0f;
      if (fabsf(dy) >= 1) continue;
      const int hw = ((int)(80 * sqrtf(1 - dy * dy))) & ~3;
      gfx::blendRect(((int)f.shadowX - hw) & ~3, y, hw * 2, 4, gfx::rgb(0x061626), 90);
    }
  }
}

void drawPlants(bool front) {
  if (!front) tipN = 0;
  for (int i = 0; i < PLANT_N; i++) {
    const Plant& p = plants[i];
    if (p.front != front) continue;
    const uint32_t* G = PLANT_PAL[p.shade & 3];
    switch (p.type) {
      case RIBBON: drawKelp(i, p, G); break;
      case FAN: drawSeagrass(i, p, G); break;
      case GLOWP: drawGlowPlant(i, p, G); break;
      default: drawShortGrass(i, p, G); break;
    }
  }
  const env::Fx& f = env::fx;
  if (f.flower > 0.05f && f.flowerPlant >= 0 && plants[f.flowerPlant].front == front) {
    float x, y;
    plantPoint(f.flowerPlant, 1.0f, x, y);
    gfx::SprOpt o;
    o.px = f.flower > 0.6f ? 2 : 1;
    o.alpha = f.flower > 0.3f ? 255 : 140;
    gfx::sprite(spr::flower, (float)(((int)x) & ~1), (float)((((int)y) & ~1) - 4), o);
  }
}

void drawDecor() {
  const env::Fx& f = env::fx;
  for (auto& d : debris)
    if (d.on) pb(((int)d.x / AP) * AP, sandTop((int)d.x) - AP, gfx::rgb(d.life > 300 ? 0x7a5a2a : 0x8a7050));
  const int na = algaeVisible();
  for (int i = 0; i < na; i++) {
    pb(algae[i].x, algae[i].y, gfx::rgb(0x58a83a));
    if (i & 1) pb(algae[i].x + AP, algae[i].y - AP, gfx::rgb(0x8ad04a));
  }
  {
    const SpriteDef& s = f.shellOpen > 0.5f ? spr::shell_open : spr::shell_closed;
    gfx::SprOpt o;
    o.px = AP;
    gfx::sprite(s, SHELL_X, sandTop(SHELL_X) - s.h * AP / 2, o);
  }
  if (f.chestUp > 0.02f) {
    const SpriteDef& s = f.chestOpen > 0.5f ? spr::chest_open : spr::chest_closed;
    const int st = sandTop(CHEST_X);
    const int cy = st + 14 - ((int)(f.chestUp * 9)) * AP;
    gfx::SprOpt o;
    o.px = AP;
    gfx::sprite(s, CHEST_X, cy, o);
    for (int y = st; y < gfx::H; y++)
      memcpy(gfx::fb + y * gfx::W + CHEST_X - 20, gfx::bg + y * gfx::W + CHEST_X - 20, 40 * sizeof(uint16_t));
  }
  if (f.pearl > 0.3f) {  // 像素化的珍珠
    const int px = PEARL_X, py = sandTop(PEARL_X) - AP * 3;
    pb(px - AP, py, gfx::rgb(0xe8dcec)); pb(px, py, gfx::rgb(0xf8f0fa)); pb(px + AP, py, gfx::rgb(0xd8c8e0));
    pb(px, py - AP, gfx::rgb(0xffffff)); pb(px, py + AP, gfx::rgb(0xd0c0d8));
  }
}

void drawSurface() {
  const env::Fx& f = env::fx;
  // 水面：每 4px 一段，高低兩格的像素波動
  for (int x = 0; x < gfx::W; x += 4) {
    const float w = util::fsin(x * 0.07f + t * 1.8f) + 0.5f * util::fsin(x * 0.15f - t * 2.6f);
    const int y = SURFACE_Y - (w > 0.6f ? 2 : 0);
    const uint16_t c = gfx::rgb(w > 0.95f ? 0xffffff : 0xcaf0fc);
    gfx::block(x, y, c);
    gfx::block(x + 2, y, c);
  }
  // 漣漪：水面上往兩側擴散的短線
  for (auto& r : ripples) {
    if (!r.on) continue;
    const uint8_t a = (uint8_t)(220 * util::clamp01(r.life / 1.5f));
    const int rr = ((int)r.r) & ~1;
    gfx::blendRect(((int)r.x - rr - 4) & ~1, SURFACE_Y + 2, 4, 2, gfx::rgb(0xffffff), a);
    gfx::blendRect(((int)r.x + rr) & ~1, SURFACE_Y + 2, 4, 2, gfx::rgb(0xffffff), a);
  }
  if (f.shimmer > 0.02f) {
    for (int i = 0; i < 18; i++) {
      if (((int)(t * 4) + i) % 3) continue;
      const int x = ((int)(util::hashf(i, (int)(t * 0.5f)) * 236)) & ~1;
      gfx::blockBlend(x, SURFACE_Y + 2 + (i % 3) * 2, gfx::rgb(0xffffff), (uint8_t)(f.shimmer * 230));
    }
  }
  if (f.rainbow > 0.02f) {  // 方塊彩虹：每 2px 一點的同心弧
    const uint32_t RB[] = {0xff5a5a, 0xffa040, 0xfff060, 0x60e060, 0x50a0ff, 0xa070ff};
    for (int k = 0; k < 6; k++) {
      const int R = 70 - k * 4;
      for (int a = 0; a <= 64; a++) {
        const float ang = 3.14159f * a / 64;
        gfx::blockBlend(150 + (int)(util::fcos(ang) * R), 128 - (int)(util::fsin(ang) * R * 1.1f), gfx::rgb(RB[k]), (uint8_t)(f.rainbow * 110));
      }
    }
  }
}

void drawGlow() {
  const env::Fx& f = env::fx;
  const float night = env::darkness();
  // 發光礦石 / 發光菌 / 發光植物：平常微亮，夜晚明顯，會一閃一閃
  for (int i = 0; i < oreN; i++) {
    const float fl = ((int)(t * 2.5f + i * 3) % 5 == 0) ? 0.6f : 1.0f;
    blockGlow(ores[i].x, ores[i].y, 12, 0x40e8ff, (0.25f + 0.55f * night) * fl);
  }
  for (int i = 0; i < shroomN; i++) blockGlow(shrooms[i].x, shrooms[i].y, 9, 0x50ffe0, 0.15f + 0.6f * night);
  for (int i = 0; i < PLANT_N; i++) {
    if (plants[i].type != GLOWP) continue;
    float x, y;
    plantPoint(i, 1.0f, x, y);
    blockGlow((int)x + 1, (int)y + 1, 9, 0x60f0ff, 0.2f + 0.6f * night);
  }
  const float bio = fmaxf(f.biolum, f.mystic * 0.7f);
  if (bio > 0.02f)
    for (int i = 0; i < tipN; i++) {
      const float p = ((int)(t * 3 + i) % 4 == 0) ? 0.6f : 1.0f;
      blockGlow(tips[i].x + 1, tips[i].y + 1, 4, f.mystic > f.biolum ? 0xb060ff : 0x40ffd0, bio * 0.65f * p);
    }
  if (f.pearl > 0.02f) blockGlow(PEARL_X + 1, sandTop(PEARL_X) - AP * 3 + 1, 8, 0xfff0ff, f.pearl * 0.6f);
  if (f.shellOpen > 0.5f) blockGlow(SHELL_X, sandTop(SHELL_X) - 8, 12, 0xffd0e8, f.shellOpen * 0.55f);
  if (f.chestOpen > 0.3f) blockGlow(CHEST_X, sandTop(CHEST_X) - 16, 20, 0xffe070, f.chestOpen * 0.65f);
  if (f.meteorX > -500)  // 流星光影：亮方塊 + 拖尾
    for (int k = 0; k < 10; k++) {
      const int x = ((int)f.meteorX - k * 6) & ~1, y = ((int)(f.meteorY - k * 0.8f)) & ~1;
      blockGlow(x, y, k == 0 ? 6 : 3, 0xc8f0ff, 0.9f - k * 0.08f);
      if (k < 3) gfx::block(x, y, gfx::rgb(0xffffff));
    }
  if (f.orb > 0.02f) {  // 神秘光點：發光方塊
    const int ox = ((int)f.orbX) & ~1, oy = ((int)f.orbY) & ~1;
    blockGlow(ox, oy, 12, 0x80ffe0, f.orb * (((int)(t * 3) % 2) ? 0.8f : 0.6f));
    gfx::block(ox, oy, gfx::rgb(0xffffff));
    gfx::block(ox - 2, oy, gfx::rgb(0xb0fff0)); gfx::block(ox + 2, oy, gfx::rgb(0xb0fff0));
    gfx::block(ox, oy - 2, gfx::rgb(0xb0fff0)); gfx::block(ox, oy + 2, gfx::rgb(0xb0fff0));
  }
}

void plantPoint(int i, float h, float& x, float& y) {
  const Plant& p = plants[i];
  float frac = h * (p.type == RIBBON ? 0.8f : 1.0f);
  float height = p.height * (float)AP + (p.type == GLOWP ? AP : 0);
  x = p.x + swayOff(p, frac, 0);
  y = baseY[i] - frac * height;
}

int nearestPlant(float x, bool frontOnly) {
  int best = -1;
  float bd = 1e9f;
  for (int i = 0; i < PLANT_N; i++) {
    if (frontOnly && !plants[i].front) continue;
    if (plants[i].type == GRASS) continue;
    float d = fabsf(plants[i].x - x);
    if (d < bd) { bd = d; best = i; }
  }
  return best;
}

bool growLeaf(int i) {
  if (i < 0 || i >= PLANT_N) return false;
  Plant& p = plants[i];
  if (p.extra >= MAX_EXTRA) { p.grow = 0; return false; }
  p.extra++;
  p.grow = 0;
  return true;
}

void addRipple(float x, float strength) {
  for (auto& r : ripples)
    if (!r.on) { r = {x, 1, 1.0f + strength, true}; return; }
}

void addDebris(float x) {
  for (auto& d : debris)
    if (!d.on) { d = {x, 900, true}; return; }
}
int debrisCount() {
  int n = 0;
  for (auto& d : debris) n += d.on;
  return n;
}
int nearestDebris(float x) {
  int best = -1;
  float bd = 1e9f;
  for (int i = 0; i < acfg::DEBRIS_CAP; i++)
    if (debris[i].on && fabsf(debris[i].x - x) < bd) { bd = fabsf(debris[i].x - x); best = i; }
  return best;
}
float debrisX(int i) { return (i >= 0 && i < acfg::DEBRIS_CAP) ? debris[i].x : 120; }
void removeDebrisNear(float x, float r) {
  for (auto& d : debris) if (d.on && fabsf(d.x - x) < r) d.on = false;
}

int algaeVisible() { return util::clamp((int)(env::eco.algae * algaeN + 0.5f), 0, algaeN); }
void algaePoint(int i, float& x, float& y) {
  i = util::clamp(i, 0, algaeN > 0 ? algaeN - 1 : 0);
  x = algae[i].x;
  y = algae[i].y;
}

}  // namespace scene
