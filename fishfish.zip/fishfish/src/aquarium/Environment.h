// 虛擬時間 (日夜) + 生態狀態 + 環境特效參數
#pragma once
#include <stdint.h>

namespace env {

enum Phase : uint8_t { DEEP_NIGHT, DAWN, DAY, DUSK, NIGHT, PHASE_COUNT };
const char* phaseName(Phase p);

// 生態狀態 (都是遊戲內模擬值；沒有感測器，溫度不是真實水溫)
struct Eco {
  float waterTemp = 25.0f;     // °C (模擬)
  float clarity = 1.0f;        // 0..1 清澈度
  float plantGrowth = 0.4f;    // 0..1
  float fishMood = 0.6f;       // 0..1 (魚群平均，由 fish 模組回填)
  float fishEnergy = 0.7f;     // 0..1
  float food = 0.0f;           // 0..1 目前水中食物量
  float algae = 0.2f;          // 0..1 岩石藻類 (有上限，不會永久惡化)
  uint32_t feeds = 0;          // 累積餵食次數
  uint32_t eaten = 0;          // 累積吃到的飼料
};
extern Eco eco;

// 環境特效 (事件設定目標值，update 平滑趨近；全部會自然回到 0)
struct Fx {
  float beams = 0, beamsT = 0;        // 陽光光束
  float caustics = 0, causticsT = 0;  // 光斑
  float shimmer = 0, shimmerT = 0;    // 水面閃光
  float murk = 0, murkT = 0;          // 混濁
  float rainbow = 0, rainbowT = 0;
  float stars = 0, starsT = 0;        // 水中星空
  float mystic = 0, mysticT = 0;      // 神秘水草森林
  float moon = 0, moonT = 0;          // 月光
  float sunrise = 0, sunriseT = 0;
  float sunset = 0, sunsetT = 0;
  float biolum = 0, biolumT = 0;      // 生物發光
  float sway = 1, swayT = 1;          // 水草擺動倍率
  float current = 0, currentT = 0;    // 水流 (px/s，正 = 往右)
  float shadowX = -999;               // 巨大陰影的中心 x (-999 = 沒有)
  float shellOpen = 0, shellOpenT = 0;
  float chestUp = 0, chestUpT = 0;    // 寶箱露出程度
  float chestOpen = 0, chestOpenT = 0;
  float pearl = 0, pearlT = 0;
  float flower = 0, flowerT = 0;
  int8_t flowerPlant = -1;
  float orbX = 0, orbY = 0, orb = 0, orbT = 0;  // 神秘光點
  float meteorX = -999, meteorY = 0;            // 流星光影
  float dread = 0, dreadT = 0;        // 掠食者逼近：整缸變暗
  float blood = 0, bloodT = 0;        // 水中血量：整缸泛紅 (由血霧量自動設定)
};
extern Fx fx;

void begin(float clock, uint32_t day, uint16_t dayLenMin);
void update(float dt);
float clock();              // 0..1，0 = 午夜
uint32_t day();
void setClock(float c);
void setDayLength(uint16_t minutes);
uint16_t dayLength();
void setTimeScale(float s); // 測試用加速
float timeScale();
Phase phase();
bool phaseChanged();        // 本次 update 是否換了時段
bool isNight();             // NIGHT 或 DEEP_NIGHT
float darkness();           // 0 = 白天，1 = 深夜
void virtualTime(char* buf, int cap);  // "第3天 14:20"
float backlightFactor();    // 背光比例

// 事件/互動觸發的時間標記 (millis)
extern uint32_t lastFeedMs, lastEatMs;
bool fedRecently(uint32_t ms, uint32_t windowMs);

}  // namespace env
