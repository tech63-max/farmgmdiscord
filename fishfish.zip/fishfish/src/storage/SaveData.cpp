#include "SaveData.h"
#include <Arduino.h>
#include <Preferences.h>
#include <cJSON.h>
#include <esp_heap_caps.h>
#include <string.h>
#include "../aquarium/Environment.h"
#include "../aquarium/Fish.h"
#include "../aquarium/Scene.h"
#include "../config/AquariumConfig.h"
#include "../events/EventManager.h"
#include "../hw/StorageManager.h"

namespace save {

Settings settings;

namespace {
constexpr const char* CFG_PATH = "/aquarium/config.json";
constexpr const char* SAVE_PATH = "/aquarium/save.json";
constexpr const char* LOG_PATH = "/aquarium/event_log.json";
constexpr size_t BUF_CAP = 16 * 1024;
constexpr int VERSION = 1;

char* buf = nullptr;  // JSON 文字緩衝 (PSRAM；寫入 SD 時 storage 會再複製到內部 RAM 對齊緩衝)
bool sd = false;
uint32_t lastSave = 0, lastNvs = 0;
const char* stat = "尚未存檔";

bool ensureBuf() {
  if (!buf) buf = (char*)heap_caps_malloc(BUF_CAP, MALLOC_CAP_SPIRAM);
  if (!buf) buf = (char*)malloc(BUF_CAP);
  return buf != nullptr;
}

cJSON* parseValid(const char* text) {
  cJSON* j = cJSON_Parse(text);
  if (j && cJSON_IsNumber(cJSON_GetObjectItem(j, "v"))) return j;
  cJSON_Delete(j);
  return nullptr;
}

// 讀檔：SD 正式檔 → SD .bak → NVS
cJSON* readJson(const char* path, const char* nvsKey) {
  if (!ensureBuf()) return nullptr;
  if (sd) {
    if (storage::readFile(path, buf, BUF_CAP) > 0)
      if (cJSON* j = parseValid(buf)) return j;
    char bak[64];
    snprintf(bak, sizeof(bak), "%s.bak", path);
    if (storage::readFile(bak, buf, BUF_CAP) > 0)
      if (cJSON* j = parseValid(buf)) { Serial.printf("[Save] %s unreadable, using .bak\n", path); return j; }
  }
  Preferences p;
  if (!p.begin("aquarium", true)) return nullptr;
  size_t n = p.getBytesLength(nvsKey);
  cJSON* j = nullptr;
  if (n > 0 && n < BUF_CAP) {
    p.getBytes(nvsKey, buf, n);
    buf[n] = 0;
    j = parseValid(buf);
  }
  p.end();
  return j;
}

bool writeJson(cJSON* j, const char* path, const char* nvsKey, bool nvsAllowed) {
  if (!ensureBuf()) return false;
  if (!cJSON_PrintPreallocated(j, buf, BUF_CAP, false)) return false;
  const size_t len = strlen(buf);
  if (sd && storage::safeWrite(path, buf, len)) return true;
  if (!nvsAllowed) return false;
  Preferences p;
  if (!p.begin("aquarium", false)) return false;
  bool ok = p.putBytes(nvsKey, buf, len) == len;
  p.end();
  return ok;
}

int num(cJSON* o, const char* k, int def) {
  cJSON* v = cJSON_GetObjectItem(o, k);
  return cJSON_IsNumber(v) ? v->valueint : def;
}
float numf(cJSON* o, const char* k, float def) {
  cJSON* v = cJSON_GetObjectItem(o, k);
  return cJSON_IsNumber(v) ? (float)v->valuedouble : def;
}
int item(cJSON* arr, int i, int def) {
  cJSON* v = cJSON_GetArrayItem(arr, i);
  return cJSON_IsNumber(v) ? v->valueint : def;
}
float itemf(cJSON* arr, int i, float def) {
  cJSON* v = cJSON_GetArrayItem(arr, i);
  return cJSON_IsNumber(v) ? (float)v->valuedouble : def;
}
}  // namespace

void begin(bool sdOk) {
  sd = sdOk;
  ensureBuf();
  if (sd) {
    storage::recover(CFG_PATH);
    storage::recover(SAVE_PATH);
    storage::recover(LOG_PATH);
  }
  stat = sd ? "SD 卡正常" : "未插 SD 卡 (使用內部備份)";
}

bool usingSd() { return sd; }
const char* status() { return stat; }

bool loadConfig() {
  cJSON* j = readJson(CFG_PATH, "cfg");
  if (!j) return false;
  settings.brightness = (uint8_t)constrain(num(j, "brightness", 80), 20, 100);
  settings.dayLenIdx = (uint8_t)constrain(num(j, "dayLen", acfg::DAY_LEN_DEFAULT_IDX), 0, 4);
  settings.freq = (uint8_t)constrain(num(j, "freq", 1), 0, 2);
  settings.notices = (uint8_t)constrain(num(j, "notices", 1), 0, 2);
  settings.mode = (uint8_t)constrain(num(j, "mode", 0), 0, 2);
  settings.gore = (uint8_t)constrain(num(j, "gore", 1), 0, 2);
  cJSON_Delete(j);
  return true;
}

bool saveConfig() {
  cJSON* j = cJSON_CreateObject();
  cJSON_AddNumberToObject(j, "v", VERSION);
  cJSON_AddNumberToObject(j, "brightness", settings.brightness);
  cJSON_AddNumberToObject(j, "dayLen", settings.dayLenIdx);
  cJSON_AddNumberToObject(j, "freq", settings.freq);
  cJSON_AddNumberToObject(j, "notices", settings.notices);
  cJSON_AddNumberToObject(j, "mode", settings.mode);
  cJSON_AddNumberToObject(j, "gore", settings.gore);
  bool ok = writeJson(j, CFG_PATH, "cfg", true);  // 設定只在使用者修改時寫入
  cJSON_Delete(j);
  return ok;
}

bool loadState() {
  cJSON* j = readJson(SAVE_PATH, "state");
  if (!j) return false;
  if (num(j, "v", 0) != VERSION) { cJSON_Delete(j); return false; }
  env::begin(numf(j, "clock", acfg::FIRST_BOOT_CLOCK), (uint32_t)num(j, "day", 1), acfg::DAY_LEN_OPTIONS[settings.dayLenIdx]);
  env::eco.feeds = (uint32_t)num(j, "feeds", 0);
  env::eco.eaten = (uint32_t)num(j, "eaten", 0);
  if (cJSON* e = cJSON_GetObjectItem(j, "eco")) {
    env::eco.clarity = constrain(numf(e, "clarity", 1), 0.3f, 1.0f);
    env::eco.plantGrowth = constrain(numf(e, "plant", 0.4f), 0.0f, 1.0f);
    env::eco.algae = constrain(numf(e, "algae", 0.2f), 0.0f, 0.6f);
  }
  if (cJSON* pl = cJSON_GetObjectItem(j, "plants"))
    for (int i = 0; i < scene::PLANT_N && i < cJSON_GetArraySize(pl); i++) scene::plants[i].extra = (uint8_t)constrain(item(pl, i, 0), 0, 3);
  if (cJSON* fa = cJSON_GetObjectItem(j, "fish")) {
    // 新格式：[魚種, 性格, 心情, 精力, 配色, 名字, 進缸天, 受傷秒]；舊格式只有前 4 個 → 照預設名單
    static fish::Record rec[acfg::FISH_CAP];
    uint8_t sp[acfg::FISH_CAP], pe[acfg::FISH_CAP];
    float mo[acfg::FISH_CAP], en[acfg::FISH_CAP];
    int n = 0;
    bool full = true;
    cJSON* it;
    cJSON_ArrayForEach(it, fa) {
      if (n >= acfg::FISH_CAP || cJSON_GetArraySize(it) < 4) continue;
      fish::Record& r = rec[n];
      sp[n] = r.sp = (uint8_t)constrain(item(it, 0, 0), 0, fish::SP_COUNT - 1);
      pe[n] = r.pers = (uint8_t)constrain(item(it, 1, 0), 0, fish::PERS_COUNT - 1);
      mo[n] = r.mood = itemf(it, 2, 0.6f);
      en[n] = r.energy = itemf(it, 3, 0.7f);
      if (cJSON_GetArraySize(it) >= 8) {
        r.var = (uint8_t)constrain(item(it, 4, 0), 0, 2);
        r.nameIdx = (uint8_t)constrain(item(it, 5, 0), 0, 255);
        r.born = (uint32_t)itemf(it, 6, 1);
        r.hurt = constrain(itemf(it, 7, 0), 0.0f, 3600.0f);
      } else full = false;
      n++;
    }
    if (full && n > 0) fish::setRecords(n, rec);
    else if (n > 0) fish::setRoster(n, sp, pe, mo, en);
    else fish::setRecords(0, rec);  // 存檔時魚被吃光 → 開機後補魚
  }
  if (cJSON* w = cJSON_GetObjectItem(j, "world")) {
    ev::World& wd = ev::world();
    wd.lastSharkDay = (uint32_t)itemf(w, 0, 0);
    wd.sharks = (uint16_t)constrain(item(w, 1, 0), 0, 65535);
    wd.newStart = item(w, 2, 0) != 0;
  }
  if (cJSON* da = cJSON_GetObjectItem(j, "deaths")) {
    static fish::Death d[fish::DEATH_LOG_CAP];
    int n = 0;
    cJSON* it;
    cJSON_ArrayForEach(it, cJSON_GetObjectItem(da, "log")) {
      if (n >= fish::DEATH_LOG_CAP || cJSON_GetArraySize(it) < 5) continue;
      d[n].sp = (uint8_t)constrain(item(it, 0, 0), 0, fish::SP_COUNT - 1);
      d[n].var = (uint8_t)constrain(item(it, 1, 0), 0, 2);
      d[n].nameIdx = (uint8_t)item(it, 2, 0);
      d[n].cause = (uint8_t)item(it, 3, 0);
      d[n].day = (uint32_t)itemf(it, 4, 1);
      n++;
    }
    fish::setDeaths(num(da, "total", n), n, d);
  }
  if (cJSON* sa = cJSON_GetObjectItem(j, "seen"))
    for (int i = 0; i < ev::EVENT_COUNT && i < cJSON_GetArraySize(sa); i++) ev::setTimesSeen(i + 1, (uint16_t)constrain(item(sa, i, 0), 0, 65535));
  cJSON_Delete(j);

  // 事件紀錄 (檔案內是舊 → 新)
  if (cJSON* lj = readJson(LOG_PATH, "log")) {
    ev::clearLog();
    cJSON* it;
    cJSON_ArrayForEach(it, cJSON_GetObjectItem(lj, "log")) {
      if (cJSON_GetArraySize(it) < 4) continue;
      ev::LogEntry e;
      e.id = (uint8_t)item(it, 0, 0);
      e.user = (uint8_t)item(it, 1, 0);
      e.minute = (uint16_t)item(it, 2, 0);
      e.day = (uint32_t)itemf(it, 3, 1);
      if (e.id >= 1 && e.id <= ev::EVENT_COUNT) ev::pushLog(e);
    }
    cJSON_Delete(lj);
  }
  stat = sd ? "已從 SD 卡恢復" : "已從內部備份恢復";
  return true;
}

bool saveState(uint32_t ms, bool force) {
  if (!force && lastSave && ms - lastSave < acfg::SAVE_MIN_GAP_MS) return false;
  // 沒有 SD 時只寫 NVS，而且間隔拉長 (關機時 force 一定寫)
  const bool nvsOk = force || !lastNvs || ms - lastNvs >= acfg::NVS_SAVE_INTERVAL_MS;
  if (!sd && !nvsOk) return false;
  lastSave = ms;

  cJSON* j = cJSON_CreateObject();
  cJSON_AddNumberToObject(j, "v", VERSION);
  cJSON_AddNumberToObject(j, "clock", env::clock());
  cJSON_AddNumberToObject(j, "day", env::day());
  cJSON_AddNumberToObject(j, "feeds", env::eco.feeds);
  cJSON_AddNumberToObject(j, "eaten", env::eco.eaten);
  cJSON* e = cJSON_AddObjectToObject(j, "eco");
  cJSON_AddNumberToObject(e, "clarity", env::eco.clarity);
  cJSON_AddNumberToObject(e, "plant", env::eco.plantGrowth);
  cJSON_AddNumberToObject(e, "algae", env::eco.algae);
  cJSON* pl = cJSON_AddArrayToObject(j, "plants");
  for (int i = 0; i < scene::PLANT_N; i++) cJSON_AddItemToArray(pl, cJSON_CreateNumber(scene::plants[i].extra));
  cJSON* fa = cJSON_AddArrayToObject(j, "fish");
  for (int i = 0; i < fish::count(); i++) {
    if (!fish::F[i].on) continue;
    const fish::Record r = fish::record(i);
    cJSON* it = cJSON_CreateArray();
    cJSON_AddItemToArray(it, cJSON_CreateNumber(r.sp));
    cJSON_AddItemToArray(it, cJSON_CreateNumber(r.pers));
    cJSON_AddItemToArray(it, cJSON_CreateNumber((int)(r.mood * 100) / 100.0));
    cJSON_AddItemToArray(it, cJSON_CreateNumber((int)(r.energy * 100) / 100.0));
    cJSON_AddItemToArray(it, cJSON_CreateNumber(r.var));
    cJSON_AddItemToArray(it, cJSON_CreateNumber(r.nameIdx));
    cJSON_AddItemToArray(it, cJSON_CreateNumber(r.born));
    cJSON_AddItemToArray(it, cJSON_CreateNumber((int)r.hurt));
    cJSON_AddItemToArray(fa, it);
  }
  const ev::World& wd = ev::world();
  cJSON* w = cJSON_AddArrayToObject(j, "world");
  cJSON_AddItemToArray(w, cJSON_CreateNumber(wd.lastSharkDay));
  cJSON_AddItemToArray(w, cJSON_CreateNumber(wd.sharks));
  cJSON_AddItemToArray(w, cJSON_CreateNumber(wd.newStart ? 1 : 0));
  cJSON* da = cJSON_AddObjectToObject(j, "deaths");
  cJSON_AddNumberToObject(da, "total", fish::deathCount());
  cJSON* dl = cJSON_AddArrayToObject(da, "log");
  for (int i = fish::deathLogN() - 1; i >= 0; i--) {  // 舊 → 新
    const fish::Death& d = fish::deathAt(i);
    cJSON* it = cJSON_CreateArray();
    cJSON_AddItemToArray(it, cJSON_CreateNumber(d.sp));
    cJSON_AddItemToArray(it, cJSON_CreateNumber(d.var));
    cJSON_AddItemToArray(it, cJSON_CreateNumber(d.nameIdx));
    cJSON_AddItemToArray(it, cJSON_CreateNumber(d.cause));
    cJSON_AddItemToArray(it, cJSON_CreateNumber(d.day));
    cJSON_AddItemToArray(dl, it);
  }
  cJSON* sa = cJSON_AddArrayToObject(j, "seen");
  for (int id = 1; id <= ev::EVENT_COUNT; id++) cJSON_AddItemToArray(sa, cJSON_CreateNumber(ev::timesSeen(id)));
  bool ok = writeJson(j, SAVE_PATH, "state", nvsOk);
  cJSON_Delete(j);

  cJSON* lj = cJSON_CreateObject();
  cJSON_AddNumberToObject(lj, "v", VERSION);
  cJSON* arr = cJSON_AddArrayToObject(lj, "log");
  for (int i = ev::logCount() - 1; i >= 0; i--) {
    const ev::LogEntry& le = ev::logAt(i);
    cJSON* it = cJSON_CreateArray();
    cJSON_AddItemToArray(it, cJSON_CreateNumber(le.id));
    cJSON_AddItemToArray(it, cJSON_CreateNumber(le.user));
    cJSON_AddItemToArray(it, cJSON_CreateNumber(le.minute));
    cJSON_AddItemToArray(it, cJSON_CreateNumber(le.day));
    cJSON_AddItemToArray(arr, it);
  }
  ok = writeJson(lj, LOG_PATH, "log", nvsOk) && ok;
  cJSON_Delete(lj);
  if (!sd && nvsOk) lastNvs = ms;
  stat = ok ? (sd ? "SD 卡存檔正常" : "已存到內部備份 (未插 SD)") : "存檔失敗 (稍後重試)";
  return ok;
}

void eraseAll() {
  storage::removeAll(SAVE_PATH);
  storage::removeAll(LOG_PATH);
  Preferences p;
  if (p.begin("aquarium", false)) { p.remove("state"); p.remove("log"); p.end(); }
}

}  // namespace save
