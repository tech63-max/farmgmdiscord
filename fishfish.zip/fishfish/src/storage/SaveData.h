// 存檔：設定 (config.json)、水族箱狀態 (save.json)、事件紀錄 (event_log.json)
// 沒有 SD 卡時改存 NVS (寫入間隔較長，保護 Flash)；兩者都失敗也能正常運作 (只保留在 RAM)
#pragma once
#include <stdint.h>

namespace save {

struct Settings {
  uint8_t brightness = 80;   // 20..100
  uint8_t dayLenIdx = 2;     // AquariumConfig::DAY_LEN_OPTIONS 索引
  uint8_t freq = 1;          // 0 低 / 1 中 / 2 高
  uint8_t notices = 1;       // 0 關 / 1 特殊以上 / 2 全部
  uint8_t mode = 0;          // 互動模式：0 餵食 / 1 敲玻璃 / 2 打氣
  uint8_t gore = 1;          // 血腥效果：0 關閉 / 1 輕微 / 2 完整
};
extern Settings settings;

void begin(bool sdOk);         // 開機：檢查 .tmp/.bak 殘留並復原
bool loadConfig();
bool saveConfig();
bool loadState();              // 讀到就套用到 env / fish / scene / ev，回傳是否成功
bool saveState(uint32_t ms, bool force);
void eraseAll();               // 重設水族箱 (刪除狀態與紀錄，保留設定)
const char* status();          // 給 UI 顯示的儲存狀態
bool usingSd();

}  // namespace save
