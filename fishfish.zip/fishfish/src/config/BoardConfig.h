// Waveshare ESP32-S3-LCD-1.54 (無觸控) 腳位 —— 全部取自 PINOUT.md (實機驗證)，不要修改
#pragma once
#include <stdint.h>

namespace board {
// LCD ST7789 240x240 SPI
constexpr int PIN_LCD_SCK = 38, PIN_LCD_MOSI = 39, PIN_LCD_CS = 21, PIN_LCD_DC = 45, PIN_LCD_RST = 40, PIN_LCD_BL = 46;
// 按鍵 (按下 = LOW，INPUT_PULLUP)。GPIO0 是 strapping pin
constexpr int PIN_BTN_BOOT = 0, PIN_BTN_PWR = 5, PIN_BTN_PLUS = 4;
// 電源鎖定 / 喇叭功放 (本專案不使用聲音，開機即關閉)
constexpr int PIN_POWER_LATCH = 2, PIN_AMP = 7;
// microSD SDMMC 4-bit
constexpr int SD_CLK = 16, SD_CMD = 15, SD_D0 = 17, SD_D1 = 18, SD_D2 = 13, SD_D3 = 14;

constexpr int LCD_W = 240, LCD_H = 240;
constexpr uint32_t LCD_SPI_HZ = 40000000;
// 畫面方向：0 = PINOUT.md 原始方向；1 = 右轉 90° (舊專案 ESP32magictree 實機使用的方向，按鍵在螢幕下方)
constexpr uint8_t LCD_ROTATION = 1;
constexpr uint32_t BL_PWM_HZ = 5000;
constexpr uint8_t BL_PWM_BITS = 10;
}  // namespace board
