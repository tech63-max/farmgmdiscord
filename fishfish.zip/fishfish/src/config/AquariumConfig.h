// 水族箱可調參數 (初始調校值)
#pragma once
#include <stdint.h>

namespace acfg {
// ---- 主迴圈節奏 ----
constexpr uint32_t FRAME_MS = 50;      // 畫面 20 FPS
constexpr uint32_t AI_MS = 40;         // 魚類 AI 25 次/秒
constexpr uint32_t EVENT_TICK_MS = 1000;  // 事件調度每秒一次

// ---- 容量 (固定大小，執行期不動態配置) ----
constexpr int FISH_CAP = 16;
constexpr int FISH_PX = 2;            // 魚的一個美術像素 = 2x2 螢幕像素 (場景是 3x3，比魚粗)
constexpr int CREATURE_CAP = 16;
constexpr int PARTICLE_CAP = 180;
constexpr int DEBRIS_CAP = 24;
constexpr int ALGAE_CAP = 18;
constexpr int EVENT_SLOTS = 3;         // 1 個主要事件 + 2 個環境/日常小事件
constexpr int EVENT_LOG_CAP = 48;

// ---- 虛擬日 (沒有 RTC，用 millis() 推進) ----
constexpr uint16_t DAY_LEN_OPTIONS[] = {30, 60, 120, 240, 480};  // 分鐘
constexpr uint8_t DAY_LEN_DEFAULT_IDX = 2;                        // 120 分鐘
constexpr float FIRST_BOOT_CLOCK = 0.34f;                         // 首次開機從上午開始

// ---- 事件調度 (秒)，再乘上設定的頻率倍率 ----
constexpr uint16_t COMMON_MIN = 20, COMMON_MAX = 60;
constexpr uint16_t SPECIAL_MIN = 120, SPECIAL_MAX = 300;
constexpr uint16_t RARE_MIN = 600, RARE_MAX = 1800;
constexpr uint16_t ULTRA_MIN = 1800, ULTRA_MAX = 5400;
constexpr uint16_t BIG_MIN = 720, BIG_MAX = 1800;   // 大型事件 12～30 分鐘一次
constexpr float ULTRA_CHANCE = 0.45f;  // 極稀有計時到了也只有這個機率真的觸發
constexpr float FREQ_MULT[] = {1.6f, 1.0f, 0.55f};  // 低 / 中 / 高 (間隔倍率)

// ---- 互動 ----
constexpr uint32_t FEED_COOLDOWN_MS = 6000;
constexpr uint32_t TAP_COOLDOWN_MS = 4000;
constexpr uint32_t AIR_COOLDOWN_MS = 20000;

// ---- 存檔 ----
constexpr uint32_t SAVE_INTERVAL_MS = 60000;     // SD 定期存檔
constexpr uint32_t SAVE_MIN_GAP_MS = 15000;      // 額外存檔的節流
constexpr uint32_t NVS_SAVE_INTERVAL_MS = 600000;  // 沒有 SD 時的備援 (NVS，考量 Flash 壽命)

// ---- 背光 ----
constexpr uint8_t BRIGHT_DEFAULT = 80;
constexpr float BL_NIGHT = 0.65f, BL_DEEP_NIGHT = 0.42f;  // 夜晚/深夜的背光比例
}  // namespace acfg
