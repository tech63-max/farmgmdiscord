"""原創方塊像素素材產生器 (Pocket Aquarium — Voxel Aquarium)

素材的唯一來源是這個檔案裡的字元圖 (全部為本專案原創繪製)。執行後產生：
  - src/gfx/SpriteData.h                 韌體內嵌的索引色像素圖 (0 = 透明)
  - assets/fish/<名稱>/<名稱>_swim.png    4 格游泳動畫 (尾巴、魚鰭逐格變化)
  - assets/fish/<名稱>/<名稱>_idle.png    2 格待機動畫
  - assets/fish/<名稱>/<名稱>_rest.png    休息 (閉眼)
  - assets/fish/<名稱>/<名稱>_turn.png    轉身 4 格 (寬度 100% → 60% → 30% → 翻面)
  - assets/<分類>/<名稱>.png              其他素材 (單張)
  - assets/preview.png                   放大 6 倍的總覽圖

方塊像素規則：
  - 魚類一律「頭朝右」繪製，左右游泳由韌體水平翻轉 (素材沒有方向性光影，翻轉不會穿幫)。
  - 方塊化輪廓：深色外框 + 上緣亮色 + 下緣暗色 (假體素的頂面/底面)，魚鰭用階梯狀像素。
  - 魚 = 身體 (body) + 尾巴 (tail，接在左邊)。4 格動畫：尾巴 中/上/中/下，魚鰭在第 2、4 格換成 alt 造型。
  - 'E' = 眼睛 (休息時改畫成 lid 的顏色)，'.' = 透明。不使用漸層與抗鋸齒。

用法：python tools/gen_sprites.py
"""
import os
import sys

from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SPRITES = []


def check(name, pal, rows):
    w = len(rows[0])
    for i, r in enumerate(rows):
        if len(r) != w:
            sys.exit(f"{name}: row {i} width {len(r)} != {w}: '{r}'")
        for ch in r:
            if ch != "." and ch not in pal:
                sys.exit(f"{name}: char '{ch}' not in palette")


def add(name, cat, pal, rows, tail=0, lid=None):
    """單張素材 (訪客、裝飾)"""
    check(name, pal, rows)
    SPRITES.append(dict(name=name, cat=cat, pal=pal, frames=[rows], tail=tail, lid=lid, fish=False))


def add_fish(name, cat, pal, body, tail, alt=None, lid=None):
    """魚：身體 + 尾巴組成 4 格游泳動畫"""
    h = len(body)
    if len(tail) != h:
        sys.exit(f"{name}: tail height {len(tail)} != body height {h}")
    check(name + ".body", pal, body)
    check(name + ".tail", pal, tail)
    wt = len(tail[0])
    frames = []
    for k, dy in enumerate((0, -1, 0, 1)):
        t = [tail[r - dy] if 0 <= r - dy < h else "." * wt for r in range(h)]
        b = list(body)
        if alt and k in (1, 3):
            for r, row in alt.items():
                b[r] = row
        rows = [t[r] + b[r] for r in range(h)]
        check(f"{name}.f{k}", pal, rows)
        frames.append(rows)
    if lid is not None and lid not in pal:
        sys.exit(f"{name}: lid '{lid}' not in palette")
    SPRITES.append(dict(name=name, cat=cat, pal=pal, frames=frames, tail=0, lid=lid, fish=True))


# ================================================================ 魚類 (頭朝右)
# 共用字元：o 外框、h 上緣亮色、b 主色、d 下緣暗色、l 腹部、f/F 魚鰭、E 眼睛、w 眼白、m 嘴

# 1. 灰褐色小型魚 (cod 欄位)：身體偏長、鈍頭、斑點、三片小背鰭
add_fish("cod", "fish", {
    "o": 0x3a342c, "h": 0xb8ac92, "b": 0x8c806a, "s": 0x655b4a, "l": 0xdcd0b4, "d": 0x5a5040,
    "f": 0x766a54, "w": 0xf4f0e0, "E": 0x101010, "m": 0x2a2620,
}, body=[
    "....ff..ff...",
    "..ooooooooo..",
    ".ohhhhhhhhhoo",
    "obbsbbbsbbwEo",
    "obbbbsbbbbbbm",
    "olllllllllllo",
    ".odddddddddo.",
    "...ofo...fo..",
], tail=[
    "....",
    "....",
    "oo..",
    "ofoo",
    "offo",
    "ofoo",
    "oo..",
    "....",
], alt={0: "...ff..ff....", 7: "....of...of.."}, lid="b")

# 2. 橘紅色細長魚 (salmon 欄位)：最細長、灰色背帶、大叉尾
add_fish("salmon", "fish", {
    "o": 0x4a1a10, "h": 0xff9a6a, "b": 0xe8582c, "d": 0xa8341c, "s": 0x8e8e98, "l": 0xffd0b0,
    "f": 0xc84422, "w": 0xfff0e8, "E": 0x101010, "m": 0x3a1008,
}, body=[
    "......fff.........",
    "...ooooooooooooo..",
    "..osssssssssssssoo",
    ".obbbbbbbbbbbbbwEo",
    "ohhbbbbbbbbbbbbbbm",
    ".olllllllllllllloo",
    "..oodddoooooddoo..",
    ".....ff.....ff....",
], tail=[
    "o...",
    "fo..",
    "ffo.",
    ".ffo",
    ".ffo",
    "ffo.",
    "fo..",
    "o...",
], alt={0: ".....fff..........", 7: "......f......f...."}, lid="b")

# 3. 河豚 (三種狀態)：未膨脹 / 半膨脹 / 完全膨脹 (刺狀外型)
PUFF = {"o": 0x3a2a08, "b": 0xe8c040, "h": 0xfff09a, "d": 0xb08a20, "s": 0x7a5a10, "l": 0xfffbe0,
        "E": 0x101010, "w": 0xffffff, "k": 0x5a4010, "f": 0xd0a030, "m": 0x3a2a08}
add_fish("puffer", "fish", PUFF, body=[
    "..ooooo..",
    ".ohhshho.",
    "obbsbbwEo",
    "obbbbbbbm",
    "olllllllo",
    ".oddddoo.",
    "..f..f...",
], tail=["..", "..", "fo", "ff", "fo", "..", ".."], alt={6: "...f..f.."}, lid="b")
add_fish("puffer_half", "fish", PUFF, body=[
    "...k.k.k...",
    "..ooooooo..",
    ".ohhshhhho.",
    "obbsbbbbwEo",
    "kbbbbsbbbbm",
    "obsbbbbbsbo",
    "olllllllllo",
    ".oddddddoo.",
    "...k.k.k...",
], tail=["..", "..", "..", "fo", "ff", "fo", "..", "..", ".."], alt={0: "..k.k.k....", 8: "....k.k.k.."}, lid="b")
add_fish("puffer_full", "fish", PUFF, body=[
    "....k.k.k....",
    "...ooooooo...",
    "k.ohhshhsho.k",
    ".obbbbbbbwEo.",
    "kobsbbbsbbbmk",
    ".obbbbbbbbbo.",
    "kobbsbbbbsbok",
    ".olllllllllo.",
    "kolllllllllok",
    ".oddddddddo..",
    "...ooooooo...",
    "..k.k.k.k....",
], tail=["..", "..", "..", "..", "fo", "ff", "ff", "fo", "..", "..", "..", ".."],
    alt={0: "...k.k.k.k...", 11: "...k.k.k.k..."}, lid="b")

# 4. 多彩斑點魚 (trop_ow 欄位)：青綠底 + 粉/黃/橘斑點
add_fish("trop_ow", "fish", {
    "o": 0x0a2a2a, "b": 0x2ac0b0, "h": 0x80f0e0, "d": 0x168070, "p": 0xff5aa8, "y": 0xffe040,
    "r": 0xff7a30, "E": 0x101010, "f": 0x50d8c8, "m": 0x0a2a2a,
}, body=[
    "...ff.....",
    "..oooooo..",
    ".ohhphhhoo",
    "obbybbrbEo",
    "obpbbbbybm",
    ".obbrbpbo.",
    "..oooooo..",
    "...ff.f...",
], tail=["...", "...", "fo.", "ffo", "ffo", "fo.", "...", "..."],
    alt={0: "..ff......", 7: "..ff..f..."}, lid="b")

# 5. 藍黃相間熱帶魚：寶藍身體、黃色橫帶、黃尾黃鰭
add_fish("trop_by", "fish", {
    "o": 0x0e1a48, "h": 0x6aa8ff, "b": 0x2a64e0, "d": 0x1a3c9a, "y": 0xffd83a, "Y": 0xc8a01a,
    "E": 0x000000, "m": 0x0e1a48,
}, body=[
    "...yyy....",
    "..yyyyy...",
    ".oohhhhoo.",
    "obbbbbbbEo",
    "obyyyybbbm",
    "obbbbbbbbo",
    ".odddddoo.",
    "..yyyy....",
], tail=["...", "...", "yy.", "yYy", "yYy", "yy.", "...", "..."],
    alt={0: "..yyy.....", 7: "...yyy...."}, lid="b")

# 6. 紫色熱帶魚：高身三角形、階梯狀長背鰭與腹鰭、淡紫條紋
add_fish("trop_purple", "fish", {
    "o": 0x2a0e44, "b": 0x8a48d0, "l": 0xc8a0f0, "d": 0x5a2a90, "f": 0xb070f0, "h": 0xe0c8ff,
    "E": 0x000000, "m": 0x2a0e44,
}, body=[
    "...f....",
    "..fff...",
    ".ooooo..",
    "obhlbbo.",
    "oblbbbEo",
    "oblbbbbm",
    "oblbbbo.",
    ".odddo..",
    "..fff...",
    "...f....",
], tail=["..", "..", "..", "fo", "ff", "ff", "fo", "..", "..", ".."],
    alt={0: "..ff....", 9: "..ff...."}, lid="b")

# 7. 黑金色熱帶魚 (trop_black 欄位)：黑身、金色直紋、金鰭金眼圈
add_fish("trop_black", "fish", {
    "o": 0x050508, "b": 0x24242e, "h": 0x46465a, "g": 0xf0b828, "G": 0xa07810, "E": 0x000000,
    "m": 0x050508,
}, body=[
    "....ggg......",
    "..ooooooooo..",
    ".ohhhhhhhhhoo",
    "obgbbgbbbbgEo",
    "obgbbgbbbbbbm",
    ".obgbbgbbbbo.",
    "..ooooooooo..",
    "....gg...g...",
], tail=["....", "go..", "ggo.", "gGgo", "gGgo", "ggo.", "go..", "...."],
    alt={0: "...ggg.......", 7: "...gg...gg..."}, lid="b")

# 8. 紅白條紋熱帶魚：白身紅色直紋、紅鰭
add_fish("trop_rw", "fish", {
    "o": 0x3a0c0c, "w": 0xfaf4ee, "r": 0xe02828, "R": 0xa01818, "E": 0x000000, "m": 0x3a0c0c,
}, body=[
    "....rrr.....",
    "..ooooooooo.",
    ".owwrrwwrrwo",
    "owwwrrwwrrEo",
    "owwwrrwwrrwm",
    ".owwrrwwrro.",
    "..ooooooooo.",
    "....rr..r...",
], tail=["...", "o..", "rro", "rRr", "rRr", "rro", "o..", "..."],
    alt={0: "...rrr......", 7: "...rr..rr..."}, lid="r")

# 9. 黃色小魚 (lemon)：最小、圓、黑色眼帶
add_fish("lemon", "fish", {
    "o": 0x3a3008, "b": 0xffe23a, "h": 0xfff6a0, "k": 0x1a1408, "E": 0xffffff, "d": 0xc8a818,
    "f": 0xffd020, "m": 0x3a3008,
}, body=[
    "..ooo..",
    ".ohhko.",
    "obbbkEo",
    "obbbkbm",
    ".oddoo.",
    "..f.f..",
], tail=["..", "fo", "ff", "fo", "..", ".."], alt={5: "...ff.."}, lid="k")

# ================================================================ 訪客魚 (同樣 4 格動畫)
add_fish("goldfish", "creatures", {
    "o": 0x5a3a06, "g": 0xffc93a, "h": 0xfff0a0, "d": 0xd89a10, "E": 0x101010, "f": 0xffb020, "m": 0x5a3a06,
}, body=[
    "...fff...",
    "..ooooo..",
    ".ohhhhhoo",
    "oggggggEo",
    "oggdggggm",
    ".odddddo.",
    "..ooooo..",
], tail=["f...", "ff..", "fffo", "ffo.", "fffo", "ff..", "f..."], alt={0: "....fff.."}, lid="g")

add_fish("bluefish", "creatures", {
    "o": 0x06304a, "c": 0x46e0ff, "b": 0x1a8ad8, "w": 0xd8faff, "E": 0x02121c, "h": 0x8af0ff, "m": 0x06304a,
}, body=[
    ".oooooooo.",
    "ohhhhhhwEo",
    "obcbcbcbbm",
    ".oooooooo.",
    "...c..c...",
], tail=["...", "cc.", "ccc", "cc.", "..."], alt={4: "..c..c...."}, lid="b")

add_fish("rarefish", "creatures", {
    "o": 0x3a0c30, "m": 0xf04ab0, "t": 0x3ee8c8, "E": 0x000000,
}, body=[
    ".oooo.",
    "ommtEo",
    "omtmmo",
    ".oooo.",
], tail=["t.", "tt", "tt", "t."], lid="m")

add_fish("fry", "creatures", {"s": 0xb8c8d0, "o": 0x50606a, "E": 0x101010}, body=[
    ".oo.",
    "osEo",
    ".oo.",
], tail=["o", "s", "o"])

add_fish("cleaner", "creatures", {
    "o": 0x241a10, "b": 0x7a5a36, "s": 0xc8a878, "m": 0x3e2c18, "E": 0x111111, "h": 0x9a7a50,
}, body=[
    "..oooooooo..",
    ".ohhshhshho.",
    "obsbbsbbsbEm",
    ".obbsbbsbbom",
    "..oooooooo..",
], tail=["o.", "bo", "bb", "bo", "o."], lid="m")

# ================================================================ 掠食者 (大型事件)
# 鯊魚：灰藍背、白腹、高背鰭、鰓裂 (g)、小黑眼；shark_bite 是張嘴咬的造型 (t 牙齒、r 嘴內)
SHARK = {"o": 0x18222c, "h": 0x8aa2b4, "b": 0x5e7688, "d": 0x3c4e5e, "l": 0xe4ecf0, "g": 0x2a3846,
         "f": 0x4a6070, "E": 0x050505, "m": 0x18222c, "t": 0xffffff, "r": 0x8a1820}
SHARK_BODY = [
    "..........oo..................",
    ".........ofo..................",
    "........offfo.................",
    "...ooooofffffoooooooooo.......",
    "..ohhhhhhhhhhhhhhhhhhhhoooo...",
    ".obbbbbbbbbbbbbbbbbbbbbbbbbo..",
    "obbbbbbbbbbbbbbbbgbgbbbbbEbbo.",
    "obbbbbbbbbbbbbbbbgbgbbbbbbbbbo",
    "olllllllllllllllllllllllllllmo",
    ".ollllllllllllllllllllllllloo.",
    "..oodddffoooooooooooodddoo....",
    ".....offo.....................",
    "......oo......................",
]
SHARK_TAIL = [
    "o.....", "fo....", "ffo...", ".ffo..", "..ffoo", "...ffo", "...ffo",
    "...ffo", "..ffoo", ".ffo..", "ffo...", "fo....", "o.....",
]
add_fish("shark", "predators", SHARK, body=SHARK_BODY, tail=SHARK_TAIL,
         alt={11: "......offo....................", 12: ".......oo....................."}, lid="b")
SHARK_BITE = list(SHARK_BODY)
SHARK_BITE[7] = "obbbbbbbbbbbbbbbbgbgbbbbbbtttt"
SHARK_BITE[8] = "olllllllllllllllllllllrrrrrr.."
SHARK_BITE[9] = ".olllllllllllllllllllllrrrr..."
SHARK_BITE[10] = "..oodddffoooooooooooodttttoo.."
add_fish("shark_bite", "predators", SHARK, body=SHARK_BITE, tail=SHARK_TAIL, lid="b")

# 鱗片碎塊 (被咬時噴出)
add("scale", "effects", {"o": 0x6a1010, "s": 0xd8d0c0}, [
    "os",
    "so",
])

# 魚骨 (屍體被吃完後留在沙地上)
add("bones", "effects", {"w": 0xe8e0cc, "d": 0xb0a68e, "E": 0x2a2620}, [
    "......w.w.w.w...",
    "w....d.d.d.d.ww.",
    "wwwwwwwwwwwwwwEw",
    "w....d.d.d.d.www",
    "......w.w.w.w...",
])

# ================================================================ 底棲生物、裝飾、道具
# 蝸牛：褐色螺旋殼、灰色身體、觸角 (頭朝右)
add("snail", "creatures", {
    "o": 0x3a2414, "s": 0xc2763a, "h": 0xe8b070, "d": 0x7a4420, "b": 0x9aa0a0,
    "l": 0xc8d0cc, "E": 0x111111,
}, [
    "...oooo..E.E",
    "..ossdso.b.b",
    ".oshhdsso.b.",
    ".osdddhso.b.",
    ".ossshsoobb.",
    "bbbbbbbbbbbb",
    ".llllllllll.",
])

# 蝦子：橘紅色分節身體、長觸鬚、細腳
add("shrimp", "creatures", {
    "o": 0x5a1a0c, "r": 0xf06a3c, "h": 0xffb08a, "a": 0xffd2b8, "E": 0x111111,
}, [
    "........aaaa",
    "oo..oooo...a",
    "rroorrhrrE..",
    "orrrrhrrrro.",
    "..o.o.o.o...",
])

# 小型淡水蟹：紅橘色、舉起的鉗子
add("crab", "creatures", {
    "o": 0x4a1408, "r": 0xe0502a, "h": 0xff9a70, "E": 0x111111,
}, [
    "oo.......oo",
    "rro.E.E.orr",
    ".roorrrroor",
    "..orhhhhro.",
    "..orrrrrro.",
    ".o.o.o.o.o.",
])

# ---------------------------------------------------------------- 裝飾與道具

# 沉睡古貝殼 (闔起 / 打開)
add("shell_closed", "decorations", {
    "o": 0x3c2a20, "p": 0xd8b8a0, "d": 0xa88670, "w": 0xf4e4d4,
}, [
    "...oooooo...",
    "..opwpwpwo..",
    ".opdpdpdpdo.",
    "opdpdpdpdpdo",
    "oooooooooooo",
])
add("shell_open", "decorations", {
    "o": 0x3c2a20, "p": 0xd8b8a0, "d": 0xa88670, "w": 0xf4e4d4, "i": 0xf8c8d8, "k": 0xb07890,
}, [
    "...oooooo...",
    "..opwpwpwo..",
    ".opdpdpdpdo.",
    ".okkkkkkkko.",
    "oiiiiiiiiiio",
    "oiiiiiiiiiio",
    "opdpdpdpdpdo",
    "oooooooooooo",
])

# 古老寶箱 (闔起 / 打開)
add("chest_closed", "decorations", {
    "o": 0x2a1a0c, "w": 0x8a5a2c, "d": 0x5e3a1a, "g": 0xe8c040, "y": 0xfff0a0,
}, [
    ".oooooooooo.",
    "owwwwwwwwwwo",
    "oggggygggggo",
    "owwwdgddwwwo",
    "owwwwgwwwwwo",
    "oddddddddddo",
    "oooooooooooo",
])
add("chest_open", "decorations", {
    "o": 0x2a1a0c, "w": 0x8a5a2c, "d": 0x5e3a1a, "g": 0xe8c040, "y": 0xfff0a0, "j": 0x60e0ff,
}, [
    ".oooooooooo.",
    "owwwwwwwwwwo",
    "oggggggggggo",
    "o.yjygyjyy.o",
    "oyyyyyyyyyyo",
    "owwwdgddwwwo",
    "owwwwgwwwwwo",
    "oddddddddddo",
    "oooooooooooo",
])

# 落葉
add("leaf", "effects", {"o": 0x5a2e10, "l": 0xd8782a, "y": 0xf0a848}, [
    ".ooo.",
    "olyll",
    ".ooo.",
])

# 水草花朵
add("flower", "plants", {"o": 0x6a1a48, "p": 0xf080c0, "w": 0xffe0f0, "y": 0xffe060, "g": 0x2a8a3a}, [
    ".p.p.",
    "pwywp",
    ".pwp.",
    "..g..",
])

# 星形閃光
add("sparkle", "effects", {"w": 0xffffff, "y": 0xfff4b0}, [
    "..w..",
    ".yyy.",
    "wywyw",
    ".yyy.",
    "..w..",
])


# ================================================================ 輸出


def rgba(c):
    return ((c >> 16) & 255, (c >> 8) & 255, c & 255, 255)


def render(s, rows, closed=False, pad=1):
    pal = s["pal"]
    w, h = len(rows[0]), len(rows)
    img = Image.new("RGBA", (w, h + pad * 2), (0, 0, 0, 0))
    px = img.load()
    for y, r in enumerate(rows):
        for x, ch in enumerate(r):
            if ch == ".":
                continue
            if closed and ch == "E" and s["lid"]:
                ch = s["lid"]
            px[x, y + pad] = rgba(pal[ch])
    return img


def sheet(frames):
    fw, fh = frames[0].size
    out = Image.new("RGBA", (fw * len(frames), fh), (0, 0, 0, 0))
    for k, f in enumerate(frames):
        out.paste(f, (k * fw, 0))
    return out


def squash(img, sx):
    """轉身影格：水平最近鄰縮放 (方塊感)，置中"""
    w, h = img.size
    nw = max(1, round(w * abs(sx)))
    s = img.resize((nw, h), Image.NEAREST)
    if sx < 0:
        s = s.transpose(Image.FLIP_LEFT_RIGHT)
    out = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    out.paste(s, ((w - nw) // 2, 0))
    return out


def write_pngs():
    previews = []
    for s in SPRITES:
        frames = [render(s, f) for f in s["frames"]]
        if s["fish"]:
            d = os.path.join(ROOT, "assets", s["cat"], s["name"]) if s["cat"] == "fish" else os.path.join(ROOT, "assets", s["cat"])
            os.makedirs(d, exist_ok=True)
            n = s["name"]
            swim = sheet(frames)
            swim.save(os.path.join(d, f"{n}_swim.png"))
            sheet([frames[0], frames[2]]).save(os.path.join(d, f"{n}_idle.png"))
            sheet([render(s, s["frames"][0], closed=True)]).save(os.path.join(d, f"{n}_rest.png"))
            sheet([squash(frames[0], v) for v in (1, 0.6, 0.3, -0.6)]).save(os.path.join(d, f"{n}_turn.png"))
            previews.append(swim)
        else:
            d = os.path.join(ROOT, "assets", s["cat"])
            os.makedirs(d, exist_ok=True)
            frames[0].save(os.path.join(d, s["name"] + ".png"))
            previews.append(frames[0])
    k, pad = 6, 4
    colw = max(p.size[0] for p in previews) * k + pad * 2
    rowh = [p.size[1] * k + pad * 2 for p in previews]
    prev = Image.new("RGBA", (colw, sum(rowh)), (34, 120, 200, 255))
    y = 0
    for p, rh in zip(previews, rowh):
        prev.alpha_composite(p.resize((p.size[0] * k, p.size[1] * k), Image.NEAREST), (pad, y + pad))
        y += rh
    prev.save(os.path.join(ROOT, "assets", "preview.png"))


def write_header():
    out = ["// 由 tools/gen_sprites.py 自動產生，請勿手動修改 (改字元圖後重新執行產生器)", "#pragma once",
           '#include "Sprite.h"', "", "namespace spr {"]
    for s in SPRITES:
        pal = s["pal"]
        keys = list(pal.keys())
        idx = {ch: i + 1 for i, ch in enumerate(keys)}
        frames = s["frames"]
        w, h = len(frames[0][0]), len(frames[0])
        eye = idx.get("E", 0)
        lid = idx[s["lid"]] if s["lid"] else 0
        n = s["name"]
        out.append(f"inline constexpr uint32_t {n}_pal[] = {{0, " + ", ".join(f"0x{pal[c]:06X}" for c in keys) + "};")
        out.append(f"inline constexpr uint8_t {n}_px[] = {{")
        for rows in frames:
            for r in rows:
                out.append("  " + ",".join(str(0 if ch == "." else idx[ch]) for ch in r) + ",")
        out.append("};")
        out.append(f"inline constexpr SpriteDef {n} = {{{w}, {h}, {s['tail']}, {eye}, {lid}, {len(frames)}, {n}_px, {n}_pal}};")
    out += ["}  // namespace spr", ""]
    with open(os.path.join(ROOT, "src", "gfx", "SpriteData.h"), "w", encoding="utf-8", newline="\n") as f:
        f.write("\n".join(out))


if __name__ == "__main__":
    write_header()
    write_pngs()
    print(f"{len(SPRITES)} sprites -> src/gfx/SpriteData.h, assets/")
