"""把序列埠 evrun 的輸出整理成 tools/event_test_results.txt (給 gen_events.py 填 EVENT_CATALOG.md 的實機測試欄)

用法：python tools/parse_evrun.py <serial_log> [備註]
只採用 "[EvTest] NNN 名稱 -> OK|FAIL" 這種行；同一個 ID 出現多次以最後一次為準。
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
log, note = sys.argv[1], (sys.argv[2] if len(sys.argv) > 2 else "")
res = {}
with open(log, encoding="utf-8", errors="replace") as f:
    for line in f:
        m = re.search(r"\[EvTest\] (\d{3}) .* -> (OK|FAIL)", line)
        if m:
            res[int(m.group(1))] = m.group(2)
out = os.path.join(ROOT, "tools", "event_test_results.txt")
old = {}
if os.path.exists(out):
    with open(out, encoding="utf-8") as f:
        for line in f:
            p = line.strip().split(None, 2)
            if len(p) >= 2 and p[0].isdigit():
                old[int(p[0])] = line.strip()
for i, r in res.items():
    old[i] = f"{i} {r} {note}".strip()
with open(out, "w", encoding="utf-8", newline="\n") as f:
    for i in sorted(old):
        f.write(old[i] + "\n")
ok = sum(1 for v in res.values() if v == "OK")
print(f"{len(res)} events parsed, {ok} OK, {len(res) - ok} FAIL -> {out}")
