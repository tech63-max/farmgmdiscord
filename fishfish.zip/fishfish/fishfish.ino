// Pocket Aquarium 口袋電子水族箱
// 板子：Waveshare ESP32-S3-LCD-1.54 (無觸控)，腳位見 PINOUT.md / src/config/BoardConfig.h
// 編譯：arduino-cli compile --fqbn "esp32:esp32:esp32s3:CDCOnBoot=cdc,FlashSize=16M,PSRAM=opi,PartitionScheme=app3M_fat9M_16MB" --build-path build .
#include <Arduino.h>
#include <esp_heap_caps.h>
#include <esp_random.h>

#include "src/aquarium/Aquarium.h"
#include "src/aquarium/Creatures.h"
#include "src/aquarium/Environment.h"
#include "src/aquarium/Fish.h"
#include "src/aquarium/ParticleSystem.h"
#include "src/config/AquariumConfig.h"
#include "src/core/Util.h"
#include "src/events/EventManager.h"
#include "src/gfx/Gfx.h"
#include "src/hw/ButtonManager.h"
#include "src/hw/Display.h"
#include "src/hw/PowerManager.h"
#include "src/hw/StorageManager.h"
#include "src/storage/SaveData.h"
#include "src/ui/Ui.h"

util::Rng util::rng;

namespace {
uint32_t lastFrame = 0, lastAi = 0, lastTick = 0, lastSave = 0, lastStats = 0;
uint32_t lastFeed = 0, lastTap = 0, lastAir = 0;
uint32_t frames = 0, frameMsSum = 0, frameMsMax = 0;
uint32_t renderUs = 0, pushUs = 0, aiUs = 0;  // 最近一次的分段耗時 (效能檢查)
float blLevel = 0;
bool standby = false;  // 插 USB 時「關機」→ 待機 (關背光、停止繪圖)
char line[96];
uint8_t lineLen = 0;

// 大型事件進行中把背光拉到至少 90%，夜晚也看得清楚
float targetBacklight() {
  float f = env::backlightFactor();
  if (ev::bigActive() && f < 0.9f) f = 0.9f;
  return save::settings.brightness * f;
}

void applySettings() {
  env::setDayLength(acfg::DAY_LEN_OPTIONS[save::settings.dayLenIdx]);
  ev::setFrequency(save::settings.freq);
  gore::level = save::settings.gore;
}

void doShutdown(uint32_t ms) {
  ui::notice("存檔中，晚安…", ms);
  save::saveState(ms, true);
  save::saveConfig();
  // 畫一幀晚安畫面再關
  aquarium::render();
  ui::draw(ms);
  display::push();
  power::shutdown();  // 電池供電時在這裡斷電
  // 還活著 = USB 供電：進入待機，按任意鍵喚醒
  standby = true;
  Serial.println("[Power] USB powered: standby (press any button to wake)");
}

void runAction(const ui::Action& a, uint32_t ms) {
  switch (a.type) {
    case ui::A_FEED:
      if (lastFeed && ms - lastFeed < acfg::FEED_COOLDOWN_MS) { ui::notice("魚兒還在吃，等一下再餵", ms); break; }
      lastFeed = ms;
      aquarium::feed(ms);
      ui::notice("餵食", ms);
      save::saveState(ms, false);
      break;
    case ui::A_TAP:
      if (lastTap && ms - lastTap < acfg::TAP_COOLDOWN_MS) break;
      lastTap = ms;
      aquarium::tap(ms);
      ui::notice("叩叩…", ms);
      break;
    case ui::A_AIR:
      if (lastAir && ms - lastAir < acfg::AIR_COOLDOWN_MS) { ui::notice("打氣機休息中", ms); break; }
      lastAir = ms;
      aquarium::air(ms);
      ui::notice("打氣", ms);
      break;
    case ui::A_SETTINGS:
      applySettings();
      save::saveConfig();
      break;
    case ui::A_SAVE:
      ui::notice(save::saveState(ms, true) ? "已存檔" : "存檔失敗", ms);
      break;
    case ui::A_RESET:
      ev::stopAll();
      save::eraseAll();
      Serial.println("[Save] aquarium reset, rebooting");
      delay(100);
      ESP.restart();
      break;
    case ui::A_JUMP_TIME: {
      static const float STARTS[] = {0.22f, 0.32f, 0.75f, 0.83f};
      const float c = env::clock();
      float target = STARTS[0];
      for (float s : STARTS) if (s > c + 0.01f) { target = s; break; }
      env::setClock(target);
      char buf[32];
      snprintf(buf, sizeof(buf), "時間：%s", env::phaseName(env::phase()));
      ui::notice(buf, ms);
      break;
    }
    case ui::A_PLAY_EVENT: {
      int r = ev::trigger(a.arg, ms, true);
      char buf[64];
      const char* why = "";
      if (r == 6) why = "還沒做";
      else if (r == 5 && (a.arg == 172 || a.arg == 174) && !gore::blood()) why = "需血腥「完整」";
      else if (r == 5) why = "魚不夠";
      if (r == 0) snprintf(buf, sizeof(buf), "測試 #%03d %s", a.arg, ev::def(a.arg).name);
      else snprintf(buf, sizeof(buf), "#%03d 無法播放：%s", a.arg, why);
      ui::notice(buf, ms);
      break;
    }
    case ui::A_SHUTDOWN: doShutdown(ms); break;
    default: break;
  }
}

void sendShot() {
  // 傳回目前畫面 (RGB565 原始資料) 給 tools/serial_mon.py 存成 PNG
  Serial.setTxTimeoutMs(2000);
  Serial.printf("SHOT_BEGIN %d %d\n", gfx::W, gfx::H);
  const uint8_t* p = (const uint8_t*)gfx::fb;
  for (size_t i = 0; i < (size_t)gfx::W * gfx::H * 2; i += 480) Serial.write(p + i, 480);
  Serial.println("\nSHOT_END");
  Serial.flush();
  Serial.setTxTimeoutMs(0);
}

// ---- 序列埠測試指令 (開發用) ----
void runCommand(char* cmdLine, uint32_t ms) {
  char* cmd = strtok(cmdLine, " ");
  char* a1 = strtok(nullptr, " ");
  char* a2 = strtok(nullptr, " ");
  char* a3 = strtok(nullptr, " ");
  if (!cmd) return;
  if (!strcmp(cmd, "help")) {
    Serial.println("status | fish | ev <id> | ev list | ev stop | evrun <from> <to> [sec] | sched | log");
    Serial.println("feed | tap | air | phase <dawn|day|dusk|night|deep> | clock <0-1> | speed <x>");
    Serial.println("btn <left|mid|right> [long] | save | load | reset | shot | mem");
    Serial.println("kill <i> | newfish | deaths | gore <0-2> | day <n>");
  } else if (!strcmp(cmd, "status")) {
    char t[32];
    env::virtualTime(t, sizeof(t));
    const env::Eco& e = env::eco;
    Serial.printf("%s %s clock %.3f speed x%.0f | temp %.1f clarity %.2f plant %.2f mood %.2f energy %.2f food %.2f algae %.2f feeds %lu\n",
                  t, env::phaseName(env::phase()), env::clock(), env::timeScale(), e.waterTemp, e.clarity, e.plantGrowth, e.fishMood, e.fishEnergy,
                  e.food, e.algae, (unsigned long)e.feeds);
    Serial.printf("discovered %d/%d, SD %s (%s), backlight %.0f%%\n", ev::discoveredCount(), ev::implementedCount(), storage::ok() ? "ok" : "none", save::status(), blLevel);
    ev::printSchedule(ms);
  } else if (!strcmp(cmd, "mem")) {
    Serial.printf("heap int %u (min %u) psram %u, frame avg %lu ms max %lu ms\n", (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL),
                  (unsigned)heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL), (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM),
                  (unsigned long)(frames ? frameMsSum / frames : 0), (unsigned long)frameMsMax);
    Serial.printf("last render %lu us, push %lu us, ai %lu us\n", (unsigned long)renderUs, (unsigned long)pushUs, (unsigned long)aiUs);
    Serial.print("  prof us:");
    for (int i = 0; i < aquarium::PROF_N; i++) Serial.printf(" %lu", (unsigned long)aquarium::prof[i]);
    Serial.println();
  } else if (!strcmp(cmd, "fish")) {
    for (int i = 0; i < fish::count(); i++) {
      const fish::Fish& f = fish::F[i];
      if (!f.on) continue;
      Serial.printf("  %2d %s %-12s v%u %s %-8s x%5.1f y%5.1f mood %.2f energy %.2f owner %u layer %u hurt %.0f born %lu\n", i, fish::nameOf(i),
                    fish::info(f.sp).name, f.var, fish::persName(f.pers), fish::stateName(f.st), f.x, f.y, f.mood, f.energy, f.owner, f.layer, f.hurt,
                    (unsigned long)f.born);
    }
    for (int i = 0; i < creatures::cap(); i++) {
      const creatures::C& c = creatures::at(i);
      if (c.on) Serial.printf("  creature %s x%.0f y%.0f mode %u owner %u\n", creatures::name(c.type), c.x, c.y, c.mode, c.owner);
    }
  } else if (!strcmp(cmd, "ev")) {
    if (!a1 || !strcmp(a1, "list")) {
      for (int id = 1; id <= ev::EVENT_COUNT; id++) Serial.printf("%03d %s (%u)%s", id, ev::def(id).name, ev::timesSeen(id), id % 5 ? "  " : "\n");
    } else if (!strcmp(a1, "stop")) {
      ev::stopAll();
      Serial.println("events stopped");
    } else {
      int id = atoi(a1);
      Serial.printf("trigger %03d %s: %d\n", id, ev::def(id).name, ev::trigger(id, ms, true));
    }
  } else if (!strcmp(cmd, "evrun") && a1 && a2) {
    ev::runSequence(atoi(a1), atoi(a2), a3 ? atof(a3) : 12, ms);
  } else if (!strcmp(cmd, "sched")) {
    ev::printSchedule(ms);
  } else if (!strcmp(cmd, "log")) {
    for (int i = 0; i < ev::logCount(); i++) {
      const ev::LogEntry& e = ev::logAt(i);
      Serial.printf("  day %lu %02u:%02u %03u %s%s\n", (unsigned long)e.day, e.minute / 60, e.minute % 60, e.id, ev::def(e.id).name, e.user ? " (user)" : "");
    }
  } else if (!strcmp(cmd, "feed")) runAction({ui::A_FEED, 0}, ms);
  else if (!strcmp(cmd, "tap")) runAction({ui::A_TAP, 0}, ms);
  else if (!strcmp(cmd, "air")) runAction({ui::A_AIR, 0}, ms);
  else if (!strcmp(cmd, "phase") && a1) {
    const char* N[] = {"deep", "dawn", "day", "dusk", "night"};
    const float C[] = {0.05f, 0.23f, 0.40f, 0.77f, 0.86f};
    for (int i = 0; i < 5; i++) if (!strcmp(a1, N[i])) env::setClock(C[i]);
    Serial.printf("phase %s\n", env::phaseName(env::phase()));
  } else if (!strcmp(cmd, "clock") && a1) {
    env::setClock(atof(a1));
  } else if (!strcmp(cmd, "speed") && a1) {
    env::setTimeScale(atof(a1));
    Serial.printf("time scale x%.1f\n", env::timeScale());
  } else if (!strcmp(cmd, "btn") && a1) {
    buttons::Event e;
    // 左鍵 = BOOT、中鍵 = PWR、右鍵 = PLUS (舊名稱也可以用)
    e.btn = (!strcmp(a1, "left") || !strcmp(a1, "boot")) ? buttons::BOOT
            : ((!strcmp(a1, "mid") || !strcmp(a1, "pwr")) ? buttons::PWR : buttons::PLUS);
    e.kind = (a2 && !strcmp(a2, "long")) ? buttons::LONG : buttons::SHORT;
    runAction(ui::handle(e, ms), ms);
  } else if (!strcmp(cmd, "save")) {
    Serial.printf("save: %d (%s)\n", save::saveState(ms, true), save::status());
  } else if (!strcmp(cmd, "load")) {
    Serial.printf("load: %d (%s)\n", save::loadState(), save::status());
  } else if (!strcmp(cmd, "reset")) {
    runAction({ui::A_RESET, 0}, ms);
  } else if (!strcmp(cmd, "kill") && a1) {
    fish::kill(atoi(a1), 0);
    fish::queueRefill(3, 5, 8);
    Serial.printf("alive %d\n", fish::alive());
  } else if (!strcmp(cmd, "blood")) {
    particles::blood(120, 110, 20, 8);
    Serial.printf("gore %u blood particles %d\n", gore::level, particles::bloodAmount());
  } else if (!strcmp(cmd, "newfish")) {
    Serial.printf("spawn %d\n", fish::spawnNew(-20, 100, 120, 100));
  } else if (!strcmp(cmd, "deaths")) {
    Serial.printf("deaths total %d\n", fish::deathCount());
    for (int i = 0; i < fish::deathLogN(); i++) {
      const fish::Death& d = fish::deathAt(i);
      Serial.printf("  day %lu %s %s v%u cause %u\n", (unsigned long)d.day, fish::nameAt(d.nameIdx), fish::info(d.sp).name, d.var, d.cause);
    }
  } else if (!strcmp(cmd, "gore") && a1) {
    save::settings.gore = (uint8_t)constrain(atoi(a1), 0, 2);
    applySettings();
    Serial.printf("gore %u\n", gore::level);
  } else if (!strcmp(cmd, "day") && a1) {
    env::begin(env::clock(), (uint32_t)atoi(a1), env::dayLength());
    Serial.printf("day %lu\n", (unsigned long)env::day());
  } else if (!strcmp(cmd, "shot")) {
    sendShot();
  } else {
    Serial.println("unknown command (help)");
  }
}

void pollSerial(uint32_t ms) {
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c == '\r') continue;
    if (c == '\n') { line[lineLen] = 0; runCommand(line, ms); lineLen = 0; continue; }
    if (lineLen < sizeof(line) - 1) line[lineLen++] = c;
  }
}
}  // namespace

void setup() {
  power::earlyInit();  // 電源鎖定 + 關功放：最先做
  Serial.begin(115200);
  Serial.setTxTimeoutMs(0);  // PINOUT 坑 #3
  util::rng.seed(esp_random());

  if (!gfx::begin()) {
    Serial.println("[Boot] framebuffer alloc failed");
    for (;;) delay(1000);
  }
  if (!display::begin()) Serial.println("[Boot] LCD init failed");
  const uint32_t ms = millis();

  const bool sdOk = storage::begin();
  Serial.printf("[Boot] SD %s\n", sdOk ? "mounted" : "not present (running from RAM / NVS backup)");
  save::begin(sdOk);
  save::loadConfig();

  env::begin(acfg::FIRST_BOOT_CLOCK, 1, acfg::DAY_LEN_OPTIONS[save::settings.dayLenIdx]);
  aquarium::begin();
  ev::begin(ms);
  ui::begin();
  ev::setStartCallback([](int id, bool user) { ui::onEventStart(id, user, millis()); });
  ev::setMessageCallback([](const char* text) { ui::notice(text, millis()); });
  const bool restored = save::loadState();
  Serial.printf("[Boot] state %s\n", restored ? "restored" : "new aquarium");
  applySettings();
  buttons::begin(ms);

  // 第一幀畫好才開背光，避免看到雜訊
  aquarium::updateFrame(0.05f, ms);
  aquarium::render();
  display::push();
  blLevel = targetBacklight();
  display::setBacklight(blLevel);
  ui::notice(restored ? "水族箱恢復運作" : "歡迎來到口袋水族箱", ms);
  lastFrame = lastAi = lastTick = lastSave = lastStats = ms;
  Serial.printf("[Boot] ready. heap int %u psram %u, fb %s\n", (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL),
                (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM), esp_ptr_internal(gfx::fb) ? "internal" : "psram");
}

void loop() {
  const uint32_t ms = millis();
  const buttons::Event be = buttons::poll(ms);
  pollSerial(ms);

  if (standby) {
    if (be.btn != buttons::NONE) {
      standby = false;
      lastFrame = lastAi = ms;
      ui::notice("早安！", ms);
    }
    vTaskDelay(10);
    return;
  }
  if (be.btn != buttons::NONE) runAction(ui::handle(be, ms), ms);

  // 魚類 AI (約 25 次/秒)
  if (ms - lastAi >= acfg::AI_MS) {
    float dt = fminf((ms - lastAi) / 1000.0f, 0.1f);
    lastAi = ms;
    uint32_t t0 = micros();
    aquarium::updateAi(dt, ms);
    aiUs = micros() - t0;
  }
  // 事件調度 (每秒)
  if (ms - lastTick >= acfg::EVENT_TICK_MS) {
    lastTick = ms;
    ev::tick(ms);
    ui::update(ms);
  }
  // 定期存檔
  if (ms - lastSave >= acfg::SAVE_INTERVAL_MS) {
    lastSave = ms;
    save::saveState(ms, true);
  }
  // 畫面 (約 20 FPS)
  if (ms - lastFrame >= acfg::FRAME_MS) {
    float dt = fminf((ms - lastFrame) / 1000.0f, 0.1f);
    lastFrame = ms;
    uint32_t t0 = micros();
    aquarium::updateFrame(dt, ms);
    aquarium::render();
    ui::draw(ms);
    uint32_t t1 = micros();
    display::push();
    renderUs = t1 - t0;
    pushUs = micros() - t1;
    blLevel = util::approach(blLevel, targetBacklight(), dt * 15);
    display::setBacklight(blLevel);
    uint32_t took = millis() - ms;
    frames++; frameMsSum += took; if (took > frameMsMax) frameMsMax = took;
  }
  if (ms - lastStats >= 60000) {
    Serial.printf("[Stats] fps %.1f avg %lu ms max %lu ms, heap int %u (min %u) psram %u\n", frames / 60.0f,
                  (unsigned long)(frames ? frameMsSum / frames : 0), (unsigned long)frameMsMax,
                  (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL), (unsigned)heap_caps_get_minimum_free_size(MALLOC_CAP_INTERNAL),
                  (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM));
    lastStats = ms;
    frames = frameMsSum = frameMsMax = 0;
  }
  vTaskDelay(1);  // 讓出 CPU (不阻塞)
}
