# farmgm（Go 版）

農場經營遊戲的 Go 重構，來源是 Python 專案 `farmgmdiscordb-feature-exploration-update`。範圍只包含農場相關功能，音樂（`app/music`、Lavalink）不移植，繼續使用 Python 版。

## 原則

- **資料庫 schema 不變**：沿用同一個 PostgreSQL，Migration 仍由 Python 專案的 Alembic 管理（目前 head 0036）。Go 版只檢查 `alembic_version`，不自己建表。
- **規則逐行對照 Python**：
  - Python `round()` 用 `numfmt.Round`（四捨六入五成雙）。
  - `//`、`%` 用 `numfmt.FloorDiv`／`Mod`。
  - 字串長度以字元（rune）計算。
  - Python 的 `None` 以 nil 指標或 `""` 表示，各函式註解有說明。
  - dict 順序有意義時，用 `*Order` 切片保留。
- **設定**：系統環境變數優先於 `.env`，空值視為未設定，`MUSIC_*` 等未知設定會被忽略。機密欄位不會出現在 `Settings.String()`。

## 進度

| 階段 | 內容 | 狀態 |
| --- | --- | --- |
| 1 | `internal/clock`、`config`、`numfmt`、`game/*`（全部純規則，對應 `app/game/`） | ✅ 完成 |
| 2 | `internal/db`（pgx 連線池、交易、交易內快取、目錄快取、Migration 版本檢查）、`db/models`（60 張表）、`repositories/*`（29 個） | ✅ 完成 |
| 3 | services（交易、鎖定、`_record` 不變式、txcache） | 未開始 |
| 4 | 管理／監控 API、介紹網站（前端靜態檔沿用） | 未開始 |
| 5 | Discord 農場面板 | 未開始 |
| 6 | CMD | 未開始 |

## 指令

```powershell
go vet ./...
go test -p 1 ./...     # -short 會縮減釣魚模擬次數
```

需要資料庫的測試讀環境變數 `FARMGM_TEST_DATABASE_URL`，資料庫名稱必須以 `_test` 結尾，因為測試會清空遊戲資料表。沒有設定這個變數時，這些測試會自動略過。
- 測試資料庫的 schema 用 Python 專案的 `alembic upgrade head` 建立。
- 所有測試共用同一個資料庫，所以一律加 `-p 1`，同一時間也只能有一個 `go test` 程序。

## 與 Python 版的差異（資料層）

- Go 沒有 ORM autoflush。Python 改 ORM 物件屬性靠 flush 寫入的地方，Go 一律寫明確的 UPDATE／INSERT（`db.UpdateByID`、`farms.Plant`、`ruins.Save` 等）。
- 時間欄位：
  - `timestamptz` 一律讀回 UTC。比較時間請用 `Equal`，不要用 `==`。
  - DATE 欄位讀回後用 `db.TaipeiDate` 轉成台灣日期，寫入用 `db.DateParam`。
- 釣魚 Session 的 `state` 保留原始 JSON（`json.RawMessage`），未知欄位不會遺失。
- 讀取快取（`db.ReadMemo`）回傳的切片與快取共用，呼叫端不可修改。
