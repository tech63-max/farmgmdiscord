# 農場 Go 重構：進度說明（2026-11-09）

來源：Python 專案 `farmgmdiscordb-feature-exploration-update`（Alembic head 0036）。
目標：把**農場相關**的 Python 程式改寫成 Go。音樂（`app/music`、Lavalink）不移植，繼續使用 Python 版。

目前完成 **第 1、2 階段**：遊戲規則與資料庫層。服務層、網站、Discord 面板、CMD 都還沒開始，**現在還不能取代 Python 版執行**。

## 進度

| 階段 | 內容 | 狀態 |
| --- | --- | --- |
| 1 | 遊戲規則（對應 `app/game/` 全部 18 個模組）、設定、時鐘 | ✅ 完成 |
| 2 | 資料庫核心、60 張表的模型、29 個 repositories | ✅ 完成 |
| 3 | services（交易、鎖定、`_record` 交易紀錄不變式、一鍵操作；約 8,200 行 Python） | 未開始 |
| 4 | 管理／監控 API、介紹網站（前端靜態檔原樣沿用） | 未開始 |
| 5 | Discord 農場面板（含 Pillow 農田圖的改寫） | 未開始 |
| 6 | CMD | 未開始 |

## 目錄結構

| 路徑 | 對應 Python | 說明 |
| --- | --- | --- |
| `internal/clock` | `app/clock.py` | `Clock` 介面、系統時鐘、測試用 `Manual` 時鐘（起點 2026-01-01 UTC）、`TaipeiTZ` |
| `internal/config` | `app/config.py` | 讀 `.env`＋環境變數（環境變數優先、空值視為未設定、未知設定忽略），只保留農場設定；`String()` 遮蔽機密 |
| `internal/numfmt` | — | 與 Python 一致的千分位、`round()`（四捨六入五成雙）、`//`、`%` |
| `internal/game/*` | `app/game/*` | 17 個規則套件：gameerr、balance、rules、featurecfg、genetics、events、seasons、checkin、pets、specialshop、achievements、exploration、ruins、fishing、worldboss、news、ranking |
| `internal/db` | `app/db/session.py`、`txcache.py`、`catalog_cache.py`、`check.py` | pgx 連線池、`Tx`（對應 Session，支援 SAVEPOINT）、一鍵操作的快取與延後寫入、讀取快取、目錄快取、Migration 版本檢查 |
| `internal/db/models` | `app/db/models.py` | 60 張表的 struct（`db` tag），約束與 server_default 寫在註解 |
| `internal/repositories/*` | `app/repositories/*` | 29 個 repository；`repotest` 是測試專用夾具 |
| `internal/dbtest` | `tests/conftest.py`（部分） | 測試資料庫連線與每個測試前的資料清空（依外鍵順序 DELETE、序號歸 1） |

## 設計原則

- **資料庫 schema 不變**：與 Python 版共用同一個 PostgreSQL。Migration 仍由 Python 專案的 Alembic 管理。Go 只檢查 `alembic_version` 是否等於 `db.AlembicHead`（0036），不會建表或改結構。Python 新增 Migration 時，Go 要同步修改。
- **逐行對照 Python**：
  - 錯誤訊息、常數、繁體中文註解照搬。
  - 數值運算用 `numfmt` 保持與 Python 相同的結果。
  - Python 的 `None` 以 nil 指標或 `""` 表示，在各函式的註解中說明。
  - dict 順序有意義時，用 `*Order` 切片保留。
- **SQL 一律參數化**：欄位名稱只能是程式常數（`db.UpdateByID` 等工具會檢查識別名稱）。
- **機密不寫入程式或日誌**：連線失敗只回報錯誤類型，不顯示連線字串。

## 與 Python 版行為不同之處（重要）

1. **沒有 ORM autoflush**：Python 修改物件屬性後靠 flush 寫入的地方，Go 一律寫明確的 UPDATE／INSERT。第 3 階段移植服務層時，這是最容易漏掉的地方。
2. **時間**：
   - `timestamptz` 一律讀回 UTC，比較時要用 `Equal`，不要用 `==`。
   - DATE 欄位讀回後用 `db.TaipeiDate` 轉成台灣日期，寫入時用 `db.DateParam`。
   - game 套件中的日期一律是「台灣時間 00:00 的 `time.Time`」。
3. **釣魚 Session 的 `state`**：資料層保留原始 JSON（`json.RawMessage`），未知欄位不會遺失。規則套件的 `fishing.State` 是固定欄位的 struct，服務層寫回時要注意不要丟失 Python 另外存的欄位。
4. **讀取快取回傳的切片**：與快取共用，呼叫端不可修改。Python 回傳的是複本。
5. **map 沒有順序**：
   - 簽到獎勵文字同一天有多種道具時，改依道具商店的順序排列。
   - 成就、世界 Boss 設定同時有多個錯誤時，第一個回報的錯誤可能和 Python 不同。
6. **農場日報的亂數**：另外實作了與 CPython 相同的 Mersenne Twister。日報文字與傳聞結果已和 Python 實際輸出逐字比對，結果一致（`internal/game/news/testdata/python_reference.json`）。
7. **釣魚、山洞的測試亂數**：測試使用 Go 的亂數，序列與 Python 不同，但斷言與統計門檻相同。

## 測試

```powershell
go vet ./...
go test -p 1 ./...     # -short 會縮減釣魚模擬次數
```

- **最後一次實際結果**（2026-11-09）：
  - `go test -p 1 -count=1 ./...` 共 144 個測試全部通過，0 失敗、0 略過。資料庫測試是對 PostgreSQL 16、schema 0036 執行的。
  - `go vet`、`gofmt` 無問題。
  - Go 檔案都是 UTF-8 無 BOM、LF。
- **已移植與未移植的測試**：
  - Python 測試中不需要資料庫的純規則測試已移植。
  - 需要服務層的整合測試（Python 約 660 個中的大部分）還沒移植，會在第 3 階段移植。
- **測試資料庫**：需要資料庫的測試讀環境變數 `FARMGM_TEST_DATABASE_URL`。資料庫名稱必須以 `_test` 結尾，因為測試會清空遊戲資料表。沒有設定時，這些測試會自動略過。
- **不能同時執行**：所有測試共用同一個資料庫，必須加 `-p 1`，而且同一時間只能有一個 `go test` 程序。同時執行會互相清空資料、甚至卡住鎖。

### 建立測試資料庫（範例）

1. 開一個暫時的 PostgreSQL 容器（隨機密碼，只綁本機）：

   ```bash
   docker run -d --name fmgonew-test-pg -e POSTGRES_USER=farmgm -e POSTGRES_PASSWORD=<隨機> \
     -e POSTGRES_DB=farmgm_test -p 127.0.0.1:5544:5432 postgres:16
   ```

2. 在 Python 專案建立 schema。Python 環境需要 `requirements-dev.txt`：

   ```bash
   DATABASE_URL=postgresql+psycopg://farmgm:<隨機>@127.0.0.1:5544/farmgm_test python -m alembic upgrade head
   ```

3. 在 Go 專案執行測試：

   ```bash
   FARMGM_TEST_DATABASE_URL=postgresql://farmgm:<隨機>@127.0.0.1:5544/farmgm_test go test -p 1 ./...
   ```

4. 用完刪除：`docker rm -f -v fmgonew-test-pg`。

不要對 `farmgm` 專案的 Volume 或正式資料庫執行測試。

## 依賴

- Go 1.23 以上（開發時使用 1.27.0）
- `github.com/jackc/pgx/v5` v5.7.5（其餘為它的間接依賴，見 `go.sum`）

## 下一步（第 3 階段）

依 Python 的服務繼承鏈，由下往上分批移植。Go 不用繼承，會改成組合多個 service struct。順序如下：

1. GameService
2. RanchService
3. ExplorationService
4. FishingService
5. SocialService
6. CommunityService
7. RankingService
8. WorldBossService
9. NewsService
10. ProgressService
11. AdminService

每一批都要同時移植對應的 Python 整合測試，並和 Python 的結果比對。需要特別注意：

- `_record()`：所有資產變動都要寫交易紀錄，`gold_delta` 加總必須等於全服金幣。
- 鎖定順序：例如遺跡列 → 農場列 → 守護者列。
- `RetryingService`：遇到 40P01／40001 時重試。
- 面板讀取整頁的共用交易（`run_batch`）。

## 已知風險

- 第 3～6 階段尚未開始，Go 版目前只有規則與資料層，不能上線。
- 資料層只做了冒煙測試，完整正確性要等服務層整合測試對照 Python 才能確認。
- Discord 函式庫要從 discord.py 換成 Go 的函式庫，例如 discordgo；Pillow 圖片合成要改用 Go 的 `image` 套件。這兩部分的行為差異要另外驗證。

## 附錄：檔案清單與 SHA-256

共 124 個檔案（不含本說明檔）。

| 檔案 | SHA-256 |
| --- | --- |
| `README.md` | `6affebb505f72acb51644a329c54c4e01e7a580eaa6f565dc7536cb0988b1f45` |
| `go.mod` | `e03429a1ced77d1cafca9e7592bd49eda3b1775538ee35380658f923ee693188` |
| `go.sum` | `5433425cdfb206402fb957dad90007ae871a79e0bd52d91c0f63db0c899b5838` |
| `internal/clock/clock.go` | `0017235591ecf1d508aecc3c361e4d7c4a51258fea9c78d7e1049e61e8a4c7be` |
| `internal/config/config.go` | `b51f4d30ea142758e7d42d6c0110c47e8b00f1a7977f8d2d01524dc14ca58eff` |
| `internal/config/config_test.go` | `da494a09a62fef0ae369668f06c98fa509aa8fc9e8f16c293ae95b99b1e07853` |
| `internal/db/catalog.go` | `eab43484e845a071b359e48b69ffc54fd561d5da2837862de9209f33d16d7d27` |
| `internal/db/check.go` | `c40ebce295a8ec29a5eed744450a57206494c40395b128b56d3843a9a141ec35` |
| `internal/db/db.go` | `1918a4f7004cee675d17ed0ab03ef977dbc40765b865d782d5af8be9c0fd9492` |
| `internal/db/db_test.go` | `5a8a5b9b2e5cbe48cfca356b3baa51328f69cc14bb20a57ec21335b626fc5c72` |
| `internal/db/models/community.go` | `f7ad97323c057ea24f4f2edc59769f822794cfa38664bc2f89eb8007620415c9` |
| `internal/db/models/constants.go` | `5a8f4df660057f90cef03ec9e5b532391c6455d2a7c6ed8bd56e67fc3447f0c6` |
| `internal/db/models/farm.go` | `9d141960b4fbee67bec3c6dfcd14211ac43e93e921803191359dec3b1f28f2b4` |
| `internal/db/models/fishing.go` | `d26a44170a22956373cba1f9f934e8a3173eae62f4e7451afa0dc5117ee76243` |
| `internal/db/models/models_test.go` | `eb4b324a8a710d7dd6c168334a06e2a11b5b6242183a96095c1c40cf4fdc9b9b` |
| `internal/db/models/progress.go` | `173e7aff9e5d1174ce5cf09294060462a3c9ee48c7cfe9b41cf832509654e786` |
| `internal/db/models/worldboss.go` | `1f2db2b61d9e2e8db289a7bc1ce0a83a27556475c599307f57750125de51acd7` |
| `internal/db/sqlutil.go` | `f7dcffee8eea287b7a0c182547300fcf6917f9ba7cb8e4d9e86eb3be2f3496b0` |
| `internal/db/txcache.go` | `9979cd0bf7e3275bcc55139caee976ee08e7ca2d61b24b2390c75ed9e4120965` |
| `internal/dbtest/dbtest.go` | `aa22f85f8fd8a7c4ce141537781a283a8e86bad91f1ed65947bb15efad5cfa45` |
| `internal/dbtest/reset.go` | `5ab0cfb74e6411b3c6455b110943649d060e3fd48739db80ca6b908b8cfcd0d6` |
| `internal/dbtest/reset_test.go` | `db536239c940c4a4a00a0f8d75be184c8083ef52c2e77851bf14b2f86972260c` |
| `internal/game/achievements/achievements.go` | `4cb417b71c2d223f5046d13bbf86c4d078d563f62c57e773d1833c2b8cf41b2d` |
| `internal/game/achievements/achievements_test.go` | `49fd0bc8c0d0931e80727bc58d6765bf066acdcaa8a532264bcce47062d2de00` |
| `internal/game/balance/balance.go` | `d590e7f7b103a93c72c6c44bfbbe8ea027dba7b8ce772ea30d8c1e872825bf9f` |
| `internal/game/checkin/checkin.go` | `7f48d4457a07a7cea8f8ca487c385bd9a8719e833345cb8236ed76506e740d17` |
| `internal/game/checkin/checkin_test.go` | `0ca089b008745912db964774e892ac603c79494cda262f90196b07c23d72c860` |
| `internal/game/events/events.go` | `74a1ec9ec051beee22911273766377de756dbe22ccf64e9a687d3c3d7647a870` |
| `internal/game/events/events_test.go` | `06a236f059e6ed8c5896225e683fabf0865d738f7ae7afcaef752d7b1ac6ee70` |
| `internal/game/exploration/exploration.go` | `10cb3b81533da01c14f47ec2cbc8737ddb87625babbf0249592c51ad97be81dc` |
| `internal/game/exploration/exploration_test.go` | `92c45a2caf2192c93bab90a1b9e3c66d2d1d2b709983cc7856d52bfe744a6c5e` |
| `internal/game/featurecfg/featurecfg.go` | `9df670e9c365358bf783f89ea724663a69053f6390cb846ad8c80af317b28c80` |
| `internal/game/fishing/fishing.go` | `164e5485c81e75813ce188ad7ffe5a10518c8eaec6a519fb82827fd1fee117f2` |
| `internal/game/fishing/fishing_test.go` | `e194c7f05dd44665c883265724cec95a65865da15abdf6d7953396c1eeb2f67f` |
| `internal/game/fishing/json_test.go` | `7613db59ac20e6f4336bbe131c006a6acbaa7289e43ed46d41072f2dcc5ff470` |
| `internal/game/gameerr/errors.go` | `a1a295c2f0e0f9ac1b431f18eea6594cf663607864234d3cae3911c234a72264` |
| `internal/game/genetics/genetics.go` | `aa93e03a5506fcff159323541c4de833eac8fb8fac75d5c5e604d240a19a9dd1` |
| `internal/game/genetics/genetics_test.go` | `6d5915b5412a42e2f6941200ffa827c026b175ff24f361dce19d659433192eca` |
| `internal/game/news/news.go` | `0ed4d661bd9147bb528a30ead5bca82b628129d92ffba6134dd9eef8d5ab3fea` |
| `internal/game/news/news_test.go` | `560577fc7d61efc97ab45f69444a995d5177258a2277f890d6ce3b600a894a15` |
| `internal/game/news/pyrandom.go` | `d42860357a6401ee709b1dc6a98c40c21d81be1428f9776b8ffb91e1130a82fe` |
| `internal/game/news/testdata/python_reference.json` | `77d34f8afea0ffe52d7609883be0791e185e197c38f2be509bd2ae926e53d5ef` |
| `internal/game/pets/pets.go` | `ff6b707dc8ae1ef0bc3f76fd707dd764cb522311ce0169e33058c1965b3922ae` |
| `internal/game/pets/pets_test.go` | `31e5e5f5ea0a7344adf6a09ee0da4c27e8baa60c33af3115cd9cc1ed52deb8d3` |
| `internal/game/ranking/ranking.go` | `44463a83831bf19ccf83d0c33157b354bca4539f8b81910d6996fe8deb329f6b` |
| `internal/game/ranking/ranking_test.go` | `4d8b0cb1e2a1aa23a212531655100e0f135e0ffc8ad4ef81836d72f999fde97e` |
| `internal/game/ruins/ruins.go` | `da90bf8b9728818c3cdbf52951d79f7e1c0674d5549572848ce8595229e116c1` |
| `internal/game/ruins/ruins_test.go` | `cd832a43e62d3d3263eb281a0718362780b62714f932f54e5d7f24bad6daf3c9` |
| `internal/game/rules/rules.go` | `71b54495ec4113dbfc6922ceec74fa8275d738f8fe4e2d0becd5f42c969bbc8c` |
| `internal/game/rules/rules_test.go` | `15a50ff32878f023b6ef40aba46da086e51defd5ad01d0b2e95dc1a8c7af76e2` |
| `internal/game/seasons/seasons.go` | `f1640cba890a95e0b12dcd4d819437971c970e5439e2ae114855bf0c728c22eb` |
| `internal/game/seasons/seasons_test.go` | `0969bac440644fd687fe7d97ee07858c258aea572611bc18881cffff7de2db8d` |
| `internal/game/specialshop/specialshop.go` | `2fec3d9bb244583b748a884e9c8566837bed59ba9d889323b10d241ce3e88120` |
| `internal/game/specialshop/specialshop_test.go` | `b7dbccb2994dfdb8f2a49731b417eaa79c6249edad3a45fd0d480d2e81276590` |
| `internal/game/worldboss/worldboss.go` | `94686352a64463785e32bfa7b26be476a701c23344e18ac42daf21f8e43eaf6e` |
| `internal/game/worldboss/worldboss_test.go` | `3e8e401523c65ea2d615853ea4c038a2b5d239c3b073cc591e8e70a0e407f718` |
| `internal/numfmt/numfmt.go` | `792645f7d8b56d8dd1650b4daff3d696bce1a7af2c6c6fc4a8982fa0cdfe5202` |
| `internal/repositories/animals/animals.go` | `12d48b0012c10a7905e4090480a7e7328e885fb18686d2b492b685c724c6c2fc` |
| `internal/repositories/animals/animals_test.go` | `60a62222f56db2a60d505504255c9f86d1754daa10cd58058b307be00c986b0a` |
| `internal/repositories/catalog/catalog.go` | `55d5ae064eca7c9c05424e2c149f9394582fbb6c96851c40f0d48d1af04bb116` |
| `internal/repositories/catalog/catalog_test.go` | `ee05bc9ccfe990a416cc9a38269161474eca1b6bf8972d0c2bae3fc84a9655c1` |
| `internal/repositories/codex/codex.go` | `4d95da61f821ac820cb7be49af43e9dd659afcb4c487c9b70dea98f7014ee6aa` |
| `internal/repositories/codex/codex_test.go` | `31cfed5a5286323ce4a1adbe3c36e02d39818172c53d5b65528ba821be976637` |
| `internal/repositories/codex/helpers_test.go` | `f1c916ec4707690601a670c6b8a327e22babafb258cf13c07ad721126e3e8000` |
| `internal/repositories/community/community.go` | `f3343f90c52a9dcc49efb5b328188df76bd686e5b3125dc9eaaf5ec53d9c2d21` |
| `internal/repositories/community/community_test.go` | `6a2f6cf1fa19842c9c77b56207703ab4254e874bde8e41252467300bd0e10dfa` |
| `internal/repositories/crops/crops.go` | `d2d13cbfefe91626660390da25fe49ea4fd004c3c7337ef26302b3bfbc99c307` |
| `internal/repositories/crops/crops_test.go` | `bd1d7d8e35b87d3ada06f709aab5aceddc9f512073de058517e19871f12ea2f2` |
| `internal/repositories/defenses/defenses.go` | `4ad45a97e3feabe4d3247b79418b05adfa78b9ac8abead16831abd056cb04b27` |
| `internal/repositories/defenses/defenses_test.go` | `80aeb6a3651affdf584edb6cdd705bca765b04ad8dbf3a417ffd283dde91fe1a` |
| `internal/repositories/events/events.go` | `7507607512de2c7860e5ddfdc0ecaff2fcbea6dc1eba4c50c56eee57a1ff3df2` |
| `internal/repositories/events/events_test.go` | `015f565b7a1aeaa8635f3f4e80f4a653094b4c5b53a698a6e87a076d2e57a395` |
| `internal/repositories/exploration/exploration.go` | `f49527fa0793da1c5edfbf36e6583e8aa3703c2f77fa3f30987ce0d7289997ca` |
| `internal/repositories/exploration/exploration_test.go` | `bacae59f6bccfed9a353d54291d170c89562ff5e40514cba449002650afffbfb` |
| `internal/repositories/exploration/helpers_test.go` | `ec9daecb81de6491aea7860246cc4117255b5a0bbed99087d8c70c861fad8981` |
| `internal/repositories/farms/farms.go` | `101cba9c58250abe04a92c225afd80aad51d6bd57d7da9e2726e52171a565d53` |
| `internal/repositories/farms/farms_test.go` | `f49ceaa960d2e1804f4168099669dda45ef268f264b69a27ce762a0a0b95c2da` |
| `internal/repositories/farmstats/farmstats.go` | `347da44c9f1bdbe89d192cf511f2757a6a4569773ddf0a2191c3ffed599f7b44` |
| `internal/repositories/farmstats/farmstats_test.go` | `41231774dfee33d665c13670d392d8371ef41724650ff7193a550707552ce430` |
| `internal/repositories/featuresettings/featuresettings.go` | `5d2a6dec9589db25bb5cb7e509f3d22b9be9066db46cbb490e2ffa40fc007f4f` |
| `internal/repositories/featuresettings/featuresettings_test.go` | `b0ca5ed9c665c4b5ace5f70552b91d0303860df61ffb4d884b8d3017c558e7b7` |
| `internal/repositories/featuresettings/helpers_test.go` | `e1d46d25725f5251132f9cf5a2322c7db302c9e4a03bab25ef5ac1f098f567f9` |
| `internal/repositories/feedback/feedback.go` | `a6b0a650e46791c1929bd58c230c8f0e56e6018242f270113710fcee5979be3a` |
| `internal/repositories/feedback/feedback_test.go` | `f01231153814146d916e7e7bef0087293c81ccea02f52620a81c7a2dc3ea108d` |
| `internal/repositories/feedback/helpers_test.go` | `c933b0883ca1d868383c0178069d7edf113ccdc4493e4302f13a88a5a1e3e576` |
| `internal/repositories/fishing/fishing.go` | `783712a0c1d3570c708afe667c3a6e52eb4bd9b8230afeaaef201b1a3bffbd99` |
| `internal/repositories/fishing/fishing_test.go` | `468ebd9680ceeed64a0ed6628784c342a1ceca96cbb67539c5526b3ff6f9a5df` |
| `internal/repositories/fishing/helpers_test.go` | `5b57f1575ebac144edca42fe126c61025a96de2c12b418a63a51b8aa59f275c5` |
| `internal/repositories/genetics/genetics.go` | `de17b8d1184a90ad58cf25f664bb47d793fb6ec30fcd22564b8d6a9ddac9de2b` |
| `internal/repositories/genetics/genetics_test.go` | `9e90d4abccbf911468979d4f7d7ec8541d960cb1c696b3b416974b1f435ebcfb` |
| `internal/repositories/groups/groups.go` | `69cdf1a4f04858500051377a8dfec7b89bc2c471689bbda5ccc1d82b766b205c` |
| `internal/repositories/groups/groups_test.go` | `241be3fe3232a34e9741ee21660125977a7757359086a6e018c6bf058eab781d` |
| `internal/repositories/inventory/inventory.go` | `9264736638c7e66d468f1e8b89cc251c014fcab35ef59af7e127f7e05216725a` |
| `internal/repositories/inventory/inventory_test.go` | `c99f0959cbad4e4ba9da61e8c000d27e67bd12795a16e8ab0c8999023f56c72a` |
| `internal/repositories/items/items.go` | `564a7a937e3772a68463baf7a4622a2fbc64acce43f4c20eb59849b6003645b5` |
| `internal/repositories/items/items_test.go` | `7d1ef0a77871fa1708c1c8dcb8114bebfb7f7ff36b0ca860e4991b3658c57a47` |
| `internal/repositories/leaderboard/leaderboard.go` | `649d480014bc54de82cbadcac7e0dcdd70bfc019d3bf963ac4c9b97bb9875bfc` |
| `internal/repositories/leaderboard/leaderboard_test.go` | `e62b42ae3e88f281bc3cd4fc5417057f87ca0d44d96b48eff43cd824cb3250b6` |
| `internal/repositories/monitor/monitor.go` | `b72f1114115ced43aff8f530199b5dd29a5df04d3fb31068d63dc5b121c949f3` |
| `internal/repositories/monitor/monitor_test.go` | `0a1baaa2eebc6459cea72a7baaadfa51d2000d81b038a03ce4fdc8eefd3db4c0` |
| `internal/repositories/news/helpers_test.go` | `db70a30e5f2ea20619b4e414c76a42f81569bd8a006eb2812ff11a7db5541f6b` |
| `internal/repositories/news/news.go` | `b239a07621fb612c4c7851927e0d8780d0f272bf25fa4abbebff0986acd5060d` |
| `internal/repositories/news/news_test.go` | `1d94f2df16795e90e363305c80b52597e85265879ea7129eb422ce7659a252e2` |
| `internal/repositories/pets/helpers_test.go` | `7f355d682814405a7e0163b489b525f2ac870c641d9da50f98ccfcc149ed8a7b` |
| `internal/repositories/pets/pets.go` | `d7cbaa8130832ae7fa2873a1fcc4a032a35ba8c28a1040881ce7157a512559de` |
| `internal/repositories/pets/pets_test.go` | `dfeb57cdb5ca49ceeaeede01cddaf16c8fbeee794e28c5bc4381846436b8a5df` |
| `internal/repositories/players/players.go` | `3d1af057d288516c0784f1b7c20abf031f4eb64a717b270fe9d9422042ec2a92` |
| `internal/repositories/players/players_test.go` | `3acaa8cc176bf1189217df29d78c25e0109dead2b0729d52d9c66fa482d94f62` |
| `internal/repositories/ranch/ranch.go` | `de5b69d5ebef64fbfbe32656ce2c938bf57a5b8153d167ff6c4198e80506517a` |
| `internal/repositories/ranch/ranch_test.go` | `797788b5a094fecb56fa1778b7d155fb60dac442ccf9f69bc596ec5e1fe84171` |
| `internal/repositories/repotest/repotest.go` | `a601b0968995a101a7b76ddb9d9b218a2a2b302c5970aa2bb179fd68f6d205e8` |
| `internal/repositories/ruins/helpers_test.go` | `30c3557b5a85fd1ccad49cc42cea448a3cfd932c56f9b22c22eb4d71e94a851d` |
| `internal/repositories/ruins/ruins.go` | `fb6216228ac5705e54af8800335ddcf67dcb4db8a28e39af065261baeaf9866c` |
| `internal/repositories/ruins/ruins_test.go` | `80c7cb737ada998023ea59a24f6f3ebe25de0719d975e4ff55f6d2d28c9a8210` |
| `internal/repositories/rumors/helpers_test.go` | `62b82f519c632c6742e984f60bfd20014395e035d0860e4ccaf5c072f18d25e5` |
| `internal/repositories/rumors/rumors.go` | `0c36135543fc82dad324e5aa03e06b0f6cceb1a66f99f5028f488e1aa6c27ff6` |
| `internal/repositories/rumors/rumors_test.go` | `cfde7b1848d056e72383940b55fe8f7d689eee30ba55eb15f7a104728188e58e` |
| `internal/repositories/steals/steals.go` | `97073442f679954790cd7b1da67fbedf0bab375027775d5559b7d715557e659c` |
| `internal/repositories/steals/steals_test.go` | `744eb5944b865e72c4fe9a10b9bdb3c5484e81dfa4ff34629c963f2afa84b18d` |
| `internal/repositories/titles/helpers_test.go` | `177beadee36177f47abad097d60f225d6f964274b36630711a401d14ef97964a` |
| `internal/repositories/titles/titles.go` | `36acc0704bf9b1d16a5e0d50f5903e03d9808525126114ff08e7f2a0699389f0` |
| `internal/repositories/titles/titles_test.go` | `5ab3a8f591e7dc7aea3f5df77b81ef51b6741a3821f9938fb4b67ee1122d7a08` |
| `internal/repositories/transactions/transactions.go` | `df76708abd94cc6a215a9593e54ede986ea48ed3da506015eb536ba5aec1abec` |
| `internal/repositories/transactions/transactions_test.go` | `f95ae56b518fcfbb28012ce301c4cd1519e9505ccc932bb84cc6583bfaf135fc` |
