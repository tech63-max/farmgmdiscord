package config

import "testing"

func TestParseDotEnvAndDefaults(t *testing.T) {
	env := ParseDotEnv(bom + "# 註解\nDATABASE_URL=postgresql+psycopg://farmgm:pw@127.0.0.1:5434/farmgm\nDISCORD_DEV_GUILD_ID=\nAPP_PORT=\"8010\"\nMUSIC_VOLUME=0.5\n")
	s, err := FromLookup(func(k string) string { return env[k] })
	if err != nil {
		t.Fatal(err)
	}
	if s.AppPort != 8010 || s.DiscordDevGuildID != 0 || s.BotWorkerThreads != 16 || s.BackgroundTasksRunner != "web" {
		t.Fatalf("%+v", s)
	}
	if got := s.PgxDatabaseURL(); got != "postgresql://farmgm:pw@127.0.0.1:5434/farmgm" {
		t.Fatal(got)
	}
	if s.String() == "" || contains(s.String(), "pw@") {
		t.Fatal("database url must be masked")
	}
}

func TestInvalidValues(t *testing.T) {
	env := map[string]string{"DATABASE_URL": "postgresql://x", "APP_PORT": "0", "APP_ENV": "prod"}
	if _, err := FromLookup(func(k string) string { return env[k] }); err == nil {
		t.Fatal("expected error")
	}
	if _, err := FromLookup(func(string) string { return "" }); err == nil {
		t.Fatal("DATABASE_URL required")
	}
}

func contains(s, sub string) bool {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}
