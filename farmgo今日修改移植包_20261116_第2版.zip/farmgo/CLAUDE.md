# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 專案概要

農場經營遊戲 farmgm 的 Go 版。這個專案是從 Python 專案 `farmgmdiscordb-feature-exploration-update` 逐行移植過來的，2026-11-12 起正式環境已經切換成 Go 版。程式由四個程序組成：

- 監控／管理網站（`cmd/farmgm-web`）
- 介紹網站（`cmd/farmgm-site`）
- Discord 農場 Bot（`cmd/farmgm-bot`）
- 音樂（`internal/music`，使用 Lavalink v4）

詳細進度、與 Python 版的差異、正式環境切換步驟，請看 `Go重構進度說明.md`。Go 版新增的功能列在 README 的「Go 版新增」。

## 指令

```powershell
go build ./...
go vet ./...
gofmt -l ./internal ./cmd           # Go 檔案為 UTF-8 無 BOM、LF
go test -p 1 ./...                  # -short 會縮減釣魚模擬次數
go test -p 1 -run TestName ./internal/bot/   # 單一測試
go run ./cmd/farmgm-web             # 讀工作目錄的 .env；預設 http://127.0.0.1:8000
go run ./cmd/farmgm-site            # 預設 http://127.0.0.1:24444
go run ./cmd/farmgm-bot             # 需要 DISCORD_BOT_TOKEN；開發時設 DISCORD_DEV_GUILD_ID
go run ./cmd/farmgm-hash-password   # 產生 ADMIN_PASSWORD_HASH
docker build -t farmgm-go .
```

**測試的注意事項**

- 需要資料庫的測試讀 `FARMGM_TEST_DATABASE_URL`，沒有設定時會自動略過。Discord 面板的測試幾乎都需要資料庫，所以只跑 `go test` 看到「ok」，不代表面板邏輯有被測到。
- 資料庫名稱必須以 `_test` 結尾，因為測試會清空遊戲資料表。
- 測試資料庫的 schema 要用 Python 專案的 `alembic upgrade head` 建立，步驟見 `Go重構進度說明.md` 的「建立測試資料庫」。
- 所有測試共用同一個資料庫，一律加 `-p 1`，同一時間也只能跑一個 `go test` 程序。
- 需要 Redis 的測試讀 `FARMGM_TEST_REDIS_URL`，沒有設定時略過。
- 不要對正式資料庫或 `farmgm` 專案的 Volume 執行測試。

## 架構重點

### 分層

依呼叫方向由上到下：

- **介面層**：`cmd/*` 與 `internal/web`、`internal/site`、`internal/bot`
- **服務層**：`internal/services`
- **資料層**：`internal/repositories/*`、`internal/db`、`internal/db/models`
- **純規則**：`internal/game/*` 不碰資料庫。數值與常數放在 `game/balance`，管理網站可以調整的規則設定放在 `featurecfg`、`feature_settings`。

### 服務層是一條嵌入鏈

服務一層嵌入一層：GameService → RanchService → ExplorationService → FishingService → SocialService → CommunityService → RankingService → WorldBossService → NewsService → ProgressService → AdminService。

- Bot 和管理 API 都拿 `*AdminService`，所以可以呼叫整條鏈上的任何方法。
- `MonitorService` 是另外一條唯讀查詢。
- 交易用 `inTx`；Bot 的頁面讀取用 `RunBatch`，自動機器和整頁讀取在同一筆交易完成；`Isolated` 是 SAVEPOINT。
- 死結重試由 `Retrier` 處理，Bot 端用 `Call`／`Runner`。

### 資料庫

- 和 Python 版共用同一個 PostgreSQL。Migration 由 Python 專案的 Alembic 管理，目前 head 是 0042。
- Go 只檢查 `alembic_version` 是否等於 `db.AlembicHead`，不會建表或改結構。要改 schema，得先在 Python 專案新增 Migration。
- SQL 一律參數化。欄位名稱只能是程式常數，`db.UpdateByID` 這類工具會檢查。
- 時間：
  - `timestamptz` 讀回來是 UTC，比較時用 `Equal`，不要用 `==`。
  - DATE 欄位讀回後用 `db.TaipeiDate` 轉成台灣日期，寫入時用 `db.DateParam`。
- 讀取快取回傳的切片和快取共用，呼叫端不可修改。

### 跟 Python 保持一致

- 錯誤訊息、常數、註解都照搬 Python。
- 數值運算用 `internal/numfmt`，結果才會和 Python 相同，例如 `round()` 四捨六入五成雙、`//`、`%`、千分位。
- 字串長度以字元（rune）計算。
- dict 順序有意義時，用 `*Order` 切片保留順序。
- 沒有 ORM autoflush：Python 改了屬性就會自動寫入的地方，Go 要寫明確的 UPDATE。

### 版本切換限制

只要有玩家用過 Go 版新增的內容（新果醬、菇房、木屑、種子實驗室等），就不能再切回 Python 版 Bot。

### Discord 面板（`internal/bot`）

**分層**

- 面板只依賴互動抽象層 `ui`（Embed、View、Button、Select、Modal、Interaction）。
- 正式環境由 `discordio` 轉接 discordgo；測試用 `ui/uitest` 模擬。
- 所有訊息都不 @ 任何人：`discordio/wire.go` 的 `encode()` 一律帶 `AllowedMentions` 空清單。

**一個頁面的運作**

- `pageDef{load, build}` 登記在 `pages_main.go` 的 `registerPages()`。
- `load` 在交易中讀資料，`build` 依資料組 Embed 和元件。
- 換頁用 `goTo`。
- 操作用 `act`：執行服務呼叫 → 在同一次排隊裡重讀頁面 → `refresh`／`render` 送出。
- 面板狀態放在 `Panel` struct 的欄位。同一面板的回呼由 `ui.Registry` 依序執行，不需要加鎖。

**共用工具**（在 `panel.go`、`format.go`）

- `Picker` 加上 `quantityButtons`：數量按鈕。`Short` 欄位設定時，改成一顆停用的說明按鈕，例如金幣不足。
- `p.confirm`：再按一次確認。
- `pageButtons`／`pagedOptions`：分頁。
- `money()`：金額加千分位。
- `ts()`：Discord 時間戳。footer 和選單說明不會轉換時間戳，所以不能放。
- `escapeMD()`：玩家可以自訂的文字（農場名稱、玩家名稱、伺服器名稱）放進 markdown 前，要先跳脫。

**Discord 限制**

- 一則訊息 5 列，每列 5 顆按鈕；下拉選單獨佔一列，最多 25 個選項。
- Embed 說明 4096 字、總長 6000 字；欄位內容 1024 字、最多 25 個欄位；按鈕標籤 80 字。
- 加元件要經過 `p.button`／`p.selectMenu`／`p.add`：指定的列滿了會自動換列，不會讓整頁 panic、變成「⚠️ 無法顯示」。

**版面原則**（產品擁有者的要求）

- 玩家遊玩時看的是最下方的按鈕區，所以下一步、目前狀態、操作結果要放在 Embed 最下面，緊貼按鈕。
- Discord 的顯示順序是：說明 → 欄位 → 大圖 → footer。有大圖的頁面，緊貼按鈕的只有 footer。
- 自動處理的部分：
  - `placeNotice`：把操作結果放在最後一個欄位（⚠️ 開頭的標成「請確認」），有大圖時再把第一行接到 footer。
  - `placeBackButtons`：把以「回」或「返回」開頭的按鈕，自動移到最後一列的右邊。

**面板測試**

- 測試用 `player` 輔助：`click`、`choose`、`chooseMany`、`goPage`、`options`、`labels`。
- 按鈕和選單是用標籤或 placeholder「包含」比對，所以「× 1」也會比對到「× 10」，第一個符合的會被選中。
- `makePlayer` 建立農場後會先停在農田頁，再回到總覽。建立後第一個畫面的文字存在 `p.created`。

### 網站

- `internal/web/static/monitor` 和 `internal/site/static` 是用 `go:embed` 打包的原生 HTML/CSS/JS。
- DOM 一律用 `el()` 加 textContent 建立，不使用 innerHTML。
- 管理 API：
  - 寫入要帶 `X-Farmgm-Admin: 1` 標頭，並檢查 Origin（`web/auth.go` 的 `checkCSRF`）。
  - session 存在 HttpOnly cookie。
  - 請求本文在 `web/schema.go` 驗證。
- 選用的 Redis（`internal/cachebus`）：管理網站修改目錄或規則設定並提交後，通知 Bot 等其他程序清空快取。

## 部署

- 映像內有四個執行檔，不含任何機密。
- 正式環境在 Python 專案目錄，用 `deploy/` 的四個 compose 覆寫檔（go-web、go-bot、redis）啟動。之後執行任何 `docker compose` 都要帶這四個 `-f`，否則會被換回 Python 版。完整指令見 README 的「Docker／正式環境」。
- 設定讀取：系統環境變數優先於 `.env`，空值視為未設定，未知設定會被忽略。機密欄位不會出現在 `Settings.String()`。
